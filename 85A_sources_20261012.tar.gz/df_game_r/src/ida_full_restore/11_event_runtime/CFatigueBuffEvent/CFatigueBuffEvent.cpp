#include "CFatigueBuffEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x811BBEA
// IDA_NAME: _ZN17CFatigueBuffEventC2Ev
// DEMANGLED: CFatigueBuffEvent::CFatigueBuffEvent(void)
void __cdecl CFatigueBuffEvent::CFatigueBuffEvent(CFatigueBuffEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B52248;
}

// IDA_EA: 0x811BC06
// IDA_NAME: _ZN17CFatigueBuffEventD2Ev
// DEMANGLED: CFatigueBuffEvent::~CFatigueBuffEvent()
void __cdecl CFatigueBuffEvent::~CFatigueBuffEvent(CFatigueBuffEvent *this)
{
  *(_DWORD *)this = off_8B52248;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x811BC36
// IDA_NAME: _ZN17CFatigueBuffEventD0Ev
// DEMANGLED: CFatigueBuffEvent::~CFatigueBuffEvent()
void __cdecl CFatigueBuffEvent::~CFatigueBuffEvent(CFatigueBuffEvent *this)
{
  CFatigueBuffEvent::~CFatigueBuffEvent(this);
  operator delete(this);
}

// IDA_EA: 0x811BC54
// IDA_NAME: _ZN17CFatigueBuffEvent10StartEventEv
// DEMANGLED: CFatigueBuffEvent::StartEvent(void)
int __cdecl CFatigueBuffEvent::StartEvent(CFatigueBuffEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CFatigueBuffEvent::StartEvent()", 17, 0);
  return cMyTrace::operator()((int)v3, "CFatigueBuffEvent Event Start!", v2);
}

// IDA_EA: 0x811BCA6
// IDA_NAME: _ZN17CFatigueBuffEvent10StartEventE10Word_Param
// DEMANGLED: CFatigueBuffEvent::StartEvent(Word_Param)
int __cdecl CFatigueBuffEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x811BCC0
// IDA_NAME: _ZN17CFatigueBuffEvent8EndEventEv
// DEMANGLED: CFatigueBuffEvent::EndEvent(void)
int __cdecl CFatigueBuffEvent::EndEvent(CFatigueBuffEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CFatigueBuffEvent::EndEvent()", 27, 0);
  return cMyTrace::operator()((int)v3, "CFatigueBuffEvent Event End!", v2);
}
