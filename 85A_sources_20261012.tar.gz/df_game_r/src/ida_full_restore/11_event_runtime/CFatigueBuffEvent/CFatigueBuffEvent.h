#ifndef __IDA91_CFATIGUEBUFFEVENT_H__
#define __IDA91_CFATIGUEBUFFEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CFatigueBuffEvent
// Source unit: CFatigueBuffEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4106

/* 4106 */
struct CFatigueBuffEvent;

// Exported member functions:
// 0x811BBEA	CFatigueBuffEvent::CFatigueBuffEvent(void)
// 0x811BC06	CFatigueBuffEvent::~CFatigueBuffEvent()
// 0x811BC36	CFatigueBuffEvent::~CFatigueBuffEvent()
// 0x811BC54	CFatigueBuffEvent::StartEvent(void)
// 0x811BCA6	CFatigueBuffEvent::StartEvent(Word_Param)
// 0x811BCC0	CFatigueBuffEvent::EndEvent(void)

// Function declaration index:
// DECL 0x811BBEA CFatigueBuffEvent::CFatigueBuffEvent
// DECL 0x811BC06 CFatigueBuffEvent::~CFatigueBuffEvent
// DECL 0x811BC36 CFatigueBuffEvent::~CFatigueBuffEvent
// DECL 0x811BC54 CFatigueBuffEvent::StartEvent
// DECL 0x811BCA6 CFatigueBuffEvent::StartEvent
// DECL 0x811BCC0 CFatigueBuffEvent::EndEvent

#endif  // __IDA91_CFATIGUEBUFFEVENT_H__
