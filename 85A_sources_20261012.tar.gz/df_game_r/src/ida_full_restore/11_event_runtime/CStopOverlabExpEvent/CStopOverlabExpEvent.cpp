#include "CStopOverlabExpEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81177A0
// IDA_NAME: _ZN20CStopOverlabExpEventC2Ev
// DEMANGLED: CStopOverlabExpEvent::CStopOverlabExpEvent(void)
void __cdecl CStopOverlabExpEvent::CStopOverlabExpEvent(CStopOverlabExpEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B4F228;
}

// IDA_EA: 0x81177BC
// IDA_NAME: _ZN20CStopOverlabExpEventD2Ev
// DEMANGLED: CStopOverlabExpEvent::~CStopOverlabExpEvent()
void __cdecl CStopOverlabExpEvent::~CStopOverlabExpEvent(CStopOverlabExpEvent *this)
{
  *(_DWORD *)this = off_8B4F228;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x81177EC
// IDA_NAME: _ZN20CStopOverlabExpEventD0Ev
// DEMANGLED: CStopOverlabExpEvent::~CStopOverlabExpEvent()
void __cdecl CStopOverlabExpEvent::~CStopOverlabExpEvent(CStopOverlabExpEvent *this)
{
  CStopOverlabExpEvent::~CStopOverlabExpEvent(this);
  operator delete(this);
}

// IDA_EA: 0x811780A
// IDA_NAME: _ZN20CStopOverlabExpEvent10StartEventEv
// DEMANGLED: CStopOverlabExpEvent::StartEvent(void)
int __cdecl CStopOverlabExpEvent::StartEvent(CStopOverlabExpEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CStopOverlabExpEvent::StartEvent()", 21, 0);
  return cMyTrace::operator()((int)v3, "CStopOverlabExpEvent Event Start!", v2);
}

// IDA_EA: 0x811785C
// IDA_NAME: _ZN20CStopOverlabExpEvent10StartEventE10Word_Param
// DEMANGLED: CStopOverlabExpEvent::StartEvent(Word_Param)
int __cdecl CStopOverlabExpEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x8117876
// IDA_NAME: _ZN20CStopOverlabExpEvent8EndEventEv
// DEMANGLED: CStopOverlabExpEvent::EndEvent(void)
int __cdecl CStopOverlabExpEvent::EndEvent(CStopOverlabExpEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CStopOverlabExpEvent::EndEvent()", 31, 0);
  return cMyTrace::operator()((int)v3, "CStopOverlabExpEvent Event End!", v2);
}
