#ifndef __IDA91_CSTOPOVERLABEXPEVENT_H__
#define __IDA91_CSTOPOVERLABEXPEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CStopOverlabExpEvent
// Source unit: CStopOverlabExpEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4103

/* 4103 */
struct CStopOverlabExpEvent;

// Exported member functions:
// 0x81177A0	CStopOverlabExpEvent::CStopOverlabExpEvent(void)
// 0x81177BC	CStopOverlabExpEvent::~CStopOverlabExpEvent()
// 0x81177EC	CStopOverlabExpEvent::~CStopOverlabExpEvent()
// 0x811780A	CStopOverlabExpEvent::StartEvent(void)
// 0x811785C	CStopOverlabExpEvent::StartEvent(Word_Param)
// 0x8117876	CStopOverlabExpEvent::EndEvent(void)

// Function declaration index:
// DECL 0x81177A0 CStopOverlabExpEvent::CStopOverlabExpEvent
// DECL 0x81177BC CStopOverlabExpEvent::~CStopOverlabExpEvent
// DECL 0x81177EC CStopOverlabExpEvent::~CStopOverlabExpEvent
// DECL 0x811780A CStopOverlabExpEvent::StartEvent
// DECL 0x811785C CStopOverlabExpEvent::StartEvent
// DECL 0x8117876 CStopOverlabExpEvent::EndEvent

#endif  // __IDA91_CSTOPOVERLABEXPEVENT_H__
