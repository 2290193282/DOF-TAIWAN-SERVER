#ifndef __IDA91_BLUEMARBLETILESCRIPT_H__
#define __IDA91_BLUEMARBLETILESCRIPT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: BlueMarbleTileScript
// Source unit: BlueMarbleTileScript
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3861

/* 3861 */
struct BlueMarbleTileScript;

// Exported member functions:
// 0x88D5068	BlueMarbleTileScript::BlueMarbleTileScript(void)
// 0x88D507C	BlueMarbleTileScript::clear(void)
// 0x88D509C	BlueMarbleTileScript::importScript(char const*)
// 0x88D520A	BlueMarbleTileScript::toType(std::string)

// Function declaration index:
// DECL 0x88D5068 BlueMarbleTileScript::BlueMarbleTileScript
// DECL 0x88D507C BlueMarbleTileScript::clear
// DECL 0x88D509C BlueMarbleTileScript::importScript
// DECL 0x88D520A BlueMarbleTileScript::toType

#endif  // __IDA91_BLUEMARBLETILESCRIPT_H__
