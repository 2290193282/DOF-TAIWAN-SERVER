#include "BlueMarbleTileScript.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x88D5068
// IDA_NAME: _ZN20BlueMarbleTileScriptC2Ev
// DEMANGLED: BlueMarbleTileScript::BlueMarbleTileScript(void)
void __cdecl BlueMarbleTileScript::BlueMarbleTileScript(BlueMarbleTileScript *this)
{
  BlueMarbleTileScript::clear(this);
}

// IDA_EA: 0x88D507C
// IDA_NAME: _ZN20BlueMarbleTileScript5clearEv
// DEMANGLED: BlueMarbleTileScript::clear(void)
BlueMarbleTileScript *__cdecl BlueMarbleTileScript::clear(BlueMarbleTileScript *this)
{
  BlueMarbleTileScript *this_1; // eax

  *(_DWORD *)this = 0;
  *((_BYTE *)this + 4) = 0;
  this_1 = this;
  *((_DWORD *)this + 2) = 0;
  return this_1;
}

// IDA_EA: 0x88D509C
// IDA_NAME: _ZN20BlueMarbleTileScript12importScriptEPKc
// DEMANGLED: BlueMarbleTileScript::importScript(char const*)
int __cdecl BlueMarbleTileScript::importScript(BlueMarbleTileScript *this, TCHAR *filename)
{
  int v2; // ebx
  int v4; // [esp+10h] [ebp-18h] BYREF
  std::string v5; // [esp+14h] [ebp-14h] BYREF
  std::string v6; // [esp+18h] [ebp-10h] BYREF
  std::string v7; // [esp+1Ch] [ebp-Ch] BYREF

  if ( !loadRDARScriptFile((TCHAR *)&dir__13, filename) )
    return 0;
  std::string::string(&v6);
  std::string::string(&v5);
  v4 = 0;
  while ( (unsigned __int8)ScanType(&v6, 1) == 1 )
  {
    if ( std::operator==<char>(&v6, "[type]") )
    {
      ScanStr(&v5);
      std::string::string(&v7, &v5);
      *(_DWORD *)this = BlueMarbleTileScript::toType(this, (std::string)&v7);
      std::string::~string(&v7);
    }
    else if ( std::operator==<char>(&v6, "[enter dungeon]") )
    {
      ScanInt(&v4);
      if ( v4 )
        *((_BYTE *)this + 4) = 1;
    }
  }
  v2 = 1;
  std::string::~string(&v5);
  std::string::~string(&v6);
  return v2;
}

// IDA_EA: 0x88D520A
// IDA_NAME: _ZN20BlueMarbleTileScript6toTypeESs
// DEMANGLED: BlueMarbleTileScript::toType(std::string)
int __cdecl BlueMarbleTileScript::toType(BlueMarbleTileScript *this, std::string a2)
{
  if ( std::operator==<char>((std::string *)a2._M_dataplus.__vftable, "empty") )
    return 0;
  if ( std::operator==<char>((std::string *)a2._M_dataplus.__vftable, "start") )
    return 1;
  if ( std::operator==<char>((std::string *)a2._M_dataplus.__vftable, "end") )
    return 2;
  if ( std::operator==<char>((std::string *)a2._M_dataplus.__vftable, "gold") )
    return 3;
  if ( std::operator==<char>((std::string *)a2._M_dataplus.__vftable, "exp") )
    return 4;
  if ( std::operator==<char>((std::string *)a2._M_dataplus.__vftable, "drop") )
    return 5;
  if ( std::operator==<char>((std::string *)a2._M_dataplus.__vftable, "item") )
    return 6;
  if ( std::operator==<char>((std::string *)a2._M_dataplus.__vftable, "unique item") )
    return 7;
  if ( std::operator==<char>((std::string *)a2._M_dataplus.__vftable, "boss unique") )
    return 8;
  if ( std::operator==<char>((std::string *)a2._M_dataplus.__vftable, "move") )
    return 9;
  if ( std::operator==<char>((std::string *)a2._M_dataplus.__vftable, "jump") )
    return 10;
  if ( std::operator==<char>((std::string *)a2._M_dataplus.__vftable, "gold goblin") )
    return 11;
  if ( std::operator==<char>((std::string *)a2._M_dataplus.__vftable, "rope") )
    return 12;
  if ( std::operator==<char>((std::string *)a2._M_dataplus.__vftable, "kick") )
    return 13;
  return 0;
}
