#include "LevelUpRewardScript.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x89861DA
// IDA_NAME: _ZN19LevelUpRewardScriptC2Ev
// DEMANGLED: LevelUpRewardScript::LevelUpRewardScript(void)
void __cdecl LevelUpRewardScript::LevelUpRewardScript(std::string *this)
{
  InGameEventScript::InGameEventScript(this);
  std::string::string(this + 3);
  std::map<int,Condition_LevelUp>::map(&this[4]);
  Action_SendMail::Action_SendMail((Action_SendMail *)&this[10]);
}
