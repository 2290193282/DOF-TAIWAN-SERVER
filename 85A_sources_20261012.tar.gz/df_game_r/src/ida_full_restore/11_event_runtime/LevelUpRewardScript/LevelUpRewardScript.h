#ifndef __IDA91_LEVELUPREWARDSCRIPT_H__
#define __IDA91_LEVELUPREWARDSCRIPT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: LevelUpRewardScript
// Source unit: LevelUpRewardScript
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4836

/* 4836 */
struct LevelUpRewardScript;

// Exported member functions:
// 0x89861DA	LevelUpRewardScript::LevelUpRewardScript(void)

// Function declaration index:
// DECL 0x89861DA LevelUpRewardScript::LevelUpRewardScript

#endif  // __IDA91_LEVELUPREWARDSCRIPT_H__
