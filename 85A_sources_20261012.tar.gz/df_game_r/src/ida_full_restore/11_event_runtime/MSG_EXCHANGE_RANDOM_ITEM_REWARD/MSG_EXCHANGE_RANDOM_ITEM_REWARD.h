#ifndef __IDA91_MSG_EXCHANGE_RANDOM_ITEM_REWARD_H__
#define __IDA91_MSG_EXCHANGE_RANDOM_ITEM_REWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: MSG_EXCHANGE_RANDOM_ITEM_REWARD
// Source unit: MSG_EXCHANGE_RANDOM_ITEM_REWARD
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 2074

/* 2074 */
struct MSG_EXCHANGE_RANDOM_ITEM_REWARD;

// Exported member functions:
// 0x824CBA6	MSG_EXCHANGE_RANDOM_ITEM_REWARD::MSG_EXCHANGE_RANDOM_ITEM_REWARD(void)
// 0x824CBC8	MSG_EXCHANGE_RANDOM_ITEM_REWARD::~MSG_EXCHANGE_RANDOM_ITEM_REWARD()

// Function declaration index:
// DECL 0x824CBA6 MSG_EXCHANGE_RANDOM_ITEM_REWARD::MSG_EXCHANGE_RANDOM_ITEM_REWARD
// DECL 0x824CBC8 MSG_EXCHANGE_RANDOM_ITEM_REWARD::~MSG_EXCHANGE_RANDOM_ITEM_REWARD

#endif  // __IDA91_MSG_EXCHANGE_RANDOM_ITEM_REWARD_H__
