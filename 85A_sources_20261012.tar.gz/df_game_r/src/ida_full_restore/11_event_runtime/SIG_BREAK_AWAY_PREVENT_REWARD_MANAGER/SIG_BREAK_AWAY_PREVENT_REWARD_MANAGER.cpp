#include "SIG_BREAK_AWAY_PREVENT_REWARD_MANAGER.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x831D264
// IDA_NAME: _ZN37SIG_BREAK_AWAY_PREVENT_REWARD_MANAGERC2Ev
// DEMANGLED: SIG_BREAK_AWAY_PREVENT_REWARD_MANAGER::SIG_BREAK_AWAY_PREVENT_REWARD_MANAGER(void)
void __cdecl SIG_BREAK_AWAY_PREVENT_REWARD_MANAGER::SIG_BREAK_AWAY_PREVENT_REWARD_MANAGER(
        SIG_BREAK_AWAY_PREVENT_REWARD_MANAGER *this)
{
  *(_BYTE *)this = 0;
  *((_BYTE *)this + 1) = 0;
  *((_BYTE *)this + 2) = 0;
  *((_DWORD *)this + 1) = 0;
  *((_DWORD *)this + 2) = 0;
  *((_DWORD *)this + 3) = 0;
  *((_DWORD *)this + 4) = 0;
  *((_DWORD *)this + 5) = 0;
}
