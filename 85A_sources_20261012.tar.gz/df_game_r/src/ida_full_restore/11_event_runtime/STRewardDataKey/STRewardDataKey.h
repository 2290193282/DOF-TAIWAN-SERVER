#ifndef __IDA91_STREWARDDATAKEY_H__
#define __IDA91_STREWARDDATAKEY_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: STRewardDataKey
// Source unit: STRewardDataKey
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2325

/* 2325 */
struct STRewardDataKey;

// Exported member functions:
// 0x831D338	STRewardDataKey::operator<(STRewardDataKey const&)const
// 0x831D3AE	STRewardDataKey::STRewardDataKey(void)

// Function declaration index:
// DECL 0x831D338 STRewardDataKey::operator<
// DECL 0x831D3AE STRewardDataKey::STRewardDataKey

#endif  // __IDA91_STREWARDDATAKEY_H__
