#include "STRewardDataKey.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x831D338
// IDA_NAME: _ZNK15STRewardDataKeyltERKS_
// DEMANGLED: STRewardDataKey::operator<(STRewardDataKey const&)const
_BOOL4 __cdecl STRewardDataKey::operator<(_BYTE *a1, _BYTE *a2)
{
  if ( *a1 < *a2 )
    return 1;
  if ( *a1 != *a2 )
    return 0;
  if ( a1[1] < a2[1] )
    return 1;
  return a1[1] == a2[1] && a1[2] < a2[2];
}

// IDA_EA: 0x831D3AE
// IDA_NAME: _ZN15STRewardDataKeyC2Ev
// DEMANGLED: STRewardDataKey::STRewardDataKey(void)
void __cdecl STRewardDataKey::STRewardDataKey(STRewardDataKey *this)
{
  *(_BYTE *)this = 0;
  *((_BYTE *)this + 1) = 0;
  *((_BYTE *)this + 2) = 0;
}
