#include "STRewardData.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x831D3C8
// IDA_NAME: _ZN12STRewardDataC2Ev
// DEMANGLED: STRewardData::STRewardData(void)
void __cdecl STRewardData::STRewardData(STRewardData *this)
{
  *(_DWORD *)this = 0;
  *((_DWORD *)this + 1) = 0;
  *((_DWORD *)this + 2) = 0;
  *((_DWORD *)this + 3) = 0;
  *((_DWORD *)this + 4) = 0;
}
