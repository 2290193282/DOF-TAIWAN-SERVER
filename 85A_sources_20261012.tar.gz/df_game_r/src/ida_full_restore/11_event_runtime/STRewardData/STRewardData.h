#ifndef __IDA91_STREWARDDATA_H__
#define __IDA91_STREWARDDATA_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: STRewardData
// Source unit: STRewardData
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2326

/* 2326 */
struct STRewardData;

// Exported member functions:
// 0x831D3C8	STRewardData::STRewardData(void)

// Function declaration index:
// DECL 0x831D3C8 STRewardData::STRewardData

#endif  // __IDA91_STREWARDDATA_H__
