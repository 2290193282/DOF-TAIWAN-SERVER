#ifndef __IDA91_LEVELUPSUPPORT2NDEVENTMANGER_H__
#define __IDA91_LEVELUPSUPPORT2NDEVENTMANGER_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: LevelupSupport2ndEventManger
// Source unit: LevelupSupport2ndEventManger
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 4712

/* 4712 */
struct LevelupSupport2ndEventManger;

// Exported member functions:
// 0x814778E	LevelupSupport2ndEventManger::LevelupSupport2ndEventManger(void)
// 0x81477C4	LevelupSupport2ndEventManger::~LevelupSupport2ndEventManger()
// 0x81477E4	LevelupSupport2ndEventManger::Load(void)
// 0x8147864	LevelupSupport2ndEventManger::Destroy(void)
// 0x8147880	LevelupSupport2ndEventManger::Process(CUser *)

// Function declaration index:
// DECL 0x814778E LevelupSupport2ndEventManger::LevelupSupport2ndEventManger
// DECL 0x81477C4 LevelupSupport2ndEventManger::~LevelupSupport2ndEventManger
// DECL 0x81477E4 LevelupSupport2ndEventManger::Load
// DECL 0x8147864 LevelupSupport2ndEventManger::Destroy
// DECL 0x8147880 LevelupSupport2ndEventManger::Process

#endif  // __IDA91_LEVELUPSUPPORT2NDEVENTMANGER_H__
