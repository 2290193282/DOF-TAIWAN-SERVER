#include "LevelupSupport2ndEventManger.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x814778E
// IDA_NAME: _ZN28LevelupSupport2ndEventMangerC2Ev
// DEMANGLED: LevelupSupport2ndEventManger::LevelupSupport2ndEventManger(void)
void __cdecl LevelupSupport2ndEventManger::LevelupSupport2ndEventManger(LevelupSupport2ndEventManger *this)
{
  ARAD::Singleton<LevelupSupport2ndEventManger>::Singleton(this);
  ARAD::ScriptInterface::ScriptInterface(this);
  *(_DWORD *)this = off_8B73C78;
  LevelupSupport2ndScript::LevelupSupport2ndScript((LevelupSupport2ndEventManger *)((char *)this + 4));
}

// IDA_EA: 0x81477C4
// IDA_NAME: _ZN28LevelupSupport2ndEventMangerD2Ev
// DEMANGLED: LevelupSupport2ndEventManger::~LevelupSupport2ndEventManger()
void __cdecl LevelupSupport2ndEventManger::~LevelupSupport2ndEventManger(_DWORD *a1)
{
  *a1 = off_8B73C78;
  LevelupSupport2ndScript::~LevelupSupport2ndScript((LevelupSupport2ndScript *)(a1 + 1));
}

// IDA_EA: 0x81477E4
// IDA_NAME: _ZN28LevelupSupport2ndEventManger4LoadEv
// DEMANGLED: LevelupSupport2ndEventManger::Load(void)
_BOOL4 __cdecl LevelupSupport2ndEventManger::Load(LevelupSupport2ndEventManger *this)
{
  char v2; // [esp+8h] [ebp-30h]
  int v3[6]; // [esp+20h] [ebp-18h] BYREF

  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual bool LevelupSupport2ndEventManger::Load()", 183, 9, 1, 0);
  cMyTrace::operator()((int)v3, "\t- Loading Level Up Support 2nd Event script - ", v2);
  std::map<int,std::vector<LevelupSupport2ndScript::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<LevelupSupport2ndScript::ItemInfo> *>>>::clear((char *)this + 8);
  return LevelupSupport2ndScript::loadScript((LevelupSupport2ndEventManger *)((char *)this + 4)) == 0;
}

// IDA_EA: 0x8147864
// IDA_NAME: _ZN28LevelupSupport2ndEventManger7DestroyEv
// DEMANGLED: LevelupSupport2ndEventManger::Destroy(void)
int __cdecl LevelupSupport2ndEventManger::Destroy(LevelupSupport2ndEventManger *this)
{
  LevelupSupport2ndScript::clearScript((LevelupSupport2ndEventManger *)((char *)this + 4));
  return 1;
}

// IDA_EA: 0x8147880
// IDA_NAME: _ZN28LevelupSupport2ndEventManger7ProcessEP5CUser
// DEMANGLED: LevelupSupport2ndEventManger::Process(CUser *)
void __cdecl LevelupSupport2ndEventManger::Process(std::string *this, CUser *a2)
{
  ustd::string::_Alloc_hider_vtbl *charac_jobEv; // ebx
  char *pszSrc; // eax
  char *pszSrc_1; // eax
  unsigned int n2; // ebx
  CItemList **v6; // eax
  int v7; // eax
  int ServerGroup; // ebx
  size_t v9; // esi
  int CurCharacNoEv; // eax
  _BYTE v11[2]; // [esp+3Fh] [ebp-69h] BYREF
  int indexEv; // [esp+41h] [ebp-67h]
  _DWORD v13[2]; // [esp+7Ch] [ebp-2Ch] BYREF
  int v14; // [esp+84h] [ebp-24h] BYREF
  _DWORD *v15; // [esp+88h] [ebp-20h]
  char *src; // [esp+8Ch] [ebp-1Ch]
  char *s; // [esp+90h] [ebp-18h]
  unsigned int v18; // [esp+94h] [ebp-14h]
  unsigned int v19; // [esp+98h] [ebp-10h]
  CItem *item; // [esp+9Ch] [ebp-Ch]

  if ( a2 )
  {
    charac_jobEv = this[1]._M_dataplus.__vftable;
    if ( charac_jobEv == (ustd::string::_Alloc_hider_vtbl *)CUserCharacInfo::get_charac_job(a2) )
    {
      v13[1] = CUserCharacInfo::get_charac_level(a2);
      std::map<int,std::vector<LevelupSupport2ndScript::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<LevelupSupport2ndScript::ItemInfo> *>>>::find((int)v13);
      std::map<int,std::vector<LevelupSupport2ndScript::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<LevelupSupport2ndScript::ItemInfo> *>>>::end((int)&v14);
      if ( !std::_Rb_tree_iterator<std::pair<int const,std::vector<LevelupSupport2ndScript::ItemInfo> *>>::operator==(
              v13,
              &v14) )
      {
        v15 = *(_DWORD **)(std::_Rb_tree_iterator<std::pair<int const,std::vector<LevelupSupport2ndScript::ItemInfo> *>>::operator->(v13)
                         + 4);
        if ( v15 )
        {
          pszSrc = (char *)std::string::c_str(this + 8);
          src = (char *)RDARScriptStringManager::findString(
                          (RDARScriptStringManager *)&g_scriptStringManager_,
                          (char *)4,
                          pszSrc,
                          0);
          pszSrc_1 = (char *)std::string::c_str(this + 9);
          s = (char *)RDARScriptStringManager::findString(
                        (RDARScriptStringManager *)&g_scriptStringManager_,
                        (char *)4,
                        pszSrc_1,
                        0);
          v18 = 0;
          v19 = std::vector<LevelupSupport2ndScript::ItemInfo>::size(v15);
          while ( v18 < v19 )
          {
            n2 = *(_DWORD *)std::vector<LevelupSupport2ndScript::ItemInfo>::at((int)v15, v18);
            v6 = (CItemList **)G_CDataManager();
            item = (CItem *)CDataManager::find_item(v6, n2);
            if ( item )
            {
              Inven_Item::Inven_Item((Inven_Item *)v11);
              indexEv = CItem::get_index(item);
              (*(void (__cdecl **)(CItem *, _BYTE *))(*(_DWORD *)item + 8))(item, v11);
              v7 = std::vector<LevelupSupport2ndScript::ItemInfo>::at((int)v15, v18);
              Inven_Item::set_add_info((Inven_Item *)v11, *(__int16 *)(v7 + 4));
              ServerGroup = CUser::GetServerGroup(a2);
              v9 = strlen(s);
              CurCharacNoEv = CUserCharacInfo::getCurCharacNo(a2);
              WongWork::CMailBoxHelper::ReqDBSendNewSystemMail(
                src,
                (Inven_Item *)v11,
                0,
                CurCharacNoEv,
                s,
                v9,
                15,
                ServerGroup,
                0,
                0);
            }
            ++v18;
          }
        }
      }
    }
  }
}
