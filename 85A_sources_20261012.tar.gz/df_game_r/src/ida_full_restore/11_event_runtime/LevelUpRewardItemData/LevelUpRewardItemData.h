#ifndef __IDA91_LEVELUPREWARDITEMDATA_H__
#define __IDA91_LEVELUPREWARDITEMDATA_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: LevelUpRewardItemData
// Source unit: LevelUpRewardItemData
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 1475

/* 1475 */
struct LevelUpRewardItemData;

// Exported member functions:
// 0x81B88BC	LevelUpRewardItemData::LevelUpRewardItemData(void)
// 0x81B88D0	LevelUpRewardItemData::clear(void)
// 0x81B967E	LevelUpRewardItemData::~LevelUpRewardItemData()

// Function declaration index:
// DECL 0x81B88BC LevelUpRewardItemData::LevelUpRewardItemData
// DECL 0x81B88D0 LevelUpRewardItemData::clear
// DECL 0x81B967E LevelUpRewardItemData::~LevelUpRewardItemData

#endif  // __IDA91_LEVELUPREWARDITEMDATA_H__
