#include "LevelUpRewardItemData.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81B88BC
// IDA_NAME: _ZN21LevelUpRewardItemDataC2Ev
// DEMANGLED: LevelUpRewardItemData::LevelUpRewardItemData(void)
void __cdecl LevelUpRewardItemData::LevelUpRewardItemData(LevelUpRewardItemData *this)
{
  LevelUpRewardItemData::clear(this);
}

// IDA_EA: 0x81B88D0
// IDA_NAME: _ZN21LevelUpRewardItemData5clearEv
// DEMANGLED: LevelUpRewardItemData::clear(void)
LevelUpRewardItemData *__cdecl LevelUpRewardItemData::clear(LevelUpRewardItemData *this)
{
  LevelUpRewardItemData *this_1; // eax

  *(_DWORD *)this = -1;
  this_1 = this;
  *((_DWORD *)this + 1) = 0;
  return this_1;
}

// IDA_EA: 0x81B967E
// IDA_NAME: _ZN21LevelUpRewardItemDataD2Ev
// DEMANGLED: LevelUpRewardItemData::~LevelUpRewardItemData()
void LevelUpRewardItemData::~LevelUpRewardItemData()
{
  ;
}
