#ifndef __IDA91_DB_INSERTEVENTSTAGELOG_H__
#define __IDA91_DB_INSERTEVENTSTAGELOG_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_InsertEventStageLog
// Source unit: DB_InsertEventStageLog
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2736

/* 2736 */
struct DB_InsertEventStageLog;

// Exported member functions:
// 0x8449144	DB_InsertEventStageLog::dispatch(int,int,Stream *)
// 0x844920E	DB_InsertEventStageLog::makeRequest(SIG_EVENT_STAGE_LOG &)
// 0x844FF4A	DB_InsertEventStageLog::DB_InsertEventStageLog(void)
// 0x845AEBE	DB_InsertEventStageLog::~DB_InsertEventStageLog()
// 0x845AEEE	DB_InsertEventStageLog::~DB_InsertEventStageLog()

// Function declaration index:
// DECL 0x8449144 DB_InsertEventStageLog::dispatch
// DECL 0x844920E DB_InsertEventStageLog::makeRequest
// DECL 0x844FF4A DB_InsertEventStageLog::DB_InsertEventStageLog
// DECL 0x845AEBE DB_InsertEventStageLog::~DB_InsertEventStageLog
// DECL 0x845AEEE DB_InsertEventStageLog::~DB_InsertEventStageLog

#endif  // __IDA91_DB_INSERTEVENTSTAGELOG_H__
