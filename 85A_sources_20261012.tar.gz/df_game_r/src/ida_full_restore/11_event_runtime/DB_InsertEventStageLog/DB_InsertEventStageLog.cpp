#include "DB_InsertEventStageLog.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8449144
// IDA_NAME: _ZN22DB_InsertEventStageLog8dispatchEiiP6Stream
// DEMANGLED: DB_InsertEventStageLog::dispatch(int,int,Stream *)
_BOOL4 __cdecl DB_InsertEventStageLog::dispatch(DB_InsertEventStageLog *this, int a2, int a3, Stream *a4)
{
  int v4; // edi
  int v5; // esi
  int v6; // ebx
  const char *v7; // eax
  MySQL *DBHandle; // [esp+38h] [ebp-20h]
  int Out; // [esp+3Ch] [ebp-1Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 9, 0);
  Out = Stream::GetOutBuffer<SIG_EVENT_STAGE_LOG>(a4);
  v4 = *(_DWORD *)(Out + 16);
  v5 = *(_DWORD *)(Out + 12);
  v6 = *(_DWORD *)(Out + 8);
  v7 = (const char *)NumberToString(*(_DWORD *)(Out + 4), 0);
  MySQL::set_query(
    DBHandle,
    "inSert into dnf_event_accept_list(event_id,m_id,charac_no,server_info,occ_date,stage,stage_result) values(%d,%s,%d,%"
    "d,now(),%d,'%s')",
    *(_DWORD *)Out,
    v7,
    v6,
    v5,
    v4,
    (const char *)(Out + 20));
  return (unsigned __int8)MySQL::exec(DBHandle, 1) == 1;
}

// IDA_EA: 0x844920E
// IDA_NAME: _ZN22DB_InsertEventStageLog11makeRequestER19SIG_EVENT_STAGE_LOG
// DEMANGLED: DB_InsertEventStageLog::makeRequest(SIG_EVENT_STAGE_LOG &)
void __cdecl DB_InsertEventStageLog::makeRequest(DB_InsertEventStageLog *this)
{
  Stream *v1; // eax
  Stream **v2; // eax
  Stream **v3; // eax
  int v4; // eax
  _BYTE v5[8]; // [esp+14h] [ebp-14h] BYREF
  void *dest; // [esp+1Ch] [ebp-Ch]

  v1 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 47071);
  CStreamGuard::CStreamGuard((CStreamGuard *)v5, v1, 1);
  v2 = (Stream **)CStreamGuard::operator*((int)v5);
  CStreamGuard::operator<<(v2, 51);
  v3 = (Stream **)CStreamGuard::operator*((int)v5);
  CStreamGuard::operator<<(v3, -1);
  v4 = CStreamGuard::operator->((int)v5);
  dest = (void *)CStreamGuard::GetInBuffer<SIG_EVENT_STAGE_LOG>(v4);
  memcpy(dest, this, 0x78u);
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v5);
  CStreamGuard::~CStreamGuard((CStreamGuard *)v5);
}

// IDA_EA: 0x844FF4A
// IDA_NAME: _ZN22DB_InsertEventStageLogC2Ev
// DEMANGLED: DB_InsertEventStageLog::DB_InsertEventStageLog(void)
void __cdecl DB_InsertEventStageLog::DB_InsertEventStageLog(DB_InsertEventStageLog *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5E130;
}

// IDA_EA: 0x845AEBE
// IDA_NAME: _ZN22DB_InsertEventStageLogD2Ev
// DEMANGLED: DB_InsertEventStageLog::~DB_InsertEventStageLog()
void __cdecl DB_InsertEventStageLog::~DB_InsertEventStageLog(DB_InsertEventStageLog *this)
{
  *(_DWORD *)this = &off_8C5E130;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845AEEE
// IDA_NAME: _ZN22DB_InsertEventStageLogD0Ev
// DEMANGLED: DB_InsertEventStageLog::~DB_InsertEventStageLog()
void __cdecl DB_InsertEventStageLog::~DB_InsertEventStageLog(DB_InsertEventStageLog *this)
{
  DB_InsertEventStageLog::~DB_InsertEventStageLog(this);
  operator delete(this);
}
