#ifndef __IDA91_CMAXFATIGUEFACTOREVENT_H__
#define __IDA91_CMAXFATIGUEFACTOREVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CMaxFatigueFactorEvent
// Source unit: CMaxFatigueFactorEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1234

/* 1234 */
struct CMaxFatigueFactorEvent;

// Exported member functions:
// 0x812CE54	CMaxFatigueFactorEvent::GetMaxFatigueFactor(void)
// 0x81B2718	CMaxFatigueFactorEvent::CMaxFatigueFactorEvent(void)
// 0x81B273E	CMaxFatigueFactorEvent::~CMaxFatigueFactorEvent()
// 0x81B276E	CMaxFatigueFactorEvent::~CMaxFatigueFactorEvent()
// 0x81B278C	CMaxFatigueFactorEvent::StartEvent(void)
// 0x81B27E8	CMaxFatigueFactorEvent::StartEvent(Word_Param)
// 0x81B284C	CMaxFatigueFactorEvent::EndEvent(void)

// Function declaration index:
// DECL 0x812CE54 CMaxFatigueFactorEvent::GetMaxFatigueFactor
// DECL 0x81B2718 CMaxFatigueFactorEvent::CMaxFatigueFactorEvent
// DECL 0x81B273E CMaxFatigueFactorEvent::~CMaxFatigueFactorEvent
// DECL 0x81B276E CMaxFatigueFactorEvent::~CMaxFatigueFactorEvent
// DECL 0x81B278C CMaxFatigueFactorEvent::StartEvent
// DECL 0x81B27E8 CMaxFatigueFactorEvent::StartEvent
// DECL 0x81B284C CMaxFatigueFactorEvent::EndEvent

#endif  // __IDA91_CMAXFATIGUEFACTOREVENT_H__
