#include "CMaxFatigueFactorEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x812CE54
// IDA_NAME: _ZN22CMaxFatigueFactorEvent19GetMaxFatigueFactorEv
// DEMANGLED: CMaxFatigueFactorEvent::GetMaxFatigueFactor(void)
int __cdecl CMaxFatigueFactorEvent::GetMaxFatigueFactor(CMaxFatigueFactorEvent *this)
{
  return *((_DWORD *)this + 3);
}

// IDA_EA: 0x81B2718
// IDA_NAME: _ZN22CMaxFatigueFactorEventC2Ev
// DEMANGLED: CMaxFatigueFactorEvent::CMaxFatigueFactorEvent(void)
void __cdecl CMaxFatigueFactorEvent::CMaxFatigueFactorEvent(CMaxFatigueFactorEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8BB7408;
  *((_DWORD *)this + 3) = 100;
}

// IDA_EA: 0x81B273E
// IDA_NAME: _ZN22CMaxFatigueFactorEventD2Ev
// DEMANGLED: CMaxFatigueFactorEvent::~CMaxFatigueFactorEvent()
void __cdecl CMaxFatigueFactorEvent::~CMaxFatigueFactorEvent(CMaxFatigueFactorEvent *this)
{
  *(_DWORD *)this = off_8BB7408;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x81B276E
// IDA_NAME: _ZN22CMaxFatigueFactorEventD0Ev
// DEMANGLED: CMaxFatigueFactorEvent::~CMaxFatigueFactorEvent()
void __cdecl CMaxFatigueFactorEvent::~CMaxFatigueFactorEvent(CMaxFatigueFactorEvent *this)
{
  CMaxFatigueFactorEvent::~CMaxFatigueFactorEvent(this);
  operator delete(this);
}

// IDA_EA: 0x81B278C
// IDA_NAME: _ZN22CMaxFatigueFactorEvent10StartEventEv
// DEMANGLED: CMaxFatigueFactorEvent::StartEvent(void)
int __cdecl CMaxFatigueFactorEvent::StartEvent(CMaxFatigueFactorEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  *((_DWORD *)this + 3) = 100;
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 22, 0);
  return cMyTrace::operator()((int)v3, "Max Fatigue Factor Event Start!", v2);
}

// IDA_EA: 0x81B27E8
// IDA_NAME: _ZN22CMaxFatigueFactorEvent10StartEventE10Word_Param
// DEMANGLED: CMaxFatigueFactorEvent::StartEvent(Word_Param)
bool __cdecl CMaxFatigueFactorEvent::StartEvent(CEventBase *a1, unsigned __int16 a2)
{
  char v3; // [esp+8h] [ebp-20h]
  int v4[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  *((_DWORD *)a1 + 3) = a2;
  cMyTrace::cMyTrace((cMyTrace *)v4, "StartEvent", 30, 0);
  cMyTrace::operator()((int)v4, "Max Fatigue Factor Event Start!", v3);
  return CLocalChina_User::SendFatigueEvent();
}

// IDA_EA: 0x81B284C
// IDA_NAME: _ZN22CMaxFatigueFactorEvent8EndEventEv
// DEMANGLED: CMaxFatigueFactorEvent::EndEvent(void)
bool __cdecl CMaxFatigueFactorEvent::EndEvent(CMaxFatigueFactorEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  *((_DWORD *)this + 3) = 100;
  cMyTrace::cMyTrace((cMyTrace *)v3, "EndEvent", 42, 0);
  cMyTrace::operator()((int)v3, "Max Fatigue Factor Event End!", v2);
  return CLocalChina_User::SendFatigueEvent();
}
