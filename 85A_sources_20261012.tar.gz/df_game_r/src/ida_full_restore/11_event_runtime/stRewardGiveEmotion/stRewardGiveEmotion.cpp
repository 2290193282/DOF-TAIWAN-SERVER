#include "stRewardGiveEmotion.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8AA96CC
// IDA_NAME: _ZN19stRewardGiveEmotionC2Ev
// DEMANGLED: stRewardGiveEmotion::stRewardGiveEmotion(void)
void __cdecl stRewardGiveEmotion::stRewardGiveEmotion(stRewardGiveEmotion *this)
{
  stTitleRewardBasis::stTitleRewardBasis(this);
  *(_DWORD *)this = 1;
  *((_DWORD *)this + 3) = -1;
}
