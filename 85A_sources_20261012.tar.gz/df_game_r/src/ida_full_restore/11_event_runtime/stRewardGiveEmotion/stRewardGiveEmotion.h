#ifndef __IDA91_STREWARDGIVEEMOTION_H__
#define __IDA91_STREWARDGIVEEMOTION_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stRewardGiveEmotion
// Source unit: stRewardGiveEmotion
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4051

/* 4051 */
struct stRewardGiveEmotion;

// Exported member functions:
// 0x8AA96CC	stRewardGiveEmotion::stRewardGiveEmotion(void)

// Function declaration index:
// DECL 0x8AA96CC stRewardGiveEmotion::stRewardGiveEmotion

#endif  // __IDA91_STREWARDGIVEEMOTION_H__
