#ifndef __IDA91_CCOINEVENTPERDAY_H__
#define __IDA91_CCOINEVENTPERDAY_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CCoinEventPerDay
// Source unit: CCoinEventPerDay
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1184

/* 1184 */
struct CCoinEventPerDay;

// Exported member functions:
// 0x810AB10	CCoinEventPerDay::CCoinEventPerDay(void)
// 0x810AB48	CCoinEventPerDay::~CCoinEventPerDay()
// 0x810AB78	CCoinEventPerDay::~CCoinEventPerDay()
// 0x810AB96	CCoinEventPerDay::StartEvent(void)
// 0x810AC04	CCoinEventPerDay::StartEvent(Word_Param)
// 0x810ACA8	CCoinEventPerDay::EndEvent(void)
// 0x810AD16	CCoinEventPerDay::GetCoinNoPerDay(int)

// Function declaration index:
// DECL 0x810AB10 CCoinEventPerDay::CCoinEventPerDay
// DECL 0x810AB48 CCoinEventPerDay::~CCoinEventPerDay
// DECL 0x810AB78 CCoinEventPerDay::~CCoinEventPerDay
// DECL 0x810AB96 CCoinEventPerDay::StartEvent
// DECL 0x810AC04 CCoinEventPerDay::StartEvent
// DECL 0x810ACA8 CCoinEventPerDay::EndEvent
// DECL 0x810AD16 CCoinEventPerDay::GetCoinNoPerDay

#endif  // __IDA91_CCOINEVENTPERDAY_H__
