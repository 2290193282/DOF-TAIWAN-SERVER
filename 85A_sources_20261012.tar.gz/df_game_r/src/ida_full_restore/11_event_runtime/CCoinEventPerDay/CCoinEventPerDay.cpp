#include "CCoinEventPerDay.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x810AB10
// IDA_NAME: _ZN16CCoinEventPerDayC2Ev
// DEMANGLED: CCoinEventPerDay::CCoinEventPerDay(void)
void __cdecl CCoinEventPerDay::CCoinEventPerDay(CCoinEventPerDay *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B4B408;
  *((_BYTE *)this + 9) = 1;
  *((_BYTE *)this + 10) = 1;
  *((_BYTE *)this + 11) = 1;
  *((_BYTE *)this + 12) = 1;
}

// IDA_EA: 0x810AB48
// IDA_NAME: _ZN16CCoinEventPerDayD2Ev
// DEMANGLED: CCoinEventPerDay::~CCoinEventPerDay()
void __cdecl CCoinEventPerDay::~CCoinEventPerDay(CCoinEventPerDay *this)
{
  *(_DWORD *)this = off_8B4B408;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x810AB78
// IDA_NAME: _ZN16CCoinEventPerDayD0Ev
// DEMANGLED: CCoinEventPerDay::~CCoinEventPerDay()
void __cdecl CCoinEventPerDay::~CCoinEventPerDay(CCoinEventPerDay *this)
{
  CCoinEventPerDay::~CCoinEventPerDay(this);
  operator delete(this);
}

// IDA_EA: 0x810AB96
// IDA_NAME: _ZN16CCoinEventPerDay10StartEventEv
// DEMANGLED: CCoinEventPerDay::StartEvent(void)
int __cdecl CCoinEventPerDay::StartEvent(CCoinEventPerDay *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  *((_BYTE *)this + 9) = 1;
  *((_BYTE *)this + 10) = 1;
  *((_BYTE *)this + 11) = 1;
  *((_BYTE *)this + 12) = 1;
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 56, 0);
  return cMyTrace::operator()((int)v3, "Coin Event Per Day Start!", v2);
}

// IDA_EA: 0x810AC04
// IDA_NAME: _ZN16CCoinEventPerDay10StartEventE10Word_Param
// DEMANGLED: CCoinEventPerDay::StartEvent(Word_Param)
int __cdecl CCoinEventPerDay::StartEvent(CEventBase *a1, int a2)
{
  char v2; // bl
  int v4[10]; // [esp+30h] [ebp-28h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  *(_DWORD *)((char *)a1 + 9) = a2;
  v2 = *((_BYTE *)a1 + 9);
  cMyTrace::cMyTrace((cMyTrace *)v4, "StartEvent", 65, 0);
  return cMyTrace::operator()((int)v4, "Coin Event Per Day Start! coin(%d) coin(%d) coin(%d) coin(%d) ", v2);
}

// IDA_EA: 0x810ACA8
// IDA_NAME: _ZN16CCoinEventPerDay8EndEventEv
// DEMANGLED: CCoinEventPerDay::EndEvent(void)
int __cdecl CCoinEventPerDay::EndEvent(CCoinEventPerDay *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  *((_BYTE *)this + 9) = 1;
  *((_BYTE *)this + 10) = 1;
  *((_BYTE *)this + 11) = 1;
  *((_BYTE *)this + 12) = 1;
  cMyTrace::cMyTrace((cMyTrace *)v3, "EndEvent", 99, 0);
  return cMyTrace::operator()((int)v3, "Coin Event Per Day End", v2);
}

// IDA_EA: 0x810AD16
// IDA_NAME: _ZN16CCoinEventPerDay15GetCoinNoPerDayEi
// DEMANGLED: CCoinEventPerDay::GetCoinNoPerDay(int)
int __cdecl CCoinEventPerDay::GetCoinNoPerDay(CCoinEventPerDay *this, int n17)
{
  if ( n17 <= 17 )
    return *((unsigned __int8 *)this + 9);
  if ( n17 > 26 )
    return *((unsigned __int8 *)this + 11);
  return *((unsigned __int8 *)this + 10);
}
