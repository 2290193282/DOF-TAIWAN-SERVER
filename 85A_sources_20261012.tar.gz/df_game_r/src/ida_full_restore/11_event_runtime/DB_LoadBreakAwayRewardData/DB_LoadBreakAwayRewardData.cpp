#include "DB_LoadBreakAwayRewardData.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x843915C
// IDA_NAME: _ZN26DB_LoadBreakAwayRewardData11makeRequestEijjR18STBreakAwayRewards
// DEMANGLED: DB_LoadBreakAwayRewardData::makeRequest(int,unsigned int,unsigned int,STBreakAwayRewards &)
void __cdecl DB_LoadBreakAwayRewardData::makeRequest(
        DB_LoadBreakAwayRewardData *this,
        char src,
        char src_1,
        int *BreakAwayRewardsEv)
{
  Stream *v4; // eax
  Stream **v5; // eax
  Stream **v6; // eax
  Stream **v7; // eax
  Stream **v8; // eax
  int src_2; // ebx
  Stream **v10; // eax
  int src_3; // ebx
  Stream **v12; // eax
  int src_4; // ebx
  Stream **v14; // eax
  int src_5; // ebx
  Stream **v16; // eax
  int src_6; // ebx
  Stream **v18; // eax
  Stream *v19[4]; // [esp+18h] [ebp-10h] BYREF

  v4 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 34515);
  CStreamGuard::CStreamGuard((CStreamGuard *)v19, v4, 1);
  v5 = (Stream **)CStreamGuard::operator*((int)v19);
  CStreamGuard::operator<<(v5, 66);
  v6 = (Stream **)CStreamGuard::operator*((int)v19);
  CStreamGuard::operator<<(v6, (char)this);
  v7 = (Stream **)CStreamGuard::operator*((int)v19);
  CStreamGuard::operator<<(v7, src);
  v8 = (Stream **)CStreamGuard::operator*((int)v19);
  CStreamGuard::operator<<(v8, src_1);
  src_2 = *BreakAwayRewardsEv;
  v10 = (Stream **)CStreamGuard::operator*((int)v19);
  CStreamGuard::operator<<(v10, src_2);
  src_3 = BreakAwayRewardsEv[1];
  v12 = (Stream **)CStreamGuard::operator*((int)v19);
  CStreamGuard::operator<<(v12, src_3);
  src_4 = BreakAwayRewardsEv[2];
  v14 = (Stream **)CStreamGuard::operator*((int)v19);
  CStreamGuard::operator<<(v14, src_4);
  src_5 = BreakAwayRewardsEv[4];
  v16 = (Stream **)CStreamGuard::operator*((int)v19);
  CStreamGuard::operator<<(v16, src_5);
  src_6 = BreakAwayRewardsEv[3];
  v18 = (Stream **)CStreamGuard::operator*((int)v19);
  CStreamGuard::operator<<(v18, src_6);
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v19);
  CStreamGuard::~CStreamGuard(v19);
}

// IDA_EA: 0x84392DC
// IDA_NAME: _ZN26DB_LoadBreakAwayRewardData8dispatchEiiP6Stream
// DEMANGLED: DB_LoadBreakAwayRewardData::dispatch(int,int,Stream *)
int __cdecl DB_LoadBreakAwayRewardData::dispatch(DB_LoadBreakAwayRewardData *this, int a2, char src, Stream *a4)
{
  const char *v4; // eax
  const char *v5; // eax
  const char *v6; // eax
  const char *v7; // eax
  int v8; // ebx
  __int64 v9; // rax
  int dest__2; // ebx
  int v12; // edi
  time_t timer_1; // esi
  const char *v14; // eax
  Stream *v15; // eax
  Stream **v16; // eax
  Stream **v17; // eax
  int v18; // eax
  char v20; // [esp+8h] [ebp-E0h]
  char v21; // [esp+8h] [ebp-E0h]
  int v22; // [esp+30h] [ebp-B8h]
  int dest__3; // [esp+34h] [ebp-B4h]
  int dest_1; // [esp+38h] [ebp-B0h]
  int v25; // [esp+3Ch] [ebp-ACh]
  struct tm tp; // [esp+48h] [ebp-A0h] BYREF
  char v27[9]; // [esp+74h] [ebp-74h] BYREF
  char s[4]; // [esp+7Dh] [ebp-6Bh] BYREF
  __int16 v29; // [esp+81h] [ebp-67h]
  char v30; // [esp+83h] [ebp-65h]
  time_t timer; // [esp+84h] [ebp-64h] BYREF
  int v32; // [esp+88h] [ebp-60h] BYREF
  int dest__1; // [esp+8Ch] [ebp-5Ch] BYREF
  int dest_; // [esp+90h] [ebp-58h] BYREF
  int dest; // [esp+94h] [ebp-54h] BYREF
  int v36; // [esp+98h] [ebp-50h] BYREF
  int v37; // [esp+9Ch] [ebp-4Ch] BYREF
  unsigned int v38; // [esp+A0h] [ebp-48h] BYREF
  int v39[4]; // [esp+A4h] [ebp-44h] BYREF
  int v40[4]; // [esp+B4h] [ebp-34h] BYREF
  MySQL *DBHandle; // [esp+C4h] [ebp-24h]
  int v42; // [esp+C8h] [ebp-20h]
  _DWORD *v43; // [esp+CCh] [ebp-1Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 6, 0);
  v38 = 0;
  v37 = 0;
  v42 = *(_DWORD *)(G_CEnvironment() + 888);
  v36 = 0;
  dest = 0;
  dest_ = 0;
  dest__1 = 0;
  v32 = 0;
  timer = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
  localtime_r(&timer, &tp);
  *(_DWORD *)s = 0;
  v29 = 0;
  v30 = 0;
  sprintf(s, "%d%02d", tp.tm_year + 1900, tp.tm_mon + 1);
  Stream::operator>>(a4, (int)&v38);
  Stream::operator>>(a4, (int)&v37);
  Stream::operator>>(a4, (int)&v36);
  Stream::operator>>(a4, &dest);
  Stream::operator>>(a4, &dest_);
  Stream::operator>>(a4, &dest__1);
  Stream::operator>>(a4, (int)&v32);
  if ( dest__1 )
  {
    switch ( dest__1 )
    {
      case 1:
        MySQL::set_query(
          DBHandle,
          "upDate churn_member_info set last_reward_time =%u, luck_point=%d where m_id=%u",
          timer,
          dest_,
          v38);
        break;
      case 2:
        v5 = (const char *)NumberToString(v38, 0);
        MySQL::set_query(
          DBHandle,
          "upDate churn_member_info set last_reward_time =%u, second_reward_time = %u, quest_time =%u, luck_point=%d, add"
          "_info=%d where m_id=%s",
          timer,
          timer,
          timer + 86400,
          dest_,
          3,
          v5);
        break;
      case 3:
        v6 = (const char *)NumberToString(v38, 0);
        MySQL::set_query(
          DBHandle,
          "upDate churn_member_info set last_reward_time =%u, luck_point=%d where m_id=%s",
          timer,
          dest_,
          v6);
        break;
      case 4:
        v7 = (const char *)NumberToString(v38, 0);
        MySQL::set_query(
          DBHandle,
          "upDate churn_member_info set last_reward_time =%u, luck_point=%d, add_info=%d where m_id=%s",
          timer,
          dest_,
          -1,
          v7);
        break;
      default:
        return 0;
    }
  }
  else
  {
    v4 = (const char *)NumberToString(v38, 0);
    MySQL::set_query(
      DBHandle,
      "upDate churn_member_info set last_reward_time =%u, first_reward_time = %u, quest_time =%u, luck_point=%d, add_info"
      "=%d where m_id=%s",
      timer,
      timer,
      timer + 86400,
      dest_,
      3,
      v4);
  }
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 || (LODWORD(v9) = MySQL::getAffectedRowCount(DBHandle), !v9) )
  {
    cMyTrace::cMyTrace(
      (cMyTrace *)v39,
      "virtual bool DB_LoadBreakAwayRewardData::dispatch(int, int, Stream*)",
      34590,
      5);
    cMyTrace::operator()((int)v39, "BREAK_AWAY : ABNORMAL DB_LoadBreakAwayRewardData REWARD!!", v20);
    return 0;
  }
  else
  {
    dest__2 = dest__1;
    v22 = v32;
    dest__3 = dest_;
    dest_1 = dest;
    v25 = v36;
    v12 = v37;
    timer_1 = timer;
    v14 = (const char *)NumberToString(v38, 0);
    MySQL::set_query(
      DBHandle,
      "inSert into churn_reward_history_%s(m_id,occ_time,server_id,charac_no,item_id,add_info,luck_point,cera,reward_orde"
      "r) values(%s, from_unixtime(%u), %d, %u, %u, %d, %d, %u, %d)",
      s,
      v14,
      timer_1,
      v42,
      v12,
      v25,
      dest_1,
      dest__3,
      v22,
      dest__2);
    if ( (unsigned __int8)MySQL::exec(DBHandle, 1) == 1 )
    {
      v15 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 34629);
      CStreamGuard::CStreamGuard((CStreamGuard *)v27, v15, 1);
      v16 = (Stream **)CStreamGuard::operator*((int)v27);
      CStreamGuard::operator<<(v16, 67);
      v17 = (Stream **)CStreamGuard::operator*((int)v27);
      CStreamGuard::operator<<(v17, src);
      v18 = CStreamGuard::operator->((int)v27);
      v43 = (_DWORD *)CStreamGuard::GetInBuffer<SIG_BREAK_AWAY_PREVENT_MESSAGE>(v18);
      if ( dest__1 && dest__1 != 2 )
      {
        v43[1] = dest__1;
      }
      else
      {
        v43[1] = dest__1;
        *v43 = timer + 86400;
      }
      MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 1, (CStreamGuard *)v27);
      v8 = 1;
      CStreamGuard::~CStreamGuard((CStreamGuard *)v27);
    }
    else
    {
      cMyTrace::cMyTrace(
        (cMyTrace *)v40,
        "virtual bool DB_LoadBreakAwayRewardData::dispatch(int, int, Stream*)",
        34624,
        5);
      cMyTrace::operator()((int)v40, "BREAK_AWAY : ABNORMAL DB_LoadBreakAwayRewardData LOG!!", v21);
      return 0;
    }
  }
  return v8;
}

// IDA_EA: 0x844ED3E
// IDA_NAME: _ZN26DB_LoadBreakAwayRewardDataC2Ev
// DEMANGLED: DB_LoadBreakAwayRewardData::DB_LoadBreakAwayRewardData(void)
void __cdecl DB_LoadBreakAwayRewardData::DB_LoadBreakAwayRewardData(DB_LoadBreakAwayRewardData *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5EAA8;
}

// IDA_EA: 0x845CD84
// IDA_NAME: _ZN26DB_LoadBreakAwayRewardDataD2Ev
// DEMANGLED: DB_LoadBreakAwayRewardData::~DB_LoadBreakAwayRewardData()
void __cdecl DB_LoadBreakAwayRewardData::~DB_LoadBreakAwayRewardData(DB_LoadBreakAwayRewardData *this)
{
  *(_DWORD *)this = &off_8C5EAA8;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845CDB4
// IDA_NAME: _ZN26DB_LoadBreakAwayRewardDataD0Ev
// DEMANGLED: DB_LoadBreakAwayRewardData::~DB_LoadBreakAwayRewardData()
void __cdecl DB_LoadBreakAwayRewardData::~DB_LoadBreakAwayRewardData(DB_LoadBreakAwayRewardData *this)
{
  DB_LoadBreakAwayRewardData::~DB_LoadBreakAwayRewardData(this);
  operator delete(this);
}
