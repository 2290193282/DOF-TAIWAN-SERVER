#ifndef __IDA91_DB_LOADBREAKAWAYREWARDDATA_H__
#define __IDA91_DB_LOADBREAKAWAYREWARDDATA_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_LoadBreakAwayRewardData
// Source unit: DB_LoadBreakAwayRewardData
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2572

/* 2572 */
struct DB_LoadBreakAwayRewardData;

// Exported member functions:
// 0x843915C	DB_LoadBreakAwayRewardData::makeRequest(int,unsigned int,unsigned int,STBreakAwayRewards &)
// 0x84392DC	DB_LoadBreakAwayRewardData::dispatch(int,int,Stream *)
// 0x844ED3E	DB_LoadBreakAwayRewardData::DB_LoadBreakAwayRewardData(void)
// 0x845CD84	DB_LoadBreakAwayRewardData::~DB_LoadBreakAwayRewardData()
// 0x845CDB4	DB_LoadBreakAwayRewardData::~DB_LoadBreakAwayRewardData()

// Function declaration index:
// DECL 0x843915C DB_LoadBreakAwayRewardData::makeRequest
// DECL 0x84392DC DB_LoadBreakAwayRewardData::dispatch
// DECL 0x844ED3E DB_LoadBreakAwayRewardData::DB_LoadBreakAwayRewardData
// DECL 0x845CD84 DB_LoadBreakAwayRewardData::~DB_LoadBreakAwayRewardData
// DECL 0x845CDB4 DB_LoadBreakAwayRewardData::~DB_LoadBreakAwayRewardData

#endif  // __IDA91_DB_LOADBREAKAWAYREWARDDATA_H__
