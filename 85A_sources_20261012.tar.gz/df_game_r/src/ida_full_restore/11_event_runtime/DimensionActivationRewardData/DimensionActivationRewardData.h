#ifndef __IDA91_DIMENSIONACTIVATIONREWARDDATA_H__
#define __IDA91_DIMENSIONACTIVATIONREWARDDATA_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DimensionActivationRewardData
// Source unit: DimensionActivationRewardData
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4551

/* 4551 */
struct DimensionActivationRewardData;

// Exported member functions:
// 0x8371348	DimensionActivationRewardData::DimensionActivationRewardData(void)
// 0x83713B4	DimensionActivationRewardData::~DimensionActivationRewardData()
// 0x8915F16	DimensionActivationRewardData::getSectionData(int)
// 0x8915F9A	DimensionActivationRewardData::getRewardGiveItems(int,int,int)
// 0x8916004	DimensionActivationRewardData::getRewardGiveItemList(int,int)
// 0x8916086	DimensionActivationRewardData::getRewardSelectItemList(int)

// Function declaration index:
// DECL 0x8371348 DimensionActivationRewardData::DimensionActivationRewardData
// DECL 0x83713B4 DimensionActivationRewardData::~DimensionActivationRewardData
// DECL 0x8915F16 DimensionActivationRewardData::getSectionData
// DECL 0x8915F9A DimensionActivationRewardData::getRewardGiveItems
// DECL 0x8916004 DimensionActivationRewardData::getRewardGiveItemList
// DECL 0x8916086 DimensionActivationRewardData::getRewardSelectItemList

#endif  // __IDA91_DIMENSIONACTIVATIONREWARDDATA_H__
