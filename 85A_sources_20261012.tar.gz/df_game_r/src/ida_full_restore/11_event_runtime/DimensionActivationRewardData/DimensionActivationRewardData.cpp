#include "DimensionActivationRewardData.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8371348
// IDA_NAME: _ZN29DimensionActivationRewardDataC2Ev
// DEMANGLED: DimensionActivationRewardData::DimensionActivationRewardData(void)
void __cdecl DimensionActivationRewardData::DimensionActivationRewardData(DimensionActivationRewardData *this)
{
  std::vector<EventRewardSection>::vector(this);
  std::map<int,std::vector<std::vector<EventRewardItemInfo>>>::map((char *)this + 12);
  std::map<std::pair<int,int>,std::vector<std::vector<EventRewardItemInfo>>>::map((char *)this + 36);
}

// IDA_EA: 0x83713B4
// IDA_NAME: _ZN29DimensionActivationRewardDataD2Ev
// DEMANGLED: DimensionActivationRewardData::~DimensionActivationRewardData()
void __cdecl DimensionActivationRewardData::~DimensionActivationRewardData(DimensionActivationRewardData *this)
{
  std::map<std::pair<int,int>,std::vector<std::vector<EventRewardItemInfo>>>::~map((int)this + 36);
  std::map<int,std::vector<std::vector<EventRewardItemInfo>>>::~map((int)this + 12);
  std::vector<EventRewardSection>::~vector(this);
}

// IDA_EA: 0x8915F16
// IDA_NAME: _ZN29DimensionActivationRewardData14getSectionDataEi
// DEMANGLED: DimensionActivationRewardData::getSectionData(int)
int __cdecl DimensionActivationRewardData::getSectionData(DimensionActivationRewardData *this, int a2)
{
  _BYTE v3[4]; // [esp+18h] [ebp-10h] BYREF
  _BYTE v4[12]; // [esp+1Ch] [ebp-Ch] BYREF

  std::vector<EventRewardSection>::rbegin(v3);
  while ( 1 )
  {
    std::vector<EventRewardSection>::rend(v4);
    if ( !(unsigned __int8)std::operator!=<__gnu_cxx::__normal_iterator<EventRewardSection *,std::vector<EventRewardSection>>>(
                             v3,
                             v4) )
      break;
    if ( *(unsigned __int8 *)(std::reverse_iterator<__gnu_cxx::__normal_iterator<EventRewardSection *,std::vector<EventRewardSection>>>::operator->(v3)
                            + 1) <= a2 )
      return std::reverse_iterator<__gnu_cxx::__normal_iterator<EventRewardSection *,std::vector<EventRewardSection>>>::operator*(v3);
    std::reverse_iterator<__gnu_cxx::__normal_iterator<EventRewardSection *,std::vector<EventRewardSection>>>::operator++(v3);
  }
  return 0;
}

// IDA_EA: 0x8915F9A
// IDA_NAME: _ZN29DimensionActivationRewardData18getRewardGiveItemsEiii
// DEMANGLED: DimensionActivationRewardData::getRewardGiveItems(int,int,int)
int __cdecl DimensionActivationRewardData::getRewardGiveItems(
        DimensionActivationRewardData *this,
        int a2,
        int charac_jobEv,
        int CurCharFirstGrowTypeEv)
{
  char v4; // al
  _DWORD *RewardGiveItemListEii; // [esp+1Ch] [ebp-Ch]

  RewardGiveItemListEii = (_DWORD *)DimensionActivationRewardData::getRewardGiveItemList(
                                      this,
                                      charac_jobEv,
                                      CurCharFirstGrowTypeEv);
  if ( RewardGiveItemListEii
    && (a2 < 0 || std::vector<std::vector<EventRewardItemInfo>>::size(RewardGiveItemListEii) < a2 ? (v4 = 0) : (v4 = 1),
        v4) )
  {
    return std::vector<std::vector<EventRewardItemInfo>>::at((int)RewardGiveItemListEii, a2);
  }
  else
  {
    return 0;
  }
}

// IDA_EA: 0x8916004
// IDA_NAME: _ZN29DimensionActivationRewardData21getRewardGiveItemListEii
// DEMANGLED: DimensionActivationRewardData::getRewardGiveItemList(int,int)
int __cdecl DimensionActivationRewardData::getRewardGiveItemList(
        DimensionActivationRewardData *this,
        int charac_jobEv,
        int CurCharFirstGrowTypeEv)
{
  int v4; // [esp+10h] [ebp-18h] BYREF
  _DWORD v5[2]; // [esp+14h] [ebp-14h] BYREF
  _DWORD v6[3]; // [esp+1Ch] [ebp-Ch] BYREF

  std::pair<int,int>::pair(v5);
  v5[0] = charac_jobEv;
  v5[1] = CurCharFirstGrowTypeEv;
  std::map<std::pair<int,int>,std::vector<std::vector<EventRewardItemInfo>>>::find(&v4);
  std::map<std::pair<int,int>,std::vector<std::vector<EventRewardItemInfo>>>::end((int)v6);
  if ( std::_Rb_tree_iterator<std::pair<std::pair const<int,int>,std::vector<std::vector<EventRewardItemInfo>>>>::operator!=(
         &v4,
         v6) )
  {
    return std::_Rb_tree_iterator<std::pair<std::pair const<int,int>,std::vector<std::vector<EventRewardItemInfo>>>>::operator->(&v4)
         + 8;
  }
  else
  {
    return 0;
  }
}

// IDA_EA: 0x8916086
// IDA_NAME: _ZN29DimensionActivationRewardData23getRewardSelectItemListEi
// DEMANGLED: DimensionActivationRewardData::getRewardSelectItemList(int)
int __cdecl DimensionActivationRewardData::getRewardSelectItemList()
{
  int v1; // [esp+18h] [ebp-10h] BYREF
  _DWORD v2[3]; // [esp+1Ch] [ebp-Ch] BYREF

  std::map<int,std::vector<std::vector<EventRewardItemInfo>>>::find(&v1);
  std::map<int,std::vector<std::vector<EventRewardItemInfo>>>::end((int)v2);
  if ( std::_Rb_tree_iterator<std::pair<int const,std::vector<std::vector<EventRewardItemInfo>>>>::operator!=(&v1, v2) )
    return std::_Rb_tree_iterator<std::pair<int const,std::vector<std::vector<EventRewardItemInfo>>>>::operator->(&v1)
         + 4;
  else
    return 0;
}
