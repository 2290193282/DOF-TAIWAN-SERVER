#include "CEventStayTime.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x816BDA0
// IDA_NAME: _ZN14CEventStayTime10StartEventEv
// DEMANGLED: CEventStayTime::StartEvent(void)
int __cdecl CEventStayTime::StartEvent(CEventStayTime *this)
{
  int v1; // ebx
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  v1 = *((_DWORD *)this + 3);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CEventStayTime::StartEvent()", 10, 0);
  cMyTrace::operator()((int)v3, "[Taiwan, StayEvent] Start! StayTime:%dMin, CheckTime:%dMin", v1);
  return CEventStayTime::RegistNextTimer(this);
}

// IDA_EA: 0x816BE18
// IDA_NAME: _ZN14CEventStayTime10StartEventE10Word_Param
// DEMANGLED: CEventStayTime::StartEvent(Word_Param)
int __cdecl CEventStayTime::StartEvent(_DWORD *a1, int a2)
{
  a1[3] = 60 * (unsigned __int16)a2;
  a1[4] = 60 * HIWORD(a2);
  return (*(int (__cdecl **)(_DWORD *))(*a1 + 8))(a1);
}

// IDA_EA: 0x816BE60
// IDA_NAME: _ZN14CEventStayTime8EndEventEv
// DEMANGLED: CEventStayTime::EndEvent(void)
CEventBase *__cdecl CEventStayTime::EndEvent(CEventStayTime *this)
{
  const char *v2; // [esp+14h] [ebp-14h]

  LogManager::logFormat(
    (LogManager *)1,
    (int)"localtaiwan/Event/EventStayTimeCharacter.cpp",
    "virtual void CEventStayTime::EndEvent()",
    (const char *)0x1B,
    "[CEventStayTime] End Event.",
    v2);
  *((_DWORD *)this + 3) = 0;
  *((_DWORD *)this + 4) = 0;
  return CEventBase::SetEventFlag(this, 0);
}

// IDA_EA: 0x816BEBC
// IDA_NAME: _ZN14CEventStayTime17getRewardStayTimeEv
// DEMANGLED: CEventStayTime::getRewardStayTime(void)
int __cdecl CEventStayTime::getRewardStayTime(CEventStayTime *this)
{
  return *((_DWORD *)this + 3);
}

// IDA_EA: 0x816BEC8
// IDA_NAME: _ZN14CEventStayTime19getIntervalStayTimeEv
// DEMANGLED: CEventStayTime::getIntervalStayTime(void)
int __cdecl CEventStayTime::getIntervalStayTime(CEventStayTime *this)
{
  return *((_DWORD *)this + 4);
}

// IDA_EA: 0x816BED4
// IDA_NAME: _ZN14CEventStayTime12IsFirstResetEv
// DEMANGLED: CEventStayTime::IsFirstReset(void)
int __cdecl CEventStayTime::IsFirstReset(CEventStayTime *this)
{
  if ( !*((_BYTE *)this + 9) )
    return *((unsigned __int8 *)this + 9);
  *((_BYTE *)this + 9) = 0;
  return 1;
}

// IDA_EA: 0x816BEFA
// IDA_NAME: _ZN14CEventStayTime15RegistNextTimerEv
// DEMANGLED: CEventStayTime::RegistNextTimer(void)
int __cdecl CEventStayTime::RegistNextTimer(CEventStayTime *this)
{
  int result; // eax
  int v2; // ebx
  TimerQueue *v3; // eax

  result = (*(int (__cdecl **)(CEventStayTime *, _DWORD))(*(_DWORD *)this + 52))(this, 0) ^ 1;
  if ( !(_BYTE)result )
  {
    v2 = *((_DWORD *)this + 4);
    v3 = (TimerQueue *)G_TimerQueue();
    return TimerQueue::InsertTimer(v3, 2, 0, 173, v2, 0, 0);
  }
  return result;
}

// IDA_EA: 0x816BF6A
// IDA_NAME: _ZN14CEventStayTime14dailyresetDataEv
// DEMANGLED: CEventStayTime::dailyresetData(void)
void __cdecl CEventStayTime::dailyresetData(CEventStayTime *this)
{
  Stream *v1; // eax
  int v2; // eax
  int v3[2]; // [esp+14h] [ebp-14h] BYREF

  if ( (*(unsigned __int8 (__cdecl **)(CEventStayTime *, _DWORD))(*(_DWORD *)this + 52))(this, 0) == 1
    && !(unsigned __int8)CEventStayTime::IsFirstReset(this) )
  {
    v1 = (Stream *)StreamPool::Acquire(GlobalData::s_stream_pool, "localtaiwan/Event/EventStayTimeCharacter.cpp", 74);
    CStreamGuard::CStreamGuard((CStreamGuard *)v3, v1, 1);
    Taiwan::internal_stream((int)v3, 7, -1);
    v2 = CStreamGuard::operator->((int)v3);
    if ( CStreamGuard::GetInBuffer<Taiwan::SigResetStayTimeEvent>(v2) )
      MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v3);
    CStreamGuard::~CStreamGuard((CStreamGuard *)v3);
  }
}

// IDA_EA: 0x816C066
// IDA_NAME: _ZN14CEventStayTimeC2Ev
// DEMANGLED: CEventStayTime::CEventStayTime(void)
void __cdecl CEventStayTime::CEventStayTime(CEventStayTime *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B80DC8;
  *((_BYTE *)this + 9) = 1;
}

// IDA_EA: 0x816C08A
// IDA_NAME: _ZN14CEventStayTimeD2Ev
// DEMANGLED: CEventStayTime::~CEventStayTime()
void __cdecl CEventStayTime::~CEventStayTime(CEventStayTime *this)
{
  *(_DWORD *)this = off_8B80DC8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x816C0BA
// IDA_NAME: _ZN14CEventStayTimeD0Ev
// DEMANGLED: CEventStayTime::~CEventStayTime()
void __cdecl CEventStayTime::~CEventStayTime(CEventStayTime *this)
{
  CEventStayTime::~CEventStayTime(this);
  operator delete(this);
}
