#ifndef __IDA91_CEVENTSTAYTIME_H__
#define __IDA91_CEVENTSTAYTIME_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CEventStayTime
// Source unit: CEventStayTime
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1353

/* 1353 */
struct CEventStayTime;

// Exported member functions:
// 0x816BDA0	CEventStayTime::StartEvent(void)
// 0x816BE18	CEventStayTime::StartEvent(Word_Param)
// 0x816BE60	CEventStayTime::EndEvent(void)
// 0x816BEBC	CEventStayTime::getRewardStayTime(void)
// 0x816BEC8	CEventStayTime::getIntervalStayTime(void)
// 0x816BED4	CEventStayTime::IsFirstReset(void)
// 0x816BEFA	CEventStayTime::RegistNextTimer(void)
// 0x816BF6A	CEventStayTime::dailyresetData(void)
// 0x816C066	CEventStayTime::CEventStayTime(void)
// 0x816C08A	CEventStayTime::~CEventStayTime()
// 0x816C0BA	CEventStayTime::~CEventStayTime()

// Function declaration index:
// DECL 0x816BDA0 CEventStayTime::StartEvent
// DECL 0x816BE18 CEventStayTime::StartEvent
// DECL 0x816BE60 CEventStayTime::EndEvent
// DECL 0x816BEBC CEventStayTime::getRewardStayTime
// DECL 0x816BEC8 CEventStayTime::getIntervalStayTime
// DECL 0x816BED4 CEventStayTime::IsFirstReset
// DECL 0x816BEFA CEventStayTime::RegistNextTimer
// DECL 0x816BF6A CEventStayTime::dailyresetData
// DECL 0x816C066 CEventStayTime::CEventStayTime
// DECL 0x816C08A CEventStayTime::~CEventStayTime
// DECL 0x816C0BA CEventStayTime::~CEventStayTime

#endif  // __IDA91_CEVENTSTAYTIME_H__
