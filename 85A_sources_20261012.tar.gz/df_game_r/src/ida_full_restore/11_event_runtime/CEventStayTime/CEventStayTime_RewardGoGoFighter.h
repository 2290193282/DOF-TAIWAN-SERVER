#ifndef __IDA91_CEVENTSTAYTIME_REWARDGOGOFIGHTER_H__
#define __IDA91_CEVENTSTAYTIME_REWARDGOGOFIGHTER_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CEventStayTime
// Source unit: CEventStayTime_RewardGoGoFighter
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 3451

/* 3451 */
struct CEventStayTime::RewardGoGoFighter;

// Exported member functions:
// 0x863C002	CEventStayTime::RewardGoGoFighter::RewardGoGoFighter(int,long)
// 0x863C018	CEventStayTime::RewardGoGoFighter::operator()(CUser *)

// Function declaration index:
// DECL 0x863C002 CEventStayTime::RewardGoGoFighter::RewardGoGoFighter
// DECL 0x863C018 CEventStayTime::RewardGoGoFighter::operator

#endif  // __IDA91_CEVENTSTAYTIME_REWARDGOGOFIGHTER_H__
