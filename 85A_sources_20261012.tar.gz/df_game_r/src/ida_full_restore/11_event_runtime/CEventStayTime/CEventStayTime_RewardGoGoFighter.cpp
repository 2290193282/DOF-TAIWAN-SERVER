#include "CEventStayTime_RewardGoGoFighter.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x863C002
// IDA_NAME: _ZN14CEventStayTime17RewardGoGoFighterC2Eil
// DEMANGLED: CEventStayTime::RewardGoGoFighter::RewardGoGoFighter(int,long)
CEventStayTime::RewardGoGoFighter *__cdecl CEventStayTime::RewardGoGoFighter::RewardGoGoFighter(
        CEventStayTime::RewardGoGoFighter *this,
        int RewardStayTimeEv,
        int a3)
{
  CEventStayTime::RewardGoGoFighter *this_1; // eax

  *(_DWORD *)this = RewardStayTimeEv;
  this_1 = this;
  *((_DWORD *)this + 1) = a3;
  return this_1;
}

// IDA_EA: 0x863C018
// IDA_NAME: _ZN14CEventStayTime17RewardGoGoFighterclEP5CUser
// DEMANGLED: CEventStayTime::RewardGoGoFighter::operator()(CUser *)
void __cdecl CEventStayTime::RewardGoGoFighter::operator()(_DWORD *a1, CUser *a2)
{
  int v2; // ebx
  Stream *v3; // eax
  char src; // al
  Stream **v5; // eax
  char acc_idEv; // bl
  unsigned int acc_idEv_1; // eax
  int v8[2]; // [esp+10h] [ebp-28h] BYREF
  int v9[4]; // [esp+18h] [ebp-20h] BYREF
  int v10; // [esp+28h] [ebp-10h]
  Taiwan::SigStayTimeEvent *v11; // [esp+2Ch] [ebp-Ch]

  if ( a2 )
  {
    v2 = a1[1];
    v10 = v2 - CUser::GetLoginTime(a2);
    if ( *a1 <= v10 )
    {
      v3 = StreamPool::Acquire(GlobalData::s_stream_pool, "localtaiwan/Event/EventStayTimeCharacter.h", 30);
      CStreamGuard::CStreamGuard((CStreamGuard *)v8, v3, 1);
      src = CUser::GetUID(a2);
      Taiwan::internal_stream((int)v8, 5, src);
      v5 = (Stream **)CStreamGuard::operator->((int)v8);
      v11 = (Taiwan::SigStayTimeEvent *)CStreamGuard::GetInBuffer<Taiwan::SigStayTimeEvent>(v5);
      if ( v11 )
      {
        acc_idEv = CUser::get_acc_id(a2);
        cMyTrace::cMyTrace((cMyTrace *)v9, "void CEventStayTime::RewardGoGoFighter::operator()(CUser*)", 36, 0);
        cMyTrace::operator()((int)v9, "[Taiwan, Event] GoGoFighter try reward mid. (%u)", acc_idEv);
        Taiwan::SigStayTimeEvent::init(v11);
        acc_idEv_1 = CUser::get_acc_id(a2);
        Taiwan::SigStayTimeEvent::set(v11, acc_idEv_1);
        MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v8);
      }
      CStreamGuard::~CStreamGuard((Stream **)v8);
    }
  }
}
