#include "CBattle_Field_stEventMonsterStatus_t.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x830EE4C
// IDA_NAME: _ZN13CBattle_Field22stEventMonsterStatus_tC2Ev
// DEMANGLED: CBattle_Field::stEventMonsterStatus_t::stEventMonsterStatus_t(void)
_DWORD *__cdecl CBattle_Field::stEventMonsterStatus_t::stEventMonsterStatus_t(
        CBattle_Field::stEventMonsterStatus_t *this)
{
  return std::pair<int,int>::pair((_DWORD *)this + 1);
}

// IDA_EA: 0x8316ADC
// IDA_NAME: _ZN13CBattle_Field22stEventMonsterStatus_tD2Ev
// DEMANGLED: CBattle_Field::stEventMonsterStatus_t::~stEventMonsterStatus_t()
void CBattle_Field::stEventMonsterStatus_t::~stEventMonsterStatus_t()
{
  ;
}
