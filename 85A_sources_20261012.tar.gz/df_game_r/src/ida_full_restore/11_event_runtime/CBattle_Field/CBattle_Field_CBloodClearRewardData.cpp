#include "CBattle_Field_CBloodClearRewardData.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x82A4458
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData14stRewardItem_tC2Ev
// DEMANGLED: CBattle_Field::CBloodClearRewardData::stRewardItem_t::stRewardItem_t(void)
bool __cdecl CBattle_Field::CBloodClearRewardData::stRewardItem_t::stRewardItem_t(
        CBattle_Field::CBloodClearRewardData::stRewardItem_t *this)
{
  Inven_Item *v1; // ebx
  int n9; // esi
  bool result; // al

  v1 = (CBattle_Field::CBloodClearRewardData::stRewardItem_t *)((char *)this + 4);
  for ( n9 = 9; ; --n9 )
  {
    result = n9 != -1;
    if ( n9 == -1 )
      break;
    Inven_Item::Inven_Item(v1);
    v1 = (Inven_Item *)((char *)v1 + 61);
  }
  return result;
}

// IDA_EA: 0x82A448E
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardDataC2Ev
// DEMANGLED: CBattle_Field::CBloodClearRewardData::CBloodClearRewardData(void)
bool __cdecl CBattle_Field::CBloodClearRewardData::CBloodClearRewardData(CBattle_Field::CBloodClearRewardData *this)
{
  CBattle_Field::CBloodClearRewardData::stRewardItem_t *v1; // ebx
  int n3; // esi
  bool result; // al

  v1 = (CBattle_Field::CBloodClearRewardData *)((char *)this + 40);
  for ( n3 = 3; ; --n3 )
  {
    result = n3 != -1;
    if ( n3 == -1 )
      break;
    CBattle_Field::CBloodClearRewardData::stRewardItem_t::stRewardItem_t(v1);
    v1 = (CBattle_Field::CBloodClearRewardData::stRewardItem_t *)((char *)v1 + 616);
  }
  return result;
}

// IDA_EA: 0x8306EE0
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData5resetEv
// DEMANGLED: CBattle_Field::CBloodClearRewardData::reset(void)
CBattle_Field::CBloodClearRewardData *__cdecl CBattle_Field::CBloodClearRewardData::reset(
        CBattle_Field::CBloodClearRewardData *this)
{
  CBattle_Field::CBloodClearRewardData *this_1; // eax
  int n3; // [esp+1Ch] [ebp-Ch]

  *((_DWORD *)this + 2) = 0;
  *(_DWORD *)this = 0;
  *((_DWORD *)this + 1) = 0;
  *((_BYTE *)this + 20) = 0;
  for ( n3 = 0; n3 <= 3; ++n3 )
  {
    *((_DWORD *)this + n3 + 6) = 0;
    CBattle_Field::CBloodClearRewardData::stRewardItem_t::reset((CBattle_Field::CBloodClearRewardData *)((char *)this + 616 * n3 + 40));
  }
  this_1 = this;
  *((_DWORD *)this + 626) = 0;
  return this_1;
}

// IDA_EA: 0x8306F5C
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData14stRewardItem_t5resetEv
// DEMANGLED: CBattle_Field::CBloodClearRewardData::stRewardItem_t::reset(void)
bool __cdecl CBattle_Field::CBloodClearRewardData::stRewardItem_t::reset(
        CBattle_Field::CBloodClearRewardData::stRewardItem_t *this)
{
  bool result; // al
  int n9; // [esp+1Ch] [ebp-Ch]

  *(_DWORD *)this = 0;
  for ( n9 = 0; ; ++n9 )
  {
    result = n9 <= 9;
    if ( n9 > 9 )
      break;
    Inven_Item::reset((CBattle_Field::CBloodClearRewardData::stRewardItem_t *)((char *)this + 61 * n9 + 4));
    *(_DWORD *)((char *)this + 61 * n9 + 6) = -1;
  }
  return result;
}

// IDA_EA: 0x8306FAA
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData17onStartBloodRoundEv
// DEMANGLED: CBattle_Field::CBloodClearRewardData::onStartBloodRound(void)
int __cdecl CBattle_Field::CBloodClearRewardData::onStartBloodRound(CBattle_Field::CBloodClearRewardData *this)
{
  int CurTickCountEv; // eax

  CurTickCountEv = CSystemTime::getCurTickCount((CSystemTime *)GlobalData::s_systemTime_);
  *((_DWORD *)this + 3) = CurTickCountEv;
  return CurTickCountEv;
}

// IDA_EA: 0x8306FC4
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData18onFinishBloodRoundEbsP6CPartyPK8CDungeon
// DEMANGLED: CBattle_Field::CBloodClearRewardData::onFinishBloodRound(bool,short,CParty *,CDungeon const*)
bool __cdecl CBattle_Field::CBloodClearRewardData::onFinishBloodRound(
        CBattle_Field::CBloodClearRewardData *this,
        bool a2,
        __int16 BloodRoundOrderEv,
        CParty *a4,
        std::string *a5)
{
  unsigned int BloodRoundClearTimeEv; // eax
  const char *DungeonName; // ebx
  unsigned int v7; // esi
  unsigned int BloodRoundClearTimeEv_1; // [esp+2Ch] [ebp-1Ch]

  if ( a2 )
    CBattle_Field::CBloodClearRewardData::setBloodClear(this, 1);
  *((_DWORD *)this + 2) = BloodRoundOrderEv;
  *((_DWORD *)this + 4) = CSystemTime::getCurTickCount((CSystemTime *)GlobalData::s_systemTime_);
  BloodRoundClearTimeEv = CBattle_Field::CBloodClearRewardData::getBloodRoundClearTime(this);
  CBattle_Field::CBloodClearRewardData::addPlayTime(this, BloodRoundClearTimeEv);
  DungeonName = (const char *)CDungeon::GetDungeonName(a5);
  v7 = CBattle_Field::CBloodClearRewardData::getPlayTime(this) / 0x3E8u;
  BloodRoundClearTimeEv_1 = CBattle_Field::CBloodClearRewardData::getBloodRoundClearTime(this);
  return CParty::historyBloodRoundClear(a4, *((_DWORD *)this + 2), BloodRoundClearTimeEv_1 / 0x3E8, v7, DungeonName);
}

// IDA_EA: 0x8307096
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData26incUltimateRoundClearPointEi
// DEMANGLED: CBattle_Field::CBloodClearRewardData::incUltimateRoundClearPoint(int)
CBattle_Field::CBloodClearRewardData *__cdecl CBattle_Field::CBloodClearRewardData::incUltimateRoundClearPoint(
        CBattle_Field::CBloodClearRewardData *this,
        int NextRoundDifficultyEs)
{
  int v2; // ebx
  int v3; // edx
  CBattle_Field::CBloodClearRewardData *this_1; // eax

  v2 = *((_DWORD *)this + 626);
  v3 = v2 + *(_DWORD *)(G_CDataManager() + 4 * (NextRoundDifficultyEs + 6236));
  this_1 = this;
  *((_DWORD *)this + 626) = v3;
  return this_1;
}

// IDA_EA: 0x83070CA
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData21getUltimateRewardItemEv
// DEMANGLED: CBattle_Field::CBloodClearRewardData::getUltimateRewardItem(void)
int __cdecl CBattle_Field::CBloodClearRewardData::getUltimateRewardItem(CBattle_Field::CBloodClearRewardData *this)
{
  _BYTE v2[4]; // [esp+18h] [ebp-20h] BYREF
  _BYTE v3[4]; // [esp+1Ch] [ebp-1Ch] BYREF
  int UltimateRoundClearPointEv; // [esp+20h] [ebp-18h]
  int rand_inti_2; // [esp+24h] [ebp-14h]
  int rand_inti_1; // [esp+28h] [ebp-10h]
  int rand_inti; // [esp+2Ch] [ebp-Ch]

  UltimateRoundClearPointEv = CBattle_Field::CBloodClearRewardData::getUltimateRoundClearPoint(this);
  rand_inti_2 = 0;
  rand_inti_1 = 0;
  G_CDataManager();
  std::map<int,STUltimateRewardProb>::end(v3);
  G_CDataManager();
  std::map<int,STUltimateRewardProb>::find(v2);
  if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,STUltimateRewardProb>>::operator==(v2, v3) )
    return -1;
  rand_inti = get_rand_int(100);
  rand_inti_2 = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,STUltimateRewardProb>>::operator->(v2) + 4);
  rand_inti_1 = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,STUltimateRewardProb>>::operator->(v2) + 8);
  if ( rand_inti <= rand_inti_1 )
    return 1252;
  rand_inti_2 += rand_inti_1;
  if ( rand_inti > rand_inti_2 )
    return -1;
  else
    return 1251;
}

// IDA_EA: 0x830EC3A
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData11addPlayTimeEj
// DEMANGLED: CBattle_Field::CBloodClearRewardData::addPlayTime(unsigned int)
CBattle_Field::CBloodClearRewardData *__cdecl CBattle_Field::CBloodClearRewardData::addPlayTime(
        CBattle_Field::CBloodClearRewardData *this,
        unsigned int BloodRoundClearTimeEv)
{
  CBattle_Field::CBloodClearRewardData *this_1; // eax

  *((_DWORD *)this + 1) = *(_DWORD *)this;
  this_1 = this;
  *(_DWORD *)this += BloodRoundClearTimeEv;
  return this_1;
}

// IDA_EA: 0x830EC5A
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData11getPlayTimeEv
// DEMANGLED: CBattle_Field::CBloodClearRewardData::getPlayTime(void)
int __cdecl CBattle_Field::CBloodClearRewardData::getPlayTime(CBattle_Field::CBloodClearRewardData *this)
{
  return *(_DWORD *)this;
}

// IDA_EA: 0x830EC64
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData22getBloodRoundClearTimeEv
// DEMANGLED: CBattle_Field::CBloodClearRewardData::getBloodRoundClearTime(void)
int __cdecl CBattle_Field::CBloodClearRewardData::getBloodRoundClearTime(CBattle_Field::CBloodClearRewardData *this)
{
  return *((_DWORD *)this + 4) - *((_DWORD *)this + 3);
}

// IDA_EA: 0x830EC7C
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData13setBloodClearEb
// DEMANGLED: CBattle_Field::CBloodClearRewardData::setBloodClear(bool)
CBattle_Field::CBloodClearRewardData *__cdecl CBattle_Field::CBloodClearRewardData::setBloodClear(
        CBattle_Field::CBloodClearRewardData *this,
        bool a2)
{
  CBattle_Field::CBloodClearRewardData *this_1; // eax

  this_1 = this;
  *((_BYTE *)this + 20) = a2;
  return this_1;
}

// IDA_EA: 0x830EC94
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData26getUltimateRoundClearPointEv
// DEMANGLED: CBattle_Field::CBloodClearRewardData::getUltimateRoundClearPoint(void)
int __cdecl CBattle_Field::CBloodClearRewardData::getUltimateRoundClearPoint(
        CBattle_Field::CBloodClearRewardData *this)
{
  return *((_DWORD *)this + 626);
}

// IDA_EA: 0x85BF0E6
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData20getCurrentBloodRoundEv
// DEMANGLED: CBattle_Field::CBloodClearRewardData::getCurrentBloodRound(void)
int __cdecl CBattle_Field::CBloodClearRewardData::getCurrentBloodRound(CBattle_Field::CBloodClearRewardData *this)
{
  return *((_DWORD *)this + 2);
}

// IDA_EA: 0x85BF0F2
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData20setCurrentBloodRoundEi
// DEMANGLED: CBattle_Field::CBloodClearRewardData::setCurrentBloodRound(int)
CBattle_Field::CBloodClearRewardData *__cdecl CBattle_Field::CBloodClearRewardData::setCurrentBloodRound(
        CBattle_Field::CBloodClearRewardData *this,
        int BloodMaxRoundEv)
{
  CBattle_Field::CBloodClearRewardData *this_1; // eax

  this_1 = this;
  *((_DWORD *)this + 2) = BloodMaxRoundEv;
  return this_1;
}

// IDA_EA: 0x85BF100
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData18getRewardItemCountEi
// DEMANGLED: CBattle_Field::CBloodClearRewardData::getRewardItemCount(int)
int __cdecl CBattle_Field::CBloodClearRewardData::getRewardItemCount(
        CBattle_Field::CBloodClearRewardData *this,
        int a2)
{
  return *((_DWORD *)this + 154 * a2 + 10);
}

// IDA_EA: 0x85BF11A
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData13getRewardItemEi
// DEMANGLED: CBattle_Field::CBloodClearRewardData::getRewardItem(int)
char *__cdecl CBattle_Field::CBloodClearRewardData::getRewardItem(CBattle_Field::CBloodClearRewardData *this, int a2)
{
  return (char *)this + 616 * a2 + 44;
}

// IDA_EA: 0x85BF132
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData12getRewardExpEi
// DEMANGLED: CBattle_Field::CBloodClearRewardData::getRewardExp(int)
int __cdecl CBattle_Field::CBloodClearRewardData::getRewardExp(CBattle_Field::CBloodClearRewardData *this, int n3)
{
  return *((_DWORD *)this + n3 + 6);
}

// IDA_EA: 0x85BF144
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData12setRewardExpEij
// DEMANGLED: CBattle_Field::CBloodClearRewardData::setRewardExp(int,unsigned int)
CBattle_Field::CBloodClearRewardData *__cdecl CBattle_Field::CBloodClearRewardData::setRewardExp(
        CBattle_Field::CBloodClearRewardData *this,
        int n3,
        unsigned int n0xF4240)
{
  CBattle_Field::CBloodClearRewardData *this_1; // eax

  this_1 = this;
  *((_DWORD *)this + n3 + 6) = n0xF4240;
  return this_1;
}

// IDA_EA: 0x85BF15A
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData13setRewardItemEii
// DEMANGLED: CBattle_Field::CBloodClearRewardData::setRewardItem(int,int)
int __cdecl CBattle_Field::CBloodClearRewardData::setRewardItem(
        CBattle_Field::CBloodClearRewardData *this,
        int n3,
        int a3)
{
  int result; // eax

  result = a3;
  *((_DWORD *)this + 154 * n3 + 10) = a3;
  return result;
}

// IDA_EA: 0x85BF176
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData16setRewarItemCopyE10Inven_Itemii
// DEMANGLED: CBattle_Field::CBloodClearRewardData::setRewarItemCopy(Inven_Item,int,int)
Inven_Item *__cdecl CBattle_Field::CBloodClearRewardData::setRewarItemCopy(
        int a1,
        int a2,
        int a3,
        int a4,
        int a5,
        int a6,
        int a7,
        int a8,
        int a9,
        int a10,
        int a11,
        int a12,
        int a13,
        int a14,
        int a15,
        int a16,
        int a17,
        int n3,
        int a19)
{
  return Inven_Item::setCopy((Inven_Item *)(a1 + 61 * a19 + 616 * n3 + 32 + 12), (const Inven_Item *)&a2);
}

// IDA_EA: 0x85BF1A8
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData20setRewardItemAddInfoEfii
// DEMANGLED: CBattle_Field::CBloodClearRewardData::setRewardItemAddInfo(float,int,int)
Inven_Item *__cdecl CBattle_Field::CBloodClearRewardData::setRewardItemAddInfo(
        CBattle_Field::CBloodClearRewardData *this,
        float a2,
        int n3,
        int a4)
{
  long double v4; // fst7

  v4 = (long double)Inven_Item::get_add_info((CBattle_Field::CBloodClearRewardData *)((char *)this
                                                                                    + 616 * n3
                                                                                    + 61 * a4
                                                                                    + 44))
     * a2;
  return Inven_Item::set_add_info(
           (CBattle_Field::CBloodClearRewardData *)((char *)this + 616 * n3 + 61 * a4 + 44),
           (int)v4);
}

// IDA_EA: 0x85BF21C
// IDA_NAME: _ZN13CBattle_Field21CBloodClearRewardData12isBloodClearEv
// DEMANGLED: CBattle_Field::CBloodClearRewardData::isBloodClear(void)
int __cdecl CBattle_Field::CBloodClearRewardData::isBloodClear(CBattle_Field::CBloodClearRewardData *this)
{
  return *((unsigned __int8 *)this + 20);
}
