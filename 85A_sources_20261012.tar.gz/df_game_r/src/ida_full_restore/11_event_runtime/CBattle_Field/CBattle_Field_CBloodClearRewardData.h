#ifndef __IDA91_CBATTLE_FIELD_CBLOODCLEARREWARDDATA_H__
#define __IDA91_CBATTLE_FIELD_CBLOODCLEARREWARDDATA_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CBattle_Field
// Source unit: CBattle_Field_CBloodClearRewardData
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
//   #include "world/CDungeon.h"
// Local type ordinals: 2314,2315

/* 2314 */
struct CBattle_Field::CBloodClearRewardData::stRewardItem_t;

/* 2315 */
struct CBattle_Field::CBloodClearRewardData;

// Exported member functions:
// 0x82A4458	CBattle_Field::CBloodClearRewardData::stRewardItem_t::stRewardItem_t(void)
// 0x82A448E	CBattle_Field::CBloodClearRewardData::CBloodClearRewardData(void)
// 0x8306EE0	CBattle_Field::CBloodClearRewardData::reset(void)
// 0x8306F5C	CBattle_Field::CBloodClearRewardData::stRewardItem_t::reset(void)
// 0x8306FAA	CBattle_Field::CBloodClearRewardData::onStartBloodRound(void)
// 0x8306FC4	CBattle_Field::CBloodClearRewardData::onFinishBloodRound(bool,short,CParty *,CDungeon const*)
// 0x8307096	CBattle_Field::CBloodClearRewardData::incUltimateRoundClearPoint(int)
// 0x83070CA	CBattle_Field::CBloodClearRewardData::getUltimateRewardItem(void)
// 0x830EC3A	CBattle_Field::CBloodClearRewardData::addPlayTime(unsigned int)
// 0x830EC5A	CBattle_Field::CBloodClearRewardData::getPlayTime(void)
// 0x830EC64	CBattle_Field::CBloodClearRewardData::getBloodRoundClearTime(void)
// 0x830EC7C	CBattle_Field::CBloodClearRewardData::setBloodClear(bool)
// 0x830EC94	CBattle_Field::CBloodClearRewardData::getUltimateRoundClearPoint(void)
// 0x85BF0E6	CBattle_Field::CBloodClearRewardData::getCurrentBloodRound(void)
// 0x85BF0F2	CBattle_Field::CBloodClearRewardData::setCurrentBloodRound(int)
// 0x85BF100	CBattle_Field::CBloodClearRewardData::getRewardItemCount(int)
// 0x85BF11A	CBattle_Field::CBloodClearRewardData::getRewardItem(int)
// 0x85BF132	CBattle_Field::CBloodClearRewardData::getRewardExp(int)
// 0x85BF144	CBattle_Field::CBloodClearRewardData::setRewardExp(int,unsigned int)
// 0x85BF15A	CBattle_Field::CBloodClearRewardData::setRewardItem(int,int)
// 0x85BF176	CBattle_Field::CBloodClearRewardData::setRewarItemCopy(Inven_Item,int,int)
// 0x85BF1A8	CBattle_Field::CBloodClearRewardData::setRewardItemAddInfo(float,int,int)
// 0x85BF21C	CBattle_Field::CBloodClearRewardData::isBloodClear(void)

// Function declaration index:
// DECL 0x82A4458 CBattle_Field::CBloodClearRewardData::stRewardItem_t::stRewardItem_t
// DECL 0x82A448E CBattle_Field::CBloodClearRewardData::CBloodClearRewardData
// DECL 0x8306EE0 CBattle_Field::CBloodClearRewardData::reset
// DECL 0x8306F5C CBattle_Field::CBloodClearRewardData::stRewardItem_t::reset
// DECL 0x8306FAA CBattle_Field::CBloodClearRewardData::onStartBloodRound
// DECL 0x8306FC4 CBattle_Field::CBloodClearRewardData::onFinishBloodRound
// DECL 0x8307096 CBattle_Field::CBloodClearRewardData::incUltimateRoundClearPoint
// DECL 0x83070CA CBattle_Field::CBloodClearRewardData::getUltimateRewardItem
// DECL 0x830EC3A CBattle_Field::CBloodClearRewardData::addPlayTime
// DECL 0x830EC5A CBattle_Field::CBloodClearRewardData::getPlayTime
// DECL 0x830EC64 CBattle_Field::CBloodClearRewardData::getBloodRoundClearTime
// DECL 0x830EC7C CBattle_Field::CBloodClearRewardData::setBloodClear
// DECL 0x830EC94 CBattle_Field::CBloodClearRewardData::getUltimateRoundClearPoint
// DECL 0x85BF0E6 CBattle_Field::CBloodClearRewardData::getCurrentBloodRound
// DECL 0x85BF0F2 CBattle_Field::CBloodClearRewardData::setCurrentBloodRound
// DECL 0x85BF100 CBattle_Field::CBloodClearRewardData::getRewardItemCount
// DECL 0x85BF11A CBattle_Field::CBloodClearRewardData::getRewardItem
// DECL 0x85BF132 CBattle_Field::CBloodClearRewardData::getRewardExp
// DECL 0x85BF144 CBattle_Field::CBloodClearRewardData::setRewardExp
// DECL 0x85BF15A CBattle_Field::CBloodClearRewardData::setRewardItem
// DECL 0x85BF176 CBattle_Field::CBloodClearRewardData::setRewarItemCopy
// DECL 0x85BF1A8 CBattle_Field::CBloodClearRewardData::setRewardItemAddInfo
// DECL 0x85BF21C CBattle_Field::CBloodClearRewardData::isBloodClear

#endif  // __IDA91_CBATTLE_FIELD_CBLOODCLEARREWARDDATA_H__
