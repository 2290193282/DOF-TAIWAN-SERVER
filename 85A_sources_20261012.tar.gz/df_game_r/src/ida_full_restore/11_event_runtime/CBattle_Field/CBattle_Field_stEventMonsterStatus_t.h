#ifndef __IDA91_CBATTLE_FIELD_STEVENTMONSTERSTATUS_T_H__
#define __IDA91_CBATTLE_FIELD_STEVENTMONSTERSTATUS_T_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CBattle_Field
// Source unit: CBattle_Field_stEventMonsterStatus_t
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2320

/* 2320 */
struct CBattle_Field::stEventMonsterStatus_t;

// Exported member functions:
// 0x830EE4C	CBattle_Field::stEventMonsterStatus_t::stEventMonsterStatus_t(void)
// 0x8316ADC	CBattle_Field::stEventMonsterStatus_t::~stEventMonsterStatus_t()

// Function declaration index:
// DECL 0x830EE4C CBattle_Field::stEventMonsterStatus_t::stEventMonsterStatus_t
// DECL 0x8316ADC CBattle_Field::stEventMonsterStatus_t::~stEventMonsterStatus_t

#endif  // __IDA91_CBATTLE_FIELD_STEVENTMONSTERSTATUS_T_H__
