#ifndef __IDA91_CCOINEVENTONCHARCREATE_H__
#define __IDA91_CCOINEVENTONCHARCREATE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CCoinEventOnCharCreate
// Source unit: CCoinEventOnCharCreate
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2838

/* 2838 */
struct CCoinEventOnCharCreate;

// Exported member functions:
// 0x810A914	CCoinEventOnCharCreate::CCoinEventOnCharCreate(void)
// 0x810A93A	CCoinEventOnCharCreate::~CCoinEventOnCharCreate()
// 0x810A96A	CCoinEventOnCharCreate::~CCoinEventOnCharCreate()
// 0x810A988	CCoinEventOnCharCreate::StartEvent(void)
// 0x810A9E4	CCoinEventOnCharCreate::StartEvent(Word_Param)
// 0x810AA42	CCoinEventOnCharCreate::EndEvent(void)
// 0x848F200	CCoinEventOnCharCreate::GetCoinNoOnCreateCharac(void)

// Function declaration index:
// DECL 0x810A914 CCoinEventOnCharCreate::CCoinEventOnCharCreate
// DECL 0x810A93A CCoinEventOnCharCreate::~CCoinEventOnCharCreate
// DECL 0x810A96A CCoinEventOnCharCreate::~CCoinEventOnCharCreate
// DECL 0x810A988 CCoinEventOnCharCreate::StartEvent
// DECL 0x810A9E4 CCoinEventOnCharCreate::StartEvent
// DECL 0x810AA42 CCoinEventOnCharCreate::EndEvent
// DECL 0x848F200 CCoinEventOnCharCreate::GetCoinNoOnCreateCharac

#endif  // __IDA91_CCOINEVENTONCHARCREATE_H__
