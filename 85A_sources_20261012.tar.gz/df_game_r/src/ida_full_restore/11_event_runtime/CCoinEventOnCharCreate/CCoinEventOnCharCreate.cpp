#include "CCoinEventOnCharCreate.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x810A914
// IDA_NAME: _ZN22CCoinEventOnCharCreateC2Ev
// DEMANGLED: CCoinEventOnCharCreate::CCoinEventOnCharCreate(void)
void __cdecl CCoinEventOnCharCreate::CCoinEventOnCharCreate(CCoinEventOnCharCreate *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B4AC68;
  *((_DWORD *)this + 3) = 5;
}

// IDA_EA: 0x810A93A
// IDA_NAME: _ZN22CCoinEventOnCharCreateD2Ev
// DEMANGLED: CCoinEventOnCharCreate::~CCoinEventOnCharCreate()
void __cdecl CCoinEventOnCharCreate::~CCoinEventOnCharCreate(CCoinEventOnCharCreate *this)
{
  *(_DWORD *)this = off_8B4AC68;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x810A96A
// IDA_NAME: _ZN22CCoinEventOnCharCreateD0Ev
// DEMANGLED: CCoinEventOnCharCreate::~CCoinEventOnCharCreate()
void __cdecl CCoinEventOnCharCreate::~CCoinEventOnCharCreate(CCoinEventOnCharCreate *this)
{
  CCoinEventOnCharCreate::~CCoinEventOnCharCreate(this);
  operator delete(this);
}

// IDA_EA: 0x810A988
// IDA_NAME: _ZN22CCoinEventOnCharCreate10StartEventEv
// DEMANGLED: CCoinEventOnCharCreate::StartEvent(void)
int __cdecl CCoinEventOnCharCreate::StartEvent(CCoinEventOnCharCreate *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  *((_DWORD *)this + 3) = 5;
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 21, 0);
  return cMyTrace::operator()((int)v3, "Coin Event On Char Create Start!", v2);
}

// IDA_EA: 0x810A9E4
// IDA_NAME: _ZN22CCoinEventOnCharCreate10StartEventE10Word_Param
// DEMANGLED: CCoinEventOnCharCreate::StartEvent(Word_Param)
int __cdecl CCoinEventOnCharCreate::StartEvent(CEventBase *a1, unsigned __int16 a2)
{
  char v3; // [esp+8h] [ebp-20h]
  int v4[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  *((_DWORD *)a1 + 3) = a2;
  cMyTrace::cMyTrace((cMyTrace *)v4, "StartEvent", 28, 0);
  return cMyTrace::operator()((int)v4, "Coin Event On Char Create Start!", v3);
}

// IDA_EA: 0x810AA42
// IDA_NAME: _ZN22CCoinEventOnCharCreate8EndEventEv
// DEMANGLED: CCoinEventOnCharCreate::EndEvent(void)
int __cdecl CCoinEventOnCharCreate::EndEvent(CCoinEventOnCharCreate *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  *((_DWORD *)this + 3) = 5;
  cMyTrace::cMyTrace((cMyTrace *)v3, "EndEvent", 36, 0);
  return cMyTrace::operator()((int)v3, "Coin Event On Char Create End!", v2);
}

// IDA_EA: 0x848F200
// IDA_NAME: _ZN22CCoinEventOnCharCreate23GetCoinNoOnCreateCharacEv
// DEMANGLED: CCoinEventOnCharCreate::GetCoinNoOnCreateCharac(void)
int __cdecl CCoinEventOnCharCreate::GetCoinNoOnCreateCharac(CCoinEventOnCharCreate *this)
{
  return *((_DWORD *)this + 3);
}
