#include "CreateDnfEventSciprtServer.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x816451E
// IDA_NAME: _ZN26CreateDnfEventSciprtServer4LoadEv
// DEMANGLED: CreateDnfEventSciprtServer::Load(void)
_BOOL4 __cdecl CreateDnfEventSciprtServer::Load(CreateDnfEventSciprtServer *this)
{
  char v2; // [esp+8h] [ebp-30h]
  int v3[6]; // [esp+20h] [ebp-18h] BYREF

  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual bool CreateDnfEventSciprtServer::Load()", 208, 9, 1, 0);
  cMyTrace::operator()((int)v3, "\t- Loading EventCreateDnf script - ", v2);
  return CreateDnfEventSciprt::loadScript((CreateDnfEventSciprtServer *)((char *)this + 4)) == 0;
}

// IDA_EA: 0x8164590
// IDA_NAME: _ZN26CreateDnfEventSciprtServer7DestroyEv
// DEMANGLED: CreateDnfEventSciprtServer::Destroy(void)
int CreateDnfEventSciprtServer::Destroy()
{
  return 1;
}

// IDA_EA: 0x81648AC
// IDA_NAME: _ZN26CreateDnfEventSciprtServerC2Ev
// DEMANGLED: CreateDnfEventSciprtServer::CreateDnfEventSciprtServer(void)
void __cdecl CreateDnfEventSciprtServer::CreateDnfEventSciprtServer(CreateDnfEventSciprtServer *this)
{
  CreateDnfEventSciprt::CreateDnfEventSciprt((CreateDnfEventSciprtServer *)((char *)this + 4));
  ARAD::Singleton<CreateDnfEventSciprtServer>::Singleton(this);
  ARAD::ScriptInterface::ScriptInterface(this);
  *(_DWORD *)this = off_8B7CBA8;
}

// IDA_EA: 0x81648E2
// IDA_NAME: _ZN26CreateDnfEventSciprtServerD2Ev
// DEMANGLED: CreateDnfEventSciprtServer::~CreateDnfEventSciprtServer()
void __cdecl CreateDnfEventSciprtServer::~CreateDnfEventSciprtServer(_DWORD *a1)
{
  *a1 = off_8B7CBA8;
  CreateDnfEventSciprt::~CreateDnfEventSciprt((CreateDnfEventSciprt *)(a1 + 1));
}
