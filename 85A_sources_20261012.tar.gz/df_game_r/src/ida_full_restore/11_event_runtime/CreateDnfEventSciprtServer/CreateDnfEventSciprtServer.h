#ifndef __IDA91_CREATEDNFEVENTSCIPRTSERVER_H__
#define __IDA91_CREATEDNFEVENTSCIPRTSERVER_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CreateDnfEventSciprtServer
// Source unit: CreateDnfEventSciprtServer
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1347

/* 1347 */
struct CreateDnfEventSciprtServer;

// Exported member functions:
// 0x816451E	CreateDnfEventSciprtServer::Load(void)
// 0x8164590	CreateDnfEventSciprtServer::Destroy(void)
// 0x81648AC	CreateDnfEventSciprtServer::CreateDnfEventSciprtServer(void)
// 0x81648E2	CreateDnfEventSciprtServer::~CreateDnfEventSciprtServer()

// Function declaration index:
// DECL 0x816451E CreateDnfEventSciprtServer::Load
// DECL 0x8164590 CreateDnfEventSciprtServer::Destroy
// DECL 0x81648AC CreateDnfEventSciprtServer::CreateDnfEventSciprtServer
// DECL 0x81648E2 CreateDnfEventSciprtServer::~CreateDnfEventSciprtServer

#endif  // __IDA91_CREATEDNFEVENTSCIPRTSERVER_H__
