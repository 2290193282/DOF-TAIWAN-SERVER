#ifndef __IDA91_DB_INSERT0712WINTEREVENTCOUPON_H__
#define __IDA91_DB_INSERT0712WINTEREVENTCOUPON_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_Insert0712WinterEventCoupon
// Source unit: DB_Insert0712WinterEventCoupon
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "network/PacketGuard.h"
//   #include "network/PacketBuf.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2550

/* 2550 */
struct DB_Insert0712WinterEventCoupon;

// Exported member functions:
// 0x842E45E	DB_Insert0712WinterEventCoupon::dispatch(int,int,Stream *)
// 0x842E648	DB_Insert0712WinterEventCoupon::makeRequest(unsigned int,unsigned int,unsigned int)
// 0x842E6E0	DB_Insert0712WinterEventCoupon::_makeRequest(ENUM_INTERNALPACKET,unsigned int,unsigned int,unsigned int)
// 0x844EAD6	DB_Insert0712WinterEventCoupon::DB_Insert0712WinterEventCoupon(void)
// 0x845DFCC	DB_Insert0712WinterEventCoupon::~DB_Insert0712WinterEventCoupon()
// 0x845DFFC	DB_Insert0712WinterEventCoupon::~DB_Insert0712WinterEventCoupon()

// Function declaration index:
// DECL 0x842E45E DB_Insert0712WinterEventCoupon::dispatch
// DECL 0x842E648 DB_Insert0712WinterEventCoupon::makeRequest
// DECL 0x842E6E0 DB_Insert0712WinterEventCoupon::_makeRequest
// DECL 0x844EAD6 DB_Insert0712WinterEventCoupon::DB_Insert0712WinterEventCoupon
// DECL 0x845DFCC DB_Insert0712WinterEventCoupon::~DB_Insert0712WinterEventCoupon
// DECL 0x845DFFC DB_Insert0712WinterEventCoupon::~DB_Insert0712WinterEventCoupon

#endif  // __IDA91_DB_INSERT0712WINTEREVENTCOUPON_H__
