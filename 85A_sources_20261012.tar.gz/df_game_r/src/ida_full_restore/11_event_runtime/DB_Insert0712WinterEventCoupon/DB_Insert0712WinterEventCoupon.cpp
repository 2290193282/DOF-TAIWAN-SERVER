#include "DB_Insert0712WinterEventCoupon.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x842E45E
// IDA_NAME: _ZN30DB_Insert0712WinterEventCoupon8dispatchEiiP6Stream
// DEMANGLED: DB_Insert0712WinterEventCoupon::dispatch(int,int,Stream *)
int __cdecl DB_Insert0712WinterEventCoupon::dispatch(
        DB_Insert0712WinterEventCoupon *this,
        int n274,
        int a3,
        Stream *a4)
{
  const char *v4; // eax
  __int64 v5; // rax
  unsigned int v7; // ebx
  const char *v8; // eax
  const char *v9; // eax
  __int64 v10; // rax
  unsigned int v12; // ebx
  const char *v13; // eax
  unsigned int *Out; // [esp+14h] [ebp-14h]
  MySQL *DBHandle; // [esp+18h] [ebp-10h]
  MySQL *v17; // [esp+1Ch] [ebp-Ch]

  Out = (unsigned int *)Stream::GetOutBuffer<SIG_INSERT_0712_WINTER_EVENT_COUPON>(a4);
  if ( n274 == 274 )
  {
    DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
    v4 = (const char *)NumberToString(*Out, 0);
    MySQL::set_query(DBHandle, "upDate event_goldcard_info set coupon=coupon+%d where m_id=%s", Out[2], v4);
    if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 || (LODWORD(v5) = MySQL::getAffectedRowCount(DBHandle), !v5) )
    {
      v7 = Out[2];
      v8 = (const char *)NumberToString(*Out, 0);
      MySQL::set_query(DBHandle, "inSert into event_goldcard_info(m_id,coupon) values(%s,%d)", v8, v7);
      MySQL::exec(DBHandle, 1);
    }
  }
  else
  {
    v17 = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 4, 0);
    v9 = (const char *)NumberToString(*Out, 0);
    MySQL::set_query(v17, "upDate event_goldcard_log set cnt=cnt+%d where m_id=%s and occ_date=now()", Out[2], v9);
    if ( (unsigned __int8)MySQL::exec(v17, 1) != 1 || (LODWORD(v10) = MySQL::getAffectedRowCount(v17), !v10) )
    {
      v12 = Out[2];
      v13 = (const char *)NumberToString(*Out, 0);
      MySQL::set_query(v17, "inSert into event_goldcard_log(m_id,cnt,occ_date) values(%s,%d,now())", v13, v12);
      MySQL::exec(v17, 1);
    }
  }
  return 1;
}

// IDA_EA: 0x842E648
// IDA_NAME: _ZN30DB_Insert0712WinterEventCoupon11makeRequestEjjj
// DEMANGLED: DB_Insert0712WinterEventCoupon::makeRequest(unsigned int,unsigned int,unsigned int)
Stream *__cdecl DB_Insert0712WinterEventCoupon::makeRequest(
        DB_Insert0712WinterEventCoupon *this,
        unsigned int CurCharacNoEv,
        unsigned int a3)
{
  Stream *result; // eax

  result = (Stream *)DB_Insert0712WinterEventCoupon::_makeRequest(18, (int)this, CurCharacNoEv, a3);
  if ( result )
  {
    MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, result);
    result = (Stream *)DB_Insert0712WinterEventCoupon::_makeRequest(19, (int)this, CurCharacNoEv, a3);
    if ( result )
      return (Stream *)MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 4, result);
  }
  return result;
}

// IDA_EA: 0x842E6E0
// IDA_NAME: _ZN30DB_Insert0712WinterEventCoupon12_makeRequestE19ENUM_INTERNALPACKETjjj
// DEMANGLED: DB_Insert0712WinterEventCoupon::_makeRequest(ENUM_INTERNALPACKET,unsigned int,unsigned int,unsigned int)
int __cdecl DB_Insert0712WinterEventCoupon::_makeRequest(char src, int this, int CurCharacNoEv, int a4)
{
  Stream *v4; // eax
  Stream **v5; // eax
  Stream **v6; // eax
  Stream **v7; // eax
  int v8; // ebx
  Stream *v10[2]; // [esp+14h] [ebp-14h] BYREF
  _DWORD *v11; // [esp+1Ch] [ebp-Ch]

  v4 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 29489);
  CStreamGuard::CStreamGuard((CStreamGuard *)v10, v4, 0);
  v5 = (Stream **)CStreamGuard::operator*((int)v10);
  CStreamGuard::operator<<(v5, src);
  v6 = (Stream **)CStreamGuard::operator*((int)v10);
  CStreamGuard::operator<<(v6, -1);
  v7 = (Stream **)CStreamGuard::operator->((int)v10);
  v11 = (_DWORD *)CStreamGuard::GetInBuffer<SIG_INSERT_0712_WINTER_EVENT_COUPON>(v7);
  *v11 = this;
  v11[1] = CurCharacNoEv;
  v11[2] = a4;
  v8 = CStreamGuard::Get((CStreamGuard *)v10);
  CStreamGuard::~CStreamGuard(v10);
  return v8;
}

// IDA_EA: 0x844EAD6
// IDA_NAME: _ZN30DB_Insert0712WinterEventCouponC2Ev
// DEMANGLED: DB_Insert0712WinterEventCoupon::DB_Insert0712WinterEventCoupon(void)
void __cdecl DB_Insert0712WinterEventCoupon::DB_Insert0712WinterEventCoupon(DB_Insert0712WinterEventCoupon *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5F048;
}

// IDA_EA: 0x845DFCC
// IDA_NAME: _ZN30DB_Insert0712WinterEventCouponD2Ev
// DEMANGLED: DB_Insert0712WinterEventCoupon::~DB_Insert0712WinterEventCoupon()
void __cdecl DB_Insert0712WinterEventCoupon::~DB_Insert0712WinterEventCoupon(DB_Insert0712WinterEventCoupon *this)
{
  *(_DWORD *)this = &off_8C5F048;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845DFFC
// IDA_NAME: _ZN30DB_Insert0712WinterEventCouponD0Ev
// DEMANGLED: DB_Insert0712WinterEventCoupon::~DB_Insert0712WinterEventCoupon()
void __cdecl DB_Insert0712WinterEventCoupon::~DB_Insert0712WinterEventCoupon(DB_Insert0712WinterEventCoupon *this)
{
  DB_Insert0712WinterEventCoupon::~DB_Insert0712WinterEventCoupon(this);
  operator delete(this);
}
