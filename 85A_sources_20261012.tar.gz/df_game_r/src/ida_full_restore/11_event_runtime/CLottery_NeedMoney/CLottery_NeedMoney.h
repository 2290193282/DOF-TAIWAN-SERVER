#ifndef __IDA91_CLOTTERY_NEEDMONEY_H__
#define __IDA91_CLOTTERY_NEEDMONEY_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CLottery_NeedMoney
// Source unit: CLottery_NeedMoney
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4503

/* 4503 */
struct CLottery_NeedMoney;

// Exported member functions:
// 0x8365066	CLottery_NeedMoney::add_lottery_needMoney(unsigned int,unsigned int)
// 0x8365162	CLottery_NeedMoney::isNeedMoney(unsigned int)const
// 0x837DD28	CLottery_NeedMoney::CLottery_NeedMoney(void)
// 0x837DD3C	CLottery_NeedMoney::~CLottery_NeedMoney()

// Function declaration index:
// DECL 0x8365066 CLottery_NeedMoney::add_lottery_needMoney
// DECL 0x8365162 CLottery_NeedMoney::isNeedMoney
// DECL 0x837DD28 CLottery_NeedMoney::CLottery_NeedMoney
// DECL 0x837DD3C CLottery_NeedMoney::~CLottery_NeedMoney

#endif  // __IDA91_CLOTTERY_NEEDMONEY_H__
