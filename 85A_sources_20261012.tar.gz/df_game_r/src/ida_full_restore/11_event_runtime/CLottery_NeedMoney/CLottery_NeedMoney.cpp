#include "CLottery_NeedMoney.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8365066
// IDA_NAME: _ZN18CLottery_NeedMoney21add_lottery_needMoneyEjj
// DEMANGLED: CLottery_NeedMoney::add_lottery_needMoney(unsigned int,unsigned int)
void __cdecl CLottery_NeedMoney::add_lottery_needMoney()
{
  int _ZZN18CLottery_NeedMoney21add_lottery_needMoneyEjjE4_itr; // [esp+1Ch] [ebp-2Ch] BYREF
  int v1; // [esp+20h] [ebp-28h] BYREF
  char v2; // [esp+27h] [ebp-21h] BYREF
  _BYTE v3[8]; // [esp+28h] [ebp-20h] BYREF
  int v4; // [esp+30h] [ebp-18h] BYREF
  unsigned int __t[4]; // [esp+38h] [ebp-10h] BYREF

  if ( !(_BYTE)`guard variable for'CLottery_NeedMoney::add_lottery_needMoney(unsigned int,unsigned int)::_itr
    && _cxa_guard_acquire(&`guard variable for'CLottery_NeedMoney::add_lottery_needMoney(unsigned int,unsigned int)::_itr) )
  {
    std::_Rb_tree_iterator<std::pair<unsigned int const,unsigned int>>::_Rb_tree_iterator(&CLottery_NeedMoney::add_lottery_needMoney(unsigned int,unsigned int)::_itr);
    _cxa_guard_release(&`guard variable for'CLottery_NeedMoney::add_lottery_needMoney(unsigned int,unsigned int)::_itr);
  }
  std::map<unsigned int,unsigned int>::end((int)&v1);
  std::map<unsigned int,unsigned int>::find((int)&_ZZN18CLottery_NeedMoney21add_lottery_needMoneyEjjE4_itr);
  CLottery_NeedMoney::add_lottery_needMoney(unsigned int,unsigned int)::_itr = _ZZN18CLottery_NeedMoney21add_lottery_needMoneyEjjE4_itr;
  if ( std::_Rb_tree_iterator<std::pair<unsigned int const,unsigned int>>::operator!=(
         &CLottery_NeedMoney::add_lottery_needMoney(unsigned int,unsigned int)::_itr,
         &v1) )
  {
    cMyTraceNoop::cMyTraceNoop((cMyTraceNoop *)&v2);
    cMyTraceNoop::operator()();
  }
  else
  {
    std::make_pair<unsigned int &,unsigned int &>(__t);
    std::pair<unsigned int const,unsigned int>::pair<unsigned int,unsigned int>((int)&v4, __t);
    std::map<unsigned int,unsigned int>::insert((int)v3);
  }
}

// IDA_EA: 0x8365162
// IDA_NAME: _ZNK18CLottery_NeedMoney11isNeedMoneyEj
// DEMANGLED: CLottery_NeedMoney::isNeedMoney(unsigned int)const
int __cdecl CLottery_NeedMoney::isNeedMoney()
{
  int v1[4]; // [esp+1Ch] [ebp-1Ch] BYREF
  _BYTE v2[12]; // [esp+2Ch] [ebp-Ch] BYREF

  if ( !(_BYTE)`guard variable for'CLottery_NeedMoney::isNeedMoney(unsigned int)::_itr
    && _cxa_guard_acquire(&`guard variable for'CLottery_NeedMoney::isNeedMoney(unsigned int)::_itr) )
  {
    std::_Rb_tree_const_iterator<std::pair<unsigned int const,unsigned int>>::_Rb_tree_const_iterator(&CLottery_NeedMoney::isNeedMoney(unsigned int)const::_itr);
    _cxa_guard_release(&`guard variable for'CLottery_NeedMoney::isNeedMoney(unsigned int)::_itr);
  }
  std::map<unsigned int,unsigned int>::find(v1);
  CLottery_NeedMoney::isNeedMoney(unsigned int)const::_itr = v1[0];
  std::map<unsigned int,unsigned int>::end(v2);
  if ( (unsigned __int8)std::_Rb_tree_const_iterator<std::pair<unsigned int const,unsigned int>>::operator!=(
                          v2,
                          &CLottery_NeedMoney::isNeedMoney(unsigned int)const::_itr) )
    return *(_DWORD *)(std::_Rb_tree_const_iterator<std::pair<unsigned int const,unsigned int>>::operator->(&CLottery_NeedMoney::isNeedMoney(unsigned int)const::_itr)
                     + 4);
  else
    return 0;
}

// IDA_EA: 0x837DD28
// IDA_NAME: _ZN18CLottery_NeedMoneyC2Ev
// DEMANGLED: CLottery_NeedMoney::CLottery_NeedMoney(void)
void __cdecl CLottery_NeedMoney::CLottery_NeedMoney(CLottery_NeedMoney *this)
{
  std::map<unsigned int,unsigned int>::map((int)this);
}

// IDA_EA: 0x837DD3C
// IDA_NAME: _ZN18CLottery_NeedMoneyD2Ev
// DEMANGLED: CLottery_NeedMoney::~CLottery_NeedMoney()
void __cdecl CLottery_NeedMoney::~CLottery_NeedMoney(CLottery_NeedMoney *this)
{
  std::map<unsigned int,unsigned int>::~map((int)this);
}
