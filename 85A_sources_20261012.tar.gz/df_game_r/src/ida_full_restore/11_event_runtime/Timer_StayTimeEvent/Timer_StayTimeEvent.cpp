#include "Timer_StayTimeEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x863B928
// IDA_NAME: _ZN19Timer_StayTimeEvent12dispatch_sigEiij
// DEMANGLED: Timer_StayTimeEvent::dispatch_sig(int,int,unsigned int)
int Timer_StayTimeEvent::dispatch_sig()
{
  time_t v1; // ebx
  int RewardStayTimeEv; // eax
  int v3; // eax
  int v5; // [esp+14h] [ebp-14h] BYREF
  CEventStayTime *RepeatEvent; // [esp+1Ch] [ebp-Ch]

  RepeatEvent = (CEventStayTime *)CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 159);
  if ( RepeatEvent
    && (*(unsigned __int8 (__cdecl **)(CEventStayTime *, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) )
  {
    v1 = time(0);
    RewardStayTimeEv = CEventStayTime::getRewardStayTime(RepeatEvent);
    CEventStayTime::RewardGoGoFighter::RewardGoGoFighter((CEventStayTime::RewardGoGoFighter *)&v5, RewardStayTimeEv, v1);
    v3 = G_GameWorld();
    GameWorld::ProcessAllUsers<CEventStayTime::RewardGoGoFighter>(v3, v5);
    CEventStayTime::RegistNextTimer(RepeatEvent);
  }
  return 1;
}

// IDA_EA: 0x863D166
// IDA_NAME: _ZN19Timer_StayTimeEventC2Ev
// DEMANGLED: Timer_StayTimeEvent::Timer_StayTimeEvent(void)
void __cdecl Timer_StayTimeEvent::Timer_StayTimeEvent(Timer_StayTimeEvent *this)
{
  TimerSig::TimerSig(this);
  *(_DWORD *)this = &off_8CE85E0;
}

// IDA_EA: 0x863E43C
// IDA_NAME: _ZN19Timer_StayTimeEventD2Ev
// DEMANGLED: Timer_StayTimeEvent::~Timer_StayTimeEvent()
void __cdecl Timer_StayTimeEvent::~Timer_StayTimeEvent(Timer_StayTimeEvent *this)
{
  *(_DWORD *)this = &off_8CE85E0;
  TimerSig::~TimerSig(this);
}

// IDA_EA: 0x863E46C
// IDA_NAME: _ZN19Timer_StayTimeEventD0Ev
// DEMANGLED: Timer_StayTimeEvent::~Timer_StayTimeEvent()
void __cdecl Timer_StayTimeEvent::~Timer_StayTimeEvent(Timer_StayTimeEvent *this)
{
  Timer_StayTimeEvent::~Timer_StayTimeEvent(this);
  operator delete(this);
}
