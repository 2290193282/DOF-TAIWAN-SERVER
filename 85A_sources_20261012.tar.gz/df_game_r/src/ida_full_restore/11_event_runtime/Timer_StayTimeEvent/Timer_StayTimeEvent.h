#ifndef __IDA91_TIMER_STAYTIMEEVENT_H__
#define __IDA91_TIMER_STAYTIMEEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Timer_StayTimeEvent
// Source unit: Timer_StayTimeEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3592

/* 3592 */
struct Timer_StayTimeEvent;

// Exported member functions:
// 0x863B928	Timer_StayTimeEvent::dispatch_sig(int,int,unsigned int)
// 0x863D166	Timer_StayTimeEvent::Timer_StayTimeEvent(void)
// 0x863E43C	Timer_StayTimeEvent::~Timer_StayTimeEvent()
// 0x863E46C	Timer_StayTimeEvent::~Timer_StayTimeEvent()

// Function declaration index:
// DECL 0x863B928 Timer_StayTimeEvent::dispatch_sig
// DECL 0x863D166 Timer_StayTimeEvent::Timer_StayTimeEvent
// DECL 0x863E43C Timer_StayTimeEvent::~Timer_StayTimeEvent
// DECL 0x863E46C Timer_StayTimeEvent::~Timer_StayTimeEvent

#endif  // __IDA91_TIMER_STAYTIMEEVENT_H__
