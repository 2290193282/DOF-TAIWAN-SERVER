#ifndef __IDA91_CEVENTADVANCEALTAROPEN_H__
#define __IDA91_CEVENTADVANCEALTAROPEN_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CEventAdvanceAltarOpen
// Source unit: CEventAdvanceAltarOpen
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1142

/* 1142 */
struct CEventAdvanceAltarOpen;

// Exported member functions:
// 0x80E94DC	CEventAdvanceAltarOpen::StartEvent(void)
// 0x80E94E2	CEventAdvanceAltarOpen::StartEvent(Word_Param)
// 0x80E9534	CEventAdvanceAltarOpen::EndEvent(void)
// 0x80E95E2	CEventAdvanceAltarOpen::~CEventAdvanceAltarOpen()
// 0x80E9612	CEventAdvanceAltarOpen::~CEventAdvanceAltarOpen()
// 0x8116B2C	CEventAdvanceAltarOpen::CEventAdvanceAltarOpen(void)

// Function declaration index:
// DECL 0x80E94DC CEventAdvanceAltarOpen::StartEvent
// DECL 0x80E94E2 CEventAdvanceAltarOpen::StartEvent
// DECL 0x80E9534 CEventAdvanceAltarOpen::EndEvent
// DECL 0x80E95E2 CEventAdvanceAltarOpen::~CEventAdvanceAltarOpen
// DECL 0x80E9612 CEventAdvanceAltarOpen::~CEventAdvanceAltarOpen
// DECL 0x8116B2C CEventAdvanceAltarOpen::CEventAdvanceAltarOpen

#endif  // __IDA91_CEVENTADVANCEALTAROPEN_H__
