#include "CEventAdvanceAltarOpen.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x80E94DC
// IDA_NAME: _ZN22CEventAdvanceAltarOpen10StartEventEv
// DEMANGLED: CEventAdvanceAltarOpen::StartEvent(void)
void CEventAdvanceAltarOpen::StartEvent()
{
  ;
}

// IDA_EA: 0x80E94E2
// IDA_NAME: _ZN22CEventAdvanceAltarOpen10StartEventE10Word_Param
// DEMANGLED: CEventAdvanceAltarOpen::StartEvent(Word_Param)
int __cdecl CEventAdvanceAltarOpen::StartEvent(CEventBase *a1)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CEventAdvanceAltarOpen::StartEvent(Word_Param)", 1166, 0);
  return cMyTrace::operator()((int)v3, "CEventAdvanceAltarOpen Event Start! ", v2);
}

// IDA_EA: 0x80E9534
// IDA_NAME: _ZN22CEventAdvanceAltarOpen8EndEventEv
// DEMANGLED: CEventAdvanceAltarOpen::EndEvent(void)
int __cdecl CEventAdvanceAltarOpen::EndEvent(CEventAdvanceAltarOpen *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CEventAdvanceAltarOpen::EndEvent()", 1172, 0);
  return cMyTrace::operator()((int)v3, "CEventAdvanceAltarOpen Event End!", v2);
}

// IDA_EA: 0x80E95E2
// IDA_NAME: _ZN22CEventAdvanceAltarOpenD2Ev
// DEMANGLED: CEventAdvanceAltarOpen::~CEventAdvanceAltarOpen()
void __cdecl CEventAdvanceAltarOpen::~CEventAdvanceAltarOpen(CEventAdvanceAltarOpen *this)
{
  *(_DWORD *)this = off_8B314E8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x80E9612
// IDA_NAME: _ZN22CEventAdvanceAltarOpenD0Ev
// DEMANGLED: CEventAdvanceAltarOpen::~CEventAdvanceAltarOpen()
void __cdecl CEventAdvanceAltarOpen::~CEventAdvanceAltarOpen(CEventAdvanceAltarOpen *this)
{
  CEventAdvanceAltarOpen::~CEventAdvanceAltarOpen(this);
  operator delete(this);
}

// IDA_EA: 0x8116B2C
// IDA_NAME: _ZN22CEventAdvanceAltarOpenC2Ev
// DEMANGLED: CEventAdvanceAltarOpen::CEventAdvanceAltarOpen(void)
void __cdecl CEventAdvanceAltarOpen::CEventAdvanceAltarOpen(CEventAdvanceAltarOpen *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B314E8;
}
