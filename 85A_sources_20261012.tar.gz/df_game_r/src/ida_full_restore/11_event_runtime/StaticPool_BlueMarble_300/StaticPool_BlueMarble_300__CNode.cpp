#include "StaticPool_BlueMarble_300__CNode.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x82AF8C6
// IDA_NAME: _ZN10StaticPoolI10BlueMarbleLi300EE5CNodeD2Ev
// DEMANGLED: StaticPool<BlueMarble,300>::CNode::~CNode()
void __cdecl StaticPool<BlueMarble,300>::CNode::~CNode(void **a1)
{
  BlueMarble::~BlueMarble(a1);
}

// IDA_EA: 0x82B971E
// IDA_NAME: _ZN10StaticPoolI10BlueMarbleLi300EE5CNodeC2Ev
// DEMANGLED: StaticPool<BlueMarble,300>::CNode::CNode(void)
BlueMarble *__cdecl StaticPool<BlueMarble,300>::CNode::CNode(BlueMarble *a1)
{
  BlueMarble *result; // eax

  BlueMarble::BlueMarble(a1);
  *((_DWORD *)a1 + 16) = 36641;
  result = a1;
  *((_BYTE *)a1 + 68) = 0;
  return result;
}
