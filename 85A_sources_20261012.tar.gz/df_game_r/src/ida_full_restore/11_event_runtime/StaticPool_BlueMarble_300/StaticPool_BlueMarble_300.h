#ifndef __IDA91_STATICPOOL_BLUEMARBLE_300_H__
#define __IDA91_STATICPOOL_BLUEMARBLE_300_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: StaticPool<BlueMarble,300>
// Source unit: StaticPool<BlueMarble,300>
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// No matching local type was found; declare types manually during cleanup.

// Exported member functions:
// 0x82AF8DA	StaticPool<BlueMarble,300>::StaticPool(void)
// 0x82AFA8C	StaticPool<BlueMarble,300>::~StaticPool()
// 0x82B4542	StaticPool<BlueMarble,300>::Acquire(void)
// 0x82B465E	StaticPool<BlueMarble,300>::GetIndex(BlueMarble*)
// 0x82B4874	StaticPool<BlueMarble,300>::Free(BlueMarble*)

// Function declaration index:
// DECL 0x82AF8DA StaticPool<BlueMarble,300>::StaticPool
// DECL 0x82AFA8C StaticPool<BlueMarble,300>::~StaticPool
// DECL 0x82B4542 StaticPool<BlueMarble,300>::Acquire
// DECL 0x82B465E StaticPool<BlueMarble,300>::GetIndex
// DECL 0x82B4874 StaticPool<BlueMarble,300>::Free

#endif  // __IDA91_STATICPOOL_BLUEMARBLE_300_H__
