#ifndef __IDA91_STATICPOOL_BLUEMARBLE_300_CNODE_H__
#define __IDA91_STATICPOOL_BLUEMARBLE_300_CNODE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: StaticPool<BlueMarble,300>
// Source unit: StaticPool<BlueMarble,300>_CNode
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// No matching local type was found; declare types manually during cleanup.

// Exported member functions:
// 0x82AF8C6	StaticPool<BlueMarble,300>::CNode::~CNode()
// 0x82B971E	StaticPool<BlueMarble,300>::CNode::CNode(void)

// Function declaration index:
// DECL 0x82AF8C6 StaticPool<BlueMarble,300>::CNode::~CNode
// DECL 0x82B971E StaticPool<BlueMarble,300>::CNode::CNode

#endif  // __IDA91_STATICPOOL_BLUEMARBLE_300_CNODE_H__
