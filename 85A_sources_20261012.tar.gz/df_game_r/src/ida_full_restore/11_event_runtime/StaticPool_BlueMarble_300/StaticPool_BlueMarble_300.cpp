#include "StaticPool_BlueMarble_300.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x82AF8DA
// IDA_NAME: _ZN10StaticPoolI10BlueMarbleLi300EEC2Ev
// DEMANGLED: StaticPool<BlueMarble,300>::StaticPool(void)
_DWORD *__cdecl StaticPool<BlueMarble,300>::StaticPool(_DWORD *a1)
{
  _DWORD *v1; // ebx
  int n299; // esi
  _DWORD *result; // eax
  BlueMarble *v4; // [esp+14h] [ebp-64h]
  _BYTE v5[40]; // [esp+20h] [ebp-58h] BYREF
  int v6[4]; // [esp+48h] [ebp-30h] BYREF
  int v7; // [esp+58h] [ebp-20h] BYREF
  int n299_1; // [esp+5Ch] [ebp-1Ch]

  std::deque<StaticPool<BlueMarble,300>::CNode *,std::allocator<StaticPool<BlueMarble,300>::CNode *>>::deque(v5);
  std::queue<StaticPool<BlueMarble,300>::CNode *,std::deque<StaticPool<BlueMarble,300>::CNode *,std::allocator<StaticPool<BlueMarble,300>::CNode *>>>::queue(
    a1 + 1,
    v5);
  std::deque<StaticPool<BlueMarble,300>::CNode *,std::allocator<StaticPool<BlueMarble,300>::CNode *>>::~deque(v5);
  v1 = (_DWORD *)operator new[](0x5464u);
  *v1 = 300;
  v4 = (BlueMarble *)(v1 + 1);
  for ( n299 = 299; n299 != -1; --n299 )
  {
    StaticPool<BlueMarble,300>::CNode::CNode(v4);
    v4 = (BlueMarble *)((char *)v4 + 72);
  }
  *a1 = v1 + 1;
  if ( !*a1 )
  {
    cMyTrace::cMyTrace((cMyTrace *)v6, "StaticPool", 108, 5);
    cMyTrace::operator()((int)v6, "[%s][%d]", (char)"StaticPool");
  }
  for ( n299_1 = 0; n299_1 <= 299; ++n299_1 )
  {
    v7 = *a1 + 72 * n299_1;
    std::queue<StaticPool<BlueMarble,300>::CNode *,std::deque<StaticPool<BlueMarble,300>::CNode *,std::allocator<StaticPool<BlueMarble,300>::CNode *>>>::push(
      a1 + 1,
      &v7);
  }
  result = a1;
  a1[11] = 0;
  return result;
}

// IDA_EA: 0x82AFA8C
// IDA_NAME: _ZN10StaticPoolI10BlueMarbleLi300EED2Ev
// DEMANGLED: StaticPool<BlueMarble,300>::~StaticPool()
int __cdecl StaticPool<BlueMarble,300>::~StaticPool(void ***a1)
{
  void **i; // ebx

  if ( *a1 )
  {
    for ( i = &(*a1)[18 * (_DWORD)*(*a1 - 1)]; i != *a1; StaticPool<BlueMarble,300>::CNode::~CNode(i) )
      i -= 18;
    operator delete[](*a1 - 1);
  }
  return std::queue<StaticPool<BlueMarble,300>::CNode *,std::deque<StaticPool<BlueMarble,300>::CNode *,std::allocator<StaticPool<BlueMarble,300>::CNode *>>>::~queue((int)(a1 + 1));
}

// IDA_EA: 0x82B4542
// IDA_NAME: _ZN10StaticPoolI10BlueMarbleLi300EE7AcquireEv
// DEMANGLED: StaticPool<BlueMarble,300>::Acquire(void)
int __cdecl StaticPool<BlueMarble,300>::Acquire(int a1)
{
  int v2; // ebx
  char v3; // bl
  int v4[4]; // [esp+1Ch] [ebp-2Ch] BYREF
  int v5[4]; // [esp+2Ch] [ebp-1Ch] BYREF
  int v6; // [esp+3Ch] [ebp-Ch]

  if ( (unsigned __int8)std::queue<StaticPool<BlueMarble,300>::CNode *,std::deque<StaticPool<BlueMarble,300>::CNode *,std::allocator<StaticPool<BlueMarble,300>::CNode *>>>::empty(a1 + 4) )
    return 0;
  v6 = *(_DWORD *)std::queue<StaticPool<BlueMarble,300>::CNode *,std::deque<StaticPool<BlueMarble,300>::CNode *,std::allocator<StaticPool<BlueMarble,300>::CNode *>>>::front(a1 + 4);
  std::queue<StaticPool<BlueMarble,300>::CNode *,std::deque<StaticPool<BlueMarble,300>::CNode *,std::allocator<StaticPool<BlueMarble,300>::CNode *>>>::pop(a1 + 4);
  if ( *(_DWORD *)(v6 + 64) != 36641 )
  {
    v2 = *(_DWORD *)(v6 + 64);
    cMyTrace::cMyTrace((cMyTrace *)v4, "Acquire", 137, 0);
    cMyTrace::operator()((int)v4, "STATIC MEMORY_POOL Acquire error dummy(%x), node(%x)", v2);
    *(_DWORD *)(a1 + 44) = 3;
  }
  if ( *(_BYTE *)(v6 + 68) )
  {
    v3 = *(_BYTE *)(v6 + 68);
    cMyTrace::cMyTrace((cMyTrace *)v5, "Acquire", 143, 0);
    cMyTrace::operator()((int)v5, "STATIC MEMORY_POOL Acquire error reference count(%d), node(%x)", v3);
    *(_DWORD *)(a1 + 44) = 4;
  }
  ++*(_BYTE *)(v6 + 68);
  return v6;
}

// IDA_EA: 0x82B465E
// IDA_NAME: _ZN10StaticPoolI10BlueMarbleLi300EE8GetIndexEPS0_
// DEMANGLED: StaticPool<BlueMarble,300>::GetIndex(BlueMarble*)
int __cdecl StaticPool<BlueMarble,300>::GetIndex(unsigned int *a1, unsigned int a2)
{
  int v3; // ebx
  char v4; // bl
  int v5[4]; // [esp+24h] [ebp-34h] BYREF
  int v6[4]; // [esp+34h] [ebp-24h] BYREF
  unsigned int v7; // [esp+44h] [ebp-14h]
  signed int n299; // [esp+48h] [ebp-10h]
  unsigned int v9; // [esp+4Ch] [ebp-Ch]

  if ( a2 < *a1 )
    return -1;
  v7 = a2 - *a1;
  n299 = 0;
  if ( v7 )
    n299 = v7 / 0x48;
  v9 = a2;
  if ( *(_DWORD *)(a2 + 64) != 36641 )
  {
    v3 = *(_DWORD *)(v9 + 64);
    cMyTrace::cMyTrace((cMyTrace *)v5, "GetIndex", 80, 0);
    cMyTrace::operator()((int)v5, "STATIC MEMORY_POOL GetIndex error dummy(%x), node(%x)", v3);
    a1[11] = 1;
  }
  if ( *(_BYTE *)(v9 + 68) != 1 )
  {
    v4 = *(_BYTE *)(v9 + 68);
    cMyTrace::cMyTrace((cMyTrace *)v6, "GetIndex", 86, 0);
    cMyTrace::operator()((int)v6, "STATIC MEMORY_POOL GetIndex error reference count(%d), node(%x)", v4);
    a1[11] = 2;
  }
  if ( n299 <= 299 )
    return n299;
  else
    return -1;
}

// IDA_EA: 0x82B4874
// IDA_NAME: _ZN10StaticPoolI10BlueMarbleLi300EE4FreeEPS0_
// DEMANGLED: StaticPool<BlueMarble,300>::Free(BlueMarble*)
int __cdecl StaticPool<BlueMarble,300>::Free(int a1, int a2)
{
  int v2; // ebx
  char v3; // bl
  int result; // eax
  int v5; // [esp+1Ch] [ebp-3Ch] BYREF
  int v6[4]; // [esp+20h] [ebp-38h] BYREF
  int v7[4]; // [esp+30h] [ebp-28h] BYREF
  int v8[6]; // [esp+40h] [ebp-18h] BYREF

  if ( !a2 )
  {
    cMyTrace::cMyTrace((cMyTrace *)v6, "Free", 160, 5);
    cMyTrace::operator()((int)v6, "[%s][%d]", (char)"Free");
  }
  v5 = a2;
  std::queue<StaticPool<BlueMarble,300>::CNode *,std::deque<StaticPool<BlueMarble,300>::CNode *,std::allocator<StaticPool<BlueMarble,300>::CNode *>>>::push(
    a1 + 4,
    &v5);
  if ( *(_DWORD *)(v5 + 64) != 36641 )
  {
    v2 = *(_DWORD *)(v5 + 64);
    cMyTrace::cMyTrace((cMyTrace *)v7, "Free", 170, 0);
    cMyTrace::operator()((int)v7, "STATIC MEMORY_POOL Free error dummy(%x), node(%x)", v2);
    *(_DWORD *)(a1 + 44) = 5;
  }
  if ( *(_BYTE *)(v5 + 68) != 1 )
  {
    v3 = *(_BYTE *)(v5 + 68);
    cMyTrace::cMyTrace((cMyTrace *)v8, "Free", 176, 0);
    cMyTrace::operator()((int)v8, "STATIC MEMORY_POOL Free error reference count(%d), node(%x)", v3);
    *(_DWORD *)(a1 + 44) = 6;
    PrintBackTrace();
  }
  result = v5;
  --*(_BYTE *)(v5 + 68);
  return result;
}
