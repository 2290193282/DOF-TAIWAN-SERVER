#ifndef __IDA91_CEVENTCREATEDNF_H__
#define __IDA91_CEVENTCREATEDNF_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CEventCreateDnf
// Source unit: CEventCreateDnf
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 1346

/* 1346 */
struct CEventCreateDnf;

// Exported member functions:
// 0x8163AA4	CEventCreateDnf::CEventCreateDnf(void)
// 0x8163AE8	CEventCreateDnf::~CEventCreateDnf()
// 0x8163B18	CEventCreateDnf::~CEventCreateDnf()
// 0x8163B36	CEventCreateDnf::StartEvent(void)
// 0x8163BE0	CEventCreateDnf::StartEvent(Word_Param)
// 0x8163CD0	CEventCreateDnf::EndEvent(void)
// 0x8163D4C	CEventCreateDnf::RegistNextTimer(void)
// 0x8163E7C	CEventCreateDnf::RegistStartTimer(bool)
// 0x8164092	CEventCreateDnf::IsRewardCondition(void)
// 0x81640D4	CEventCreateDnf::SetEventInfo(int,int,int)
// 0x8164246	CEventCreateDnf::GetState(void)
// 0x8164252	CEventCreateDnf::setState(CEventCreateDnf::State::T)
// 0x8164260	CEventCreateDnf::GetRate(void)
// 0x816426C	CEventCreateDnf::SendReward(CUser *)

// Function declaration index:
// DECL 0x8163AA4 CEventCreateDnf::CEventCreateDnf
// DECL 0x8163AE8 CEventCreateDnf::~CEventCreateDnf
// DECL 0x8163B18 CEventCreateDnf::~CEventCreateDnf
// DECL 0x8163B36 CEventCreateDnf::StartEvent
// DECL 0x8163BE0 CEventCreateDnf::StartEvent
// DECL 0x8163CD0 CEventCreateDnf::EndEvent
// DECL 0x8163D4C CEventCreateDnf::RegistNextTimer
// DECL 0x8163E7C CEventCreateDnf::RegistStartTimer
// DECL 0x8164092 CEventCreateDnf::IsRewardCondition
// DECL 0x81640D4 CEventCreateDnf::SetEventInfo
// DECL 0x8164246 CEventCreateDnf::GetState
// DECL 0x8164252 CEventCreateDnf::setState
// DECL 0x8164260 CEventCreateDnf::GetRate
// DECL 0x816426C CEventCreateDnf::SendReward

#endif  // __IDA91_CEVENTCREATEDNF_H__
