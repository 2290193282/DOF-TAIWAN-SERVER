#include "CEventCreateDnf.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8163AA4
// IDA_NAME: _ZN15CEventCreateDnfC2Ev
// DEMANGLED: CEventCreateDnf::CEventCreateDnf(void)
void __cdecl CEventCreateDnf::CEventCreateDnf(CEventCreateDnf *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B7CBC8;
  *((_DWORD *)this + 3) = 0;
  *((_BYTE *)this + 16) = 0;
  *((_BYTE *)this + 17) = 0;
  *((_WORD *)this + 9) = 0;
  *((_BYTE *)this + 20) = 0;
}

// IDA_EA: 0x8163AE8
// IDA_NAME: _ZN15CEventCreateDnfD2Ev
// DEMANGLED: CEventCreateDnf::~CEventCreateDnf()
void __cdecl CEventCreateDnf::~CEventCreateDnf(CEventCreateDnf *this)
{
  *(_DWORD *)this = off_8B7CBC8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x8163B18
// IDA_NAME: _ZN15CEventCreateDnfD0Ev
// DEMANGLED: CEventCreateDnf::~CEventCreateDnf()
void __cdecl CEventCreateDnf::~CEventCreateDnf(CEventCreateDnf *this)
{
  CEventCreateDnf::~CEventCreateDnf(this);
  operator delete(this);
}

// IDA_EA: 0x8163B36
// IDA_NAME: _ZN15CEventCreateDnf10StartEventEv
// DEMANGLED: CEventCreateDnf::StartEvent(void)
int __cdecl CEventCreateDnf::StartEvent(CEventCreateDnf *this)
{
  char v1; // bl
  int v3[10]; // [esp+20h] [ebp-28h] BYREF

  CEventBase::SetEventFlag(this, 1);
  CEventCreateDnf::setState(this, 0);
  CEventCreateDnf::RegistStartTimer(this, 1);
  v1 = *((_BYTE *)this + 16);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CEventCreateDnf::StartEvent()", 29, 0);
  return cMyTrace::operator()(
           (int)v3,
           "[Taiwan, CreateDnfEvent] Start! startTime:%2dh, endTime:%2dh, reLoadInterval:%d",
           v1);
}

// IDA_EA: 0x8163BE0
// IDA_NAME: _ZN15CEventCreateDnf10StartEventE10Word_Param
// DEMANGLED: CEventCreateDnf::StartEvent(Word_Param)
int __cdecl CEventCreateDnf::StartEvent(int a1, int a2)
{
  *(_WORD *)(a1 + 16) = a2;
  *(_WORD *)(a1 + 18) = 60 * BYTE2(a2);
  if ( *(_BYTE *)(a1 + 16) <= 0x17u
    && *(_BYTE *)(a1 + 17) <= 0x17u
    && *(_WORD *)(a1 + 18) > 0x3Bu
    && *(_WORD *)(a1 + 18) <= 0xE10u )
  {
    return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
  }
  LogManager::logFormat(
    (LogManager *)1,
    (int)"localtaiwan/Event/EventCreateDnf.cpp",
    "virtual void CEventCreateDnf::StartEvent(Word_Param)",
    (const char *)0x31,
    "[Taiwan, CreateDnfEvent] Error! startTime:%2dh, endTime:%2dh, reLoadInterval:%d",
    (const char *)*(unsigned __int8 *)(a1 + 16),
    *(unsigned __int8 *)(a1 + 17),
    *(unsigned __int16 *)(a1 + 18));
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 12))(a1);
}

// IDA_EA: 0x8163CD0
// IDA_NAME: _ZN15CEventCreateDnf8EndEventEv
// DEMANGLED: CEventCreateDnf::EndEvent(void)
CEventBase *__cdecl CEventCreateDnf::EndEvent(CEventCreateDnf *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CEventCreateDnf::EndEvent()", 56, 0);
  cMyTrace::operator()((int)v3, "[Taiwan, CreateDnfEvent] End Event.", v2);
  *((_BYTE *)this + 16) = 0;
  *((_BYTE *)this + 17) = 0;
  *((_WORD *)this + 9) = 0;
  CEventCreateDnf::setState(this, 0);
  return CEventBase::SetEventFlag(this, 0);
}

// IDA_EA: 0x8163D4C
// IDA_NAME: _ZN15CEventCreateDnf15RegistNextTimerEv
// DEMANGLED: CEventCreateDnf::RegistNextTimer(void)
int __cdecl CEventCreateDnf::RegistNextTimer(CEventCreateDnf *this)
{
  int result; // eax
  int v2; // ebx
  TimerQueue *v3; // eax
  struct tm tp; // [esp+2Ch] [ebp-4Ch] BYREF
  time_t timer; // [esp+58h] [ebp-20h] BYREF
  int v6[4]; // [esp+5Ch] [ebp-1Ch] BYREF
  time_t timer_1; // [esp+6Ch] [ebp-Ch]

  result = (*(int (__cdecl **)(CEventCreateDnf *, _DWORD))(*(_DWORD *)this + 52))(this, 0) ^ 1;
  if ( !(_BYTE)result )
  {
    timer = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
    localtime_r(&timer, &tp);
    tp.tm_hour = *((unsigned __int8 *)this + 17);
    tp.tm_min = 0;
    tp.tm_sec = 0;
    timer_1 = mktime(&tp);
    if ( timer_1 >= timer )
      CEventCreateDnf::setState(this, 2);
    v2 = *((unsigned __int16 *)this + 9);
    v3 = (TimerQueue *)G_TimerQueue();
    TimerQueue::InsertTimer(v3, 2, 0, 174, v2, 0, 0);
    LOWORD(v2) = *((_WORD *)this + 9);
    LOBYTE(v2) = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_) + v2;
    cMyTrace::cMyTrace((cMyTrace *)v6, "void CEventCreateDnf::RegistNextTimer()", 85, 0);
    return cMyTrace::operator()((int)v6, "[Taiwan, CreateDnfEvent] next db load time:%d", v2);
  }
  return result;
}

// IDA_EA: 0x8163E7C
// IDA_NAME: _ZN15CEventCreateDnf16RegistStartTimerEb
// DEMANGLED: CEventCreateDnf::RegistStartTimer(bool)
int __cdecl CEventCreateDnf::RegistStartTimer(CEventCreateDnf *this)
{
  int result; // eax
  int v2; // ebx
  TimerQueue *v3; // eax
  int v4; // ebx
  TimerQueue *v5; // eax
  struct tm tp; // [esp+38h] [ebp-60h] BYREF
  time_t timer; // [esp+64h] [ebp-34h] BYREF
  int v8[4]; // [esp+68h] [ebp-30h] BYREF
  int v9[4]; // [esp+78h] [ebp-20h] BYREF
  char v10[4]; // [esp+88h] [ebp-10h]
  char v11[4]; // [esp+8Ch] [ebp-Ch]

  result = (*(int (__cdecl **)(CEventCreateDnf *, _DWORD))(*(_DWORD *)this + 52))(this, 0) ^ 1;
  if ( !(_BYTE)result )
  {
    CEventCreateDnf::SetEventInfo(this, 0, 0, 0);
    timer = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
    localtime_r(&timer, &tp);
    tp.tm_hour = *((unsigned __int8 *)this + 16);
    tp.tm_min = 0;
    tp.tm_sec = 0;
    *(_DWORD *)v10 = mktime(&tp);
    if ( *(int *)v10 < timer )
    {
      DBSelectCreateDnfEventInfo::makeRequest();
      CEventCreateDnf::setState(this, 1);
      *(_DWORD *)v11 = *(_DWORD *)v10 + *((unsigned __int16 *)this + 9);
      while ( *(int *)v11 < timer )
        *(_DWORD *)v11 += *((unsigned __int16 *)this + 9);
      v4 = *(_DWORD *)v11 - timer;
      v5 = (TimerQueue *)G_TimerQueue();
      TimerQueue::InsertTimer(v5, 2, 0, 174, v4, 0, 0);
      cMyTrace::cMyTrace((cMyTrace *)v9, "void CEventCreateDnf::RegistStartTimer(bool)", 126, 0);
      return cMyTrace::operator()((int)v9, "[Taiwan, CreateDnfEvent] next db load time:%d", v11[0]);
    }
    else
    {
      CEventCreateDnf::setState(this, 0);
      v2 = *(_DWORD *)v10 - timer;
      v3 = (TimerQueue *)G_TimerQueue();
      TimerQueue::InsertTimer(v3, 2, 0, 174, v2, 0, 0);
      cMyTrace::cMyTrace((cMyTrace *)v8, "void CEventCreateDnf::RegistStartTimer(bool)", 110, 0);
      return cMyTrace::operator()((int)v8, "[Taiwan, CreateDnfEvent] next db load time:%d", v10[0]);
    }
  }
  return result;
}

// IDA_EA: 0x8164092
// IDA_NAME: _ZN15CEventCreateDnf17IsRewardConditionEv
// DEMANGLED: CEventCreateDnf::IsRewardCondition(void)
_BOOL4 __cdecl CEventCreateDnf::IsRewardCondition(CEventCreateDnf *this)
{
  return CEventCreateDnf::GetState(this) == 2 && *((_WORD *)this + 11) == 100;
}

// IDA_EA: 0x81640D4
// IDA_NAME: _ZN15CEventCreateDnf12SetEventInfoEiii
// DEMANGLED: CEventCreateDnf::SetEventInfo(int,int,int)
CEventCreateDnf *__cdecl CEventCreateDnf::SetEventInfo(CEventCreateDnf *this, int a2, __int16 a3, int a4)
{
  __int16 v5; // bx
  CEventCreateDnf *this_1; // eax
  int v7[4]; // [esp+10h] [ebp-38h] BYREF
  int v8[4]; // [esp+20h] [ebp-28h] BYREF
  int v9[6]; // [esp+30h] [ebp-18h] BYREF

  if ( CEventCreateDnf::GetState(this) == 2
    && *((unsigned __int8 *)this + 16) > a2
    && *((unsigned __int8 *)this + 17) <= a2 )
  {
    v5 = *((_WORD *)this + 11);
    cMyTrace::cMyTrace((cMyTrace *)v7, "void CEventCreateDnf::SetEventInfo(int, int, int)", 142, 0);
    return (CEventCreateDnf *)cMyTrace::operator()((int)v7, "[Taiwan, CreateDnfEvent] State:kReward rate:%d", v5);
  }
  else
  {
    if ( *((unsigned __int8 *)this + 16) > a2 || *((unsigned __int8 *)this + 17) <= a2 )
    {
      CEventCreateDnf::setState(this, 2);
      cMyTrace::cMyTrace((cMyTrace *)v9, "void CEventCreateDnf::SetEventInfo(int, int, int)", 154, 0);
      cMyTrace::operator()((int)v9, "[Taiwan, CreateDnfEvent] State:kReward rate:%d", a3);
    }
    else
    {
      CEventCreateDnf::setState(this, 1);
      cMyTrace::cMyTrace((cMyTrace *)v8, "void CEventCreateDnf::SetEventInfo(int, int, int)", 149, 0);
      cMyTrace::operator()((int)v8, "[Taiwan, CreateDnfEvent] State:kIng rate:%d", a3);
    }
    this_1 = this;
    *((_WORD *)this + 11) = a3;
    if ( a4 )
    {
      this_1 = this;
      *((_BYTE *)this + 20) = a4;
    }
  }
  return this_1;
}

// IDA_EA: 0x8164246
// IDA_NAME: _ZN15CEventCreateDnf8GetStateEv
// DEMANGLED: CEventCreateDnf::GetState(void)
int __cdecl CEventCreateDnf::GetState(CEventCreateDnf *this)
{
  return *((_DWORD *)this + 3);
}

// IDA_EA: 0x8164252
// IDA_NAME: _ZN15CEventCreateDnf8setStateENS_5State1TE
// DEMANGLED: CEventCreateDnf::setState(CEventCreateDnf::State::T)
int __cdecl CEventCreateDnf::setState(int a1, int a2)
{
  int result; // eax

  result = a1;
  *(_DWORD *)(a1 + 12) = a2;
  return result;
}

// IDA_EA: 0x8164260
// IDA_NAME: _ZN15CEventCreateDnf7GetRateEv
// DEMANGLED: CEventCreateDnf::GetRate(void)
int __cdecl CEventCreateDnf::GetRate(CEventCreateDnf *this)
{
  return *((unsigned __int16 *)this + 11);
}

// IDA_EA: 0x816426C
// IDA_NAME: _ZN15CEventCreateDnf10SendRewardEP5CUser
// DEMANGLED: CEventCreateDnf::SendReward(CUser *)
void __cdecl CEventCreateDnf::SendReward(CEventCreateDnf *this, CUser *a2)
{
  char v2; // bl
  int v3; // eax
  const char *src; // eax
  const char *src_1; // eax
  int *v6; // ebx
  int n9; // esi
  int ServerGroup; // esi
  size_t v9; // edi
  int CurCharacNoEv; // ebx
  int v11; // eax
  int v12; // eax
  int *v13; // eax
  int v14; // eax
  int v15[152]; // [esp+3Eh] [ebp-3BAh] BYREF
  char s[256]; // [esp+2A0h] [ebp-158h] BYREF
  PacketBuf *v17[3]; // [esp+3A0h] [ebp-58h] BYREF
  char dest[30]; // [esp+3AEh] [ebp-4Ah] BYREF
  int v19[3]; // [esp+3CCh] [ebp-2Ch] BYREF
  unsigned int v20; // [esp+3D8h] [ebp-20h]
  unsigned int v21; // [esp+3DCh] [ebp-1Ch]

  std::vector<std::pair<int,int>>::vector((int)v19);
  v2 = *((_BYTE *)this + 20);
  v3 = ARAD::Singleton<CreateDnfEventSciprtServer>::Get();
  CreateDnfEventSciprt::GetItemInfo(v3 + 4, v19, v2);
  src = (const char *)RDARScriptStringManager::findString(
                        (RDARScriptStringManager *)&g_scriptStringManager_,
                        4,
                        "tw_cb_launching_title_01",
                        0);
  strncpy(dest, src, 0x1Du);
  src_1 = (const char *)RDARScriptStringManager::findString(
                          (RDARScriptStringManager *)&g_scriptStringManager_,
                          4,
                          "game_server_msg_81",
                          0);
  strncpy(s, src_1, 0xFFu);
  v6 = v15;
  for ( n9 = 9; n9 != -1; --n9 )
  {
    Inven_Item::Inven_Item((Inven_Item *)v6);
    v6 = (int *)((char *)v6 + 61);
  }
  WongWork::CMailBoxHelper::MakeSystemMultiMailPostal(v19, v15, 10);
  ServerGroup = CUser::GetServerGroup(a2);
  v9 = strlen(s);
  CurCharacNoEv = CUserCharacInfo::getCurCharacNo(a2);
  v11 = std::vector<std::pair<int,int>>::size(v19);
  WongWork::CMailBoxHelper::ReqDBSendNewSystemMultiMail(dest, (int)v15, v11, 0, CurCharacNoEv, s, v9, 0, ServerGroup, 0);
  PacketGuard::PacketGuard((PacketGuard *)v17);
  InterfacePacketBuf::put_header(v17, 1, 600);
  InterfacePacketBuf::put_byte(v17, 1);
  v12 = std::vector<std::pair<int,int>>::size(v19);
  InterfacePacketBuf::put_byte(v17, v12);
  v20 = 0;
  v21 = std::vector<std::pair<int,int>>::size(v19);
  while ( v20 < v21 )
  {
    v13 = (int *)std::vector<std::pair<int,int>>::operator[](v19, v20);
    InterfacePacketBuf::put_int(v17, *v13);
    v14 = std::vector<std::pair<int,int>>::operator[](v19, v20);
    InterfacePacketBuf::put_byte(v17, *(_DWORD *)(v14 + 4));
    ++v20;
  }
  InterfacePacketBuf::finalize(v17, 1);
  CUser::Send(a2, (PacketGuard *)v17);
  PacketGuard::~PacketGuard(v17);
  std::vector<std::pair<int,int>>::~vector(v19);
}
