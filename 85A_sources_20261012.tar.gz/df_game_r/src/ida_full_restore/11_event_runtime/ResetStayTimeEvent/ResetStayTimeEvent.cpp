#include "ResetStayTimeEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x815B76A
// IDA_NAME: _ZN18ResetStayTimeEvent8dispatchEiiP6Stream
// DEMANGLED: ResetStayTimeEvent::dispatch(int,int,Stream *)
int ResetStayTimeEvent::dispatch()
{
  _DWORD *exception; // eax
  _DWORD *v1; // eax
  MySQL *DBHandle; // [esp+28h] [ebp-10h]

  DBHandle = (MySQL *)DBMgr::GetDBHandle(GlobalData::s_db_mgr, 9, 0);
  if ( !DBHandle )
  {
    exception = _cxa_allocate_exception(4u);
    *exception = "handle null";
    _cxa_throw(exception, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  MySQL::set_query(DBHandle, "upDate event_stay_time_charac set reward_flag = 0");
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
  {
    v1 = _cxa_allocate_exception(4u);
    *v1 = "exec";
    _cxa_throw(v1, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  return 1;
}

// IDA_EA: 0x815E1C0
// IDA_NAME: _ZN18ResetStayTimeEventC2Ev
// DEMANGLED: ResetStayTimeEvent::ResetStayTimeEvent(void)
void __cdecl ResetStayTimeEvent::ResetStayTimeEvent(ResetStayTimeEvent *this)
{
  TaiwanInterfaceDBDispatcher::TaiwanInterfaceDBDispatcher(this, 7);
  *(_DWORD *)this = off_8B79400;
}

// IDA_EA: 0x815E1E4
// IDA_NAME: _ZN18ResetStayTimeEventD2Ev
// DEMANGLED: ResetStayTimeEvent::~ResetStayTimeEvent()
void __cdecl ResetStayTimeEvent::~ResetStayTimeEvent(ResetStayTimeEvent *this)
{
  *(_DWORD *)this = off_8B79400;
  TaiwanInterfaceDBDispatcher::~TaiwanInterfaceDBDispatcher(this);
}

// IDA_EA: 0x815E214
// IDA_NAME: _ZN18ResetStayTimeEventD0Ev
// DEMANGLED: ResetStayTimeEvent::~ResetStayTimeEvent()
void __cdecl ResetStayTimeEvent::~ResetStayTimeEvent(ResetStayTimeEvent *this)
{
  ResetStayTimeEvent::~ResetStayTimeEvent(this);
  operator delete(this);
}
