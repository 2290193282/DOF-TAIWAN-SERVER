#ifndef __IDA91_RESETSTAYTIMEEVENT_H__
#define __IDA91_RESETSTAYTIMEEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: ResetStayTimeEvent
// Source unit: ResetStayTimeEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "network/Stream.h"
// Local type ordinals: 1320

/* 1320 */
struct ResetStayTimeEvent;

// Exported member functions:
// 0x815B76A	ResetStayTimeEvent::dispatch(int,int,Stream *)
// 0x815E1C0	ResetStayTimeEvent::ResetStayTimeEvent(void)
// 0x815E1E4	ResetStayTimeEvent::~ResetStayTimeEvent()
// 0x815E214	ResetStayTimeEvent::~ResetStayTimeEvent()

// Function declaration index:
// DECL 0x815B76A ResetStayTimeEvent::dispatch
// DECL 0x815E1C0 ResetStayTimeEvent::ResetStayTimeEvent
// DECL 0x815E1E4 ResetStayTimeEvent::~ResetStayTimeEvent
// DECL 0x815E214 ResetStayTimeEvent::~ResetStayTimeEvent

#endif  // __IDA91_RESETSTAYTIMEEVENT_H__
