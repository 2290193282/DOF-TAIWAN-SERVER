#ifndef __IDA91_DISPATCHER_EXCHANGE_RANDOM_ITEM_REWARD_H__
#define __IDA91_DISPATCHER_EXCHANGE_RANDOM_ITEM_REWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Dispatcher_Exchange_Random_Item_Reward
// Source unit: Dispatcher_Exchange_Random_Item_Reward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
//   #include "items/CItem.h"
// Local type ordinals: 4319

/* 4319 */
struct Dispatcher_Exchange_Random_Item_Reward;

// Exported member functions:
// 0x81DE406	Dispatcher_Exchange_Random_Item_Reward::read(PacketBuf &,MSG_BASE &)
// 0x81DE52C	Dispatcher_Exchange_Random_Item_Reward::process(CUser *,MSG_BASE &,ParamBase &)
// 0x81DE72C	Dispatcher_Exchange_Random_Item_Reward::send(CUser *,ParamBase &)
// 0x8244578	Dispatcher_Exchange_Random_Item_Reward::~Dispatcher_Exchange_Random_Item_Reward()
// 0x82445A8	Dispatcher_Exchange_Random_Item_Reward::~Dispatcher_Exchange_Random_Item_Reward()
// 0x8597A46	Dispatcher_Exchange_Random_Item_Reward::Dispatcher_Exchange_Random_Item_Reward(void)

// Function declaration index:
// DECL 0x81DE406 Dispatcher_Exchange_Random_Item_Reward::read
// DECL 0x81DE52C Dispatcher_Exchange_Random_Item_Reward::process
// DECL 0x81DE72C Dispatcher_Exchange_Random_Item_Reward::send
// DECL 0x8244578 Dispatcher_Exchange_Random_Item_Reward::~Dispatcher_Exchange_Random_Item_Reward
// DECL 0x82445A8 Dispatcher_Exchange_Random_Item_Reward::~Dispatcher_Exchange_Random_Item_Reward
// DECL 0x8597A46 Dispatcher_Exchange_Random_Item_Reward::Dispatcher_Exchange_Random_Item_Reward

#endif  // __IDA91_DISPATCHER_EXCHANGE_RANDOM_ITEM_REWARD_H__
