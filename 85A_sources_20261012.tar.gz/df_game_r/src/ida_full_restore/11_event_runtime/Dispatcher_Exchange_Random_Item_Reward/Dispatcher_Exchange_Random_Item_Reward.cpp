#include "Dispatcher_Exchange_Random_Item_Reward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81DE406
// IDA_NAME: _ZN38Dispatcher_Exchange_Random_Item_Reward4readER9PacketBufR8MSG_BASE
// DEMANGLED: Dispatcher_Exchange_Random_Item_Reward::read(PacketBuf &,MSG_BASE &)
int __cdecl Dispatcher_Exchange_Random_Item_Reward::read(
        Dispatcher_Exchange_Random_Item_Reward *this,
        PacketBuf *a2,
        MSG_BASE *a3)
{
  unsigned __int16 v4; // [esp+10h] [ebp-18h] BYREF
  unsigned __int8 v5; // [esp+13h] [ebp-15h] BYREF
  int v6; // [esp+14h] [ebp-14h] BYREF
  MSG_BASE *v7; // [esp+18h] [ebp-10h]
  unsigned int i; // [esp+1Ch] [ebp-Ch]

  v7 = a3;
  if ( (unsigned __int8)PacketBuf::get_short(a2, (unsigned __int16 *)a3 + 7) != 1 )
    return LineFunc(20424, "virtual int Dispatcher_Exchange_Random_Item_Reward::read(PacketBuf&, MSG_BASE&)", 0, 0);
  v5 = 0;
  if ( (unsigned __int8)PacketBuf::get_byte(a2, &v5) != 1 )
    return LineFunc(20428, "virtual int Dispatcher_Exchange_Random_Item_Reward::read(PacketBuf&, MSG_BASE&)", 0, 0);
  v4 = 0;
  for ( i = 0; v5 > i; ++i )
  {
    if ( (unsigned __int8)PacketBuf::get_short(a2, &v4) != 1 )
      return LineFunc(20434, "virtual int Dispatcher_Exchange_Random_Item_Reward::read(PacketBuf&, MSG_BASE&)", 0, 0);
    v6 = v4;
    std::vector<int>::push_back((int)v7 + 16, (int)&v6);
    v4 = 0;
  }
  return 0;
}

// IDA_EA: 0x81DE52C
// IDA_NAME: _ZN38Dispatcher_Exchange_Random_Item_Reward7processEP5CUserR8MSG_BASER9ParamBase
// DEMANGLED: Dispatcher_Exchange_Random_Item_Reward::process(CUser *,MSG_BASE &,ParamBase &)
int __cdecl Dispatcher_Exchange_Random_Item_Reward::process(
        Dispatcher_Exchange_Random_Item_Reward *this,
        CUser *a2,
        MSG_BASE *a3,
        ParamBase *a4)
{
  int n17; // ebx
  CDataManager *v5; // eax
  int v6; // eax
  int RewardItemERSt6vectorISt4pairIiiESaIS3_EE; // eax
  int v8; // eax
  int v9; // eax
  int v11[3]; // [esp+2Ch] [ebp-2Ch] BYREF
  int v12[3]; // [esp+38h] [ebp-20h] BYREF
  MSG_BASE *v13; // [esp+44h] [ebp-14h]
  ParamBase *v14; // [esp+48h] [ebp-10h]
  int event_entityEi; // [esp+4Ch] [ebp-Ch]

  v13 = a3;
  v14 = a4;
  if ( CUser::get_state(a2) == 3 )
  {
    n17 = *((unsigned __int16 *)v13 + 7);
    v5 = (CDataManager *)G_CDataManager();
    CDataManager::get_event_script_mng(v5);
    event_entityEi = EventClassify::CEventScriptMng::get_event_entity();
    if ( event_entityEi )
    {
      if ( (*(unsigned __int8 (__cdecl **)(int, int))(*(_DWORD *)event_entityEi + 8))(event_entityEi, n17) == 1 )
      {
        std::vector<std::pair<int,int>>::vector((int)v12);
        v6 = EventClassify::CExchangeRandomItemReward::verifyMaterialItemByRule(
               event_entityEi,
               a2,
               (_DWORD *)v13 + 4,
               v12);
        *((_DWORD *)v14 + 1) = v6;
        if ( !*((_DWORD *)v14 + 1) )
        {
          std::vector<std::pair<int,int>>::vector((int)v11);
          RewardItemERSt6vectorISt4pairIiiESaIS3_EE = EventClassify::CExchangeRandomItemReward::getRewardItem(
                                                        n17,
                                                        event_entityEi,
                                                        (int)v11);
          *((_DWORD *)v14 + 1) = RewardItemERSt6vectorISt4pairIiiESaIS3_EE;
          if ( !*((_DWORD *)v14 + 1) )
          {
            v8 = EventClassify::CExchangeRandomItemReward::deleteUsedMaterialItem(
                   event_entityEi,
                   a2,
                   v12,
                   (_DWORD *)v14 + 3);
            *((_DWORD *)v14 + 1) = v8;
            if ( !*((_DWORD *)v14 + 1) )
            {
              v9 = EventClassify::CExchangeRandomItemReward::sendRandomItemReward(
                     event_entityEi,
                     a2,
                     (int)v11,
                     (int *)v14 + 6,
                     (_BYTE *)v14 + 9);
              *((_DWORD *)v14 + 1) = v9;
            }
          }
          std::vector<std::pair<int,int>>::~vector(v11);
        }
        std::vector<std::pair<int,int>>::~vector(v12);
      }
      else
      {
        *((_DWORD *)v14 + 1) = 178;
      }
    }
    else
    {
      *((_DWORD *)v14 + 1) = 178;
    }
  }
  else
  {
    *((_DWORD *)v14 + 1) = 7;
  }
  return 0;
}

// IDA_EA: 0x81DE72C
// IDA_NAME: _ZN38Dispatcher_Exchange_Random_Item_Reward4sendEP5CUserR9ParamBase
// DEMANGLED: Dispatcher_Exchange_Random_Item_Reward::send(CUser *,ParamBase &)
void __cdecl Dispatcher_Exchange_Random_Item_Reward::send(
        Dispatcher_Exchange_Random_Item_Reward *this,
        CUser *a2,
        ParamBase *a3)
{
  int v3; // eax
  int *v4; // eax
  int v5; // eax
  _DWORD *v6; // eax
  int *v7; // eax
  int *v8; // eax
  _DWORD *v9; // eax
  int v10; // [esp+10h] [ebp-28h] BYREF
  int v11; // [esp+14h] [ebp-24h] BYREF
  PacketBuf *v12[3]; // [esp+18h] [ebp-20h] BYREF
  _BYTE v13[4]; // [esp+24h] [ebp-14h] BYREF
  _BYTE v14[4]; // [esp+28h] [ebp-10h] BYREF
  ParamBase *v15; // [esp+2Ch] [ebp-Ch]

  v15 = a3;
  PacketGuard::PacketGuard((PacketGuard *)v12);
  InterfacePacketBuf::put_header(v12, 1, 449);
  if ( *((_DWORD *)v15 + 1) )
  {
    InterfacePacketBuf::put_byte(v12, 0);
    InterfacePacketBuf::put_byte(v12, *((_DWORD *)v15 + 1));
  }
  else
  {
    InterfacePacketBuf::put_byte(v12, 1);
    v3 = std::vector<std::pair<int,int>>::size((_DWORD *)v15 + 3);
    InterfacePacketBuf::put_byte(v12, v3);
    if ( std::vector<std::pair<int,int>>::size((_DWORD *)v15 + 3) )
    {
      std::vector<std::pair<int,int>>::begin((int)&v11, (int)v15 + 12);
      while ( 1 )
      {
        std::vector<std::pair<int,int>>::end((int)v13, (int)v15 + 12);
        if ( !__gnu_cxx::operator!=<std::pair<int,int> *,std::vector<std::pair<int,int>>>((int)&v11, (int)v13) )
          break;
        v4 = (int *)__gnu_cxx::__normal_iterator<std::pair<int,int> *,std::vector<std::pair<int,int>>>::operator->((int)&v11);
        InterfacePacketBuf::put_int(v12, *v4);
        v5 = __gnu_cxx::__normal_iterator<std::pair<int,int> *,std::vector<std::pair<int,int>>>::operator->((int)&v11);
        InterfacePacketBuf::put_int(v12, *(_DWORD *)(v5 + 4));
        __gnu_cxx::__normal_iterator<std::pair<int,int> *,std::vector<std::pair<int,int>>>::operator++(&v11);
      }
    }
    InterfacePacketBuf::put_byte(v12, *((unsigned __int8 *)v15 + 9));
    if ( *((_BYTE *)v15 + 9) )
    {
      std::vector<int>::begin((int)&v10, (int)v15 + 24);
      while ( 1 )
      {
        std::vector<int>::end((int)v14, (int)v15 + 24);
        if ( !__gnu_cxx::operator!=<int *,std::vector<int>>((int)&v10, (int)v14) )
          break;
        v6 = (_DWORD *)__gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator*((int)&v10);
        InterfacePacketBuf::put_short(v12, *v6);
        __gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator++(&v10);
        v7 = (int *)__gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator*((int)&v10);
        InterfacePacketBuf::put_int(v12, *v7);
        __gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator++(&v10);
        v8 = (int *)__gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator*((int)&v10);
        InterfacePacketBuf::put_int(v12, *v8);
        __gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator++(&v10);
        v9 = (_DWORD *)__gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator*((int)&v10);
        InterfacePacketBuf::put_short(v12, *v9);
        __gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator++(&v10);
      }
    }
  }
  InterfacePacketBuf::finalize(v12, 1);
  CUser::Send(a2, (PacketGuard *)v12);
  PacketGuard::~PacketGuard(v12);
}

// IDA_EA: 0x8244578
// IDA_NAME: _ZN38Dispatcher_Exchange_Random_Item_RewardD2Ev
// DEMANGLED: Dispatcher_Exchange_Random_Item_Reward::~Dispatcher_Exchange_Random_Item_Reward()
void __cdecl Dispatcher_Exchange_Random_Item_Reward::~Dispatcher_Exchange_Random_Item_Reward(
        Dispatcher_Exchange_Random_Item_Reward *this)
{
  *(_DWORD *)this = &off_8BDA3C8;
  IPacketDispatcher<MSG_EXCHANGE_RANDOM_ITEM_REWARD,stExchangeRandomItemReward,(ch_state)0>::~IPacketDispatcher(this);
}

// IDA_EA: 0x82445A8
// IDA_NAME: _ZN38Dispatcher_Exchange_Random_Item_RewardD0Ev
// DEMANGLED: Dispatcher_Exchange_Random_Item_Reward::~Dispatcher_Exchange_Random_Item_Reward()
void __cdecl Dispatcher_Exchange_Random_Item_Reward::~Dispatcher_Exchange_Random_Item_Reward(
        Dispatcher_Exchange_Random_Item_Reward *this)
{
  Dispatcher_Exchange_Random_Item_Reward::~Dispatcher_Exchange_Random_Item_Reward(this);
  operator delete(this);
}

// IDA_EA: 0x8597A46
// IDA_NAME: _ZN38Dispatcher_Exchange_Random_Item_RewardC2Ev
// DEMANGLED: Dispatcher_Exchange_Random_Item_Reward::Dispatcher_Exchange_Random_Item_Reward(void)
void __cdecl Dispatcher_Exchange_Random_Item_Reward::Dispatcher_Exchange_Random_Item_Reward(
        Dispatcher_Exchange_Random_Item_Reward *this)
{
  IPacketDispatcher<MSG_EXCHANGE_RANDOM_ITEM_REWARD,stExchangeRandomItemReward,(ch_state)0>::IPacketDispatcher(this);
  *(_DWORD *)this = &off_8BDA3C8;
}
