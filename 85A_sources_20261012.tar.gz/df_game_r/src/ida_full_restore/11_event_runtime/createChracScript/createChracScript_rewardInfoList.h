#ifndef __IDA91_CREATECHRACSCRIPT_REWARDINFOLIST_H__
#define __IDA91_CREATECHRACSCRIPT_REWARDINFOLIST_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: createChracScript
// Source unit: createChracScript_rewardInfoList
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4723

/* 4723 */
struct createChracScript::rewardInfoList;

// Exported member functions:
// 0x83CF71C	createChracScript::rewardInfoList::~rewardInfoList()
// 0x84E91FA	createChracScript::rewardInfoList::rewardInfoList(void)
// 0x8962B4C	createChracScript::rewardInfoList::rewardInfoList(createChracScript::rewardInfoList const&)

// Function declaration index:
// DECL 0x83CF71C createChracScript::rewardInfoList::~rewardInfoList
// DECL 0x84E91FA createChracScript::rewardInfoList::rewardInfoList
// DECL 0x8962B4C createChracScript::rewardInfoList::rewardInfoList

#endif  // __IDA91_CREATECHRACSCRIPT_REWARDINFOLIST_H__
