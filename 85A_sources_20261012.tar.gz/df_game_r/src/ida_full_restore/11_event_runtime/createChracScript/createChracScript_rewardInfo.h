#ifndef __IDA91_CREATECHRACSCRIPT_REWARDINFO_H__
#define __IDA91_CREATECHRACSCRIPT_REWARDINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: createChracScript
// Source unit: createChracScript_rewardInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4442

/* 4442 */
struct createChracScript::rewardInfo;

// Exported member functions:
// 0x83DD574	createChracScript::rewardInfo::~rewardInfo()
// 0x83ECCBC	createChracScript::rewardInfo::rewardInfo(createChracScript::rewardInfo const&)
// 0x83EFC90	createChracScript::rewardInfo::operator=(createChracScript::rewardInfo const&)
// 0x8962460	createChracScript::rewardInfo::rewardInfo(void)

// Function declaration index:
// DECL 0x83DD574 createChracScript::rewardInfo::~rewardInfo
// DECL 0x83ECCBC createChracScript::rewardInfo::rewardInfo
// DECL 0x83EFC90 createChracScript::rewardInfo::operator=
// DECL 0x8962460 createChracScript::rewardInfo::rewardInfo

#endif  // __IDA91_CREATECHRACSCRIPT_REWARDINFO_H__
