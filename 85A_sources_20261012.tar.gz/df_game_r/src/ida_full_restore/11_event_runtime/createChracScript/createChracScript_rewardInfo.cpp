#include "createChracScript_rewardInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x83DD574
// IDA_NAME: _ZN17createChracScript10rewardInfoD2Ev
// DEMANGLED: createChracScript::rewardInfo::~rewardInfo()
void __cdecl createChracScript::rewardInfo::~rewardInfo(createChracScript::rewardInfo *this)
{
  std::string::~string((char *)this + 24);
  std::string::~string((char *)this + 20);
  std::vector<int>::~vector(this);
}

// IDA_EA: 0x83ECCBC
// IDA_NAME: _ZN17createChracScript10rewardInfoC2ERKS0_
// DEMANGLED: createChracScript::rewardInfo::rewardInfo(createChracScript::rewardInfo const&)
int __cdecl createChracScript::rewardInfo::rewardInfo(createChracScript::rewardInfo *this, std::string *a2)
{
  std::vector<int>::vector((int *)this, a2);
  *((std::string *)this + 3) = a2[3];
  *((std::string *)this + 4) = a2[4];
  std::string::string((std::string *)this + 5, a2 + 5);
  return std::string::string((std::string *)this + 6, a2 + 6);
}

// IDA_EA: 0x83EFC90
// IDA_NAME: _ZN17createChracScript10rewardInfoaSERKS0_
// DEMANGLED: createChracScript::rewardInfo::operator=(createChracScript::rewardInfo const&)
int *__cdecl createChracScript::rewardInfo::operator=(int *a1, int *a2)
{
  std::vector<int>::operator=(a1, a2);
  a1[3] = a2[3];
  a1[4] = a2[4];
  std::string::operator=(a1 + 5, a2 + 5);
  std::string::operator=(a1 + 6, a2 + 6);
  return a1;
}

// IDA_EA: 0x8962460
// IDA_NAME: _ZN17createChracScript10rewardInfoC2Ev
// DEMANGLED: createChracScript::rewardInfo::rewardInfo(void)
std::string *__cdecl createChracScript::rewardInfo::rewardInfo(std::string *this)
{
  std::string *this_1; // eax

  std::vector<int>::vector((int)this);
  std::string::string(this + 5);
  std::string::string(this + 6);
  std::vector<int>::clear(this);
  std::string::clear(this + 5);
  std::string::clear(this + 6);
  this[3]._M_dataplus.__vftable = 0;
  this_1 = this;
  this[4]._M_dataplus.__vftable = 0;
  return this_1;
}
