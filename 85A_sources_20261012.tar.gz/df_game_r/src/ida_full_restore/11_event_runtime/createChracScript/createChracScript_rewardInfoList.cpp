#include "createChracScript_rewardInfoList.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x83CF71C
// IDA_NAME: _ZN17createChracScript14rewardInfoListD2Ev
// DEMANGLED: createChracScript::rewardInfoList::~rewardInfoList()
void __cdecl createChracScript::rewardInfoList::~rewardInfoList(createChracScript::rewardInfoList *this)
{
  std::vector<createChracScript::rewardInfo>::~vector((int)this);
}

// IDA_EA: 0x84E91FA
// IDA_NAME: _ZN17createChracScript14rewardInfoListC2Ev
// DEMANGLED: createChracScript::rewardInfoList::rewardInfoList(void)
int __cdecl createChracScript::rewardInfoList::rewardInfoList(createChracScript::rewardInfoList *this)
{
  std::vector<createChracScript::rewardInfo>::vector(this);
  return std::vector<createChracScript::rewardInfo>::clear(this);
}

// IDA_EA: 0x8962B4C
// IDA_NAME: _ZN17createChracScript14rewardInfoListC2ERKS0_
// DEMANGLED: createChracScript::rewardInfoList::rewardInfoList(createChracScript::rewardInfoList const&)
int __cdecl createChracScript::rewardInfoList::rewardInfoList(
        createChracScript::rewardInfoList *this,
        const createChracScript::rewardInfoList *a2)
{
  return std::vector<createChracScript::rewardInfo>::vector(this, a2);
}
