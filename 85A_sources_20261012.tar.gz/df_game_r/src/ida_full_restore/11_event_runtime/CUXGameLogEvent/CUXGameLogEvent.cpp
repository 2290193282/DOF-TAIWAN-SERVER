#include "CUXGameLogEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8117678
// IDA_NAME: _ZN15CUXGameLogEventC2Ev
// DEMANGLED: CUXGameLogEvent::CUXGameLogEvent(void)
void __cdecl CUXGameLogEvent::CUXGameLogEvent(CUXGameLogEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B4F268;
}

// IDA_EA: 0x8117694
// IDA_NAME: _ZN15CUXGameLogEventD2Ev
// DEMANGLED: CUXGameLogEvent::~CUXGameLogEvent()
void __cdecl CUXGameLogEvent::~CUXGameLogEvent(CUXGameLogEvent *this)
{
  *(_DWORD *)this = off_8B4F268;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x81176C4
// IDA_NAME: _ZN15CUXGameLogEventD0Ev
// DEMANGLED: CUXGameLogEvent::~CUXGameLogEvent()
void __cdecl CUXGameLogEvent::~CUXGameLogEvent(CUXGameLogEvent *this)
{
  CUXGameLogEvent::~CUXGameLogEvent(this);
  operator delete(this);
}

// IDA_EA: 0x81176E2
// IDA_NAME: _ZN15CUXGameLogEvent10StartEventEv
// DEMANGLED: CUXGameLogEvent::StartEvent(void)
int __cdecl CUXGameLogEvent::StartEvent(CUXGameLogEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CUXGameLogEvent::StartEvent()", 19, 0);
  return cMyTrace::operator()((int)v3, "CUXGameLogEvent Event Start!", v2);
}

// IDA_EA: 0x8117734
// IDA_NAME: _ZN15CUXGameLogEvent10StartEventE10Word_Param
// DEMANGLED: CUXGameLogEvent::StartEvent(Word_Param)
int __cdecl CUXGameLogEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x811774E
// IDA_NAME: _ZN15CUXGameLogEvent8EndEventEv
// DEMANGLED: CUXGameLogEvent::EndEvent(void)
int __cdecl CUXGameLogEvent::EndEvent(CUXGameLogEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CUXGameLogEvent::EndEvent()", 30, 0);
  return cMyTrace::operator()((int)v3, "CUXGameLogEvent Event End!", v2);
}
