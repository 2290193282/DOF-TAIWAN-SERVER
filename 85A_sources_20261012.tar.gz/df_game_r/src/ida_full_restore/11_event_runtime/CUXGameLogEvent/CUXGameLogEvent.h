#ifndef __IDA91_CUXGAMELOGEVENT_H__
#define __IDA91_CUXGAMELOGEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CUXGameLogEvent
// Source unit: CUXGameLogEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4102

/* 4102 */
struct CUXGameLogEvent;

// Exported member functions:
// 0x8117678	CUXGameLogEvent::CUXGameLogEvent(void)
// 0x8117694	CUXGameLogEvent::~CUXGameLogEvent()
// 0x81176C4	CUXGameLogEvent::~CUXGameLogEvent()
// 0x81176E2	CUXGameLogEvent::StartEvent(void)
// 0x8117734	CUXGameLogEvent::StartEvent(Word_Param)
// 0x811774E	CUXGameLogEvent::EndEvent(void)

// Function declaration index:
// DECL 0x8117678 CUXGameLogEvent::CUXGameLogEvent
// DECL 0x8117694 CUXGameLogEvent::~CUXGameLogEvent
// DECL 0x81176C4 CUXGameLogEvent::~CUXGameLogEvent
// DECL 0x81176E2 CUXGameLogEvent::StartEvent
// DECL 0x8117734 CUXGameLogEvent::StartEvent
// DECL 0x811774E CUXGameLogEvent::EndEvent

#endif  // __IDA91_CUXGAMELOGEVENT_H__
