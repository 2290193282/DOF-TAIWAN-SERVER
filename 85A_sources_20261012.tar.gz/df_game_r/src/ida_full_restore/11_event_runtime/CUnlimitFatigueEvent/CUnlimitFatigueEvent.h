#ifndef __IDA91_CUNLIMITFATIGUEEVENT_H__
#define __IDA91_CUNLIMITFATIGUEEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CUnlimitFatigueEvent
// Source unit: CUnlimitFatigueEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4167

/* 4167 */
struct CUnlimitFatigueEvent;

// Exported member functions:
// 0x8285C44	CUnlimitFatigueEvent::CUnlimitFatigueEvent(void)
// 0x8285C60	CUnlimitFatigueEvent::~CUnlimitFatigueEvent()
// 0x8285C90	CUnlimitFatigueEvent::~CUnlimitFatigueEvent()
// 0x8285CAE	CUnlimitFatigueEvent::StartEvent(void)
// 0x8285D00	CUnlimitFatigueEvent::StartEvent(Word_Param)
// 0x8285D52	CUnlimitFatigueEvent::EndEvent(void)

// Function declaration index:
// DECL 0x8285C44 CUnlimitFatigueEvent::CUnlimitFatigueEvent
// DECL 0x8285C60 CUnlimitFatigueEvent::~CUnlimitFatigueEvent
// DECL 0x8285C90 CUnlimitFatigueEvent::~CUnlimitFatigueEvent
// DECL 0x8285CAE CUnlimitFatigueEvent::StartEvent
// DECL 0x8285D00 CUnlimitFatigueEvent::StartEvent
// DECL 0x8285D52 CUnlimitFatigueEvent::EndEvent

#endif  // __IDA91_CUNLIMITFATIGUEEVENT_H__
