#include "CUnlimitFatigueEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8285C44
// IDA_NAME: _ZN20CUnlimitFatigueEventC2Ev
// DEMANGLED: CUnlimitFatigueEvent::CUnlimitFatigueEvent(void)
void __cdecl CUnlimitFatigueEvent::CUnlimitFatigueEvent(CUnlimitFatigueEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8C0EB68;
}

// IDA_EA: 0x8285C60
// IDA_NAME: _ZN20CUnlimitFatigueEventD2Ev
// DEMANGLED: CUnlimitFatigueEvent::~CUnlimitFatigueEvent()
void __cdecl CUnlimitFatigueEvent::~CUnlimitFatigueEvent(CUnlimitFatigueEvent *this)
{
  *(_DWORD *)this = off_8C0EB68;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x8285C90
// IDA_NAME: _ZN20CUnlimitFatigueEventD0Ev
// DEMANGLED: CUnlimitFatigueEvent::~CUnlimitFatigueEvent()
void __cdecl CUnlimitFatigueEvent::~CUnlimitFatigueEvent(CUnlimitFatigueEvent *this)
{
  CUnlimitFatigueEvent::~CUnlimitFatigueEvent(this);
  operator delete(this);
}

// IDA_EA: 0x8285CAE
// IDA_NAME: _ZN20CUnlimitFatigueEvent10StartEventEv
// DEMANGLED: CUnlimitFatigueEvent::StartEvent(void)
int __cdecl CUnlimitFatigueEvent::StartEvent(CUnlimitFatigueEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 18, 0);
  return cMyTrace::operator()((int)v3, "Unlimit Fatigue Event Start!", v2);
}

// IDA_EA: 0x8285D00
// IDA_NAME: _ZN20CUnlimitFatigueEvent10StartEventE10Word_Param
// DEMANGLED: CUnlimitFatigueEvent::StartEvent(Word_Param)
int __cdecl CUnlimitFatigueEvent::StartEvent(CEventBase *a1)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 25, 0);
  return cMyTrace::operator()((int)v3, "Unlimit Fatigue Event Start!", v2);
}

// IDA_EA: 0x8285D52
// IDA_NAME: _ZN20CUnlimitFatigueEvent8EndEventEv
// DEMANGLED: CUnlimitFatigueEvent::EndEvent(void)
int __cdecl CUnlimitFatigueEvent::EndEvent(CUnlimitFatigueEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "EndEvent", 32, 0);
  return cMyTrace::operator()((int)v3, "Unlimit Fatigue Event End!", v2);
}
