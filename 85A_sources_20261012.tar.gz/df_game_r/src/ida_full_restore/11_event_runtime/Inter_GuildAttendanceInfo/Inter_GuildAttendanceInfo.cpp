#include "Inter_GuildAttendanceInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84E4052
// IDA_NAME: _ZN25Inter_GuildAttendanceInfo12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_GuildAttendanceInfo::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_GuildAttendanceInfo::dispatch_sig(Inter_GuildAttendanceInfo *this, CUser *a2, char *a3)
{
  int CurCharacNoEv; // ebx
  PacketBuf *v5[3]; // [esp+10h] [ebp-18h] BYREF
  char *v6; // [esp+1Ch] [ebp-Ch]

  v6 = a3;
  if ( CUser::get_state(a2) > 2 )
  {
    CurCharacNoEv = *(_DWORD *)(v6 + 10);
    if ( CurCharacNoEv == CUserCharacInfo::getCurCharacNo(a2) )
    {
      PacketGuard::PacketGuard((PacketGuard *)v5);
      InterfacePacketBuf::put_header(v5, 1, 356);
      InterfacePacketBuf::put_byte(v5, 1);
      InterfacePacketBuf::put_byte(v5, v6[18]);
      InterfacePacketBuf::put_int(v5, *(_DWORD *)(v6 + 19));
      InterfacePacketBuf::put_int(v5, *(_DWORD *)(v6 + 23));
      InterfacePacketBuf::put_int(v5, *(_DWORD *)(v6 + 43));
      InterfacePacketBuf::put_int(v5, *(_DWORD *)(v6 + 35));
      InterfacePacketBuf::put_int(v5, *(_DWORD *)(v6 + 39));
      InterfacePacketBuf::put_int(v5, *(_DWORD *)(v6 + 27));
      InterfacePacketBuf::put_int(v5, *(_DWORD *)(v6 + 31));
      InterfacePacketBuf::finalize(v5, 1);
      CUser::Send(a2, (PacketGuard *)v5);
      PacketGuard::~PacketGuard(v5);
    }
  }
  return 0;
}

// IDA_EA: 0x84EEA78
// IDA_NAME: _ZN25Inter_GuildAttendanceInfoC2Ev
// DEMANGLED: Inter_GuildAttendanceInfo::Inter_GuildAttendanceInfo(void)
void __cdecl Inter_GuildAttendanceInfo::Inter_GuildAttendanceInfo(Inter_GuildAttendanceInfo *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8E7F0;
}

// IDA_EA: 0x84F65E2
// IDA_NAME: _ZN25Inter_GuildAttendanceInfoD2Ev
// DEMANGLED: Inter_GuildAttendanceInfo::~Inter_GuildAttendanceInfo()
void __cdecl Inter_GuildAttendanceInfo::~Inter_GuildAttendanceInfo(Inter_GuildAttendanceInfo *this)
{
  *(_DWORD *)this = &off_8C8E7F0;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84F6612
// IDA_NAME: _ZN25Inter_GuildAttendanceInfoD0Ev
// DEMANGLED: Inter_GuildAttendanceInfo::~Inter_GuildAttendanceInfo()
void __cdecl Inter_GuildAttendanceInfo::~Inter_GuildAttendanceInfo(Inter_GuildAttendanceInfo *this)
{
  Inter_GuildAttendanceInfo::~Inter_GuildAttendanceInfo(this);
  operator delete(this);
}
