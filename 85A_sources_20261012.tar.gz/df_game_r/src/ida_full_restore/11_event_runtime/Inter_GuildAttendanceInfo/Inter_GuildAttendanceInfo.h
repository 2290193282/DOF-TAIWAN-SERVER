#ifndef __IDA91_INTER_GUILDATTENDANCEINFO_H__
#define __IDA91_INTER_GUILDATTENDANCEINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_GuildAttendanceInfo
// Source unit: Inter_GuildAttendanceInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 3200

/* 3200 */
struct Inter_GuildAttendanceInfo;

// Exported member functions:
// 0x84E4052	Inter_GuildAttendanceInfo::dispatch_sig(CUser *,char *,int)
// 0x84EEA78	Inter_GuildAttendanceInfo::Inter_GuildAttendanceInfo(void)
// 0x84F65E2	Inter_GuildAttendanceInfo::~Inter_GuildAttendanceInfo()
// 0x84F6612	Inter_GuildAttendanceInfo::~Inter_GuildAttendanceInfo()

// Function declaration index:
// DECL 0x84E4052 Inter_GuildAttendanceInfo::dispatch_sig
// DECL 0x84EEA78 Inter_GuildAttendanceInfo::Inter_GuildAttendanceInfo
// DECL 0x84F65E2 Inter_GuildAttendanceInfo::~Inter_GuildAttendanceInfo
// DECL 0x84F6612 Inter_GuildAttendanceInfo::~Inter_GuildAttendanceInfo

#endif  // __IDA91_INTER_GUILDATTENDANCEINFO_H__
