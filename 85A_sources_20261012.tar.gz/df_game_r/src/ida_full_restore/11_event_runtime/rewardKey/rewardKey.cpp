#include "rewardKey.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x80F11F0
// IDA_NAME: _ZN9rewardKeyC2Ev
// DEMANGLED: rewardKey::rewardKey(void)
void __cdecl rewardKey::rewardKey(rewardKey *this)
{
  *(_BYTE *)this = 0;
  *((_BYTE *)this + 1) = 0;
  *((_BYTE *)this + 2) = 0;
  rewardSubKey::rewardSubKey((rewardKey *)((char *)this + 3));
}

// IDA_EA: 0x80F121A
// IDA_NAME: _ZNK9rewardKeyltERKS_
// DEMANGLED: rewardKey::operator<(rewardKey const&)const
bool __cdecl rewardKey::operator<(_BYTE *a1, _BYTE *a2)
{
  if ( *a1 != *a2 )
    return *a1 < *a2;
  if ( a1[1] != a2[1] )
    return a1[1] < a2[1];
  if ( a1[2] == a2[2] )
    return rewardSubKey::operator<(a1 + 3, a2 + 3);
  return a1[2] < a2[2];
}

// IDA_EA: 0x80F12AC
// IDA_NAME: _ZN9rewardKey5clearEv
// DEMANGLED: rewardKey::clear(void)
rewardSubKey *__cdecl rewardKey::clear(rewardKey *this)
{
  *(_BYTE *)this = 0;
  *((_BYTE *)this + 1) = 0;
  *((_BYTE *)this + 2) = 0;
  return rewardSubKey::clear((rewardKey *)((char *)this + 3));
}
