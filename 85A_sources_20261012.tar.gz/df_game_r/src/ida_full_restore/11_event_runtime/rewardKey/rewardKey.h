#ifndef __IDA91_REWARDKEY_H__
#define __IDA91_REWARDKEY_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: rewardKey
// Source unit: rewardKey
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1150

/* 1150 */
struct rewardKey;

// Exported member functions:
// 0x80F11F0	rewardKey::rewardKey(void)
// 0x80F121A	rewardKey::operator<(rewardKey const&)const
// 0x80F12AC	rewardKey::clear(void)

// Function declaration index:
// DECL 0x80F11F0 rewardKey::rewardKey
// DECL 0x80F121A rewardKey::operator<
// DECL 0x80F12AC rewardKey::clear

#endif  // __IDA91_REWARDKEY_H__
