#include "CConditionEventManager.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8334844
// IDA_NAME: _ZN22CConditionEventManagerC2Ev
// DEMANGLED: CConditionEventManager::CConditionEventManager(void)
void __cdecl CConditionEventManager::CConditionEventManager(CConditionEventManager *this)
{
  ;
}

// IDA_EA: 0x833484A
// IDA_NAME: _ZN22CConditionEventManagerD2Ev
// DEMANGLED: CConditionEventManager::~CConditionEventManager()
void CConditionEventManager::~CConditionEventManager()
{
  ;
}

// IDA_EA: 0x8334850
// IDA_NAME: _ZN22CConditionEventManager27RequestConditionEventRewardEP5CUserscRSt3mapIiiSt4lessIiESaISt4pairIKiiEEE
// DEMANGLED: CConditionEventManager::RequestConditionEventReward(CUser *,short,char,std::map<int,int,std::less<int>,std::allocator<std::pair<int const,int>>> &)
int __usercall CConditionEventManager::RequestConditionEventReward@<eax>(
        int n17@<ebx>,
        int a2,
        CUserCharacInfo *a3,
        __int16 a4,
        char a5,
        int CharacLevelUpGift_AccountOnceEv)
{
  int RepeatEvent; // eax
  CInventory *CurCharacInvenREv; // eax
  int EventCoin; // esi
  unsigned int v10; // esi
  CInventory *CurCharacInvenWEv; // eax
  int v12; // esi
  CInventory *CurCharacInvenREv_1; // eax
  int v14; // eax
  unsigned int n2; // esi
  CItemList **v16; // eax
  int v17; // esi
  int v18; // eax
  int v21; // esi
  int v22; // eax
  int v23; // esi
  CUserCharacInfo **CurCharacInvenWEv_2; // eax
  const char *src_3; // eax
  const char *src_4; // eax
  int v28; // esi
  size_t v29; // edi
  int CurCharacNoEv_1; // eax
  CUserCharacInfo **CurCharacInvenWEv_1; // eax
  const char *src_1; // eax
  const char *src_2; // eax
  int ServerGroup; // esi
  size_t v35; // edi
  int CurCharacNoEv; // eax
  char s[256]; // [esp+63h] [ebp-1F5h] BYREF
  __int64 v39; // [esp+163h] [ebp-F5h] BYREF
  int v40; // [esp+16Bh] [ebp-EDh]
  int v41; // [esp+16Fh] [ebp-E9h]
  int v42; // [esp+173h] [ebp-E5h]
  int v43; // [esp+177h] [ebp-E1h]
  int v44; // [esp+17Bh] [ebp-DDh]
  int v45; // [esp+17Fh] [ebp-D9h]
  int v46; // [esp+183h] [ebp-D5h]
  int v47; // [esp+187h] [ebp-D1h]
  int v48; // [esp+18Bh] [ebp-CDh]
  int v49; // [esp+18Fh] [ebp-C9h]
  int v50; // [esp+193h] [ebp-C5h]
  int v51; // [esp+197h] [ebp-C1h]
  int v52; // [esp+19Bh] [ebp-BDh]
  char v53; // [esp+19Fh] [ebp-B9h]
  char src[30]; // [esp+1A0h] [ebp-B8h] BYREF
  char dest[30]; // [esp+1BEh] [ebp-9Ah] BYREF
  int v56[6]; // [esp+1DCh] [ebp-7Ch] BYREF
  int v57[3]; // [esp+1F4h] [ebp-64h] BYREF
  int v58; // [esp+200h] [ebp-58h] BYREF
  bool v59; // [esp+207h] [ebp-51h] BYREF
  int v60; // [esp+208h] [ebp-50h] BYREF
  int v61; // [esp+20Ch] [ebp-4Ch] BYREF
  std::_Rb_tree_node_base *v62; // [esp+210h] [ebp-48h] BYREF
  _BYTE v63[12]; // [esp+214h] [ebp-44h] BYREF
  int v64; // [esp+220h] [ebp-38h] BYREF
  int v65; // [esp+224h] [ebp-34h]
  __int16 CurConditionEventStep; // [esp+228h] [ebp-30h]
  __int16 CurConditionEventRewardStep; // [esp+22Ah] [ebp-2Eh]
  int item; // [esp+22Ch] [ebp-2Ch]
  CUser *n50000; // [esp+230h] [ebp-28h]
  int CurSecEv; // [esp+234h] [ebp-24h]
  int v71; // [esp+238h] [ebp-20h]
  int inserted; // [esp+23Ch] [ebp-1Ch]

  RepeatEvent = CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 113);
  if ( (*(unsigned __int8 (__cdecl **)(int, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) != 1 )
    return 0;
  v65 = *(_DWORD *)(G_CDataManager() + 19864);
  if ( a4 != v65 )
    return 1;
  if ( a5 <= 0 )
    return 19;
  CurConditionEventStep = CUserCharacInfo::GetCurConditionEventStep(a3);
  if ( a5 > CurConditionEventStep )
    return 19;
  CurConditionEventRewardStep = CUserCharacInfo::GetCurConditionEventRewardStep(a3);
  if ( CurConditionEventRewardStep != a5 - 1 )
    return 19;
  std::vector<stConditionEventRewardInfo>::vector(v63);
  CConditionEventManager::GetConditionRewardInfo(a2, 0, v63, a4, a5);
  CConditionEventManager::ConditionRewardSameItemCombine(a2, v63, CharacLevelUpGift_AccountOnceEv);
  if ( !std::map<int,int>::empty(CharacLevelUpGift_AccountOnceEv) )
  {
    std::map<int,int>::begin(&v62, CharacLevelUpGift_AccountOnceEv);
    while ( 1 )
    {
      std::map<int,int>::end((int)&v64);
      if ( !std::_Rb_tree_iterator<std::pair<int const,int>>::operator!=(&v62, &v64) )
        goto LABEL_55;
      if ( *(_DWORD *)std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v62) == 1
        && *(int *)(std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v62) + 4) >= 0 )
      {
        CurCharacInvenREv = (CInventory *)CUserCharacInfo::getCurCharacInvenR(a3);
        EventCoin = CInventory::GetEventCoin(CurCharacInvenREv);
        v10 = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v62) + 4) + EventCoin;
        CurCharacInvenWEv = (CInventory *)CUserCharacInfo::getCurCharacInvenW(a3);
        CInventory::SetEventCoin(CurCharacInvenWEv, v10);
        v12 = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v62) + 4);
        CurCharacInvenREv_1 = (CInventory *)CUserCharacInfo::getCurCharacInvenR(a3);
        v14 = CInventory::GetEventCoin(CurCharacInvenREv_1);
        cUserHistoryLog::EventCoinAdd((char *)a3 + 497408, v14, v12, 2);
        CUser::SaveMoneyCoin(a3);
        CUser::SendCoin(a3);
        goto LABEL_53;
      }
      n2 = *(_DWORD *)std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v62);
      v16 = (CItemList **)G_CDataManager();
      item = CDataManager::find_item(v16, n2);
      if ( !item )
      {
        n17 = 17;
        goto LABEL_56;
      }
      Inven_Item::Inven_Item((Inven_Item *)&v39);
      *(_DWORD *)((char *)&v39 + 2) = *(_DWORD *)std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v62);
      v17 = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v62) + 4);
      v18 = G_CDataManager();
      CItemList::create_item(*(CItemList **)(v18 + 12), 0, (Inven_Item *)&v39, v17);
      if ( *(_DWORD *)((char *)&v39 + 2) && Inven_Item::get_add_info((Inven_Item *)&v39) )
        break;
LABEL_53:
      std::_Rb_tree_iterator<std::pair<int const,int>>::operator++(&v62);
    }
    v61 = 0;
    v60 = 0;
    v59 = 0;
    if ( !(unsigned __int8)WongWork::CCeraShop::IsSpecialItem(
                             GlobalData::s_pCeraShop,
                             *(int *)((char *)&v39 + 2),
                             &v61,
                             &v60,
                             &v59) )
    {
      inserted = -1;
      CurCharacInvenWEv_1 = (CUserCharacInfo **)CUserCharacInfo::getCurCharacInvenW(a3);
      inserted = CInventory::insertItemIntoInventory(
                   CurCharacInvenWEv_1,
                   v39,
                   v40,
                   v41,
                   v42,
                   v43,
                   v44,
                   v45,
                   v46,
                   v47,
                   v48,
                   v49,
                   v50,
                   v51,
                   v52,
                   v53,
                   37,
                   1u,
                   1u);
      if ( inserted >= 0 )
      {
        if ( (unsigned __int8)Inven_Item::IsCreatureItemType((Inven_Item *)&v39) )
          CUser::SendUpdateItem(a3, 1, 7, inserted);
        else
          CUser::SendUpdateItem(a3, 1, 0, inserted);
      }
      else
      {
        src_1 = (const char *)RDARScriptStringManager::findString(
                                (RDARScriptStringManager *)&g_scriptStringManager_,
                                4,
                                "game_server_msg_80",
                                0);
        strncpy(src, src_1, 0x1Du);
        src_2 = (const char *)RDARScriptStringManager::findString(
                                (RDARScriptStringManager *)&g_scriptStringManager_,
                                4,
                                "game_server_msg_81",
                                0);
        strncpy(s, src_2, 0xFFu);
        ServerGroup = CUser::GetServerGroup(a3);
        v35 = strlen(s);
        CurCharacNoEv = CUserCharacInfo::getCurCharacNo(a3);
        WongWork::CMailBoxHelper::ReqDBSendNewSystemMail(
          src,
          (Inven_Item *)&v39,
          0,
          CurCharacNoEv,
          s,
          v35,
          0,
          ServerGroup,
          0,
          0);
        Inven_Item::reset((Inven_Item *)&v39);
      }
      goto LABEL_53;
    }
    if ( (*(int (__cdecl **)(int))(*(_DWORD *)item + 12))(item) == 16 || *(_DWORD *)((char *)&v39 + 2) == 1 )
    {
      if ( (*(int (__cdecl **)(int))(*(_DWORD *)item + 12))(item) == 16 )
      {
        v71 = -1;
        CurCharacInvenWEv_2 = (CUserCharacInfo **)CUserCharacInfo::getCurCharacInvenW(a3);
        v71 = CInventory::insertItemIntoInventory(
                CurCharacInvenWEv_2,
                v39,
                v40,
                v41,
                v42,
                v43,
                v44,
                v45,
                v46,
                v47,
                v48,
                v49,
                v50,
                v51,
                v52,
                v53,
                37,
                1u,
                1u);
        if ( v71 >= 0 )
        {
          CUser::SendUpdateItem(a3, 1, 0, v71);
        }
        else
        {
          src_3 = (const char *)RDARScriptStringManager::findString(
                                  (RDARScriptStringManager *)&g_scriptStringManager_,
                                  4,
                                  "game_server_msg_80",
                                  0);
          strncpy(dest, src_3, 0x1Du);
          src_4 = (const char *)RDARScriptStringManager::findString(
                                  (RDARScriptStringManager *)&g_scriptStringManager_,
                                  4,
                                  "game_server_msg_81",
                                  0);
          strncpy(s, src_4, 0xFFu);
          v28 = CUser::GetServerGroup(a3);
          v29 = strlen(s);
          CurCharacNoEv_1 = CUserCharacInfo::getCurCharacNo(a3);
          WongWork::CMailBoxHelper::ReqDBSendNewSystemMail(
            dest,
            (Inven_Item *)&v39,
            0,
            CurCharacNoEv_1,
            s,
            v29,
            0,
            v28,
            0,
            0);
          Inven_Item::reset((Inven_Item *)&v39);
        }
      }
      goto LABEL_53;
    }
    v58 = 0;
    v21 = *(_DWORD *)((char *)&v39 + 2);
    v22 = G_CDataManager();
    n50000 = (CUser *)CItemList::GetRestrictCode(*(CItemList **)(v22 + 12), v21);
    CurSecEv = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
    std::vector<Inven_Item>::vector((int)v57);
    WongWork::CCeraShop::stCeraShopItemParam_t::stCeraShopItemParam_t((WongWork::CCeraShop::stCeraShopItemParam_t *)v56);
    if ( (unsigned __int8)WongWork::CCeraShop::ProcessSpecialItem(
                            GlobalData::s_pCeraShop,
                            a3,
                            *(int *)((char *)&v39 + 2),
                            (int)n50000,
                            &v58,
                            CurSecEv,
                            1,
                            (int)v57,
                            (int)v56,
                            0,
                            0,
                            0,
                            1) )
    {
      if ( v58 )
      {
        n17 = 17;
        v23 = 0;
        goto LABEL_41;
      }
      if ( n50000 && (unsigned __int8)CUser::IsRestrictedGoods(a3, (int)n50000) != 1 )
      {
        CUser::SetRestrictedGoods(a3, (int)n50000);
        WongWork::CCeraShop::SaveFeaturedIdx(a3, n50000, CurSecEv, 0);
        CUser::SendRestrictedGoods(a3, 1, (int)n50000);
      }
    }
    v23 = 1;
LABEL_41:
    WongWork::CCeraShop::stCeraShopItemParam_t::~stCeraShopItemParam_t((WongWork::CCeraShop::stCeraShopItemParam_t *)v56);
    std::vector<Inven_Item>::~vector(v57);
    if ( !v23 )
      goto LABEL_56;
    goto LABEL_53;
  }
LABEL_55:
  CUserCharacInfo::IncCurConditionEventRewardStep(a3);
  n17 = 0;
LABEL_56:
  std::vector<stConditionEventRewardInfo>::~vector(v63);
  return n17;
}

// IDA_EA: 0x8335264
// IDA_NAME: _ZN22CConditionEventManager30ConditionRewardSameItemCombineERSt6vectorI26stConditionEventRewardInfoSaIS1_EERSt3mapIiiSt4lessIiESaISt4pairIKiiEEE
// DEMANGLED: CConditionEventManager::ConditionRewardSameItemCombine(std::vector<stConditionEventRewardInfo,std::allocator<stConditionEventRewardInfo>> &,std::map<int,int,std::less<int>,std::allocator<std::pair<int const,int>>> &)
bool __cdecl CConditionEventManager::ConditionRewardSameItemCombine(int a1, _BYTE *p_src)
{
  int v2; // ebx
  int v3; // eax
  int v4; // ebx
  int v5; // esi
  bool result; // al
  int v7; // [esp+18h] [ebp-30h] BYREF
  int v8; // [esp+1Ch] [ebp-2Ch] BYREF
  _BYTE v9[4]; // [esp+20h] [ebp-28h] BYREF
  int v10; // [esp+24h] [ebp-24h] BYREF
  _BYTE v11[8]; // [esp+28h] [ebp-20h] BYREF
  int v12; // [esp+30h] [ebp-18h] BYREF
  _DWORD v13[4]; // [esp+38h] [ebp-10h] BYREF

  std::vector<stConditionEventRewardInfo>::begin((int)&v8, (int)p_src);
  while ( 1 )
  {
    std::vector<stConditionEventRewardInfo>::end((int)v9, (int)p_src);
    result = __gnu_cxx::operator!=<stConditionEventRewardInfo *,std::vector<stConditionEventRewardInfo>>(
               (int)&v8,
               (int)v9);
    if ( !result )
      break;
    __gnu_cxx::__normal_iterator<stConditionEventRewardInfo *,std::vector<stConditionEventRewardInfo>>::operator->((int)&v8);
    std::map<int,int>::find((int)&v7);
    std::map<int,int>::end((int)&v10);
    if ( std::_Rb_tree_iterator<std::pair<int const,int>>::operator==(&v7, &v10) )
    {
      v2 = __gnu_cxx::__normal_iterator<stConditionEventRewardInfo *,std::vector<stConditionEventRewardInfo>>::operator->((int)&v8)
         + 4;
      v3 = __gnu_cxx::__normal_iterator<stConditionEventRewardInfo *,std::vector<stConditionEventRewardInfo>>::operator->((int)&v8);
      std::make_pair<int &,int &>(v13, v3, v2);
      std::pair<int const,int>::pair<int,int>(&v12, (int)v13);
      std::map<int,int>::insert((int)v11);
    }
    else
    {
      v4 = std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v7);
      v5 = *(_DWORD *)(v4 + 4);
      *(_DWORD *)(v4 + 4) = v5
                          + *(_DWORD *)(__gnu_cxx::__normal_iterator<stConditionEventRewardInfo *,std::vector<stConditionEventRewardInfo>>::operator->((int)&v8)
                                      + 4);
    }
    __gnu_cxx::__normal_iterator<stConditionEventRewardInfo *,std::vector<stConditionEventRewardInfo>>::operator++(&v8);
  }
  return result;
}

// IDA_EA: 0x83353A0
// IDA_NAME: _ZN22CConditionEventManager22GetConditionRewardInfoEcRSt6vectorI26stConditionEventRewardInfoSaIS1_EEsc
// DEMANGLED: CConditionEventManager::GetConditionRewardInfo(char,std::vector<stConditionEventRewardInfo,std::allocator<stConditionEventRewardInfo>> &,short,char)
char __cdecl CConditionEventManager::GetConditionRewardInfo(int this, char a2, _DWORD *a3, __int16 a4, char a5)
{
  int RepeatEvent; // eax
  int v6; // eax
  int v7; // eax
  _DWORD v9[2]; // [esp+24h] [ebp-34h] BYREF
  __int16 v10; // [esp+2Ch] [ebp-2Ch]
  std::_Rb_tree_node_base *src_; // [esp+30h] [ebp-28h] BYREF
  int v12; // [esp+34h] [ebp-24h] BYREF
  _DWORD v13[3]; // [esp+38h] [ebp-20h] BYREF
  _BYTE dest[4]; // [esp+44h] [ebp-14h] BYREF
  int v15; // [esp+48h] [ebp-10h]
  int v16; // [esp+4Ch] [ebp-Ch]

  RepeatEvent = CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 113);
  v6 = (*(int (__cdecl **)(int, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) ^ 1;
  if ( !(_BYTE)v6 )
  {
    v15 = *(_DWORD *)(G_CDataManager() + 19864);
    LOBYTE(v6) = a4;
    if ( a4 == v15 )
    {
      std::vector<stConditionEventRewardInfo>::clear(a3);
      if ( a2 )
        v16 = G_CDataManager() + 19920;
      else
        v16 = G_CDataManager() + 19896;
      v13[1] = a5;
      std::multimap<int,stConditionEventRewardInfo>::lower_bound((int)v13);
      v13[2] = a5;
      std::multimap<int,stConditionEventRewardInfo>::upper_bound((int)&v12);
      for ( src_ = (std::_Rb_tree_node_base *)v13[0];
            ;
            std::_Rb_tree_iterator<std::pair<int const,stConditionEventRewardInfo>>::operator++(dest, &src_) )
      {
        LOBYTE(v6) = std::_Rb_tree_iterator<std::pair<int const,stConditionEventRewardInfo>>::operator!=(&src_, &v12);
        if ( !(_BYTE)v6 )
          break;
        v7 = std::_Rb_tree_iterator<std::pair<int const,stConditionEventRewardInfo>>::operator->(&src_);
        v9[0] = *(_DWORD *)(v7 + 4);
        v9[1] = *(_DWORD *)(v7 + 8);
        v10 = *(_WORD *)(v7 + 12);
        std::vector<stConditionEventRewardInfo>::push_back((int)a3, (int)v9);
      }
    }
  }
  return v6;
}

// IDA_EA: 0x83354F0
// IDA_NAME: _ZN22CConditionEventManager16GetMaxRewardStepEs
// DEMANGLED: CConditionEventManager::GetMaxRewardStep(short)
int __cdecl CConditionEventManager::GetMaxRewardStep(CConditionEventManager *this, __int16 a2)
{
  int RepeatEvent; // eax
  int v4; // eax

  RepeatEvent = CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 113);
  if ( (*(unsigned __int8 (__cdecl **)(int, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) != 1 )
    return 0;
  if ( a2 != *(_DWORD *)(G_CDataManager() + 19864) )
    return 0;
  v4 = G_CDataManager();
  return std::map<int,std::pair<int,int>>::size(v4 + 19872);
}

// IDA_EA: 0x8335566
// IDA_NAME: _ZN22CConditionEventManager18ProcessCheckStepUpEP5CUsers
// DEMANGLED: CConditionEventManager::ProcessCheckStepUp(CUser *,short)
int __cdecl CConditionEventManager::ProcessCheckStepUp(CConditionEventManager *this, CUser *a2, __int16 n2)
{
  int RepeatEvent; // eax
  int n2_1; // eax
  int n2_2; // [esp+2Ch] [ebp-Ch]

  RepeatEvent = CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 113);
  n2_1 = (*(int (__cdecl **)(int, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) ^ 1;
  if ( !(_BYTE)n2_1 )
  {
    n2_2 = *(_DWORD *)(G_CDataManager() + 19864);
    n2_1 = n2;
    if ( n2 == n2_2 )
    {
      n2_1 = n2;
      if ( n2 == 2 )
        return CConditionEventManager::_processProperDungeonClearEvent(this, a2, n2);
    }
  }
  return n2_1;
}

// IDA_EA: 0x83355E6
// IDA_NAME: _ZN22CConditionEventManager31_processProperDungeonClearEventEP5CUsers
// DEMANGLED: CConditionEventManager::_processProperDungeonClearEvent(CUser *,short)
void __cdecl CConditionEventManager::_processProperDungeonClearEvent(CConditionEventManager *this, CUser *a2)
{
  PacketPool *v2[3]; // [esp+24h] [ebp-24h] BYREF
  _DWORD v3[3]; // [esp+30h] [ebp-18h] BYREF
  int ProperDungeonClearCount; // [esp+3Ch] [ebp-Ch]

  v3[2] = (__int16)CUserCharacInfo::GetCurConditionEventStep(a2);
  CConditionEventManager::_getRequiredParameter((CConditionEventManager *)v3, (__int16)this);
  ProperDungeonClearCount = (__int16)CUserCharacInfo::GetProperDungeonClearCount(a2);
  PacketGuard::PacketGuard((PacketGuard *)v2);
  if ( v3[0] != -1 && v3[0] <= ProperDungeonClearCount )
  {
    CUserCharacInfo::IncCurConditionEventStep(a2);
    CUser::SendConditionEventInfo(a2);
  }
  CUser::SendProperDungeonClearCount(a2);
  PacketGuard::~PacketGuard(v2);
}

// IDA_EA: 0x83356A4
// IDA_NAME: _ZN22CConditionEventManager21_getRequiredParameterEs
// DEMANGLED: CConditionEventManager::_getRequiredParameter(short)
CConditionEventManager *__stdcall CConditionEventManager::_getRequiredParameter(
        CConditionEventManager *this,
        __int16 a2,
        __int16 a3)
{
  _DWORD v4[2]; // [esp+24h] [ebp-14h] BYREF
  _DWORD v5[2]; // [esp+2Ch] [ebp-Ch] BYREF

  std::pair<int,int>::pair(this);
  v4[1] = a3;
  G_CDataManager();
  std::map<int,std::pair<int,int>>::find((int)v4);
  G_CDataManager();
  std::map<int,std::pair<int,int>>::end((int)v5);
  if ( std::_Rb_tree_iterator<std::pair<int const,std::pair<int,int>>>::operator!=(v4, v5) )
  {
    *(_DWORD *)this = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,std::pair<int,int>>>::operator*(v4) + 4);
    *((_DWORD *)this + 1) = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,std::pair<int,int>>>::operator*(v4)
                                      + 8);
  }
  else
  {
    *(_DWORD *)this = -1;
    *((_DWORD *)this + 1) = -1;
  }
  return this;
}

// IDA_EA: 0x8335754
// IDA_NAME: _ZN22CConditionEventManager16GetCurEventIndexEv
// DEMANGLED: CConditionEventManager::GetCurEventIndex(void)
int CConditionEventManager::GetCurEventIndex()
{
  int RepeatEvent; // eax

  RepeatEvent = CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 113);
  if ( (*(unsigned __int8 (__cdecl **)(int, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) == 1 )
    return *(_DWORD *)(G_CDataManager() + 19864);
  else
    return 0;
}

// IDA_EA: 0x833579E
// IDA_NAME: _ZN22CConditionEventManager14IsFreeGoldCardEP5CUserc
// DEMANGLED: CConditionEventManager::IsFreeGoldCard(CUser *,char)
int __cdecl CConditionEventManager::IsFreeGoldCard(CConditionEventManager *this, CUser *a2, char a3)
{
  int v3; // ebx
  _BYTE v5[13]; // [esp+30h] [ebp-18h] BYREF
  unsigned __int8 IsFreeGoldCardProcess; // [esp+3Dh] [ebp-Bh]
  __int16 CurEventIndex; // [esp+3Eh] [ebp-Ah]

  IsFreeGoldCardProcess = CConditionEventManager::CheckErrorCardForStep(this, a2, a3);
  if ( IsFreeGoldCardProcess != 1 )
    return 0;
  CurEventIndex = CConditionEventManager::GetCurEventIndex();
  std::vector<stConditionEventRewardInfo>::vector(v5);
  CConditionEventManager::GetConditionRewardInfo((int)this, 0, (int)v5, CurEventIndex, a3);
  IsFreeGoldCardProcess = CConditionEventManager::IsFreeGoldCardProcess(this, v5);
  v3 = IsFreeGoldCardProcess;
  std::vector<stConditionEventRewardInfo>::~vector(v5);
  return v3;
}

// IDA_EA: 0x833586C
// IDA_NAME: _ZN22CConditionEventManager21IsFreeGoldCardProcessERSt6vectorI26stConditionEventRewardInfoSaIS1_EE
// DEMANGLED: CConditionEventManager::IsFreeGoldCardProcess(std::vector<stConditionEventRewardInfo,std::allocator<stConditionEventRewardInfo>> &)
int __cdecl CConditionEventManager::IsFreeGoldCardProcess(CConditionEventManager *this, _BYTE *a2)
{
  unsigned int i; // [esp+1Ch] [ebp-Ch]

  for ( i = 0; std::vector<stConditionEventRewardInfo>::size(a2) > i; ++i )
  {
    if ( *(_BYTE *)(std::vector<stConditionEventRewardInfo>::operator[](a2, i) + 8) )
      return 1;
  }
  return 0;
}

// IDA_EA: 0x83358BC
// IDA_NAME: _ZN22CConditionEventManager16IsDoubleGoldCardEP5CUserc
// DEMANGLED: CConditionEventManager::IsDoubleGoldCard(CUser *,char)
int __cdecl CConditionEventManager::IsDoubleGoldCard(CConditionEventManager *this, CUser *a2, char a3)
{
  int v3; // ebx
  CParty *Party; // eax
  _BYTE v7[12]; // [esp+30h] [ebp-28h] BYREF
  _BYTE v8[15]; // [esp+3Ch] [ebp-1Ch] BYREF
  unsigned __int8 IsDoubleGoldCardProcess; // [esp+4Bh] [ebp-Dh]
  int CurEventIndex; // [esp+4Ch] [ebp-Ch]

  IsDoubleGoldCardProcess = CConditionEventManager::CheckErrorCardForStep(this, a2, a3);
  if ( IsDoubleGoldCardProcess != 1 )
    return 0;
  CurEventIndex = CConditionEventManager::GetCurEventIndex();
  std::vector<stConditionEventRewardInfo>::vector(v8);
  CConditionEventManager::GetConditionRewardInfo((int)this, 0, (int)v8, CurEventIndex, a3);
  IsDoubleGoldCardProcess = CConditionEventManager::IsDoubleGoldCardProcess(this, v8);
  if ( IsDoubleGoldCardProcess != 1 && CUser::GetParty(a2) )
  {
    Party = (CParty *)CUser::GetParty(a2);
    if ( (unsigned __int8)CParty::is_quick_party(Party) )
    {
      std::vector<stConditionEventRewardInfo>::vector(v7);
      CConditionEventManager::GetConditionRewardInfo((int)this, 1, (int)v7, CurEventIndex, a3);
      IsDoubleGoldCardProcess = CConditionEventManager::IsDoubleGoldCardProcess(this, v7);
      std::vector<stConditionEventRewardInfo>::~vector(v7);
    }
  }
  v3 = IsDoubleGoldCardProcess;
  std::vector<stConditionEventRewardInfo>::~vector(v8);
  return v3;
}

// IDA_EA: 0x8335A3A
// IDA_NAME: _ZN22CConditionEventManager23IsDoubleGoldCardProcessERSt6vectorI26stConditionEventRewardInfoSaIS1_EE
// DEMANGLED: CConditionEventManager::IsDoubleGoldCardProcess(std::vector<stConditionEventRewardInfo,std::allocator<stConditionEventRewardInfo>> &)
int __cdecl CConditionEventManager::IsDoubleGoldCardProcess(CConditionEventManager *this, _BYTE *a2)
{
  unsigned int i; // [esp+1Ch] [ebp-Ch]

  for ( i = 0; std::vector<stConditionEventRewardInfo>::size(a2) > i; ++i )
  {
    if ( *(_BYTE *)(std::vector<stConditionEventRewardInfo>::operator[](a2, i) + 9) )
      return 1;
  }
  return 0;
}

// IDA_EA: 0x8335A8A
// IDA_NAME: _ZN22CConditionEventManager21CheckErrorCardForStepEP5CUserc
// DEMANGLED: CConditionEventManager::CheckErrorCardForStep(CUser *,char)
_BOOL4 __cdecl CConditionEventManager::CheckErrorCardForStep(CConditionEventManager *this, CUser *a2, char a3)
{
  int v4; // [esp+24h] [ebp-14h] BYREF
  int ProperDungeonClearCount; // [esp+2Ch] [ebp-Ch]

  if ( !a2 )
    return 0;
  if ( (unsigned __int8)CUserCharacInfo::IsProperDungeonUser(a2) != 1 )
    return 0;
  if ( a3 < 0 )
    return 0;
  CConditionEventManager::_getRequiredParameter((CConditionEventManager *)&v4, (__int16)this, a3);
  ProperDungeonClearCount = (__int16)CUserCharacInfo::GetProperDungeonClearCount(a2);
  return v4 != -1 && v4 >= ProperDungeonClearCount;
}
