#ifndef __IDA91_CCONDITIONEVENTMANAGER_H__
#define __IDA91_CCONDITIONEVENTMANAGER_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CConditionEventManager
// Source unit: CConditionEventManager
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
//   #include "world/CDungeon.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2343

/* 2343 */
struct CConditionEventManager;

// Exported member functions:
// 0x8334844	CConditionEventManager::CConditionEventManager(void)
// 0x833484A	CConditionEventManager::~CConditionEventManager()
// 0x8334850	CConditionEventManager::RequestConditionEventReward(CUser *,short,char,std::map<int,int,std::less<int>,std::allocator<std::pair<int const,int>>> &)
// 0x8335264	CConditionEventManager::ConditionRewardSameItemCombine(std::vector<stConditionEventRewardInfo,std::allocator<stConditionEventRewardInfo>> &,std::map<int,int,std::less<int>,std::allocator<std::pair<int const,int>>> &)
// 0x83353A0	CConditionEventManager::GetConditionRewardInfo(char,std::vector<stConditionEventRewardInfo,std::allocator<stConditionEventRewardInfo>> &,short,char)
// 0x83354F0	CConditionEventManager::GetMaxRewardStep(short)
// 0x8335566	CConditionEventManager::ProcessCheckStepUp(CUser *,short)
// 0x83355E6	CConditionEventManager::_processProperDungeonClearEvent(CUser *,short)
// 0x83356A4	CConditionEventManager::_getRequiredParameter(short)
// 0x8335754	CConditionEventManager::GetCurEventIndex(void)
// 0x833579E	CConditionEventManager::IsFreeGoldCard(CUser *,char)
// 0x833586C	CConditionEventManager::IsFreeGoldCardProcess(std::vector<stConditionEventRewardInfo,std::allocator<stConditionEventRewardInfo>> &)
// 0x83358BC	CConditionEventManager::IsDoubleGoldCard(CUser *,char)
// 0x8335A3A	CConditionEventManager::IsDoubleGoldCardProcess(std::vector<stConditionEventRewardInfo,std::allocator<stConditionEventRewardInfo>> &)
// 0x8335A8A	CConditionEventManager::CheckErrorCardForStep(CUser *,char)

// Function declaration index:
// DECL 0x8334844 CConditionEventManager::CConditionEventManager
// DECL 0x833484A CConditionEventManager::~CConditionEventManager
// DECL 0x8334850 CConditionEventManager::RequestConditionEventReward
// DECL 0x8335264 CConditionEventManager::ConditionRewardSameItemCombine
// DECL 0x83353A0 CConditionEventManager::GetConditionRewardInfo
// DECL 0x83354F0 CConditionEventManager::GetMaxRewardStep
// DECL 0x8335566 CConditionEventManager::ProcessCheckStepUp
// DECL 0x83355E6 CConditionEventManager::_processProperDungeonClearEvent
// DECL 0x83356A4 CConditionEventManager::_getRequiredParameter
// DECL 0x8335754 CConditionEventManager::GetCurEventIndex
// DECL 0x833579E CConditionEventManager::IsFreeGoldCard
// DECL 0x833586C CConditionEventManager::IsFreeGoldCardProcess
// DECL 0x83358BC CConditionEventManager::IsDoubleGoldCard
// DECL 0x8335A3A CConditionEventManager::IsDoubleGoldCardProcess
// DECL 0x8335A8A CConditionEventManager::CheckErrorCardForStep

#endif  // __IDA91_CCONDITIONEVENTMANAGER_H__
