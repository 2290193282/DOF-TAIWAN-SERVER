#include "STEventSuper.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8A3D4CC
// IDA_NAME: _ZN12STEventSuper5clearEv
// DEMANGLED: STEventSuper::clear(void)
STEventSuper *__cdecl STEventSuper::clear(STEventSuper *this)
{
  STEventSuper *this_1; // eax

  *(_DWORD *)this = -1;
  *((_DWORD *)this + 1) = -1;
  *((_DWORD *)this + 2) = -1;
  *((_DWORD *)this + 3) = 0;
  *((_BYTE *)this + 16) = 0;
  *((_DWORD *)this + 5) = -1;
  *((_DWORD *)this + 6) = -1;
  *((_DWORD *)this + 7) = -1;
  *((_DWORD *)this + 8) = -1;
  this_1 = this;
  *((_BYTE *)this + 36) = 0;
  return this_1;
}

// IDA_EA: 0x8A3D52E
// IDA_NAME: _ZN12STEventSuperC2Ev
// DEMANGLED: STEventSuper::STEventSuper(void)
void __cdecl STEventSuper::STEventSuper(STEventSuper *this)
{
  STEventSuper::clear(this);
}

// IDA_EA: 0x8A4D310
// IDA_NAME: _ZN12STEventSuperD2Ev
// DEMANGLED: STEventSuper::~STEventSuper()
void STEventSuper::~STEventSuper()
{
  ;
}
