#ifndef __IDA91_STEVENTSUPER_H__
#define __IDA91_STEVENTSUPER_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: STEventSuper
// Source unit: STEventSuper
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3996

/* 3996 */
struct STEventSuper;

// Exported member functions:
// 0x8A3D4CC	STEventSuper::clear(void)
// 0x8A3D52E	STEventSuper::STEventSuper(void)
// 0x8A4D310	STEventSuper::~STEventSuper()

// Function declaration index:
// DECL 0x8A3D4CC STEventSuper::clear
// DECL 0x8A3D52E STEventSuper::STEventSuper
// DECL 0x8A4D310 STEventSuper::~STEventSuper

#endif  // __IDA91_STEVENTSUPER_H__
