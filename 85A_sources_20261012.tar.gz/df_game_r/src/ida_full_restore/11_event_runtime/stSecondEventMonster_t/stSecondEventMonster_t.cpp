#include "stSecondEventMonster_t.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x88F8EBE
// IDA_NAME: _ZN22stSecondEventMonster_tD2Ev
// DEMANGLED: stSecondEventMonster_t::~stSecondEventMonster_t()
void stSecondEventMonster_t::~stSecondEventMonster_t()
{
  ;
}
