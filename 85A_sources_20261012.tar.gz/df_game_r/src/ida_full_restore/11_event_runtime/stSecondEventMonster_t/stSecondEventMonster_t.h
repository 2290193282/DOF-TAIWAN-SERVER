#ifndef __IDA91_STSECONDEVENTMONSTER_T_H__
#define __IDA91_STSECONDEVENTMONSTER_T_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stSecondEventMonster_t
// Source unit: stSecondEventMonster_t
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3878

/* 3878 */
struct stSecondEventMonster_t;

// Exported member functions:
// 0x88F8EBE	stSecondEventMonster_t::~stSecondEventMonster_t()

// Function declaration index:
// DECL 0x88F8EBE stSecondEventMonster_t::~stSecondEventMonster_t

#endif  // __IDA91_STSECONDEVENTMONSTER_T_H__
