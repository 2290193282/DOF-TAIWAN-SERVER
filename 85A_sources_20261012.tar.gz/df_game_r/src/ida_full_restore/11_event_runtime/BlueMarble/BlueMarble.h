#ifndef __IDA91_BLUEMARBLE_H__
#define __IDA91_BLUEMARBLE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: BlueMarble
// Source unit: BlueMarble
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
//   #include "items/CItem.h"
//   #include "world/CDungeon.h"
// Local type ordinals: 1120

/* 1120 */
struct BlueMarble;

// Exported member functions:
// 0x80D6D48	BlueMarble::resetBlueMarble(void)
// 0x80D6D7C	BlueMarble::resetBuffInfo(int)
// 0x80D6DA2	BlueMarble::resetIndexInfo(int)
// 0x80D6DC8	BlueMarble::getState(void)const
// 0x80D6DD4	BlueMarble::checkStartBlueMarble(void)
// 0x80D6E34	BlueMarble::setBlueMarbleMap(void)
// 0x80D6E7C	BlueMarble::getBlueMarbleMap(void)const
// 0x80D6E88	BlueMarble::setMaxBoardSize(void)
// 0x80D6ECC	BlueMarble::getMaxBoardSize(void)const
// 0x80D6ED8	BlueMarble::checkThrowDice(int)
// 0x80D6F62	BlueMarble::throwDice(int)
// 0x80D6F88	BlueMarble::setDiceNumber(void)
// 0x80D6FC4	BlueMarble::getDiceNumber(void)const
// 0x80D6FD0	BlueMarble::setMovePosition(int,int)
// 0x80D7012	BlueMarble::getMovePosition(int)const
// 0x80D7038	BlueMarble::intoBoardZone(int)
// 0x80D70AE	BlueMarble::tileType(int)
// 0x80D738A	BlueMarble::setDungeonIndex(int,int)
// 0x80D73B6	BlueMarble::getDungeonIndex(int)const
// 0x80D73DC	BlueMarble::getRandomDungeon(int,BlueMarbleTileScript::Type)const
// 0x80D7690	BlueMarble::getRandomItem(void)const
// 0x80D7746	BlueMarble::setItemIndex(int,int)
// 0x80D7778	BlueMarble::getItemIndex(int)const
// 0x80D779E	BlueMarble::setExpBuff(int,int)
// 0x80D77CA	BlueMarble::getExpBuff(int)const
// 0x80D77F0	BlueMarble::setGoldBuff(int,int)
// 0x80D781C	BlueMarble::getGoldBuff(int)const
// 0x80D7842	BlueMarble::setDropBuff(int,int)
// 0x80D786E	BlueMarble::getDropBuff(int)const
// 0x80D7894	BlueMarble::setUserDeadCount(int)
// 0x80D78C2	BlueMarble::getUserDeadCount(int)const
// 0x80D78F0	BlueMarble::checkMoveFirstZone(int,BlueMarbleTileScript::Type)
// 0x80D793A	BlueMarble::setUserState(int,BlueMarbleUserState::T)
// 0x80D7966	BlueMarble::getUserState(int)const
// 0x80D798C	BlueMarble::checkLastZoneDungeonClear(int)
// 0x80D79EE	BlueMarble::finishBlueMarble(int)
// 0x80D7A26	BlueMarble::setVisitZone(int)
// 0x80D7A9A	BlueMarble::getVisitZone(int)const
// 0x80D7AFC	BlueMarble::setUserGrade(int)
// 0x80D7D5E	BlueMarble::getWinner(void)const
// 0x80D7DDE	BlueMarble::resultReward(void)
// 0x80D7E8E	BlueMarble::setResultItem(int,Inven_Item &)
// 0x80D800E	BlueMarble::insertItem(int,Inven_Item &,eItemAddReason)
// 0x80D82F2	BlueMarble::setLeaveUserSlot(int)
// 0x80D8412	BlueMarble::setLeaveUserBlueMarbleState(void)
// 0x80D84B4	BlueMarble::sendBlueMarbleRoomInfo(void)const
// 0x80D8600	BlueMarble::sendBlueMarbleDiceInfo(int)const
// 0x80D86B2	BlueMarble::sendStartBlueMarble(void)const
// 0x80D8752	BlueMarble::sendFinishBlueMarble(void)const
// 0x80D8802	BlueMarble::sendBoardZoneActionInfo(int,int,unsigned int)const
// 0x80D88C2	BlueMarble::sendTileGiveUpInfo(int)const
// 0x80D8956	BlueMarble::sendUpdateItemInfo(int,int)const
// 0x80D8A5C	BlueMarble::BlueMarble(void)
// 0x80D8BAE	BlueMarble::~BlueMarble()
// 0x80D8C26	BlueMarble::setMemoryPoolIndex(int)
// 0x80D8C34	BlueMarble::getMemoryPoolIndex(void)const
// 0x80D8C3E	BlueMarble::setUserInfo(BlueMarbleScriptManager *)
// 0x80D8CA8	BlueMarble::setScript(BlueMarbleScriptManager *)
// 0x80D8CB6	BlueMarble::checkJoin(void)
// 0x80D8D02	BlueMarble::checkUserConditionEnterBlueMarble(CUser *)
// 0x80D8F58	BlueMarble::join(CUser *)
// 0x80D9074	BlueMarble::getUserSlot(CUser *)const
// 0x80D90DA	BlueMarble::getWaitUserCount(void)const
// 0x80D9136	BlueMarble::leaveUser(CUser *)
// 0x80D9202	BlueMarble::changeState(BlueMarbleState::T)
// 0x80D9210	BlueMarble::enterBlueMarble(CUser *)
// 0x80D92BE	BlueMarble::startBlueMarble(void)
// 0x80D93D8	BlueMarble::userThrowDice(CUser *)
// 0x80D94F6	BlueMarble::enterDungeon(CUser *)
// 0x80D9572	BlueMarble::giveupDungeon(CUser *)
// 0x80D96F4	BlueMarble::clearDungeon(CUser *)
// 0x80D978C	BlueMarble::exitDungeon(CUser *)
// 0x80D9808	BlueMarble::giveBonusItem(CUser *)
// 0x80D990E	BlueMarble::getBuff(CUser *,BlueMarbleBuffType::T)
// 0x80D99CE	BlueMarble::sendToBlueMarble(PacketGuard &)const
// 0x80D9A4C	BlueMarble::movePosition(CUser *,int)
// 0x80D9C12	BlueMarble::checkBlueMarbleUserConfirm(CUser *)

// Function declaration index:
// DECL 0x80D6D48 BlueMarble::resetBlueMarble
// DECL 0x80D6D7C BlueMarble::resetBuffInfo
// DECL 0x80D6DA2 BlueMarble::resetIndexInfo
// DECL 0x80D6DC8 BlueMarble::getState
// DECL 0x80D6DD4 BlueMarble::checkStartBlueMarble
// DECL 0x80D6E34 BlueMarble::setBlueMarbleMap
// DECL 0x80D6E7C BlueMarble::getBlueMarbleMap
// DECL 0x80D6E88 BlueMarble::setMaxBoardSize
// DECL 0x80D6ECC BlueMarble::getMaxBoardSize
// DECL 0x80D6ED8 BlueMarble::checkThrowDice
// DECL 0x80D6F62 BlueMarble::throwDice
// DECL 0x80D6F88 BlueMarble::setDiceNumber
// DECL 0x80D6FC4 BlueMarble::getDiceNumber
// DECL 0x80D6FD0 BlueMarble::setMovePosition
// DECL 0x80D7012 BlueMarble::getMovePosition
// DECL 0x80D7038 BlueMarble::intoBoardZone
// DECL 0x80D70AE BlueMarble::tileType
// DECL 0x80D738A BlueMarble::setDungeonIndex
// DECL 0x80D73B6 BlueMarble::getDungeonIndex
// DECL 0x80D73DC BlueMarble::getRandomDungeon
// DECL 0x80D7690 BlueMarble::getRandomItem
// DECL 0x80D7746 BlueMarble::setItemIndex
// DECL 0x80D7778 BlueMarble::getItemIndex
// DECL 0x80D779E BlueMarble::setExpBuff
// DECL 0x80D77CA BlueMarble::getExpBuff
// DECL 0x80D77F0 BlueMarble::setGoldBuff
// DECL 0x80D781C BlueMarble::getGoldBuff
// DECL 0x80D7842 BlueMarble::setDropBuff
// DECL 0x80D786E BlueMarble::getDropBuff
// DECL 0x80D7894 BlueMarble::setUserDeadCount
// DECL 0x80D78C2 BlueMarble::getUserDeadCount
// DECL 0x80D78F0 BlueMarble::checkMoveFirstZone
// DECL 0x80D793A BlueMarble::setUserState
// DECL 0x80D7966 BlueMarble::getUserState
// DECL 0x80D798C BlueMarble::checkLastZoneDungeonClear
// DECL 0x80D79EE BlueMarble::finishBlueMarble
// DECL 0x80D7A26 BlueMarble::setVisitZone
// DECL 0x80D7A9A BlueMarble::getVisitZone
// DECL 0x80D7AFC BlueMarble::setUserGrade
// DECL 0x80D7D5E BlueMarble::getWinner
// DECL 0x80D7DDE BlueMarble::resultReward
// DECL 0x80D7E8E BlueMarble::setResultItem
// DECL 0x80D800E BlueMarble::insertItem
// DECL 0x80D82F2 BlueMarble::setLeaveUserSlot
// DECL 0x80D8412 BlueMarble::setLeaveUserBlueMarbleState
// DECL 0x80D84B4 BlueMarble::sendBlueMarbleRoomInfo
// DECL 0x80D8600 BlueMarble::sendBlueMarbleDiceInfo
// DECL 0x80D86B2 BlueMarble::sendStartBlueMarble
// DECL 0x80D8752 BlueMarble::sendFinishBlueMarble
// DECL 0x80D8802 BlueMarble::sendBoardZoneActionInfo
// DECL 0x80D88C2 BlueMarble::sendTileGiveUpInfo
// DECL 0x80D8956 BlueMarble::sendUpdateItemInfo
// DECL 0x80D8A5C BlueMarble::BlueMarble
// DECL 0x80D8BAE BlueMarble::~BlueMarble
// DECL 0x80D8C26 BlueMarble::setMemoryPoolIndex
// DECL 0x80D8C34 BlueMarble::getMemoryPoolIndex
// DECL 0x80D8C3E BlueMarble::setUserInfo
// DECL 0x80D8CA8 BlueMarble::setScript
// DECL 0x80D8CB6 BlueMarble::checkJoin
// DECL 0x80D8D02 BlueMarble::checkUserConditionEnterBlueMarble
// DECL 0x80D8F58 BlueMarble::join
// DECL 0x80D9074 BlueMarble::getUserSlot
// DECL 0x80D90DA BlueMarble::getWaitUserCount
// DECL 0x80D9136 BlueMarble::leaveUser
// DECL 0x80D9202 BlueMarble::changeState
// DECL 0x80D9210 BlueMarble::enterBlueMarble
// DECL 0x80D92BE BlueMarble::startBlueMarble
// DECL 0x80D93D8 BlueMarble::userThrowDice
// DECL 0x80D94F6 BlueMarble::enterDungeon
// DECL 0x80D9572 BlueMarble::giveupDungeon
// DECL 0x80D96F4 BlueMarble::clearDungeon
// DECL 0x80D978C BlueMarble::exitDungeon
// DECL 0x80D9808 BlueMarble::giveBonusItem
// DECL 0x80D990E BlueMarble::getBuff
// DECL 0x80D99CE BlueMarble::sendToBlueMarble
// DECL 0x80D9A4C BlueMarble::movePosition
// DECL 0x80D9C12 BlueMarble::checkBlueMarbleUserConfirm

#endif  // __IDA91_BLUEMARBLE_H__
