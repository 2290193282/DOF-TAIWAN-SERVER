#include "BlueMarble.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x80D6D48
// IDA_NAME: _ZN10BlueMarble15resetBlueMarbleEv
// DEMANGLED: BlueMarble::resetBlueMarble(void)
BlueMarble *__cdecl BlueMarble::resetBlueMarble(BlueMarble *this)
{
  BlueMarble *this_1; // eax

  *((_DWORD *)this + 6) = 0;
  *((_DWORD *)this + 7) = 0;
  std::set<int>::clear((char *)this + 32);
  this_1 = this;
  *((_DWORD *)this + 15) = 0;
  return this_1;
}

// IDA_EA: 0x80D6D7C
// IDA_NAME: _ZN10BlueMarble13resetBuffInfoEi
// DEMANGLED: BlueMarble::resetBuffInfo(int)
int __cdecl BlueMarble::resetBuffInfo(BlueMarble *this, int UserSlotEP5CUser)
{
  BlueMarbleUserInfo *v2; // eax

  v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  return BlueMarbleUserInfo::resetBuff(v2);
}

// IDA_EA: 0x80D6DA2
// IDA_NAME: _ZN10BlueMarble14resetIndexInfoEi
// DEMANGLED: BlueMarble::resetIndexInfo(int)
int __cdecl BlueMarble::resetIndexInfo(BlueMarble *this, int UserSlotEP5CUser)
{
  BlueMarbleUserInfo *v2; // eax

  v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  return BlueMarbleUserInfo::resetIndex(v2);
}

// IDA_EA: 0x80D6DC8
// IDA_NAME: _ZNK10BlueMarble8getStateEv
// DEMANGLED: BlueMarble::getState(void)const
int __cdecl BlueMarble::getState(BlueMarble *this)
{
  return *((_DWORD *)this + 4);
}

// IDA_EA: 0x80D6DD4
// IDA_NAME: _ZN10BlueMarble20checkStartBlueMarbleEv
// DEMANGLED: BlueMarble::checkStartBlueMarble(void)
int __cdecl BlueMarble::checkStartBlueMarble(BlueMarble *this)
{
  if ( BlueMarble::getState(this) != 1 )
    return 0;
  if ( BlueMarble::getWaitUserCount(this) >= *(_DWORD *)(*((_DWORD *)this + 14) + 48) )
    return 1;
  BlueMarble::changeState(this, 0);
  return 0;
}

// IDA_EA: 0x80D6E34
// IDA_NAME: _ZN10BlueMarble16setBlueMarbleMapEv
// DEMANGLED: BlueMarble::setBlueMarbleMap(void)
BlueMarble *__cdecl BlueMarble::setBlueMarbleMap(BlueMarble *this)
{
  unsigned int v1; // ebx
  int v2; // edx
  BlueMarble *this_1; // eax

  v1 = CMTRand::randInt((unsigned int **)(*((_DWORD *)this + 5) + 2504));
  v2 = v1 % BlueMarbleScriptManager::getMapTotalCount(*((BlueMarbleScriptManager **)this + 14)) + 1;
  this_1 = this;
  *((_DWORD *)this + 7) = v2;
  return this_1;
}

// IDA_EA: 0x80D6E7C
// IDA_NAME: _ZNK10BlueMarble16getBlueMarbleMapEv
// DEMANGLED: BlueMarble::getBlueMarbleMap(void)const
int __cdecl BlueMarble::getBlueMarbleMap(BlueMarble *this)
{
  return *((_DWORD *)this + 7);
}

// IDA_EA: 0x80D6E88
// IDA_NAME: _ZN10BlueMarble15setMaxBoardSizeEv
// DEMANGLED: BlueMarble::setMaxBoardSize(void)
BlueMarbleScriptManager **__cdecl BlueMarble::setMaxBoardSize(BlueMarbleScriptManager **this)
{
  char BlueMarbleMapEv; // al
  BlueMarbleScriptManager **MapEi; // eax
  BlueMarbleScriptManager *v3; // edx

  BlueMarbleMapEv = BlueMarble::getBlueMarbleMap((BlueMarble *)this);
  MapEi = (BlueMarbleScriptManager **)BlueMarbleScriptManager::getMap(this[14], BlueMarbleMapEv);
  if ( MapEi )
  {
    v3 = (BlueMarbleScriptManager *)std::vector<BlueMarbleTileScript *>::size(MapEi);
    MapEi = this;
    this[15] = v3;
  }
  return MapEi;
}

// IDA_EA: 0x80D6ECC
// IDA_NAME: _ZNK10BlueMarble15getMaxBoardSizeEv
// DEMANGLED: BlueMarble::getMaxBoardSize(void)const
int __cdecl BlueMarble::getMaxBoardSize(BlueMarble *this)
{
  return *((_DWORD *)this + 15);
}

// IDA_EA: 0x80D6ED8
// IDA_NAME: _ZN10BlueMarble14checkThrowDiceEi
// DEMANGLED: BlueMarble::checkThrowDice(int)
_BOOL4 __cdecl BlueMarble::checkThrowDice(BlueMarble *this, int UserSlotEP5CUser)
{
  BlueMarbleUserInfo *v2; // eax
  int BoardZoneEv; // ebx
  BlueMarbleUserInfo *v4; // eax
  bool v5; // al

  v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  BoardZoneEv = BlueMarbleUserInfo::getBoardZone(v2);
  v5 = 1;
  if ( BoardZoneEv < BlueMarble::getMaxBoardSize(this) )
  {
    v4 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
    if ( BlueMarbleUserInfo::getUserState(v4) == 1 && BlueMarble::getState(this) == 2 )
      v5 = 0;
  }
  return !v5;
}

// IDA_EA: 0x80D6F62
// IDA_NAME: _ZN10BlueMarble9throwDiceEi
// DEMANGLED: BlueMarble::throwDice(int)
void __cdecl BlueMarble::throwDice(unsigned int ***this, int UserSlotEP5CUser)
{
  BlueMarble::setDiceNumber(this);
  BlueMarble::sendBlueMarbleDiceInfo((BlueMarble *)this, UserSlotEP5CUser);
}

// IDA_EA: 0x80D6F88
// IDA_NAME: _ZN10BlueMarble13setDiceNumberEv
// DEMANGLED: BlueMarble::setDiceNumber(void)
unsigned int ***__cdecl BlueMarble::setDiceNumber(unsigned int ***this)
{
  unsigned int v1; // edx
  unsigned int ***this_1; // eax

  v1 = (unsigned int)this[14][17] + CMTRand::randInt(this[5]) % (unsigned int)this[14][18];
  this_1 = this;
  this[6] = (unsigned int **)v1;
  return this_1;
}

// IDA_EA: 0x80D6FC4
// IDA_NAME: _ZNK10BlueMarble13getDiceNumberEv
// DEMANGLED: BlueMarble::getDiceNumber(void)const
int __cdecl BlueMarble::getDiceNumber(BlueMarble *this)
{
  return *((_DWORD *)this + 6);
}

// IDA_EA: 0x80D6FD0
// IDA_NAME: _ZN10BlueMarble15setMovePositionEii
// DEMANGLED: BlueMarble::setMovePosition(int,int)
BlueMarbleUserInfo *__cdecl BlueMarble::setMovePosition(BlueMarble *this, int a2, int a3)
{
  int MaxBoardSizeEv; // ebx
  BlueMarbleUserInfo *v4; // eax

  MaxBoardSizeEv = BlueMarble::getMaxBoardSize(this);
  v4 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, a2);
  return BlueMarbleUserInfo::setBoardZone(v4, a3, MaxBoardSizeEv);
}

// IDA_EA: 0x80D7012
// IDA_NAME: _ZNK10BlueMarble15getMovePositionEi
// DEMANGLED: BlueMarble::getMovePosition(int)const
int __cdecl BlueMarble::getMovePosition(BlueMarble *this, int a2)
{
  BlueMarbleUserInfo *v2; // eax

  v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, a2);
  return BlueMarbleUserInfo::getBoardZone(v2);
}

// IDA_EA: 0x80D7038
// IDA_NAME: _ZN10BlueMarble13intoBoardZoneEi
// DEMANGLED: BlueMarble::intoBoardZone(int)
int __cdecl BlueMarble::intoBoardZone(BlueMarbleScriptManager **this, int UserSlotEP5CUser)
{
  int RandomDungeonEiN20BlueMarbleTileScript4TypeE; // eax
  BlueMarbleUserInfo *v3; // eax

  RandomDungeonEiN20BlueMarbleTileScript4TypeE = BlueMarble::getRandomDungeon(this, UserSlotEP5CUser, 14);
  BlueMarble::setDungeonIndex((BlueMarble *)this, UserSlotEP5CUser, RandomDungeonEiN20BlueMarbleTileScript4TypeE);
  BlueMarble::tileType(this, UserSlotEP5CUser);
  v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[](this + 1, UserSlotEP5CUser);
  BlueMarbleUserInfo::getBoardZone(v3);
  return BlueMarble::setVisitZone();
}

// IDA_EA: 0x80D70AE
// IDA_NAME: _ZN10BlueMarble8tileTypeEi
// DEMANGLED: BlueMarble::tileType(int)
char __cdecl BlueMarble::tileType(BlueMarbleScriptManager **this, int UserSlotEP5CUser)
{
  BlueMarbleUserInfo *v2; // eax
  int TileEj; // eax
  BlueMarbleMapScript *MapEi; // eax
  int RandomDungeonEiN20BlueMarbleTileScript4TypeE; // eax
  unsigned int RandomItemEv; // eax
  int RandomDungeonEiN20BlueMarbleTileScript4TypeE_1; // eax
  int v8; // ebx
  int MovePositionEi; // eax
  unsigned int BoardZoneEv; // [esp+18h] [ebp-10h]
  _DWORD *TileEj_1; // [esp+1Ch] [ebp-Ch]

  v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[](this + 1, UserSlotEP5CUser);
  BoardZoneEv = BlueMarbleUserInfo::getBoardZone(v2);
  BlueMarble::getBlueMarbleMap((BlueMarble *)this);
  LOBYTE(TileEj) = BlueMarbleScriptManager::getMap() == 0;
  if ( !(_BYTE)TileEj )
  {
    BlueMarble::getBlueMarbleMap((BlueMarble *)this);
    MapEi = (BlueMarbleMapScript *)BlueMarbleScriptManager::getMap();
    TileEj = BlueMarbleMapScript::getTile(MapEi, BoardZoneEv);
    TileEj_1 = (_DWORD *)TileEj;
    if ( TileEj )
    {
      TileEj = *(_DWORD *)TileEj;
      switch ( *TileEj_1 )
      {
        case 2:
        case 8:
          RandomDungeonEiN20BlueMarbleTileScript4TypeE = BlueMarble::getRandomDungeon(this, UserSlotEP5CUser, 2);
          LOBYTE(TileEj) = (unsigned __int8)BlueMarble::setDungeonIndex(
                                              (BlueMarble *)this,
                                              UserSlotEP5CUser,
                                              RandomDungeonEiN20BlueMarbleTileScript4TypeE);
          break;
        case 3:
          LOBYTE(TileEj) = (unsigned __int8)BlueMarble::setGoldBuff((BlueMarble *)this, UserSlotEP5CUser, TileEj_1[2]);
          break;
        case 4:
          LOBYTE(TileEj) = (unsigned __int8)BlueMarble::setExpBuff((BlueMarble *)this, UserSlotEP5CUser, TileEj_1[2]);
          break;
        case 5:
          LOBYTE(TileEj) = (unsigned __int8)BlueMarble::setDropBuff((BlueMarble *)this, UserSlotEP5CUser, TileEj_1[2]);
          break;
        case 6:
          RandomItemEv = BlueMarble::getRandomItem((BlueMarble *)this);
          LOBYTE(TileEj) = (unsigned __int8)BlueMarble::setItemIndex((BlueMarble *)this, UserSlotEP5CUser, RandomItemEv);
          break;
        case 7:
          TileEj = !BlueMarble::getVisitZone();
          if ( (_BYTE)TileEj )
          {
            RandomDungeonEiN20BlueMarbleTileScript4TypeE_1 = BlueMarble::getRandomDungeon(this, UserSlotEP5CUser, 7);
            LOBYTE(TileEj) = (unsigned __int8)BlueMarble::setDungeonIndex(
                                                (BlueMarble *)this,
                                                UserSlotEP5CUser,
                                                RandomDungeonEiN20BlueMarbleTileScript4TypeE_1);
          }
          break;
        case 9:
          BlueMarble::setVisitZone();
          BlueMarble::setMovePosition((BlueMarble *)this, UserSlotEP5CUser, TileEj_1[2]);
          if ( (unsigned __int8)BlueMarble::checkMoveFirstZone((BlueMarble *)this, UserSlotEP5CUser, 9) )
            BlueMarble::resetBuffInfo((BlueMarble *)this, UserSlotEP5CUser);
          goto LABEL_13;
        case 0xA:
          BlueMarble::setVisitZone();
          v8 = TileEj_1[2];
          MovePositionEi = BlueMarble::getMovePosition((BlueMarble *)this, UserSlotEP5CUser);
          BlueMarble::setMovePosition((BlueMarble *)this, UserSlotEP5CUser, v8 - MovePositionEi);
          if ( (unsigned __int8)BlueMarble::checkMoveFirstZone((BlueMarble *)this, UserSlotEP5CUser, 10) )
            BlueMarble::resetBuffInfo((BlueMarble *)this, UserSlotEP5CUser);
LABEL_13:
          LOBYTE(TileEj) = BlueMarble::intoBoardZone(this, UserSlotEP5CUser);
          break;
        case 0xB:
        case 0xC:
        case 0xD:
          LOBYTE(TileEj) = (unsigned __int8)BlueMarble::setDungeonIndex(
                                              (BlueMarble *)this,
                                              UserSlotEP5CUser,
                                              TileEj_1[2]);
          break;
        default:
          return TileEj;
      }
    }
  }
  return TileEj;
}

// IDA_EA: 0x80D738A
// IDA_NAME: _ZN10BlueMarble15setDungeonIndexEii
// DEMANGLED: BlueMarble::setDungeonIndex(int,int)
BlueMarbleUserInfo *__cdecl BlueMarble::setDungeonIndex(
        BlueMarble *this,
        int UserSlotEP5CUser,
        int RandomDungeonEiN20BlueMarbleTileScript4TypeE)
{
  BlueMarbleUserInfo *v3; // eax

  v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  return BlueMarbleUserInfo::setDungeon(v3, RandomDungeonEiN20BlueMarbleTileScript4TypeE);
}

// IDA_EA: 0x80D73B6
// IDA_NAME: _ZNK10BlueMarble15getDungeonIndexEi
// DEMANGLED: BlueMarble::getDungeonIndex(int)const
int __cdecl BlueMarble::getDungeonIndex(BlueMarble *this, int UserSlotEP5CUser)
{
  BlueMarbleUserInfo *v2; // eax

  v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  return BlueMarbleUserInfo::getDungeon(v2);
}

// IDA_EA: 0x80D73DC
// IDA_NAME: _ZNK10BlueMarble16getRandomDungeonEiN20BlueMarbleTileScript4TypeE
// DEMANGLED: BlueMarble::getRandomDungeon(int,BlueMarbleTileScript::Type)const
int __cdecl BlueMarble::getRandomDungeon(BlueMarbleScriptManager **this, int UserSlotEP5CUser, int n14)
{
  BlueMarbleUserInfo *v3; // eax
  CUserCharacInfo *UserEv; // eax
  int v5; // ebx
  BlueMarbleUserInfo *v6; // eax
  unsigned int BoardZoneEv; // ebx
  BlueMarbleMapScript *MapEi; // eax
  unsigned int v9; // ebx
  unsigned int v10; // eax
  _DWORD v12[3]; // [esp+14h] [ebp-44h] BYREF
  _DWORD v13[3]; // [esp+20h] [ebp-38h] BYREF
  _DWORD v14[3]; // [esp+2Ch] [ebp-2Ch] BYREF
  _DWORD v15[3]; // [esp+38h] [ebp-20h] BYREF
  int charac_levelEv; // [esp+44h] [ebp-14h]
  int TileEj; // [esp+48h] [ebp-10h]
  unsigned int v18; // [esp+4Ch] [ebp-Ch]

  std::vector<int>::vector((int)v12);
  v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[](this + 1, UserSlotEP5CUser);
  UserEv = (CUserCharacInfo *)BlueMarbleUserInfo::getUser(v3);
  charac_levelEv = CUserCharacInfo::get_charac_level(UserEv);
  BlueMarble::getBlueMarbleMap((BlueMarble *)this);
  if ( BlueMarbleScriptManager::getMap() )
  {
    v6 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[](this + 1, UserSlotEP5CUser);
    BoardZoneEv = BlueMarbleUserInfo::getBoardZone(v6);
    BlueMarble::getBlueMarbleMap((BlueMarble *)this);
    MapEi = (BlueMarbleMapScript *)BlueMarbleScriptManager::getMap();
    TileEj = BlueMarbleMapScript::getTile(MapEi, BoardZoneEv);
    if ( TileEj )
    {
      if ( *(_BYTE *)(TileEj + 4) == 1 )
      {
        if ( n14 == 7 )
        {
          BlueMarbleInfoScript::getUniqueDungeonIndex((BlueMarbleInfoScript *)v13, (int)this[14] + 48, charac_levelEv);
          std::vector<int>::operator=(v12, (int)v13);
          std::vector<int>::~vector(v13);
        }
        else if ( n14 == 8 || n14 == 2 )
        {
          BlueMarbleInfoScript::getBossDungeonIndex((BlueMarbleInfoScript *)v14, (int)this[14] + 48, charac_levelEv);
          std::vector<int>::operator=(v12, (int)v14);
          std::vector<int>::~vector(v14);
        }
        else
        {
          BlueMarbleInfoScript::getRandomDungeonIndex((BlueMarbleInfoScript *)v15, (int)this[14] + 48, charac_levelEv);
          std::vector<int>::operator=(v12, (int)v15);
          std::vector<int>::~vector(v15);
        }
        if ( std::vector<int>::size(v12) )
        {
          v9 = CMTRand::randInt((unsigned int **)this[5] + 1252);
          v18 = v9 % std::vector<int>::size(v12);
          v10 = std::vector<int>::size(v12);
          if ( v10 > v18 )
            v5 = *(_DWORD *)std::vector<int>::operator[](v12, v18);
          else
            v5 = 0;
        }
        else
        {
          v5 = 0;
        }
      }
      else
      {
        v5 = 0;
      }
    }
    else
    {
      v5 = 0;
    }
  }
  else
  {
    v5 = 0;
  }
  std::vector<int>::~vector(v12);
  return v5;
}

// IDA_EA: 0x80D7690
// IDA_NAME: _ZNK10BlueMarble13getRandomItemEv
// DEMANGLED: BlueMarble::getRandomItem(void)const
int __cdecl BlueMarble::getRandomItem(BlueMarble *this)
{
  int v1; // eax
  unsigned int v3; // [esp+1Ch] [ebp-1Ch] BYREF
  signed int v4; // [esp+20h] [ebp-18h]
  int v5; // [esp+24h] [ebp-14h]
  signed int v6; // [esp+28h] [ebp-10h]
  int i; // [esp+2Ch] [ebp-Ch]

  v3 = *(_DWORD *)(*((_DWORD *)this + 14) + 76);
  v4 = CMTRand::randInt((unsigned int **)(*((_DWORD *)this + 5) + 7512), &v3);
  v5 = std::vector<BlueMarbleRandomItemInfo>::size(*((_DWORD *)this + 14) + 152);
  v6 = 0;
  for ( i = 0; i < v5; ++i )
  {
    v1 = std::vector<BlueMarbleRandomItemInfo>::operator[](*((_DWORD *)this + 14) + 152, i);
    v6 += *(_DWORD *)(v1 + 4);
    if ( v6 >= v4 )
      return *(_DWORD *)std::vector<BlueMarbleRandomItemInfo>::operator[](*((_DWORD *)this + 14) + 152, i);
  }
  return 0;
}

// IDA_EA: 0x80D7746
// IDA_NAME: _ZN10BlueMarble12setItemIndexEii
// DEMANGLED: BlueMarble::setItemIndex(int,int)
BlueMarbleUserInfo *__cdecl BlueMarble::setItemIndex(BlueMarble *this, int UserSlotEP5CUser, unsigned int RandomItemEv)
{
  BlueMarbleUserInfo *v3; // eax

  v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  return BlueMarbleUserInfo::setItem(v3, RandomItemEv);
}

// IDA_EA: 0x80D7778
// IDA_NAME: _ZNK10BlueMarble12getItemIndexEi
// DEMANGLED: BlueMarble::getItemIndex(int)const
int __cdecl BlueMarble::getItemIndex(BlueMarble *this, int UserSlotEP5CUser)
{
  BlueMarbleUserInfo *v2; // eax

  v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  return BlueMarbleUserInfo::getItem(v2);
}

// IDA_EA: 0x80D779E
// IDA_NAME: _ZN10BlueMarble10setExpBuffEii
// DEMANGLED: BlueMarble::setExpBuff(int,int)
BlueMarbleUserInfo *__cdecl BlueMarble::setExpBuff(BlueMarble *this, int UserSlotEP5CUser, int a3)
{
  BlueMarbleUserInfo *v3; // eax

  v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  return BlueMarbleUserInfo::setExp(v3, a3);
}

// IDA_EA: 0x80D77CA
// IDA_NAME: _ZNK10BlueMarble10getExpBuffEi
// DEMANGLED: BlueMarble::getExpBuff(int)const
int __cdecl BlueMarble::getExpBuff(BlueMarble *this, int UserSlotEP5CUser)
{
  BlueMarbleUserInfo *v2; // eax

  v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  return BlueMarbleUserInfo::getExp(v2);
}

// IDA_EA: 0x80D77F0
// IDA_NAME: _ZN10BlueMarble11setGoldBuffEii
// DEMANGLED: BlueMarble::setGoldBuff(int,int)
BlueMarbleUserInfo *__cdecl BlueMarble::setGoldBuff(BlueMarble *this, int UserSlotEP5CUser, int a3)
{
  BlueMarbleUserInfo *v3; // eax

  v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  return BlueMarbleUserInfo::setGold(v3, a3);
}

// IDA_EA: 0x80D781C
// IDA_NAME: _ZNK10BlueMarble11getGoldBuffEi
// DEMANGLED: BlueMarble::getGoldBuff(int)const
int __cdecl BlueMarble::getGoldBuff(BlueMarble *this, int UserSlotEP5CUser)
{
  BlueMarbleUserInfo *v2; // eax

  v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  return BlueMarbleUserInfo::getGold(v2);
}

// IDA_EA: 0x80D7842
// IDA_NAME: _ZN10BlueMarble11setDropBuffEii
// DEMANGLED: BlueMarble::setDropBuff(int,int)
BlueMarbleUserInfo *__cdecl BlueMarble::setDropBuff(BlueMarble *this, int UserSlotEP5CUser, int a3)
{
  BlueMarbleUserInfo *v3; // eax

  v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  return BlueMarbleUserInfo::setDrop(v3, a3);
}

// IDA_EA: 0x80D786E
// IDA_NAME: _ZNK10BlueMarble11getDropBuffEi
// DEMANGLED: BlueMarble::getDropBuff(int)const
int __cdecl BlueMarble::getDropBuff(BlueMarble *this, int UserSlotEP5CUser)
{
  BlueMarbleUserInfo *v2; // eax

  v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  return BlueMarbleUserInfo::getDrop(v2);
}

// IDA_EA: 0x80D7894
// IDA_NAME: _ZN10BlueMarble16setUserDeadCountEi
// DEMANGLED: BlueMarble::setUserDeadCount(int)
int __cdecl BlueMarble::setUserDeadCount(BlueMarble *this, int a2)
{
  BlueMarbleUserInfo *v2; // eax
  CUserCharacInfo *UserEv; // eax

  v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, a2);
  UserEv = (CUserCharacInfo *)BlueMarbleUserInfo::getUser(v2);
  return CUserCharacInfo::increaseBlueMarbleUserDeadCount(UserEv);
}

// IDA_EA: 0x80D78C2
// IDA_NAME: _ZNK10BlueMarble16getUserDeadCountEi
// DEMANGLED: BlueMarble::getUserDeadCount(int)const
int __cdecl BlueMarble::getUserDeadCount(BlueMarble *this, int a2)
{
  BlueMarbleUserInfo *v2; // eax
  CUserCharacInfo *UserEv; // eax

  v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, a2);
  UserEv = (CUserCharacInfo *)BlueMarbleUserInfo::getUser(v2);
  return CUserCharacInfo::getBlueMarbleUserDeadCount(UserEv);
}

// IDA_EA: 0x80D78F0
// IDA_NAME: _ZN10BlueMarble18checkMoveFirstZoneEiN20BlueMarbleTileScript4TypeE
// DEMANGLED: BlueMarble::checkMoveFirstZone(int,BlueMarbleTileScript::Type)
int __cdecl BlueMarble::checkMoveFirstZone(BlueMarble *this, int UserSlotEP5CUser, int n9)
{
  if ( n9 >= 9 )
  {
    if ( n9 <= 10 )
    {
      if ( BlueMarble::getMovePosition(this, UserSlotEP5CUser) != 1 )
        return 0;
    }
    else if ( n9 <= 13 )
    {
      return 0;
    }
  }
  return 1;
}

// IDA_EA: 0x80D793A
// IDA_NAME: _ZN10BlueMarble12setUserStateEiN19BlueMarbleUserState1TE
// DEMANGLED: BlueMarble::setUserState(int,BlueMarbleUserState::T)
int __cdecl BlueMarble::setUserState(int this, int UserSlotEP5CUser, int n2)
{
  int v3; // eax

  v3 = std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)(this + 4), UserSlotEP5CUser);
  return BlueMarbleUserInfo::setUserState(v3, n2);
}

// IDA_EA: 0x80D7966
// IDA_NAME: _ZNK10BlueMarble12getUserStateEi
// DEMANGLED: BlueMarble::getUserState(int)const
int __cdecl BlueMarble::getUserState(BlueMarble *this, int UserSlotEP5CUser)
{
  BlueMarbleUserInfo *v2; // eax

  v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  return BlueMarbleUserInfo::getUserState(v2);
}

// IDA_EA: 0x80D798C
// IDA_NAME: _ZN10BlueMarble25checkLastZoneDungeonClearEi
// DEMANGLED: BlueMarble::checkLastZoneDungeonClear(int)
_BOOL4 __cdecl BlueMarble::checkLastZoneDungeonClear(BlueMarble *this, int UserSlotEP5CUser)
{
  BlueMarbleUserInfo *v2; // eax
  int BoardZoneEv; // ebx
  _BOOL4 result; // eax

  result = 0;
  if ( BlueMarble::getState(this) == 2 )
  {
    v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
    BoardZoneEv = BlueMarbleUserInfo::getBoardZone(v2);
    if ( BoardZoneEv == BlueMarble::getMaxBoardSize(this) )
      return 1;
  }
  return result;
}

// IDA_EA: 0x80D79EE
// IDA_NAME: _ZN10BlueMarble16finishBlueMarbleEi
// DEMANGLED: BlueMarble::finishBlueMarble(int)
void __cdecl BlueMarble::finishBlueMarble(BlueMarble *this, int UserSlotEP5CUser)
{
  BlueMarble::setUserGrade(this, UserSlotEP5CUser);
  BlueMarble::changeState((int)this, 3);
  BlueMarble::sendFinishBlueMarble(this);
}

// IDA_EA: 0x80D7A26
// IDA_NAME: _ZN10BlueMarble12setVisitZoneEi
// DEMANGLED: BlueMarble::setVisitZone(int)
int __cdecl BlueMarble::setVisitZone()
{
  int result; // eax
  _BYTE v1[4]; // [esp+10h] [ebp-18h] BYREF
  _BYTE v2[4]; // [esp+14h] [ebp-14h] BYREF
  _BYTE v3[16]; // [esp+18h] [ebp-10h] BYREF

  std::set<int>::find(v1);
  std::set<int>::end(v2);
  result = std::_Rb_tree_const_iterator<int>::operator==(v1, v2);
  if ( (_BYTE)result )
    return std::set<int>::insert(v3);
  return result;
}

// IDA_EA: 0x80D7A9A
// IDA_NAME: _ZNK10BlueMarble12getVisitZoneEi
// DEMANGLED: BlueMarble::getVisitZone(int)const
_BOOL4 __cdecl BlueMarble::getVisitZone()
{
  _BYTE v1[4]; // [esp+18h] [ebp-10h] BYREF
  _BYTE v2[12]; // [esp+1Ch] [ebp-Ch] BYREF

  std::set<int>::find(v1);
  std::set<int>::end(v2);
  return (unsigned __int8)std::_Rb_tree_const_iterator<int>::operator==(v1, v2) == 0;
}

// IDA_EA: 0x80D7AFC
// IDA_NAME: _ZN10BlueMarble12setUserGradeEi
// DEMANGLED: BlueMarble::setUserGrade(int)
int __cdecl BlueMarble::setUserGrade(BlueMarble *this, int UserSlotEP5CUser)
{
  int v2; // eax
  BlueMarbleUserInfo *v3; // eax
  BlueMarbleUserInfo *v4; // eax
  BlueMarbleUserInfo *v5; // eax
  _DWORD *v6; // eax
  int v7; // ebx
  int v8; // eax
  int v9; // eax
  int v10; // ebx
  int v11; // eax
  int v12; // eax
  int i; // [esp+18h] [ebp-50h] BYREF
  std::_Rb_tree_node_base *v15; // [esp+1Ch] [ebp-4Ch] BYREF
  _BYTE v16[24]; // [esp+20h] [ebp-48h] BYREF
  _BYTE v17[4]; // [esp+38h] [ebp-30h] BYREF
  int v18; // [esp+3Ch] [ebp-2Ch] BYREF
  _BYTE v19[8]; // [esp+44h] [ebp-24h] BYREF
  int BoardZoneEv; // [esp+4Ch] [ebp-1Ch] BYREF
  int v21; // [esp+50h] [ebp-18h] BYREF
  int v22; // [esp+54h] [ebp-14h]
  int v23; // [esp+58h] [ebp-10h]
  int v24; // [esp+5Ch] [ebp-Ch]

  std::multimap<int,int,std::greater<int>,std::allocator<std::pair<int const,int>>>::multimap((int)v16);
  v2 = std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  BlueMarbleUserInfo::setGrade(v2, 0);
  for ( i = 0; *(_DWORD *)(*((_DWORD *)this + 14) + 48) > i; ++i )
  {
    v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, i);
    if ( BlueMarbleUserInfo::getUser(v3) )
    {
      v4 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, i);
      if ( BlueMarbleUserInfo::getGrade(v4) )
      {
        v5 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, i);
        BoardZoneEv = BlueMarbleUserInfo::getBoardZone(v5);
        std::make_pair<int,int &>((int)v19, (int)&BoardZoneEv, (int)&i);
        std::pair<int const,int>::pair<int,int>(&v18, (int)v19);
        std::multimap<int,int,std::greater<int>,std::allocator<std::pair<int const,int>>>::insert((int)v17);
      }
    }
  }
  std::multimap<int,int,std::greater<int>,std::allocator<std::pair<int const,int>>>::begin((int)&v15);
  v22 = 0;
  v23 = 1;
  v24 = 0;
  while ( 1 )
  {
    std::multimap<int,int,std::greater<int>,std::allocator<std::pair<int const,int>>>::end((int)&v21);
    if ( !std::_Rb_tree_iterator<std::pair<int const,int>>::operator!=(&v15, &v21) )
      break;
    v6 = (_DWORD *)std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v15);
    if ( *v6 == v24 )
    {
      v24 = *(_DWORD *)std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v15);
      v7 = v22;
      v8 = std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v15);
      v9 = std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, *(_DWORD *)(v8 + 4));
      BlueMarbleUserInfo::setGrade(v9, v7);
    }
    else
    {
      v24 = *(_DWORD *)std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v15);
      v10 = v23;
      v11 = std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v15);
      v12 = std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, *(_DWORD *)(v11 + 4));
      BlueMarbleUserInfo::setGrade(v12, v10);
      v22 = v23++;
    }
    std::_Rb_tree_iterator<std::pair<int const,int>>::operator++(&v15);
  }
  return std::multimap<int,int,std::greater<int>,std::allocator<std::pair<int const,int>>>::~multimap((int)v16);
}

// IDA_EA: 0x80D7D5E
// IDA_NAME: _ZNK10BlueMarble9getWinnerEv
// DEMANGLED: BlueMarble::getWinner(void)const
int __cdecl BlueMarble::getWinner(BlueMarble *this)
{
  BlueMarbleUserInfo *v1; // eax
  BlueMarbleUserInfo *v2; // eax
  int i; // [esp+1Ch] [ebp-Ch]

  for ( i = 0; *(_DWORD *)(*((_DWORD *)this + 14) + 48) > i; ++i )
  {
    v1 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
    if ( BlueMarbleUserInfo::getUser(v1) )
    {
      v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
      if ( !BlueMarbleUserInfo::getGrade(v2) )
        return i;
    }
  }
  return -1;
}

// IDA_EA: 0x80D7DDE
// IDA_NAME: _ZN10BlueMarble12resultRewardEv
// DEMANGLED: BlueMarble::resultReward(void)
bool __cdecl BlueMarble::resultReward(BlueMarble *this)
{
  BlueMarbleUserInfo *v1; // eax
  bool result; // al
  _BYTE v3[2]; // [esp+1Fh] [ebp-49h] BYREF
  int v4; // [esp+21h] [ebp-47h]
  int i; // [esp+5Ch] [ebp-Ch]

  Inven_Item::Inven_Item((Inven_Item *)v3);
  for ( i = 0; ; ++i )
  {
    result = *(_DWORD *)(*((_DWORD *)this + 14) + 48) > i;
    if ( *(_DWORD *)(*((_DWORD *)this + 14) + 48) <= i )
      break;
    v1 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
    if ( BlueMarbleUserInfo::getUser(v1) )
    {
      Inven_Item::reset((Inven_Item *)v3);
      BlueMarble::setResultItem(this, i, (Inven_Item *)v3);
      if ( v4 )
        BlueMarble::insertItem(this, i, (Inven_Item *)v3, 66);
    }
  }
  return result;
}

// IDA_EA: 0x80D7E8E
// IDA_NAME: _ZN10BlueMarble13setResultItemEiR10Inven_Item
// DEMANGLED: BlueMarble::setResultItem(int,Inven_Item &)
int __cdecl BlueMarble::setResultItem(BlueMarble *this, int a2, Inven_Item *GradeEv_1)
{
  BlueMarbleUserInfo *v3; // eax
  int GradeEv; // eax
  int v5; // edx
  int v6; // edx
  int v7; // edx
  int v8; // edx

  v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, a2);
  GradeEv = BlueMarbleUserInfo::getGrade(v3);
  if ( GradeEv == 1 )
  {
    *(_DWORD *)((char *)GradeEv_1 + 2) = *(_DWORD *)std::vector<BlueMarbleRewardInfo>::operator[](
                                                      *((_DWORD *)this + 14) + 164,
                                                      1);
    v6 = *(_DWORD *)(std::vector<BlueMarbleRewardInfo>::operator[](*((_DWORD *)this + 14) + 164, 1) + 4);
    GradeEv = (int)GradeEv_1;
    *(_DWORD *)((char *)GradeEv_1 + 7) = v6;
  }
  else if ( GradeEv > 1 )
  {
    if ( GradeEv == 2 )
    {
      *(_DWORD *)((char *)GradeEv_1 + 2) = *(_DWORD *)std::vector<BlueMarbleRewardInfo>::operator[](
                                                        *((_DWORD *)this + 14) + 164,
                                                        2);
      v7 = *(_DWORD *)(std::vector<BlueMarbleRewardInfo>::operator[](*((_DWORD *)this + 14) + 164, 2) + 4);
      GradeEv = (int)GradeEv_1;
      *(_DWORD *)((char *)GradeEv_1 + 7) = v7;
    }
    else if ( GradeEv == 3 )
    {
      *(_DWORD *)((char *)GradeEv_1 + 2) = *(_DWORD *)std::vector<BlueMarbleRewardInfo>::operator[](
                                                        *((_DWORD *)this + 14) + 164,
                                                        3);
      v8 = *(_DWORD *)(std::vector<BlueMarbleRewardInfo>::operator[](*((_DWORD *)this + 14) + 164, 3) + 4);
      GradeEv = (int)GradeEv_1;
      *(_DWORD *)((char *)GradeEv_1 + 7) = v8;
    }
  }
  else if ( !GradeEv )
  {
    *(_DWORD *)((char *)GradeEv_1 + 2) = *(_DWORD *)std::vector<BlueMarbleRewardInfo>::operator[](
                                                      *((_DWORD *)this + 14) + 164,
                                                      0);
    v5 = *(_DWORD *)(std::vector<BlueMarbleRewardInfo>::operator[](*((_DWORD *)this + 14) + 164, 0) + 4);
    GradeEv = (int)GradeEv_1;
    *(_DWORD *)((char *)GradeEv_1 + 7) = v5;
  }
  return GradeEv;
}

// IDA_EA: 0x80D800E
// IDA_NAME: _ZN10BlueMarble10insertItemEiR10Inven_Item14eItemAddReason
// DEMANGLED: BlueMarble::insertItem(int,Inven_Item &,eItemAddReason)
void __cdecl BlueMarble::insertItem(BlueMarble *this, int UserSlotEP5CUser, Inven_Item *a3, int n66)
{
  int v4; // ebx
  int v5; // eax
  BlueMarbleUserInfo *v6; // eax
  CUserCharacInfo *UserEv; // eax
  CUserCharacInfo **CurCharacInvenWEv; // eax
  const char *src; // eax
  const char *src_1; // eax
  BlueMarbleUserInfo *v11; // eax
  CUser *UserEv_1; // eax
  int ServerGroup; // ebx
  size_t v14; // esi
  BlueMarbleUserInfo *v15; // eax
  CUser *UserEv_2; // eax
  int charac_noEi; // eax
  BlueMarbleUserInfo *v18; // eax
  int UserEv_3; // eax
  char s_[17]; // [esp+59h] [ebp-26Fh] BYREF
  char dest_[40]; // [esp+6Ah] [ebp-25Eh] BYREF
  int v22; // [esp+92h] [ebp-236h]
  int v23; // [esp+96h] [ebp-232h]
  char s[256]; // [esp+19Eh] [ebp-12Ah] BYREF
  char dest[30]; // [esp+29Eh] [ebp-2Ah] BYREF
  int n3; // [esp+2BCh] [ebp-Ch]

  v4 = *(_DWORD *)((char *)a3 + 7);
  v5 = G_CDataManager();
  CItemList::create_item(*(CItemList **)(v5 + 12), 0, a3, v4);
  v6 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  UserEv = (CUserCharacInfo *)BlueMarbleUserInfo::getUser(v6);
  CurCharacInvenWEv = (CUserCharacInfo **)CUserCharacInfo::getCurCharacInvenW(UserEv);
  n3 = CInventory::insertItemIntoInventory(
         CurCharacInvenWEv,
         *(_QWORD *)a3,
         *((_DWORD *)a3 + 2),
         *((_DWORD *)a3 + 3),
         *((_DWORD *)a3 + 4),
         *((_DWORD *)a3 + 5),
         *((_DWORD *)a3 + 6),
         *((_DWORD *)a3 + 7),
         *((_DWORD *)a3 + 8),
         *((_DWORD *)a3 + 9),
         *((_DWORD *)a3 + 10),
         *((_DWORD *)a3 + 11),
         *((_DWORD *)a3 + 12),
         *((_DWORD *)a3 + 13),
         *((_DWORD *)a3 + 14),
         *((_BYTE *)a3 + 60),
         n66,
         1u,
         0);
  if ( n3 >= 0 )
  {
    BlueMarble::sendUpdateItemInfo(this, UserSlotEP5CUser, n3);
  }
  else
  {
    src = RDARScriptStringManager::findString(
            (RDARScriptStringManager *)&g_scriptStringManager_,
            (char *)4,
            "game_server_msg_268",
            0);
    strncpy(dest, src, 0x1Du);
    src_1 = RDARScriptStringManager::findString(
              (RDARScriptStringManager *)&g_scriptStringManager_,
              (char *)4,
              "game_server_msg_269",
              0);
    strncpy(s, src_1, 0xFFu);
    v11 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
    UserEv_1 = (CUser *)BlueMarbleUserInfo::getUser(v11);
    ServerGroup = CUser::GetServerGroup(UserEv_1);
    v14 = strlen(s);
    v15 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
    UserEv_2 = (CUser *)BlueMarbleUserInfo::getUser(v15);
    charac_noEi = CUser::get_charac_no(UserEv_2, -1);
    if ( !WongWork::CMailBoxHelper::ReqDBSendNewSystemMail(dest, a3, 0, charac_noEi, s, v14, 15, ServerGroup, 0, 0) )
    {
      memset(s_, 0, 0x145u);
      strncpy(dest_, dest, 0x1Du);
      v22 = *(_DWORD *)((char *)a3 + 2);
      v23 = *(_DWORD *)((char *)a3 + 7);
      v18 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
      UserEv_3 = BlueMarbleUserInfo::getUser(v18);
      cUserHistoryLog::SendMail((CUser **)(UserEv_3 + 497408), s_, 0);
    }
  }
}

// IDA_EA: 0x80D82F2
// IDA_NAME: _ZN10BlueMarble16setLeaveUserSlotEi
// DEMANGLED: BlueMarble::setLeaveUserSlot(int)
void __cdecl BlueMarble::setLeaveUserSlot(BlueMarble *this, char *UserSlotEP5CUser)
{
  BlueMarbleUserInfo *v2; // eax
  BlueMarbleUserInfo *v3; // eax
  BlueMarbleUserInfo *v4; // eax
  CUser *UserEv; // eax
  BlueMarbleUserInfo *v6; // eax
  int UserEv_1; // eax
  BlueMarbleUserInfo *v8; // eax
  CUserCharacInfo *UserEv_2; // eax
  BlueMarbleUserInfo *v10; // eax

  v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, (int)UserSlotEP5CUser);
  if ( BlueMarbleUserInfo::getUser(v2) )
  {
    v4 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, (int)UserSlotEP5CUser);
    UserEv = (CUser *)BlueMarbleUserInfo::getUser(v4);
    CUser::setBlueMarbleIndex(UserEv, -1);
    v6 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, (int)UserSlotEP5CUser);
    UserEv_1 = BlueMarbleUserInfo::getUser(v6);
    CUser::setMoveSpace(UserEv_1, 0);
    v8 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, (int)UserSlotEP5CUser);
    UserEv_2 = (CUserCharacInfo *)BlueMarbleUserInfo::getUser(v8);
    CUserCharacInfo::resetBlueMarbleUserDeadCount(UserEv_2);
    v10 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, (int)UserSlotEP5CUser);
    BlueMarbleUserInfo::resetBlueMarbleUserInfo(v10);
  }
  else
  {
    v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, (int)UserSlotEP5CUser);
    BlueMarbleUserInfo::resetBlueMarbleUserInfo(v3);
    LogManager::logFormat(
      (LogManager *)1,
      (int)"BlueMarble.cpp",
      "void BlueMarble::setLeaveUserSlot(int)",
      (const char *)0x2C4,
      "BlueMarble::setLeaveUserSlot slot(%d)",
      UserSlotEP5CUser);
  }
}

// IDA_EA: 0x80D8412
// IDA_NAME: _ZN10BlueMarble27setLeaveUserBlueMarbleStateEv
// DEMANGLED: BlueMarble::setLeaveUserBlueMarbleState(void)
unsigned __int8 __cdecl BlueMarble::setLeaveUserBlueMarbleState(BlueMarble *this)
{
  BlueMarbleUserInfo *v1; // eax
  unsigned __int8 result; // al
  int i; // [esp+1Ch] [ebp-Ch]

  if ( BlueMarble::getWaitUserCount(this) )
  {
    result = BlueMarble::getState(this) == 1;
    if ( result )
      return BlueMarble::changeState(this, 0);
  }
  else
  {
    for ( i = 0; *(_DWORD *)(*((_DWORD *)this + 14) + 48) > i; ++i )
    {
      v1 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
      BlueMarbleUserInfo::resetBlueMarbleUserInfo(v1);
    }
    BlueMarble::changeState(this, 0);
    return (unsigned __int8)BlueMarble::resetBlueMarble(this);
  }
  return result;
}

// IDA_EA: 0x80D84B4
// IDA_NAME: _ZNK10BlueMarble22sendBlueMarbleRoomInfoEv
// DEMANGLED: BlueMarble::sendBlueMarbleRoomInfo(void)const
void __cdecl BlueMarble::sendBlueMarbleRoomInfo(BlueMarble *this)
{
  int MemoryPoolIndexEv; // eax
  int WaitUserCountEv; // eax
  BlueMarbleUserInfo *v3; // eax
  BlueMarbleUserInfo *v4; // eax
  CUser *UserEv; // eax
  unsigned __int16 unique_idEv; // ax
  PacketBuf *v7[3]; // [esp+10h] [ebp-18h] BYREF
  int i; // [esp+1Ch] [ebp-Ch]

  PacketGuard::PacketGuard((PacketGuard *)v7);
  InterfacePacketBuf::put_header(v7, 0, 430);
  MemoryPoolIndexEv = BlueMarble::getMemoryPoolIndex(this);
  InterfacePacketBuf::put_short((InterfacePacketBuf *)v7, MemoryPoolIndexEv);
  WaitUserCountEv = BlueMarble::getWaitUserCount(this);
  InterfacePacketBuf::put_byte(v7, WaitUserCountEv);
  for ( i = 0; *(_DWORD *)(*((_DWORD *)this + 14) + 48) > i; ++i )
  {
    v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
    if ( BlueMarbleUserInfo::getUser(v3) )
    {
      InterfacePacketBuf::put_byte(v7, i);
      v4 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
      UserEv = (CUser *)BlueMarbleUserInfo::getUser(v4);
      unique_idEv = CUser::get_unique_id(UserEv);
      InterfacePacketBuf::put_short((InterfacePacketBuf *)v7, unique_idEv);
    }
  }
  InterfacePacketBuf::finalize(v7, 1);
  BlueMarble::sendToBlueMarble(this, (PacketGuard *)v7);
  PacketGuard::~PacketGuard(v7);
}

// IDA_EA: 0x80D8600
// IDA_NAME: _ZNK10BlueMarble22sendBlueMarbleDiceInfoEi
// DEMANGLED: BlueMarble::sendBlueMarbleDiceInfo(int)const
void __cdecl BlueMarble::sendBlueMarbleDiceInfo(BlueMarble *this, int UserSlotEP5CUser)
{
  char DiceNumberEv; // al
  PacketBuf *v3[5]; // [esp+14h] [ebp-14h] BYREF

  PacketGuard::PacketGuard((PacketGuard *)v3);
  InterfacePacketBuf::put_header(v3, 0, 431);
  InterfacePacketBuf::put_byte(v3, UserSlotEP5CUser);
  DiceNumberEv = BlueMarble::getDiceNumber(this);
  InterfacePacketBuf::put_byte(v3, DiceNumberEv);
  InterfacePacketBuf::finalize(v3, 1);
  BlueMarble::sendToBlueMarble(this, (PacketGuard *)v3);
  PacketGuard::~PacketGuard(v3);
}

// IDA_EA: 0x80D86B2
// IDA_NAME: _ZNK10BlueMarble19sendStartBlueMarbleEv
// DEMANGLED: BlueMarble::sendStartBlueMarble(void)const
void __cdecl BlueMarble::sendStartBlueMarble(BlueMarble *this)
{
  char BlueMarbleMapEv; // al
  PacketBuf *v2[5]; // [esp+14h] [ebp-14h] BYREF

  PacketGuard::PacketGuard((PacketGuard *)v2);
  InterfacePacketBuf::put_header(v2, 0, 432);
  BlueMarbleMapEv = BlueMarble::getBlueMarbleMap(this);
  InterfacePacketBuf::put_byte(v2, BlueMarbleMapEv);
  InterfacePacketBuf::finalize(v2, 1);
  BlueMarble::sendToBlueMarble(this, (PacketGuard *)v2);
  PacketGuard::~PacketGuard(v2);
}

// IDA_EA: 0x80D8752
// IDA_NAME: _ZNK10BlueMarble20sendFinishBlueMarbleEv
// DEMANGLED: BlueMarble::sendFinishBlueMarble(void)const
void __cdecl BlueMarble::sendFinishBlueMarble(BlueMarble *this)
{
  PacketBuf *v1[3]; // [esp+10h] [ebp-18h] BYREF
  int WinnerEv; // [esp+1Ch] [ebp-Ch]

  WinnerEv = BlueMarble::getWinner(this);
  if ( WinnerEv != -1 )
  {
    PacketGuard::PacketGuard((PacketGuard *)v1);
    InterfacePacketBuf::put_header(v1, 0, 433);
    InterfacePacketBuf::put_byte(v1, WinnerEv);
    InterfacePacketBuf::finalize(v1, 1);
    BlueMarble::sendToBlueMarble(this, (PacketGuard *)v1);
    PacketGuard::~PacketGuard(v1);
  }
}

// IDA_EA: 0x80D8802
// IDA_NAME: _ZNK10BlueMarble23sendBoardZoneActionInfoEiij
// DEMANGLED: BlueMarble::sendBoardZoneActionInfo(int,int,unsigned int)const
void __cdecl BlueMarble::sendBoardZoneActionInfo(
        BlueMarble *this,
        int UserSlotEP5CUser,
        __int16 DungeonIndexEi,
        unsigned int ItemIndexEi)
{
  BlueMarbleUserInfo *v4; // eax
  CUser *UserEv; // eax
  PacketBuf *v6[5]; // [esp+14h] [ebp-14h] BYREF

  PacketGuard::PacketGuard((PacketGuard *)v6);
  InterfacePacketBuf::put_header(v6, 0, 434);
  InterfacePacketBuf::put_short(v6, DungeonIndexEi);
  InterfacePacketBuf::put_int(v6, ItemIndexEi);
  InterfacePacketBuf::finalize(v6, 1);
  v4 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  UserEv = (CUser *)BlueMarbleUserInfo::getUser(v4);
  CUser::Send(UserEv, (PacketGuard *)v6);
  PacketGuard::~PacketGuard(v6);
}

// IDA_EA: 0x80D88C2
// IDA_NAME: _ZNK10BlueMarble18sendTileGiveUpInfoEi
// DEMANGLED: BlueMarble::sendTileGiveUpInfo(int)const
void __cdecl BlueMarble::sendTileGiveUpInfo(BlueMarble *this, int UserSlotEP5CUser)
{
  PacketBuf *v2[5]; // [esp+14h] [ebp-14h] BYREF

  PacketGuard::PacketGuard((PacketGuard *)v2);
  InterfacePacketBuf::put_header(v2, 0, 435);
  InterfacePacketBuf::put_byte(v2, UserSlotEP5CUser);
  InterfacePacketBuf::finalize(v2, 1);
  BlueMarble::sendToBlueMarble(this, (PacketGuard *)v2);
  PacketGuard::~PacketGuard(v2);
}

// IDA_EA: 0x80D8956
// IDA_NAME: _ZNK10BlueMarble18sendUpdateItemInfoEii
// DEMANGLED: BlueMarble::sendUpdateItemInfo(int,int)const
void __cdecl BlueMarble::sendUpdateItemInfo(BlueMarble *this, int UserSlotEP5CUser, unsigned int n3)
{
  BlueMarbleUserInfo *v3; // eax
  CUserCharacInfo *UserEv; // eax
  CInventory *CurCharacInvenREv; // eax
  BlueMarbleUserInfo *v6; // eax
  CUser *UserEv_1; // eax
  PacketBuf *v8[5]; // [esp+14h] [ebp-14h] BYREF

  PacketGuard::PacketGuard((PacketGuard *)v8);
  InterfacePacketBuf::put_header(v8, 0, 14);
  InterfacePacketBuf::put_byte(v8, 0);
  InterfacePacketBuf::put_short(v8, 1);
  v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  UserEv = (CUserCharacInfo *)BlueMarbleUserInfo::getUser(v3);
  CurCharacInvenREv = (CInventory *)CUserCharacInfo::getCurCharacInvenR(UserEv);
  CInventory::MakeItemPacket(CurCharacInvenREv, 1, n3, (OS_API *)v8);
  InterfacePacketBuf::finalize(v8, 1);
  v6 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, UserSlotEP5CUser);
  UserEv_1 = (CUser *)BlueMarbleUserInfo::getUser(v6);
  CUser::Send(UserEv_1, (PacketGuard *)v8);
  PacketGuard::~PacketGuard(v8);
}

// IDA_EA: 0x80D8A5C
// IDA_NAME: _ZN10BlueMarbleC2Ev
// DEMANGLED: BlueMarble::BlueMarble(void)
void __cdecl BlueMarble::BlueMarble(BlueMarble *this)
{
  CMTRand *v1; // ebx
  CMTRand *v2; // esi
  int n3; // edi
  time_t v4; // [esp+18h] [ebp-20h]
  int n3_1; // [esp+1Ch] [ebp-1Ch]

  *(_DWORD *)this = -1;
  std::vector<BlueMarbleUserInfo>::vector((char *)this + 4);
  *((_DWORD *)this + 4) = 0;
  *((_DWORD *)this + 6) = 0;
  *((_DWORD *)this + 7) = 0;
  std::set<int>::set((char *)this + 32);
  *((_DWORD *)this + 14) = 0;
  *((_DWORD *)this + 15) = 0;
  v1 = (CMTRand *)operator new[](0x2720u);
  v2 = v1;
  for ( n3 = 3; n3 != -1; --n3 )
  {
    CMTRand::CMTRand(v2);
    v2 = (CMTRand *)((char *)v2 + 2504);
  }
  *((_DWORD *)this + 5) = v1;
  v4 = time(0);
  for ( n3_1 = 0; n3_1 <= 3; ++n3_1 )
    CMTRand::seed((CMTRand *)(*((_DWORD *)this + 5) + 2504 * n3_1), v4);
  std::vector<BlueMarbleUserInfo>::clear((char *)this + 4);
  std::set<int>::clear((char *)this + 32);
}

// IDA_EA: 0x80D8BAE
// IDA_NAME: _ZN10BlueMarbleD2Ev
// DEMANGLED: BlueMarble::~BlueMarble()
void __cdecl BlueMarble::~BlueMarble(void **this)
{
  if ( this[5] )
    operator delete[](this[5]);
  this[5] = 0;
  std::set<int>::~set(this + 8);
  std::vector<BlueMarbleUserInfo>::~vector(this + 1);
}

// IDA_EA: 0x80D8C26
// IDA_NAME: _ZN10BlueMarble18setMemoryPoolIndexEi
// DEMANGLED: BlueMarble::setMemoryPoolIndex(int)
BlueMarble *__cdecl BlueMarble::setMemoryPoolIndex(BlueMarble *this, int a2)
{
  BlueMarble *this_1; // eax

  this_1 = this;
  *(_DWORD *)this = a2;
  return this_1;
}

// IDA_EA: 0x80D8C34
// IDA_NAME: _ZNK10BlueMarble18getMemoryPoolIndexEv
// DEMANGLED: BlueMarble::getMemoryPoolIndex(void)const
int __cdecl BlueMarble::getMemoryPoolIndex(BlueMarble *this)
{
  return *(_DWORD *)this;
}

// IDA_EA: 0x80D8C3E
// IDA_NAME: _ZN10BlueMarble11setUserInfoEP23BlueMarbleScriptManager
// DEMANGLED: BlueMarble::setUserInfo(BlueMarbleScriptManager *)
void __cdecl BlueMarble::setUserInfo(BlueMarble *this, BlueMarbleScriptManager *BlueMarbleScriptEv)
{
  _BYTE v2[48]; // [esp+18h] [ebp-30h] BYREF

  BlueMarbleUserInfo::BlueMarbleUserInfo((BlueMarbleUserInfo *)v2);
  BlueMarbleUserInfo::setScript((BlueMarbleUserInfo *)v2, BlueMarbleScriptEv);
  std::vector<BlueMarbleUserInfo>::push_back((int)this + 4, (int)v2);
  BlueMarbleUserInfo::~BlueMarbleUserInfo();
}

// IDA_EA: 0x80D8CA8
// IDA_NAME: _ZN10BlueMarble9setScriptEP23BlueMarbleScriptManager
// DEMANGLED: BlueMarble::setScript(BlueMarbleScriptManager *)
BlueMarble *__cdecl BlueMarble::setScript(BlueMarble *this, BlueMarbleScriptManager *BlueMarbleScriptEv)
{
  BlueMarble *this_1; // eax

  this_1 = this;
  *((_DWORD *)this + 14) = BlueMarbleScriptEv;
  return this_1;
}

// IDA_EA: 0x80D8CB6
// IDA_NAME: _ZN10BlueMarble9checkJoinEv
// DEMANGLED: BlueMarble::checkJoin(void)
_BOOL4 __cdecl BlueMarble::checkJoin(BlueMarble *this)
{
  return !BlueMarble::getState(this) && BlueMarble::getWaitUserCount(this) < *(_DWORD *)(*((_DWORD *)this + 14) + 48);
}

// IDA_EA: 0x80D8D02
// IDA_NAME: _ZN10BlueMarble33checkUserConditionEnterBlueMarbleEP5CUser
// DEMANGLED: BlueMarble::checkUserConditionEnterBlueMarble(CUser *)
int __cdecl BlueMarble::checkUserConditionEnterBlueMarble(BlueMarble *this, CUser *UserEv)
{
  BlueMarbleUserInfo *v3; // eax
  private_store::CPrivateStoreMgr *InstancePrivateStoreMgr; // eax
  unsigned __int16 unique_idEv; // ax
  CGameManager *v7; // eax
  private_store *v8; // [esp+0h] [ebp-28h]
  int v9; // [esp+14h] [ebp-14h]
  int i; // [esp+18h] [ebp-10h]
  CParty *Party; // [esp+1Ch] [ebp-Ch]

  if ( !UserEv )
    return 23;
  v9 = 0;
  for ( i = 0; *(_DWORD *)(*((_DWORD *)this + 14) + 48) > i; ++i )
  {
    v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
    if ( (CUser *)BlueMarbleUserInfo::getUser(v3) == UserEv )
      ++v9;
  }
  if ( v9 <= 0 )
  {
    if ( CUser::get_state(UserEv) == 3 )
    {
      if ( (unsigned __int8)CUser::checkInBlueMarble(UserEv) )
      {
        return 23;
      }
      else if ( CUser::getMoveSpace(UserEv) == 1 )
      {
        return 23;
      }
      else if ( CUserCharacInfo::get_charac_level(UserEv) < *(_DWORD *)(*((_DWORD *)this + 14) + 52)
             || CUserCharacInfo::get_charac_level(UserEv) > *(_DWORD *)(*((_DWORD *)this + 14) + 56) )
      {
        return 23;
      }
      else if ( (unsigned __int8)CUserCharacInfo::getBlueMarbleEnterCount(UserEv) < *(int *)(*((_DWORD *)this + 14) + 60) )
      {
        if ( (unsigned __int8)CUserCharacInfo::getCurCharacVill(UserEv) == 7 )
        {
          return 23;
        }
        else
        {
          InstancePrivateStoreMgr = (private_store::CPrivateStoreMgr *)private_store::GetInstancePrivateStoreMgr(v8);
          if ( (unsigned __int8)private_store::CPrivateStoreMgr::IsBusyPrivateStore(InstancePrivateStoreMgr, UserEv) )
          {
            return 23;
          }
          else if ( (unsigned __int8)CUserCharacInfo::IsBusyDisjointStore(UserEv) )
          {
            return 23;
          }
          else if ( (unsigned __int8)CUserCharacInfo::IsCurCharacGhost(UserEv) )
          {
            return 23;
          }
          else if ( (unsigned __int8)CUser::CheckInTrade(UserEv) )
          {
            return 23;
          }
          else if ( (unsigned __int8)CUser::isCompetitionMercenary(UserEv) )
          {
            return 23;
          }
          else
          {
            if ( (unsigned __int8)CUser::CheckInParty(UserEv) )
            {
              Party = (CParty *)CUser::GetParty(UserEv);
              if ( Party )
              {
                unique_idEv = CUser::get_unique_id(UserEv);
                CParty::send_invite_bluemarble(Party, unique_idEv);
                v7 = (CGameManager *)G_CGameManager();
                CGameManager::CheckOutParty(v7, UserEv, 0);
              }
            }
            return 0;
          }
        }
      }
      else
      {
        return 23;
      }
    }
    else
    {
      return 23;
    }
  }
  else
  {
    BlueMarble::leaveUser(this, UserEv);
    return 18;
  }
}

// IDA_EA: 0x80D8F58
// IDA_NAME: _ZN10BlueMarble4joinEP5CUser
// DEMANGLED: BlueMarble::join(CUser *)
int __cdecl BlueMarble::join(BlueMarble *this, CUser *UserEv)
{
  BlueMarbleUserInfo *v3; // eax
  BlueMarbleUserInfo *v4; // eax
  __int16 MemoryPoolIndexEv; // bx
  BlueMarbleUserInfo *v6; // eax
  CUser *UserEv_1; // eax
  BlueMarbleUserInfo *v8; // eax
  int UserEv_2; // eax
  GameWorld *v10; // eax
  int i; // [esp+1Ch] [ebp-Ch]

  if ( !UserEv )
    return 23;
  for ( i = 0; *(_DWORD *)(*((_DWORD *)this + 14) + 48) > i; ++i )
  {
    v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, i);
    if ( !BlueMarbleUserInfo::getUser(v3) )
    {
      v4 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, i);
      BlueMarbleUserInfo::setUser(v4, UserEv);
      MemoryPoolIndexEv = BlueMarble::getMemoryPoolIndex(this);
      v6 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, i);
      UserEv_1 = (CUser *)BlueMarbleUserInfo::getUser(v6);
      CUser::setBlueMarbleIndex(UserEv_1, MemoryPoolIndexEv);
      v8 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((_DWORD *)this + 1, i);
      UserEv_2 = BlueMarbleUserInfo::getUser(v8);
      CUser::setMoveSpace(UserEv_2, 1);
      break;
    }
  }
  v10 = (GameWorld *)G_GameWorld();
  GameWorld::gotoBlueMarble(v10, UserEv);
  BlueMarble::sendBlueMarbleRoomInfo(this);
  return 0;
}

// IDA_EA: 0x80D9074
// IDA_NAME: _ZNK10BlueMarble11getUserSlotEP5CUser
// DEMANGLED: BlueMarble::getUserSlot(CUser *)const
int __cdecl BlueMarble::getUserSlot(BlueMarble *this, CUser *UserEv)
{
  BlueMarbleUserInfo *v3; // eax
  int i; // [esp+1Ch] [ebp-Ch]

  if ( !UserEv )
    return -1;
  for ( i = 0; *(_DWORD *)(*((_DWORD *)this + 14) + 48) > i; ++i )
  {
    v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
    if ( (CUser *)BlueMarbleUserInfo::getUser(v3) == UserEv )
      return i;
  }
  return -1;
}

// IDA_EA: 0x80D90DA
// IDA_NAME: _ZNK10BlueMarble16getWaitUserCountEv
// DEMANGLED: BlueMarble::getWaitUserCount(void)const
int __cdecl BlueMarble::getWaitUserCount(BlueMarble *this)
{
  BlueMarbleUserInfo *v1; // eax
  int v3; // [esp+18h] [ebp-10h]
  int i; // [esp+1Ch] [ebp-Ch]

  v3 = 0;
  for ( i = 0; *(_DWORD *)(*((_DWORD *)this + 14) + 48) > i; ++i )
  {
    v1 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
    if ( BlueMarbleUserInfo::getUser(v1) )
      ++v3;
  }
  return v3;
}

// IDA_EA: 0x80D9136
// IDA_NAME: _ZN10BlueMarble9leaveUserEP5CUser
// DEMANGLED: BlueMarble::leaveUser(CUser *)
void __cdecl BlueMarble::leaveUser(BlueMarble *this, CUser *UserEv)
{
  GameWorld *v2; // eax
  const char *v3; // [esp+14h] [ebp-24h]
  char *UserSlotEP5CUser; // [esp+2Ch] [ebp-Ch]

  if ( UserEv )
  {
    UserSlotEP5CUser = (char *)BlueMarble::getUserSlot(this, UserEv);
    if ( UserSlotEP5CUser == (char *)-1 )
    {
      LogManager::logFormat(
        (LogManager *)1,
        (int)"BlueMarble.cpp",
        "void BlueMarble::leaveUser(CUser*)",
        (const char *)0x400,
        "BlueMarble::leaveUser slot(%d)",
        (const char *)0xFFFFFFFF);
    }
    else
    {
      v2 = (GameWorld *)G_GameWorld();
      GameWorld::outFromBlueMarble(v2, UserEv);
      BlueMarble::setLeaveUserSlot(this, UserSlotEP5CUser);
      BlueMarble::setLeaveUserBlueMarbleState(this);
      BlueMarble::sendBlueMarbleRoomInfo(this);
    }
  }
  else
  {
    LogManager::logFormat(
      (LogManager *)1,
      (int)"BlueMarble.cpp",
      "void BlueMarble::leaveUser(CUser*)",
      (const char *)0x3F9,
      "BlueMarble::leaveUser user is NULL",
      v3);
  }
}

// IDA_EA: 0x80D9202
// IDA_NAME: _ZN10BlueMarble11changeStateEN15BlueMarbleState1TE
// DEMANGLED: BlueMarble::changeState(BlueMarbleState::T)
int __cdecl BlueMarble::changeState(int a1, int a2)
{
  int result; // eax

  result = a1;
  *(_DWORD *)(a1 + 16) = a2;
  return result;
}

// IDA_EA: 0x80D9210
// IDA_NAME: _ZN10BlueMarble15enterBlueMarbleEP5CUser
// DEMANGLED: BlueMarble::enterBlueMarble(CUser *)
int __cdecl BlueMarble::enterBlueMarble(BlueMarble *this, CUser *UserEv)
{
  int v3; // [esp+1Ch] [ebp-Ch]
  int v4; // [esp+1Ch] [ebp-Ch]

  if ( !UserEv )
    return 23;
  if ( !BlueMarble::checkJoin(this) )
    return 23;
  v3 = BlueMarble::checkUserConditionEnterBlueMarble(this, UserEv);
  if ( v3 > 0 )
    return v3;
  v4 = BlueMarble::join(this, UserEv);
  if ( v4 > 0 )
    return v4;
  if ( BlueMarble::getWaitUserCount(this) == *(_DWORD *)(*((_DWORD *)this + 14) + 48) )
    BlueMarble::changeState((int)this, 1);
  return 0;
}

// IDA_EA: 0x80D92BE
// IDA_NAME: _ZN10BlueMarble15startBlueMarbleEv
// DEMANGLED: BlueMarble::startBlueMarble(void)
void __cdecl BlueMarble::startBlueMarble(BlueMarble *this)
{
  BlueMarbleUserInfo *v1; // eax
  int v2; // eax
  BlueMarbleUserInfo *v3; // eax
  CUserCharacInfo *UserEv; // eax
  BlueMarbleUserInfo *v5; // eax
  CUser *UserEv_1; // eax
  int i; // [esp+1Ch] [ebp-Ch]

  if ( (unsigned __int8)BlueMarble::checkStartBlueMarble(this) )
  {
    BlueMarble::resetBlueMarble(this);
    BlueMarble::changeState((int)this, 2);
    BlueMarble::setBlueMarbleMap(this);
    BlueMarble::setMaxBoardSize((BlueMarbleScriptManager **)this);
    for ( i = 0; *(_DWORD *)(*((_DWORD *)this + 14) + 48) > i; ++i )
    {
      v1 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
      if ( BlueMarbleUserInfo::getUser(v1) )
      {
        v2 = std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
        BlueMarbleUserInfo::setUserState(v2, 1);
        v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
        UserEv = (CUserCharacInfo *)BlueMarbleUserInfo::getUser(v3);
        CUserCharacInfo::increaseBlueMarbleEnterCount(UserEv);
        v5 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
        UserEv_1 = (CUser *)BlueMarbleUserInfo::getUser(v5);
        CUser::sendBlueMarbleEnterCount(UserEv_1);
      }
    }
    BlueMarble::sendStartBlueMarble(this);
  }
}

// IDA_EA: 0x80D93D8
// IDA_NAME: _ZN10BlueMarble13userThrowDiceEP5CUser
// DEMANGLED: BlueMarble::userThrowDice(CUser *)
void __cdecl BlueMarble::userThrowDice(BlueMarble *this, CUser *UserEv)
{
  int DiceNumberEv; // eax
  unsigned int ItemIndexEi; // ebx
  int DungeonIndexEi; // eax
  char *UserSlotEP5CUser; // [esp+2Ch] [ebp-Ch]

  if ( UserEv )
  {
    UserSlotEP5CUser = (char *)BlueMarble::getUserSlot(this, UserEv);
    if ( UserSlotEP5CUser == (char *)-1 )
    {
      LogManager::logFormat(
        (LogManager *)1,
        (int)"BlueMarble.cpp",
        "void BlueMarble::userThrowDice(CUser*)",
        (const char *)0x446,
        "BlueMarble::userThrowDice slot(%d)",
        (const char *)0xFFFFFFFF);
    }
    else if ( BlueMarble::checkThrowDice(this, (int)UserSlotEP5CUser) )
    {
      BlueMarble::resetIndexInfo(this, (int)UserSlotEP5CUser);
      BlueMarble::throwDice(this, (int)UserSlotEP5CUser);
      DiceNumberEv = BlueMarble::getDiceNumber(this);
      BlueMarble::setMovePosition(this, (int)UserSlotEP5CUser, DiceNumberEv);
      BlueMarble::intoBoardZone(this, (int)UserSlotEP5CUser);
      ItemIndexEi = BlueMarble::getItemIndex(this, (int)UserSlotEP5CUser);
      DungeonIndexEi = BlueMarble::getDungeonIndex(this, (int)UserSlotEP5CUser);
      BlueMarble::sendBoardZoneActionInfo(this, (int)UserSlotEP5CUser, DungeonIndexEi, ItemIndexEi);
    }
  }
}

// IDA_EA: 0x80D94F6
// IDA_NAME: _ZN10BlueMarble12enterDungeonEP5CUser
// DEMANGLED: BlueMarble::enterDungeon(CUser *)
void __cdecl BlueMarble::enterDungeon(BlueMarble *this, CUser *UserEv)
{
  char *UserSlotEP5CUser; // [esp+2Ch] [ebp-Ch]

  if ( UserEv )
  {
    UserSlotEP5CUser = (char *)BlueMarble::getUserSlot(this, UserEv);
    if ( UserSlotEP5CUser == (char *)-1 )
      LogManager::logFormat(
        (LogManager *)1,
        (int)"BlueMarble.cpp",
        "void BlueMarble::enterDungeon(CUser*)",
        (const char *)0x45C,
        "BlueMarble::enterDungeon slot(%d)",
        (const char *)0xFFFFFFFF);
    else
      BlueMarble::setUserState((int)this, (int)UserSlotEP5CUser, 2);
  }
}

// IDA_EA: 0x80D9572
// IDA_NAME: _ZN10BlueMarble13giveupDungeonEP5CUser
// DEMANGLED: BlueMarble::giveupDungeon(CUser *)
void __cdecl BlueMarble::giveupDungeon(BlueMarbleScriptManager **this, CUser *UserEv)
{
  char BlueMarbleMapEv; // al
  BlueMarbleUserInfo *v3; // eax
  unsigned int BoardZoneEv; // ebx
  char BlueMarbleMapEv_1; // al
  BlueMarbleMapScript *MapEi; // eax
  int MovePositionEi; // eax
  char *UserSlotEP5CUser; // [esp+28h] [ebp-10h]
  int *TileEj; // [esp+2Ch] [ebp-Ch]

  if ( UserEv )
  {
    UserSlotEP5CUser = (char *)BlueMarble::getUserSlot((BlueMarble *)this, UserEv);
    if ( UserSlotEP5CUser == (char *)-1 )
    {
      LogManager::logFormat(
        (LogManager *)1,
        (int)"BlueMarble.cpp",
        "void BlueMarble::giveupDungeon(CUser*)",
        (const char *)0x46B,
        "BlueMarble::giveupDungeon slot(%d)",
        (const char *)0xFFFFFFFF);
    }
    else
    {
      BlueMarbleMapEv = BlueMarble::getBlueMarbleMap((BlueMarble *)this);
      if ( BlueMarbleScriptManager::getMap(this[14], BlueMarbleMapEv) )
      {
        v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[](this + 1, UserSlotEP5CUser);
        BoardZoneEv = BlueMarbleUserInfo::getBoardZone(v3);
        BlueMarbleMapEv_1 = BlueMarble::getBlueMarbleMap((BlueMarble *)this);
        MapEi = (BlueMarbleMapScript *)BlueMarbleScriptManager::getMap(this[14], BlueMarbleMapEv_1);
        TileEj = (int *)BlueMarbleMapScript::getTile(MapEi, BoardZoneEv);
        if ( TileEj )
        {
          if ( (unsigned __int8)BlueMarble::checkMoveFirstZone((BlueMarble *)this, (int)UserSlotEP5CUser, *TileEj) )
          {
            MovePositionEi = BlueMarble::getMovePosition((BlueMarble *)this, (int)UserSlotEP5CUser);
            BlueMarble::setMovePosition((BlueMarble *)this, (int)UserSlotEP5CUser, 1 - MovePositionEi);
            BlueMarble::resetBuffInfo((BlueMarble *)this, (int)UserSlotEP5CUser);
            BlueMarble::sendTileGiveUpInfo((BlueMarble *)this, (int)UserSlotEP5CUser);
          }
          BlueMarble::setUserState((int)this, (int)UserSlotEP5CUser, 1);
        }
      }
    }
  }
}

// IDA_EA: 0x80D96F4
// IDA_NAME: _ZN10BlueMarble12clearDungeonEP5CUser
// DEMANGLED: BlueMarble::clearDungeon(CUser *)
void __cdecl BlueMarble::clearDungeon(BlueMarble *this, CUser *UserEv)
{
  char *UserSlotEP5CUser; // [esp+2Ch] [ebp-Ch]

  if ( UserEv )
  {
    UserSlotEP5CUser = (char *)BlueMarble::getUserSlot(this, UserEv);
    if ( UserSlotEP5CUser == (char *)-1 )
    {
      LogManager::logFormat(
        (LogManager *)1,
        (int)"BlueMarble.cpp",
        "void BlueMarble::clearDungeon(CUser*)",
        (const char *)0x48A,
        "BlueMarble::clearDungeon slot(%d)",
        (const char *)0xFFFFFFFF);
    }
    else if ( BlueMarble::checkLastZoneDungeonClear(this, (int)UserSlotEP5CUser) )
    {
      BlueMarble::finishBlueMarble(this, (int)UserSlotEP5CUser);
      BlueMarble::resultReward(this);
    }
  }
}

// IDA_EA: 0x80D978C
// IDA_NAME: _ZN10BlueMarble11exitDungeonEP5CUser
// DEMANGLED: BlueMarble::exitDungeon(CUser *)
void __cdecl BlueMarble::exitDungeon(BlueMarble *this, CUser *UserEv)
{
  char *UserSlotEP5CUser; // [esp+2Ch] [ebp-Ch]

  if ( UserEv )
  {
    UserSlotEP5CUser = (char *)BlueMarble::getUserSlot(this, UserEv);
    if ( UserSlotEP5CUser == (char *)-1 )
      LogManager::logFormat(
        (LogManager *)1,
        (int)"BlueMarble.cpp",
        "void BlueMarble::exitDungeon(CUser*)",
        (const char *)0x49D,
        "BlueMarble::exitDungeon slot(%d)",
        (const char *)0xFFFFFFFF);
    else
      BlueMarble::setUserState((int)this, (int)UserSlotEP5CUser, 1);
  }
}

// IDA_EA: 0x80D9808
// IDA_NAME: _ZN10BlueMarble13giveBonusItemEP5CUser
// DEMANGLED: BlueMarble::giveBonusItem(CUser *)
void __cdecl BlueMarble::giveBonusItem(BlueMarble *this, CUser *UserEv)
{
  _BYTE v3[2]; // [esp+2Fh] [ebp-49h] BYREF
  int ItemIndexEi; // [esp+31h] [ebp-47h]
  int v5; // [esp+36h] [ebp-42h]
  char *UserSlotEP5CUser; // [esp+6Ch] [ebp-Ch]

  if ( UserEv )
  {
    UserSlotEP5CUser = (char *)BlueMarble::getUserSlot(this, UserEv);
    if ( UserSlotEP5CUser == (char *)-1 )
    {
      LogManager::logFormat(
        (LogManager *)1,
        (int)"BlueMarble.cpp",
        "void BlueMarble::giveBonusItem(CUser*)",
        (const char *)0x4AC,
        "BlueMarble::giveBonusItem slot(%d)",
        (const char *)0xFFFFFFFF);
    }
    else if ( BlueMarble::getState(this) == 2 && BlueMarble::getUserState(this, (int)UserSlotEP5CUser) == 1 )
    {
      Inven_Item::Inven_Item((Inven_Item *)v3);
      ItemIndexEi = BlueMarble::getItemIndex(this, (int)UserSlotEP5CUser);
      v5 = 1;
      if ( ItemIndexEi )
      {
        BlueMarble::insertItem(this, (int)UserSlotEP5CUser, (Inven_Item *)v3, 65);
        BlueMarble::resetIndexInfo(this, (int)UserSlotEP5CUser);
      }
    }
  }
}

// IDA_EA: 0x80D990E
// IDA_NAME: _ZN10BlueMarble7getBuffEP5CUserN18BlueMarbleBuffType1TE
// DEMANGLED: BlueMarble::getBuff(CUser *,BlueMarbleBuffType::T)
int __cdecl BlueMarble::getBuff(BlueMarble *BlueMarbleEv, CUser *UserEv, int n2)
{
  char *UserSlotEP5CUser; // [esp+2Ch] [ebp-Ch]

  if ( !UserEv )
    return 0;
  UserSlotEP5CUser = (char *)BlueMarble::getUserSlot(BlueMarbleEv, UserEv);
  if ( UserSlotEP5CUser == (char *)-1 )
  {
    LogManager::logFormat(
      (LogManager *)1,
      (int)"BlueMarble.cpp",
      "int BlueMarble::getBuff(CUser*, BlueMarbleBuffType::T)",
      (const char *)0x4C7,
      "BlueMarble::getBuff slot(%d)",
      (const char *)0xFFFFFFFF);
    return 0;
  }
  else if ( n2 == 1 )
  {
    return BlueMarble::getGoldBuff(BlueMarbleEv, (int)UserSlotEP5CUser);
  }
  else if ( n2 == 2 )
  {
    return BlueMarble::getDropBuff(BlueMarbleEv, (int)UserSlotEP5CUser);
  }
  else if ( n2 )
  {
    return 0;
  }
  else
  {
    return BlueMarble::getExpBuff(BlueMarbleEv, (int)UserSlotEP5CUser);
  }
}

// IDA_EA: 0x80D99CE
// IDA_NAME: _ZNK10BlueMarble16sendToBlueMarbleER11PacketGuard
// DEMANGLED: BlueMarble::sendToBlueMarble(PacketGuard &)const
bool __cdecl BlueMarble::sendToBlueMarble(BlueMarble *this, PacketGuard *a2)
{
  BlueMarbleUserInfo *v2; // eax
  BlueMarbleUserInfo *v3; // eax
  CUser *UserEv; // eax
  bool result; // al
  int i; // [esp+1Ch] [ebp-Ch]

  for ( i = 0; ; ++i )
  {
    result = *(_DWORD *)(*((_DWORD *)this + 14) + 48) > i;
    if ( *(_DWORD *)(*((_DWORD *)this + 14) + 48) <= i )
      break;
    v2 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
    if ( BlueMarbleUserInfo::getUser(v2) )
    {
      v3 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
      UserEv = (CUser *)BlueMarbleUserInfo::getUser(v3);
      CUser::Send(UserEv, a2);
    }
  }
  return result;
}

// IDA_EA: 0x80D9A4C
// IDA_NAME: _ZN10BlueMarble12movePositionEP5CUseri
// DEMANGLED: BlueMarble::movePosition(CUser *,int)
void __cdecl BlueMarble::movePosition(BlueMarble *this, CUser *UserEv, int a3)
{
  int MovePositionEi; // eax
  int MovePositionEi_1; // eax
  unsigned int ItemIndexEi; // ebx
  int DungeonIndexEi; // eax
  PacketBuf *v7[3]; // [esp+20h] [ebp-18h] BYREF
  char *UserSlotEP5CUser; // [esp+2Ch] [ebp-Ch]

  UserSlotEP5CUser = (char *)BlueMarble::getUserSlot(this, UserEv);
  if ( UserSlotEP5CUser == (char *)-1 )
  {
    LogManager::logFormat(
      (LogManager *)1,
      (int)"BlueMarble.cpp",
      "void BlueMarble::movePosition(CUser*, int)",
      (const char *)0x4F4,
      "BlueMarble::movePosition slot(%d)",
      (const char *)0xFFFFFFFF);
  }
  else if ( BlueMarble::checkThrowDice(this, (int)UserSlotEP5CUser) )
  {
    PacketGuard::PacketGuard((PacketGuard *)v7);
    InterfacePacketBuf::put_header(v7, 0, 431);
    InterfacePacketBuf::put_byte(v7, (int)UserSlotEP5CUser);
    MovePositionEi = BlueMarble::getMovePosition(this, (int)UserSlotEP5CUser);
    InterfacePacketBuf::put_byte(v7, a3 - MovePositionEi);
    InterfacePacketBuf::finalize(v7, 1);
    BlueMarble::sendToBlueMarble(this, (PacketGuard *)v7);
    BlueMarble::resetIndexInfo(this, (int)UserSlotEP5CUser);
    MovePositionEi_1 = BlueMarble::getMovePosition(this, (int)UserSlotEP5CUser);
    BlueMarble::setMovePosition(this, (int)UserSlotEP5CUser, a3 - MovePositionEi_1);
    BlueMarble::intoBoardZone(this, (int)UserSlotEP5CUser);
    ItemIndexEi = BlueMarble::getItemIndex(this, (int)UserSlotEP5CUser);
    DungeonIndexEi = BlueMarble::getDungeonIndex(this, (int)UserSlotEP5CUser);
    BlueMarble::sendBoardZoneActionInfo(this, (int)UserSlotEP5CUser, DungeonIndexEi, ItemIndexEi);
    PacketGuard::~PacketGuard(v7);
  }
}

// IDA_EA: 0x80D9C12
// IDA_NAME: _ZN10BlueMarble26checkBlueMarbleUserConfirmEP5CUser
// DEMANGLED: BlueMarble::checkBlueMarbleUserConfirm(CUser *)
void __cdecl BlueMarble::checkBlueMarbleUserConfirm(BlueMarble *this, CUser *UserEv_5)
{
  CEnvironment *v2; // eax
  const char *file_nameEv; // eax
  BlueMarbleUserInfo *v4; // eax
  BlueMarbleUserInfo *v5; // eax
  CUser *UserEv; // eax
  BlueMarbleUserInfo *v7; // eax
  CUser *UserEv_1; // eax
  BlueMarbleUserInfo *v9; // eax
  CUser *UserEv_2; // eax
  BlueMarbleUserInfo *v11; // eax
  CUser *UserEv_3; // eax
  BlueMarbleUserInfo *v13; // eax
  CUser *UserEv_4; // eax
  unsigned int acc_idEv; // eax
  char v16; // bl
  char s[1024]; // [esp+44h] [ebp-424h] BYREF
  int v18[2]; // [esp+444h] [ebp-24h] BYREF
  int i; // [esp+44Ch] [ebp-1Ch]

  if ( UserEv_5 )
  {
    memset(s, 0, sizeof(s));
    v2 = (CEnvironment *)G_CEnvironment();
    file_nameEv = (const char *)CEnvironment::get_file_name(v2);
    sprintf(s, "./log/%s/BlueMarbleConfirmInfo", file_nameEv);
    for ( i = 0; *(_DWORD *)(*((_DWORD *)this + 14) + 48) > i; ++i )
    {
      v4 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
      if ( (CUser *)BlueMarbleUserInfo::getUser(v4) == UserEv_5 )
      {
        v5 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
        UserEv = (CUser *)BlueMarbleUserInfo::getUser(v5);
        CUser::getBlueMarbleIndex(UserEv);
        BlueMarble::getMemoryPoolIndex(this);
        v7 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
        UserEv_1 = (CUser *)BlueMarbleUserInfo::getUser(v7);
        CUser::getMoveSpace(UserEv_1);
        v9 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
        UserEv_2 = (CUser *)BlueMarbleUserInfo::getUser(v9);
        CUser::get_state(UserEv_2);
        v11 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
        UserEv_3 = (CUser *)BlueMarbleUserInfo::getUser(v11);
        CUser::get_charac_no(UserEv_3, -1);
        v13 = (BlueMarbleUserInfo *)std::vector<BlueMarbleUserInfo>::operator[]((char *)this + 4, i);
        UserEv_4 = (CUser *)BlueMarbleUserInfo::getUser(v13);
        acc_idEv = CUser::get_acc_id(UserEv_4);
        v16 = NumberToString(acc_idEv, 0);
        CMyFileLog::CMyFileLog((CMyFileLog *)v18, "void BlueMarble::checkBlueMarbleUserConfirm(CUser*)", 1300);
        CMyFileLog::operator()(
          (int)v18,
          s,
          "checkBlueMarbleUserConfirm() m_id(%s) charac_no(%u)userState(%d) userSpace(%d) blueMarble_Index(%d) user_bluem"
          "arble_index(%d) slot_index(%d)",
          v16);
      }
    }
  }
}
