#include "stTournamentRewardSelect.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x824BE96
// IDA_NAME: _ZN24stTournamentRewardSelectC2Ev
// DEMANGLED: stTournamentRewardSelect::stTournamentRewardSelect(void)
void __cdecl stTournamentRewardSelect::stTournamentRewardSelect(stTournamentRewardSelect *this)
{
  ParamBase::ParamBase(this);
  *(_DWORD *)this = off_8BDE9A0;
}

// IDA_EA: 0x824BEB2
// IDA_NAME: _ZN24stTournamentRewardSelectD2Ev
// DEMANGLED: stTournamentRewardSelect::~stTournamentRewardSelect()
void __cdecl stTournamentRewardSelect::~stTournamentRewardSelect(stTournamentRewardSelect *this)
{
  *(_DWORD *)this = off_8BDE9A0;
  ParamBase::~ParamBase(this);
}

// IDA_EA: 0x824BEE2
// IDA_NAME: _ZN24stTournamentRewardSelectD0Ev
// DEMANGLED: stTournamentRewardSelect::~stTournamentRewardSelect()
void __cdecl stTournamentRewardSelect::~stTournamentRewardSelect(stTournamentRewardSelect *this)
{
  stTournamentRewardSelect::~stTournamentRewardSelect(this);
  operator delete(this);
}
