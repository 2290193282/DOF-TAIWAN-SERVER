#ifndef __IDA91_STTOURNAMENTREWARDSELECT_H__
#define __IDA91_STTOURNAMENTREWARDSELECT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stTournamentRewardSelect
// Source unit: stTournamentRewardSelect
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2071

/* 2071 */
struct stTournamentRewardSelect;

// Exported member functions:
// 0x824BE96	stTournamentRewardSelect::stTournamentRewardSelect(void)
// 0x824BEB2	stTournamentRewardSelect::~stTournamentRewardSelect()
// 0x824BEE2	stTournamentRewardSelect::~stTournamentRewardSelect()

// Function declaration index:
// DECL 0x824BE96 stTournamentRewardSelect::stTournamentRewardSelect
// DECL 0x824BEB2 stTournamentRewardSelect::~stTournamentRewardSelect
// DECL 0x824BEE2 stTournamentRewardSelect::~stTournamentRewardSelect

#endif  // __IDA91_STTOURNAMENTREWARDSELECT_H__
