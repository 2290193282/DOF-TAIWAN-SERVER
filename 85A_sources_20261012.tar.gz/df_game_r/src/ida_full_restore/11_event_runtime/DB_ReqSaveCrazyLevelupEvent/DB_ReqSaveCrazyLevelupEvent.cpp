#include "DB_ReqSaveCrazyLevelupEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x842527A
// IDA_NAME: _ZN27DB_ReqSaveCrazyLevelupEvent8dispatchEiiP6Stream
// DEMANGLED: DB_ReqSaveCrazyLevelupEvent::dispatch(int,int,Stream *)
_BOOL4 __cdecl DB_ReqSaveCrazyLevelupEvent::dispatch(DB_ReqSaveCrazyLevelupEvent *this, int a2, int a3, Stream *a4)
{
  int v4; // esi
  const char *v5; // eax
  int v6; // esi
  const char *v7; // eax
  _BOOL4 result; // eax
  int Out; // [esp+28h] [ebp-10h]
  MySQL *DBHandle; // [esp+2Ch] [ebp-Ch]

  Out = Stream::GetOutBuffer<SIG_SAVE_CRAZY_LEVELUP_EVENT>(a4);
  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 4, 0);
  v4 = *(_DWORD *)(Out + 9);
  v5 = (const char *)NumberToString(*(_DWORD *)(Out + 5), 0);
  MySQL::set_query(
    DBHandle,
    "inSert into log_fighter_event(m_id,event_id,charac_no,occ_time,occ_cnt) values(%s,'%s',%d,now(),1)",
    v5,
    (const char *)Out,
    v4);
  result = 1;
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
  {
    v6 = *(_DWORD *)(Out + 9);
    v7 = (const char *)NumberToString(*(_DWORD *)(Out + 5), 0);
    MySQL::set_query(
      DBHandle,
      "upDate log_fighter_event set occ_time=now(),occ_cnt=occ_cnt+1 where m_id=%s and event_id='%s' and charac_no=%d",
      v7,
      (const char *)Out,
      v6);
    if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
      return 0;
  }
  return result;
}

// IDA_EA: 0x844E55E
// IDA_NAME: _ZN27DB_ReqSaveCrazyLevelupEventC2Ev
// DEMANGLED: DB_ReqSaveCrazyLevelupEvent::DB_ReqSaveCrazyLevelupEvent(void)
void __cdecl DB_ReqSaveCrazyLevelupEvent::DB_ReqSaveCrazyLevelupEvent(DB_ReqSaveCrazyLevelupEvent *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5F498;
}

// IDA_EA: 0x845EDD0
// IDA_NAME: _ZN27DB_ReqSaveCrazyLevelupEventD2Ev
// DEMANGLED: DB_ReqSaveCrazyLevelupEvent::~DB_ReqSaveCrazyLevelupEvent()
void __cdecl DB_ReqSaveCrazyLevelupEvent::~DB_ReqSaveCrazyLevelupEvent(DB_ReqSaveCrazyLevelupEvent *this)
{
  *(_DWORD *)this = &off_8C5F498;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845EE00
// IDA_NAME: _ZN27DB_ReqSaveCrazyLevelupEventD0Ev
// DEMANGLED: DB_ReqSaveCrazyLevelupEvent::~DB_ReqSaveCrazyLevelupEvent()
void __cdecl DB_ReqSaveCrazyLevelupEvent::~DB_ReqSaveCrazyLevelupEvent(DB_ReqSaveCrazyLevelupEvent *this)
{
  DB_ReqSaveCrazyLevelupEvent::~DB_ReqSaveCrazyLevelupEvent(this);
  operator delete(this);
}
