#ifndef __IDA91_DB_REQSAVECRAZYLEVELUPEVENT_H__
#define __IDA91_DB_REQSAVECRAZYLEVELUPEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_ReqSaveCrazyLevelupEvent
// Source unit: DB_ReqSaveCrazyLevelupEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
// Local type ordinals: 2500

/* 2500 */
struct DB_ReqSaveCrazyLevelupEvent;

// Exported member functions:
// 0x842527A	DB_ReqSaveCrazyLevelupEvent::dispatch(int,int,Stream *)
// 0x844E55E	DB_ReqSaveCrazyLevelupEvent::DB_ReqSaveCrazyLevelupEvent(void)
// 0x845EDD0	DB_ReqSaveCrazyLevelupEvent::~DB_ReqSaveCrazyLevelupEvent()
// 0x845EE00	DB_ReqSaveCrazyLevelupEvent::~DB_ReqSaveCrazyLevelupEvent()

// Function declaration index:
// DECL 0x842527A DB_ReqSaveCrazyLevelupEvent::dispatch
// DECL 0x844E55E DB_ReqSaveCrazyLevelupEvent::DB_ReqSaveCrazyLevelupEvent
// DECL 0x845EDD0 DB_ReqSaveCrazyLevelupEvent::~DB_ReqSaveCrazyLevelupEvent
// DECL 0x845EE00 DB_ReqSaveCrazyLevelupEvent::~DB_ReqSaveCrazyLevelupEvent

#endif  // __IDA91_DB_REQSAVECRAZYLEVELUPEVENT_H__
