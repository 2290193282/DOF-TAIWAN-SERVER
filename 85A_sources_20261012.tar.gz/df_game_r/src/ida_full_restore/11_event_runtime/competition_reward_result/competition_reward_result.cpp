#include "competition_reward_result.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81B47A8
// IDA_NAME: _ZN25competition_reward_resultC2Ev
// DEMANGLED: competition_reward_result::competition_reward_result(void)
void __cdecl competition_reward_result::competition_reward_result(competition_reward_result *this)
{
  *(_DWORD *)this = 0;
  *((_DWORD *)this + 1) = 0;
  *((_BYTE *)this + 8) = 0;
}
