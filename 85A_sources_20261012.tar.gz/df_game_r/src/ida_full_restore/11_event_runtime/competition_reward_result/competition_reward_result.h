#ifndef __IDA91_COMPETITION_REWARD_RESULT_H__
#define __IDA91_COMPETITION_REWARD_RESULT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: competition_reward_result
// Source unit: competition_reward_result
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1469

/* 1469 */
struct competition_reward_result;

// Exported member functions:
// 0x81B47A8	competition_reward_result::competition_reward_result(void)

// Function declaration index:
// DECL 0x81B47A8 competition_reward_result::competition_reward_result

#endif  // __IDA91_COMPETITION_REWARD_RESULT_H__
