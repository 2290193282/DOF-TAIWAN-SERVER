#ifndef __IDA91_ATTENDANCESCRIPT_H__
#define __IDA91_ATTENDANCESCRIPT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: AttendanceScript
// Source unit: AttendanceScript
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4827

/* 4827 */
struct AttendanceScript;

// Exported member functions:
// 0x898597A	AttendanceScript::AttendanceScript(void)

// Function declaration index:
// DECL 0x898597A AttendanceScript::AttendanceScript

#endif  // __IDA91_ATTENDANCESCRIPT_H__
