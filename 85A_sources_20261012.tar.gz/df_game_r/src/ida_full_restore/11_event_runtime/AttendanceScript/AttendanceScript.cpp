#include "AttendanceScript.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x898597A
// IDA_NAME: _ZN16AttendanceScriptC2Ev
// DEMANGLED: AttendanceScript::AttendanceScript(void)
void __cdecl AttendanceScript::AttendanceScript(std::string *this)
{
  InGameEventScript::InGameEventScript(this);
  std::string::string(this + 2);
  std::vector<std::pair<int,int>>::vector((int)&this[4]);
  std::pair<int,int>::pair(&this[7]._M_dataplus.__vftable);
  std::string::string(this + 10);
  Action_SendMail::Action_SendMail((Action_SendMail *)&this[11]);
  std::string::string(this + 28);
  std::string::string(this + 29);
  std::string::clear(this + 2);
  std::vector<std::pair<int,int>>::clear(&this[4]._M_dataplus.__vftable);
  Action_SendMail::reset(this + 11);
  this[3]._M_dataplus.__vftable = 0;
  this[9]._M_dataplus.__vftable = 0;
}
