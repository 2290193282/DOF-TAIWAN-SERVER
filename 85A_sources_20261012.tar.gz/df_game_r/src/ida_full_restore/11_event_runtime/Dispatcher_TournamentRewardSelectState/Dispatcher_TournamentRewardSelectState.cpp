#include "Dispatcher_TournamentRewardSelectState.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81DFC98
// IDA_NAME: _ZN38Dispatcher_TournamentRewardSelectState4readER9PacketBufR8MSG_BASE
// DEMANGLED: Dispatcher_TournamentRewardSelectState::read(PacketBuf &,MSG_BASE &)
int Dispatcher_TournamentRewardSelectState::read()
{
  return 0;
}

// IDA_EA: 0x81DFCA2
// IDA_NAME: _ZN38Dispatcher_TournamentRewardSelectState7processEP5CUserR8MSG_BASER9ParamBase
// DEMANGLED: Dispatcher_TournamentRewardSelectState::process(CUser *,MSG_BASE &,ParamBase &)
int __cdecl Dispatcher_TournamentRewardSelectState::process(
        Dispatcher_TournamentRewardSelectState *this,
        CUser *a2,
        MSG_BASE *a3,
        ParamBase *a4)
{
  char PartyIndex; // bl
  CGameManager *v6; // eax
  unsigned int acc_idEv; // eax

  *((_DWORD *)a4 + 1) = Dispatcher_TournamentRewardSelectState::check_error(this, a2, a3);
  if ( *((int *)a4 + 1) > 0 )
    return 0;
  if ( *((int *)a4 + 1) < 0 )
    return LineFunc(
             21167,
             "virtual int Dispatcher_TournamentRewardSelectState::process(CUser*, MSG_BASE&, ParamBase&)",
             *((_DWORD *)a4 + 1),
             0);
  PartyIndex = CUser::GetPartyIndex(a2);
  v6 = (CGameManager *)G_CGameManager();
  if ( CGameManager::GetParty(v6, PartyIndex) )
    return 0;
  acc_idEv = CUser::get_acc_id(a2);
  return LineFunc(
           21172,
           "virtual int Dispatcher_TournamentRewardSelectState::process(CUser*, MSG_BASE&, ParamBase&)",
           0,
           acc_idEv);
}

// IDA_EA: 0x81DFD74
// IDA_NAME: _ZN38Dispatcher_TournamentRewardSelectState4sendEP5CUserR9ParamBase
// DEMANGLED: Dispatcher_TournamentRewardSelectState::send(CUser *,ParamBase &)
void __cdecl Dispatcher_TournamentRewardSelectState::send(
        Dispatcher_TournamentRewardSelectState *this,
        CUser *a2,
        ParamBase *a3)
{
  char PartyIndex; // bl
  CGameManager *v4; // eax
  CUser *userEi; // eax
  __int16 CurCharacTotalFatigueEv; // bx
  CUser *userEi_1; // eax
  PacketBuf *v8[3]; // [esp+18h] [ebp-20h] BYREF
  ParamBase *v9; // [esp+24h] [ebp-14h]
  CParty *Party; // [esp+28h] [ebp-10h]
  int n3; // [esp+2Ch] [ebp-Ch]

  v9 = a3;
  PacketGuard::PacketGuard((PacketGuard *)v8);
  InterfacePacketBuf::clear(v8);
  InterfacePacketBuf::put_header(v8, 1, 458);
  if ( !*((_DWORD *)v9 + 1) )
  {
    InterfacePacketBuf::put_byte(v8, 1);
    PartyIndex = CUser::GetPartyIndex(a2);
    v4 = (CGameManager *)G_CGameManager();
    Party = (CParty *)CGameManager::GetParty(v4, PartyIndex);
    if ( Party )
    {
      for ( n3 = 0; n3 <= 3; ++n3 )
      {
        if ( CParty::get_user(Party, n3) )
        {
          userEi = (CUser *)CParty::get_user(Party, n3);
          CurCharacTotalFatigueEv = CUser::getCurCharacTotalFatigue(userEi);
          userEi_1 = (CUser *)CParty::get_user(Party, n3);
          if ( CurCharacTotalFatigueEv == (unsigned __int16)CUser::getCurCharacTotalMaxFatigue(userEi_1) )
            InterfacePacketBuf::put_byte(v8, 0);
          else
            InterfacePacketBuf::put_byte(v8, 1);
        }
        else
        {
          InterfacePacketBuf::put_byte(v8, -1);
        }
      }
      InterfacePacketBuf::finalize(v8, 1);
      CParty::send_to_party(Party, (PacketGuard *)v8);
      CParty::SetTournamentDungeonClearState(Party, 2);
      CParty::InsertTournamentDungeonTimer(Party, 47);
    }
  }
  PacketGuard::~PacketGuard(v8);
}

// IDA_EA: 0x81DFF32
// IDA_NAME: _ZN38Dispatcher_TournamentRewardSelectState11check_errorEP5CUserR8MSG_BASE
// DEMANGLED: Dispatcher_TournamentRewardSelectState::check_error(CUser *,MSG_BASE &)
int __cdecl Dispatcher_TournamentRewardSelectState::check_error(
        Dispatcher_TournamentRewardSelectState *this,
        CUser *a2)
{
  char PartyIndex; // bl
  CGameManager *v4; // eax
  CParty *Party; // [esp+1Ch] [ebp-Ch]

  if ( !a2 )
    return -1;
  if ( CUser::get_state(a2) != 5 )
    return 0x7FFFFFFF;
  PartyIndex = CUser::GetPartyIndex(a2);
  v4 = (CGameManager *)G_CGameManager();
  Party = (CParty *)CGameManager::GetParty(v4, PartyIndex);
  if ( !Party )
    return -1;
  if ( (unsigned __int8)CParty::GetTournamentDungeonClearState(Party) != 1 )
    return 0x7FFFFFFF;
  if ( (unsigned __int8)CParty::CheckRecvFromAllMember(Party, a2) == 1 )
    return 0;
  return 0x7FFFFFFF;
}

// IDA_EA: 0x82443A4
// IDA_NAME: _ZN38Dispatcher_TournamentRewardSelectStateD2Ev
// DEMANGLED: Dispatcher_TournamentRewardSelectState::~Dispatcher_TournamentRewardSelectState()
void __cdecl Dispatcher_TournamentRewardSelectState::~Dispatcher_TournamentRewardSelectState(
        Dispatcher_TournamentRewardSelectState *this)
{
  *(_DWORD *)this = &off_8BDA248;
  IPacketDispatcher<MSG_BASE,stTournamentRewardSelectState,(ch_state)0>::~IPacketDispatcher(this);
}

// IDA_EA: 0x82443D4
// IDA_NAME: _ZN38Dispatcher_TournamentRewardSelectStateD0Ev
// DEMANGLED: Dispatcher_TournamentRewardSelectState::~Dispatcher_TournamentRewardSelectState()
void __cdecl Dispatcher_TournamentRewardSelectState::~Dispatcher_TournamentRewardSelectState(
        Dispatcher_TournamentRewardSelectState *this)
{
  Dispatcher_TournamentRewardSelectState::~Dispatcher_TournamentRewardSelectState(this);
  operator delete(this);
}

// IDA_EA: 0x8597B0A
// IDA_NAME: _ZN38Dispatcher_TournamentRewardSelectStateC2Ev
// DEMANGLED: Dispatcher_TournamentRewardSelectState::Dispatcher_TournamentRewardSelectState(void)
void __cdecl Dispatcher_TournamentRewardSelectState::Dispatcher_TournamentRewardSelectState(
        Dispatcher_TournamentRewardSelectState *this)
{
  IPacketDispatcher<MSG_BASE,stTournamentRewardSelectState,(ch_state)0>::IPacketDispatcher(this);
  *(_DWORD *)this = &off_8BDA248;
}
