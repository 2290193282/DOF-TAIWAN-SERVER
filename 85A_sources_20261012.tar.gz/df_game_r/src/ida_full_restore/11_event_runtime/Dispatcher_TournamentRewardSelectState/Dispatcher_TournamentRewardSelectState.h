#ifndef __IDA91_DISPATCHER_TOURNAMENTREWARDSELECTSTATE_H__
#define __IDA91_DISPATCHER_TOURNAMENTREWARDSELECTSTATE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Dispatcher_TournamentRewardSelectState
// Source unit: Dispatcher_TournamentRewardSelectState
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 1529

/* 1529 */
struct Dispatcher_TournamentRewardSelectState;

// Exported member functions:
// 0x81DFC98	Dispatcher_TournamentRewardSelectState::read(PacketBuf &,MSG_BASE &)
// 0x81DFCA2	Dispatcher_TournamentRewardSelectState::process(CUser *,MSG_BASE &,ParamBase &)
// 0x81DFD74	Dispatcher_TournamentRewardSelectState::send(CUser *,ParamBase &)
// 0x81DFF32	Dispatcher_TournamentRewardSelectState::check_error(CUser *,MSG_BASE &)
// 0x82443A4	Dispatcher_TournamentRewardSelectState::~Dispatcher_TournamentRewardSelectState()
// 0x82443D4	Dispatcher_TournamentRewardSelectState::~Dispatcher_TournamentRewardSelectState()
// 0x8597B0A	Dispatcher_TournamentRewardSelectState::Dispatcher_TournamentRewardSelectState(void)

// Function declaration index:
// DECL 0x81DFC98 Dispatcher_TournamentRewardSelectState::read
// DECL 0x81DFCA2 Dispatcher_TournamentRewardSelectState::process
// DECL 0x81DFD74 Dispatcher_TournamentRewardSelectState::send
// DECL 0x81DFF32 Dispatcher_TournamentRewardSelectState::check_error
// DECL 0x82443A4 Dispatcher_TournamentRewardSelectState::~Dispatcher_TournamentRewardSelectState
// DECL 0x82443D4 Dispatcher_TournamentRewardSelectState::~Dispatcher_TournamentRewardSelectState
// DECL 0x8597B0A Dispatcher_TournamentRewardSelectState::Dispatcher_TournamentRewardSelectState

#endif  // __IDA91_DISPATCHER_TOURNAMENTREWARDSELECTSTATE_H__
