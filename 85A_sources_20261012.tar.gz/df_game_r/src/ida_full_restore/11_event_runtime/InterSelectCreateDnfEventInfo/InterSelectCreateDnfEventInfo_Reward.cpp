#include "InterSelectCreateDnfEventInfo_Reward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8160C4A
// IDA_NAME: _ZN29InterSelectCreateDnfEventInfo6RewardC2Eib
// DEMANGLED: InterSelectCreateDnfEventInfo::Reward::Reward(int,bool)
InterSelectCreateDnfEventInfo::Reward *__cdecl InterSelectCreateDnfEventInfo::Reward::Reward(
        InterSelectCreateDnfEventInfo::Reward *this,
        __int16 a2,
        bool a3)
{
  InterSelectCreateDnfEventInfo::Reward *this_1; // eax

  *(_WORD *)this = a2;
  this_1 = this;
  *((_BYTE *)this + 2) = a3;
  return this_1;
}

// IDA_EA: 0x8160C6E
// IDA_NAME: _ZN29InterSelectCreateDnfEventInfo6RewardclEP5CUser
// DEMANGLED: InterSelectCreateDnfEventInfo::Reward::operator()(CUser *)
void __cdecl InterSelectCreateDnfEventInfo::Reward::operator()(int a1, CUser *a2)
{
  PacketBuf *v3[5]; // [esp+14h] [ebp-14h] BYREF

  PacketGuard::PacketGuard((PacketGuard *)v3);
  InterfacePacketBuf::put_header(v3, 0, 557);
  InterfacePacketBuf::put_short(v3, *(_WORD *)a1);
  if ( (unsigned __int8)CUser::GetEventCreateDnfReward(a2) != 1 && *(_BYTE *)(a1 + 2) )
    InterfacePacketBuf::put_byte(v3, 1);
  else
    InterfacePacketBuf::put_byte(v3, 0);
  InterfacePacketBuf::finalize(v3, 1);
  CUser::Send(a2, (PacketGuard *)v3);
  PacketGuard::~PacketGuard(v3);
}
