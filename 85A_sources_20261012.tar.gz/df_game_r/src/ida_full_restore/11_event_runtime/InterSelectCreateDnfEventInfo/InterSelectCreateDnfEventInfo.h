#ifndef __IDA91_INTERSELECTCREATEDNFEVENTINFO_H__
#define __IDA91_INTERSELECTCREATEDNFEVENTINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: InterSelectCreateDnfEventInfo
// Source unit: InterSelectCreateDnfEventInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 1337

/* 1337 */
struct InterSelectCreateDnfEventInfo;

// Exported member functions:
// 0x8160D5E	InterSelectCreateDnfEventInfo::dispatch_sig(CUser *,char *,int)
// 0x8160EF6	InterSelectCreateDnfEventInfo::makeRequest(int,int,int)
// 0x816201A	InterSelectCreateDnfEventInfo::InterSelectCreateDnfEventInfo(void)
// 0x816203E	InterSelectCreateDnfEventInfo::~InterSelectCreateDnfEventInfo()
// 0x816206E	InterSelectCreateDnfEventInfo::~InterSelectCreateDnfEventInfo()

// Function declaration index:
// DECL 0x8160D5E InterSelectCreateDnfEventInfo::dispatch_sig
// DECL 0x8160EF6 InterSelectCreateDnfEventInfo::makeRequest
// DECL 0x816201A InterSelectCreateDnfEventInfo::InterSelectCreateDnfEventInfo
// DECL 0x816203E InterSelectCreateDnfEventInfo::~InterSelectCreateDnfEventInfo
// DECL 0x816206E InterSelectCreateDnfEventInfo::~InterSelectCreateDnfEventInfo

#endif  // __IDA91_INTERSELECTCREATEDNFEVENTINFO_H__
