#include "InterSelectCreateDnfEventInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8160D5E
// IDA_NAME: _ZN29InterSelectCreateDnfEventInfo12dispatch_sigEP5CUserPci
// DEMANGLED: InterSelectCreateDnfEventInfo::dispatch_sig(CUser *,char *,int)
int __cdecl InterSelectCreateDnfEventInfo::dispatch_sig(InterSelectCreateDnfEventInfo *this, CUser *a2, char *a3)
{
  int v5; // edx
  char IsRewardCondition; // bl
  __int16 Rate; // ax
  int v8; // eax
  const char *v9; // [esp+14h] [ebp-24h]
  int v10; // [esp+24h] [ebp-14h] BYREF
  char *v11; // [esp+28h] [ebp-10h]
  CEventCreateDnf *RepeatEvent; // [esp+2Ch] [ebp-Ch]

  v11 = a3;
  if ( a3 )
  {
    RepeatEvent = (CEventCreateDnf *)CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 160);
    if ( !RepeatEvent
      || (*(unsigned __int8 (__cdecl **)(CEventCreateDnf *, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) != 1 )
    {
      v5 = (*(unsigned __int8 (__cdecl **)(CEventCreateDnf *, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0);
      if ( RepeatEvent )
        LogManager::logFormat(
          (LogManager *)1,
          (int)"localtaiwan/Dispatcher/Taiwan_InterDispatcher.cpp",
          "virtual int InterSelectCreateDnfEventInfo::dispatch_sig(CUser*, char*, int)",
          (const char *)0x107,
          "[Taiwan, Event] stayEvent=%s eventing:%d",
          "ok",
          v5);
      else
        LogManager::logFormat(
          (LogManager *)1,
          (int)"localtaiwan/Dispatcher/Taiwan_InterDispatcher.cpp",
          "virtual int InterSelectCreateDnfEventInfo::dispatch_sig(CUser*, char*, int)",
          (const char *)0x107,
          "[Taiwan, Event] stayEvent=%s eventing:%d",
          "nullptr",
          v5);
      return 264;
    }
    else
    {
      if ( *(int *)v11 < 0 )
        *(_DWORD *)v11 = (unsigned __int16)CEventCreateDnf::GetRate(RepeatEvent);
      CEventCreateDnf::SetEventInfo(RepeatEvent, *((_DWORD *)v11 + 1), *(_DWORD *)v11, *((_DWORD *)v11 + 2));
      IsRewardCondition = CEventCreateDnf::IsRewardCondition(RepeatEvent);
      Rate = CEventCreateDnf::GetRate(RepeatEvent);
      InterSelectCreateDnfEventInfo::Reward::Reward(
        (InterSelectCreateDnfEventInfo::Reward *)&v10,
        Rate,
        IsRewardCondition);
      v8 = G_GameWorld();
      GameWorld::ProcessAllUsers<InterSelectCreateDnfEventInfo::Reward>(v8, v10);
      return 0;
    }
  }
  else
  {
    LogManager::logFormat(
      (LogManager *)1,
      (int)"localtaiwan/Dispatcher/Taiwan_InterDispatcher.cpp",
      "virtual int InterSelectCreateDnfEventInfo::dispatch_sig(CUser*, char*, int)",
      (const char *)0xFD,
      "[Taiwan, Event] interMsg is null.",
      v9);
    return 254;
  }
}

// IDA_EA: 0x8160EF6
// IDA_NAME: _ZN29InterSelectCreateDnfEventInfo11makeRequestEiii
// DEMANGLED: InterSelectCreateDnfEventInfo::makeRequest(int,int,int)
void __cdecl InterSelectCreateDnfEventInfo::makeRequest(InterSelectCreateDnfEventInfo *this, char *a2, int a3)
{
  Stream *v3; // eax
  int v4; // eax
  int v5[2]; // [esp+24h] [ebp-14h] BYREF
  _DWORD *v6; // [esp+2Ch] [ebp-Ch]

  v3 = (Stream *)StreamPool::Acquire(
                   GlobalData::s_stream_pool,
                   "localtaiwan/Dispatcher/Taiwan_InterDispatcher.cpp",
                   283);
  CStreamGuard::CStreamGuard((CStreamGuard *)v5, v3, 1);
  Taiwan::internal_stream((int)v5, 9, -1);
  v4 = CStreamGuard::operator->((int)v5);
  v6 = (_DWORD *)CStreamGuard::GetInBuffer<InterSelectCreateDnfEventInfo::Msg>(v4);
  if ( v6 )
  {
    *v6 = this;
    v6[1] = a2;
    v6[2] = a3;
    MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 1, (CStreamGuard *)v5);
  }
  else
  {
    LogManager::logFormat(
      (LogManager *)1,
      (int)"localtaiwan/Dispatcher/Taiwan_InterDispatcher.cpp",
      "static void InterSelectCreateDnfEventInfo::makeRequest(int, int, int)",
      (const char *)0x120,
      "[Taiwan, Event] hour:%d rate:%d event_day:%d",
      a2,
      this,
      a3);
  }
  CStreamGuard::~CStreamGuard((CStreamGuard *)v5);
}

// IDA_EA: 0x816201A
// IDA_NAME: _ZN29InterSelectCreateDnfEventInfoC2Ev
// DEMANGLED: InterSelectCreateDnfEventInfo::InterSelectCreateDnfEventInfo(void)
void __cdecl InterSelectCreateDnfEventInfo::InterSelectCreateDnfEventInfo(InterSelectCreateDnfEventInfo *this)
{
  TaiwanInterfaceInterDispatcher::TaiwanInterfaceInterDispatcher(this, 9);
  *(_DWORD *)this = off_8B7ACA8;
}

// IDA_EA: 0x816203E
// IDA_NAME: _ZN29InterSelectCreateDnfEventInfoD2Ev
// DEMANGLED: InterSelectCreateDnfEventInfo::~InterSelectCreateDnfEventInfo()
void __cdecl InterSelectCreateDnfEventInfo::~InterSelectCreateDnfEventInfo(InterSelectCreateDnfEventInfo *this)
{
  *(_DWORD *)this = off_8B7ACA8;
  TaiwanInterfaceInterDispatcher::~TaiwanInterfaceInterDispatcher(this);
}

// IDA_EA: 0x816206E
// IDA_NAME: _ZN29InterSelectCreateDnfEventInfoD0Ev
// DEMANGLED: InterSelectCreateDnfEventInfo::~InterSelectCreateDnfEventInfo()
void __cdecl InterSelectCreateDnfEventInfo::~InterSelectCreateDnfEventInfo(InterSelectCreateDnfEventInfo *this)
{
  InterSelectCreateDnfEventInfo::~InterSelectCreateDnfEventInfo(this);
  operator delete(this);
}
