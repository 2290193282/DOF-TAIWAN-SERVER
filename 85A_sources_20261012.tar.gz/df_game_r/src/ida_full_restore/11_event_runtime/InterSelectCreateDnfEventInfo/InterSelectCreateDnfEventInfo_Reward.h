#ifndef __IDA91_INTERSELECTCREATEDNFEVENTINFO_REWARD_H__
#define __IDA91_INTERSELECTCREATEDNFEVENTINFO_REWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: InterSelectCreateDnfEventInfo
// Source unit: InterSelectCreateDnfEventInfo_Reward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 1331

/* 1331 */
struct InterSelectCreateDnfEventInfo::Reward;

// Exported member functions:
// 0x8160C4A	InterSelectCreateDnfEventInfo::Reward::Reward(int,bool)
// 0x8160C6E	InterSelectCreateDnfEventInfo::Reward::operator()(CUser *)

// Function declaration index:
// DECL 0x8160C4A InterSelectCreateDnfEventInfo::Reward::Reward
// DECL 0x8160C6E InterSelectCreateDnfEventInfo::Reward::operator

#endif  // __IDA91_INTERSELECTCREATEDNFEVENTINFO_REWARD_H__
