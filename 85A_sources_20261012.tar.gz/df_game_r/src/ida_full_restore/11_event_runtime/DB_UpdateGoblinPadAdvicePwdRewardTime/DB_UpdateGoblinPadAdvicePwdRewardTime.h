#ifndef __IDA91_DB_UPDATEGOBLINPADADVICEPWDREWARDTIME_H__
#define __IDA91_DB_UPDATEGOBLINPADADVICEPWDREWARDTIME_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_UpdateGoblinPadAdvicePwdRewardTime
// Source unit: DB_UpdateGoblinPadAdvicePwdRewardTime
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2657

/* 2657 */
struct DB_UpdateGoblinPadAdvicePwdRewardTime;

// Exported member functions:
// 0x843F5D2	DB_UpdateGoblinPadAdvicePwdRewardTime::dispatch(int,int,Stream *)
// 0x843F684	DB_UpdateGoblinPadAdvicePwdRewardTime::makeRequest(int,unsigned int)
// 0x844F6A6	DB_UpdateGoblinPadAdvicePwdRewardTime::DB_UpdateGoblinPadAdvicePwdRewardTime(void)
// 0x845BE96	DB_UpdateGoblinPadAdvicePwdRewardTime::~DB_UpdateGoblinPadAdvicePwdRewardTime()
// 0x845BEC6	DB_UpdateGoblinPadAdvicePwdRewardTime::~DB_UpdateGoblinPadAdvicePwdRewardTime()

// Function declaration index:
// DECL 0x843F5D2 DB_UpdateGoblinPadAdvicePwdRewardTime::dispatch
// DECL 0x843F684 DB_UpdateGoblinPadAdvicePwdRewardTime::makeRequest
// DECL 0x844F6A6 DB_UpdateGoblinPadAdvicePwdRewardTime::DB_UpdateGoblinPadAdvicePwdRewardTime
// DECL 0x845BE96 DB_UpdateGoblinPadAdvicePwdRewardTime::~DB_UpdateGoblinPadAdvicePwdRewardTime
// DECL 0x845BEC6 DB_UpdateGoblinPadAdvicePwdRewardTime::~DB_UpdateGoblinPadAdvicePwdRewardTime

#endif  // __IDA91_DB_UPDATEGOBLINPADADVICEPWDREWARDTIME_H__
