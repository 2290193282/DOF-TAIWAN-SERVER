#include "DB_UpdateGoblinPadAdvicePwdRewardTime.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x843F5D2
// IDA_NAME: _ZN37DB_UpdateGoblinPadAdvicePwdRewardTime8dispatchEiiP6Stream
// DEMANGLED: DB_UpdateGoblinPadAdvicePwdRewardTime::dispatch(int,int,Stream *)
_BOOL4 __cdecl DB_UpdateGoblinPadAdvicePwdRewardTime::dispatch(
        DB_UpdateGoblinPadAdvicePwdRewardTime *this,
        int a2,
        int a3,
        Stream *a4)
{
  const char *v4; // eax
  __int64 v5; // rax
  bool v6; // al
  unsigned int v8; // [esp+18h] [ebp-10h] BYREF
  MySQL *DBHandle; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 6, 0);
  v8 = 0;
  Stream::operator>>(a4, (int)&v8);
  v4 = (const char *)NumberToString(v8, 0);
  MySQL::set_query(DBHandle, "upDate member_mousepass set reward_time=0 where m_id=%s and enable_flag = '1'", v4);
  v6 = 1;
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) == 1 )
  {
    LODWORD(v5) = MySQL::getAffectedRowCount(DBHandle);
    if ( v5 )
      v6 = 0;
  }
  return !v6;
}

// IDA_EA: 0x843F684
// IDA_NAME: _ZN37DB_UpdateGoblinPadAdvicePwdRewardTime11makeRequestEij
// DEMANGLED: DB_UpdateGoblinPadAdvicePwdRewardTime::makeRequest(int,unsigned int)
void __cdecl DB_UpdateGoblinPadAdvicePwdRewardTime::makeRequest(DB_UpdateGoblinPadAdvicePwdRewardTime *this, char src)
{
  Stream *v2; // eax
  Stream **v3; // eax
  Stream **v4; // eax
  Stream **v5; // eax
  _BYTE v6[16]; // [esp+18h] [ebp-10h] BYREF

  v2 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 39207);
  CStreamGuard::CStreamGuard((CStreamGuard *)v6, v2, 1);
  v3 = (Stream **)CStreamGuard::operator*((int)v6);
  CStreamGuard::operator<<(v3, 71);
  v4 = (Stream **)CStreamGuard::operator*((int)v6);
  CStreamGuard::operator<<(v4, (char)this);
  v5 = (Stream **)CStreamGuard::operator*((int)v6);
  CStreamGuard::operator<<(v5, src);
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v6);
  CStreamGuard::~CStreamGuard((CStreamGuard *)v6);
}

// IDA_EA: 0x844F6A6
// IDA_NAME: _ZN37DB_UpdateGoblinPadAdvicePwdRewardTimeC2Ev
// DEMANGLED: DB_UpdateGoblinPadAdvicePwdRewardTime::DB_UpdateGoblinPadAdvicePwdRewardTime(void)
void __cdecl DB_UpdateGoblinPadAdvicePwdRewardTime::DB_UpdateGoblinPadAdvicePwdRewardTime(
        DB_UpdateGoblinPadAdvicePwdRewardTime *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5E610;
}

// IDA_EA: 0x845BE96
// IDA_NAME: _ZN37DB_UpdateGoblinPadAdvicePwdRewardTimeD2Ev
// DEMANGLED: DB_UpdateGoblinPadAdvicePwdRewardTime::~DB_UpdateGoblinPadAdvicePwdRewardTime()
void __cdecl DB_UpdateGoblinPadAdvicePwdRewardTime::~DB_UpdateGoblinPadAdvicePwdRewardTime(
        DB_UpdateGoblinPadAdvicePwdRewardTime *this)
{
  *(_DWORD *)this = &off_8C5E610;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845BEC6
// IDA_NAME: _ZN37DB_UpdateGoblinPadAdvicePwdRewardTimeD0Ev
// DEMANGLED: DB_UpdateGoblinPadAdvicePwdRewardTime::~DB_UpdateGoblinPadAdvicePwdRewardTime()
void __cdecl DB_UpdateGoblinPadAdvicePwdRewardTime::~DB_UpdateGoblinPadAdvicePwdRewardTime(
        DB_UpdateGoblinPadAdvicePwdRewardTime *this)
{
  DB_UpdateGoblinPadAdvicePwdRewardTime::~DB_UpdateGoblinPadAdvicePwdRewardTime(this);
  operator delete(this);
}
