#ifndef __IDA91_INTER_TRIGGEREVENTSTART_H__
#define __IDA91_INTER_TRIGGEREVENTSTART_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_TriggerEventStart
// Source unit: Inter_TriggerEventStart
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 2990

/* 2990 */
struct Inter_TriggerEventStart;

// Exported member functions:
// 0x84CE5F4	Inter_TriggerEventStart::dispatch_sig(CUser *,char *,int)
// 0x84EB1EE	Inter_TriggerEventStart::Inter_TriggerEventStart(void)
// 0x84EB20A	Inter_TriggerEventStart::~Inter_TriggerEventStart()
// 0x84EB23A	Inter_TriggerEventStart::~Inter_TriggerEventStart()

// Function declaration index:
// DECL 0x84CE5F4 Inter_TriggerEventStart::dispatch_sig
// DECL 0x84EB1EE Inter_TriggerEventStart::Inter_TriggerEventStart
// DECL 0x84EB20A Inter_TriggerEventStart::~Inter_TriggerEventStart
// DECL 0x84EB23A Inter_TriggerEventStart::~Inter_TriggerEventStart

#endif  // __IDA91_INTER_TRIGGEREVENTSTART_H__
