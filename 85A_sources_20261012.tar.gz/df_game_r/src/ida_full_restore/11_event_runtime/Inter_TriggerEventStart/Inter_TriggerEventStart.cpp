#include "Inter_TriggerEventStart.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84CE5F4
// IDA_NAME: _ZN23Inter_TriggerEventStart12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_TriggerEventStart::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_TriggerEventStart::dispatch_sig(Inter_TriggerEventStart *this, CUser *a2, char *a3)
{
  if ( !GlobalData::s_event_manager )
    return 0;
  if ( (unsigned __int8)CEventManager::TriggerEventStart(
                          GlobalData::s_event_manager,
                          *(_DWORD *)(a3 + 10),
                          *(_DWORD *)(a3 + 14)) )
    return 0;
  return 10891;
}

// IDA_EA: 0x84EB1EE
// IDA_NAME: _ZN23Inter_TriggerEventStartC2Ev
// DEMANGLED: Inter_TriggerEventStart::Inter_TriggerEventStart(void)
void __cdecl Inter_TriggerEventStart::Inter_TriggerEventStart(Inter_TriggerEventStart *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8FA50;
}

// IDA_EA: 0x84EB20A
// IDA_NAME: _ZN23Inter_TriggerEventStartD2Ev
// DEMANGLED: Inter_TriggerEventStart::~Inter_TriggerEventStart()
void __cdecl Inter_TriggerEventStart::~Inter_TriggerEventStart(Inter_TriggerEventStart *this)
{
  *(_DWORD *)this = &off_8C8FA50;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84EB23A
// IDA_NAME: _ZN23Inter_TriggerEventStartD0Ev
// DEMANGLED: Inter_TriggerEventStart::~Inter_TriggerEventStart()
void __cdecl Inter_TriggerEventStart::~Inter_TriggerEventStart(Inter_TriggerEventStart *this)
{
  Inter_TriggerEventStart::~Inter_TriggerEventStart(this);
  operator delete(this);
}
