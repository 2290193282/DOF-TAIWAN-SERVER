#include "advancealtar_ClearRewardData.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x836A072
// IDA_NAME: _ZN12advancealtar15ClearRewardDataC2Ev
// DEMANGLED: advancealtar::ClearRewardData::ClearRewardData(void)
bool __cdecl advancealtar::ClearRewardData::ClearRewardData(advancealtar::ClearRewardData *this)
{
  int n2; // esi
  bool result; // al

  for ( n2 = 2; ; --n2 )
  {
    result = n2 != -1;
    if ( n2 == -1 )
      break;
    std::vector<advancealtar::_RewardItem>::vector((int)this);
    this = (advancealtar::ClearRewardData *)((char *)this + 12);
  }
  return result;
}

// IDA_EA: 0x836A0E6
// IDA_NAME: _ZN12advancealtar15ClearRewardDataD2Ev
// DEMANGLED: advancealtar::ClearRewardData::~ClearRewardData()
void __cdecl advancealtar::ClearRewardData::~ClearRewardData(advancealtar::ClearRewardData *this)
{
  advancealtar::ClearRewardData *this_1; // ebx

  if ( this )
  {
    for ( this_1 = (advancealtar::ClearRewardData *)((char *)this + 36);
          this_1 != this;
          std::vector<advancealtar::_RewardItem>::~vector(this_1) )
    {
      this_1 = (advancealtar::ClearRewardData *)((char *)this_1 - 12);
    }
  }
}

// IDA_EA: 0x836A114
// IDA_NAME: _ZN12advancealtar15ClearRewardData5clearEv
// DEMANGLED: advancealtar::ClearRewardData::clear(void)
bool __cdecl advancealtar::ClearRewardData::clear(advancealtar::ClearRewardData *this)
{
  bool result; // al
  int n2; // [esp+1Ch] [ebp-Ch]

  for ( n2 = 0; ; ++n2 )
  {
    result = n2 <= 2;
    if ( n2 > 2 )
      break;
    std::vector<advancealtar::_RewardItem>::clear((_DWORD *)this + 3 * n2);
  }
  return result;
}

// IDA_EA: 0x8376C9C
// IDA_NAME: _ZN12advancealtar15ClearRewardDataaSERKS0_
// DEMANGLED: advancealtar::ClearRewardData::operator=(advancealtar::ClearRewardData const&)
int __cdecl advancealtar::ClearRewardData::operator=(int a1, int a2)
{
  int v2; // esi
  int n2; // edi

  v2 = a1;
  for ( n2 = 2; n2 != -1; --n2 )
  {
    std::vector<advancealtar::_RewardItem>::operator=(v2, a2);
    v2 += 12;
    a2 += 12;
  }
  return a1;
}
