#include "advancealtar_Dispatcher_GetAchievementReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8140C64
// IDA_NAME: _ZN12advancealtar31Dispatcher_GetAchievementReward12dispatch_sigEP5CUserR9PacketBuf
// DEMANGLED: advancealtar::Dispatcher_GetAchievementReward::dispatch_sig(CUser *,PacketBuf &)
int __cdecl advancealtar::Dispatcher_GetAchievementReward::dispatch_sig(
        advancealtar::Dispatcher_GetAchievementReward *this,
        CUser *a2,
        PacketBuf *a3)
{
  int v4; // ebx
  _BYTE v6[8]; // [esp+1Ch] [ebp-2Ch] BYREF
  int v7; // [esp+24h] [ebp-24h]
  _BYTE v8[16]; // [esp+28h] [ebp-20h] BYREF
  int v9; // [esp+38h] [ebp-10h]
  int v10; // [esp+3Ch] [ebp-Ch]

  if ( !a2 || CUser::get_state(a2) <= 2 || !CUserCharacInfo::getCurCharacR(a2) )
    return 1393;
  CMDPacketStruct::_ReqAdvanceAltarGetAchievementReward::_ReqAdvanceAltarGetAchievementReward((CMDPacketStruct::_ReqAdvanceAltarGetAchievementReward *)v8);
  CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::_ResAdvanceAltarGetAchievementReward((CMDPacketStruct::_ResAdvanceAltarGetAchievementReward *)v6);
  advancealtar::Dispatcher_GetAchievementReward::read_packet(this, a3, (CMDPacketStruct::STBaseRequest *)v8);
  v7 = v9;
  v10 = advancealtar::Dispatcher_GetAchievementReward::process_packet(
          this,
          a2,
          (CMDPacketStruct::STBaseRequest *)v8,
          (CMDPacketStruct::STBaseResponse *)v6);
  advancealtar::Dispatcher_GetAchievementReward::send_packet(this, a2, (CMDPacketStruct::STBaseResponse *)v6);
  v4 = 0;
  CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::~_ResAdvanceAltarGetAchievementReward((CMDPacketStruct::_ResAdvanceAltarGetAchievementReward *)v6);
  return v4;
}

// IDA_EA: 0x8140D52
// IDA_NAME: _ZNK12advancealtar31Dispatcher_GetAchievementReward11read_packetER9PacketBufRN15CMDPacketStruct13STBaseRequestE
// DEMANGLED: advancealtar::Dispatcher_GetAchievementReward::read_packet(PacketBuf &,CMDPacketStruct::STBaseRequest &)const
int __cdecl advancealtar::Dispatcher_GetAchievementReward::read_packet(
        advancealtar::Dispatcher_GetAchievementReward *this,
        PacketBuf *a2,
        CMDPacketStruct::STBaseRequest *a3)
{
  PacketBuf::get_binary(a2, (char *)a3, 20);
  return 0;
}

// IDA_EA: 0x8140D80
// IDA_NAME: _ZNK12advancealtar31Dispatcher_GetAchievementReward11check_errorEP5CUserRN15CMDPacketStruct13STBaseRequestE
// DEMANGLED: advancealtar::Dispatcher_GetAchievementReward::check_error(CUser *,CMDPacketStruct::STBaseRequest &)const
_BOOL4 advancealtar::Dispatcher_GetAchievementReward::check_error()
{
  return !advancealtar::isOpenAdvanceAltar();
}

// IDA_EA: 0x8140DA0
// IDA_NAME: _ZNK12advancealtar31Dispatcher_GetAchievementReward14process_packetEP5CUserRN15CMDPacketStruct13STBaseRequestERNS3_14STBaseResponseE
// DEMANGLED: advancealtar::Dispatcher_GetAchievementReward::process_packet(CUser *,CMDPacketStruct::STBaseRequest &,CMDPacketStruct::STBaseResponse &)const
int advancealtar::Dispatcher_GetAchievementReward::process_packet()
{
  return 0;
}

// IDA_EA: 0x8140DAA
// IDA_NAME: _ZN12advancealtar31Dispatcher_GetAchievementReward11send_packetEP5CUserRN15CMDPacketStruct14STBaseResponseE
// DEMANGLED: advancealtar::Dispatcher_GetAchievementReward::send_packet(CUser *,CMDPacketStruct::STBaseResponse &)
void __cdecl advancealtar::Dispatcher_GetAchievementReward::send_packet(
        advancealtar::Dispatcher_GetAchievementReward *this,
        CUser *UserEv,
        CMDPacketStruct::STBaseResponse *a3)
{
  int v3; // eax
  char *v4; // eax
  int v5; // [esp+1Ch] [ebp-2Ch] BYREF
  int v6; // [esp+20h] [ebp-28h] BYREF
  PacketBuf *v7[3]; // [esp+24h] [ebp-24h] BYREF
  _BYTE v8[4]; // [esp+30h] [ebp-18h] BYREF
  _BYTE v9[4]; // [esp+34h] [ebp-14h] BYREF
  char *v10; // [esp+38h] [ebp-10h]
  int v11; // [esp+3Ch] [ebp-Ch]

  v10 = (char *)a3;
  PacketGuard::PacketGuard((PacketGuard *)v7);
  InterfacePacketBuf::put_header(v7, 1, 579);
  InterfacePacketBuf::put_byte(v7, 1);
  v11 = 0;
  v6 = 0;
  v3 = advancealtar::CharacAdvanceAltarManager::sendAchievementReward(
         (int)UserEv + 581472,
         UserEv,
         *((_DWORD *)v10 + 2),
         &v6);
  *((_DWORD *)v10 + 1) = v3;
  InterfacePacketBuf::put_binary(v7, v10, 12);
  if ( *((_DWORD *)v10 + 1) || !v6 )
  {
    InterfacePacketBuf::put_int(v7, v11);
  }
  else
  {
    v11 = std::vector<advancealtar::_RewardItem>::size((_DWORD *)v6);
    InterfacePacketBuf::put_int(v7, v11);
    std::vector<advancealtar::_RewardItem>::begin((int)&v5, (_DWORD *)v6);
    while ( 1 )
    {
      std::vector<advancealtar::_RewardItem>::end((int)v8, v6);
      if ( !__gnu_cxx::operator!=<advancealtar::_RewardItem const*,std::vector<advancealtar::_RewardItem>>(
              (int)&v5,
              (int)v8) )
        break;
      v4 = (char *)__gnu_cxx::__normal_iterator<advancealtar::_RewardItem const*,std::vector<advancealtar::_RewardItem>>::operator*((int)&v5);
      InterfacePacketBuf::put_binary(v7, v4, 12);
      __gnu_cxx::__normal_iterator<advancealtar::_RewardItem const*,std::vector<advancealtar::_RewardItem>>::operator++(
        (int)v9,
        &v5);
    }
  }
  InterfacePacketBuf::finalize(v7, 1);
  CUser::Send(UserEv, (PacketGuard *)v7);
  PacketGuard::~PacketGuard(v7);
}

// IDA_EA: 0x8142424
// IDA_NAME: _ZN12advancealtar31Dispatcher_GetAchievementRewardD2Ev
// DEMANGLED: advancealtar::Dispatcher_GetAchievementReward::~Dispatcher_GetAchievementReward()
void __cdecl advancealtar::Dispatcher_GetAchievementReward::~Dispatcher_GetAchievementReward(
        advancealtar::Dispatcher_GetAchievementReward *this)
{
  *(_DWORD *)this = &off_8B6ECE8;
  IPacketDispatcher<MSG_BASE,ParamBase,(ch_state)0>::~IPacketDispatcher(this);
}

// IDA_EA: 0x8142454
// IDA_NAME: _ZN12advancealtar31Dispatcher_GetAchievementRewardD0Ev
// DEMANGLED: advancealtar::Dispatcher_GetAchievementReward::~Dispatcher_GetAchievementReward()
void __cdecl advancealtar::Dispatcher_GetAchievementReward::~Dispatcher_GetAchievementReward(
        advancealtar::Dispatcher_GetAchievementReward *this)
{
  advancealtar::Dispatcher_GetAchievementReward::~Dispatcher_GetAchievementReward(this);
  operator delete(this);
}

// IDA_EA: 0x8142472
// IDA_NAME: _ZN12advancealtar31Dispatcher_GetAchievementReward4readER9PacketBufR8MSG_BASE
// DEMANGLED: advancealtar::Dispatcher_GetAchievementReward::read(PacketBuf &,MSG_BASE &)
int advancealtar::Dispatcher_GetAchievementReward::read()
{
  return 0;
}

// IDA_EA: 0x814247C
// IDA_NAME: _ZN12advancealtar31Dispatcher_GetAchievementReward7processEP5CUserR8MSG_BASER9ParamBase
// DEMANGLED: advancealtar::Dispatcher_GetAchievementReward::process(CUser *,MSG_BASE &,ParamBase &)
int advancealtar::Dispatcher_GetAchievementReward::process()
{
  return 0;
}

// IDA_EA: 0x8595794
// IDA_NAME: _ZN12advancealtar31Dispatcher_GetAchievementRewardC2Ev
// DEMANGLED: advancealtar::Dispatcher_GetAchievementReward::Dispatcher_GetAchievementReward(void)
advancealtar::Dispatcher_GetAchievementReward *__cdecl advancealtar::Dispatcher_GetAchievementReward::Dispatcher_GetAchievementReward(
        advancealtar::Dispatcher_GetAchievementReward *this)
{
  advancealtar::Dispatcher_GetAchievementReward *this_1; // eax

  IPacketDispatcher<MSG_BASE,ParamBase,(ch_state)0>::IPacketDispatcher(this);
  this_1 = this;
  *(_DWORD *)this = &off_8B6ECE8;
  return this_1;
}
