#ifndef __IDA91_ADVANCEALTAR_REWARDPARAMETER_H__
#define __IDA91_ADVANCEALTAR_REWARDPARAMETER_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: advancealtar
// Source unit: advancealtar_RewardParameter
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4544

/* 4544 */
struct advancealtar::RewardParameter;

// Exported member functions:
// 0x889AF74	advancealtar::RewardParameter::RewardParameter(void)
// 0x889AF88	advancealtar::RewardParameter::~RewardParameter()
// 0x889AF9C	advancealtar::RewardParameter::reset(void)
// 0x889AFB0	advancealtar::RewardParameter::importAchievementRewardParameter(char const*)
// 0x889B544	advancealtar::RewardParameter::getAchievementRewardData(int)const
// 0x889B5A8	advancealtar::RewardParameter::getAchievementRewardData(advancealtar::StageDifficulty::T,int)const

// Function declaration index:
// DECL 0x889AF74 advancealtar::RewardParameter::RewardParameter
// DECL 0x889AF88 advancealtar::RewardParameter::~RewardParameter
// DECL 0x889AF9C advancealtar::RewardParameter::reset
// DECL 0x889AFB0 advancealtar::RewardParameter::importAchievementRewardParameter
// DECL 0x889B544 advancealtar::RewardParameter::getAchievementRewardData
// DECL 0x889B5A8 advancealtar::RewardParameter::getAchievementRewardData

#endif  // __IDA91_ADVANCEALTAR_REWARDPARAMETER_H__
