#ifndef __IDA91_ADVANCEALTAR_CLEARREWARDDATA_H__
#define __IDA91_ADVANCEALTAR_CLEARREWARDDATA_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: advancealtar
// Source unit: advancealtar_ClearRewardData
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4424

/* 4424 */
struct advancealtar::ClearRewardData;

// Exported member functions:
// 0x836A072	advancealtar::ClearRewardData::ClearRewardData(void)
// 0x836A0E6	advancealtar::ClearRewardData::~ClearRewardData()
// 0x836A114	advancealtar::ClearRewardData::clear(void)
// 0x8376C9C	advancealtar::ClearRewardData::operator=(advancealtar::ClearRewardData const&)

// Function declaration index:
// DECL 0x836A072 advancealtar::ClearRewardData::ClearRewardData
// DECL 0x836A0E6 advancealtar::ClearRewardData::~ClearRewardData
// DECL 0x836A114 advancealtar::ClearRewardData::clear
// DECL 0x8376C9C advancealtar::ClearRewardData::operator=

#endif  // __IDA91_ADVANCEALTAR_CLEARREWARDDATA_H__
