#include "advancealtar_RoundRewardData.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x836A14C
// IDA_NAME: _ZN12advancealtar15RoundRewardDataD2Ev
// DEMANGLED: advancealtar::RoundRewardData::~RoundRewardData()
void __cdecl advancealtar::RoundRewardData::~RoundRewardData(advancealtar::RoundRewardData *this)
{
  std::vector<advancealtar::_RewardItem>::~vector((_DWORD *)this + 2);
}

// IDA_EA: 0x83D1D72
// IDA_NAME: _ZN12advancealtar15RoundRewardDataC2ERKS0_
// DEMANGLED: advancealtar::RoundRewardData::RoundRewardData(advancealtar::RoundRewardData const&)
int __cdecl advancealtar::RoundRewardData::RoundRewardData(
        advancealtar::RoundRewardData *this,
        const advancealtar::RoundRewardData *a2)
{
  *(_DWORD *)this = *(_DWORD *)a2;
  *((_DWORD *)this + 1) = *((_DWORD *)a2 + 1);
  return std::vector<advancealtar::_RewardItem>::vector((char *)this + 8, (char *)a2 + 8);
}

// IDA_EA: 0x83DF710
// IDA_NAME: _ZN12advancealtar15RoundRewardDataaSERKS0_
// DEMANGLED: advancealtar::RoundRewardData::operator=(advancealtar::RoundRewardData const&)
_DWORD *__cdecl advancealtar::RoundRewardData::operator=(_DWORD *a1, _DWORD *a2)
{
  *a1 = *a2;
  a1[1] = a2[1];
  std::vector<advancealtar::_RewardItem>::operator=(a1 + 2, a2 + 2);
  return a1;
}

// IDA_EA: 0x88F28EC
// IDA_NAME: _ZN12advancealtar15RoundRewardDataC2Ev
// DEMANGLED: advancealtar::RoundRewardData::RoundRewardData(void)
int __cdecl advancealtar::RoundRewardData::RoundRewardData(advancealtar::RoundRewardData *this)
{
  return std::vector<advancealtar::_RewardItem>::vector((int)this + 8);
}
