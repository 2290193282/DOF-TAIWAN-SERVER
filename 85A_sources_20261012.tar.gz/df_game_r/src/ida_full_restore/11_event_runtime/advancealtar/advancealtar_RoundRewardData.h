#ifndef __IDA91_ADVANCEALTAR_ROUNDREWARDDATA_H__
#define __IDA91_ADVANCEALTAR_ROUNDREWARDDATA_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: advancealtar
// Source unit: advancealtar_RoundRewardData
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4506

/* 4506 */
struct advancealtar::RoundRewardData;

// Exported member functions:
// 0x836A14C	advancealtar::RoundRewardData::~RoundRewardData()
// 0x83D1D72	advancealtar::RoundRewardData::RoundRewardData(advancealtar::RoundRewardData const&)
// 0x83DF710	advancealtar::RoundRewardData::operator=(advancealtar::RoundRewardData const&)
// 0x88F28EC	advancealtar::RoundRewardData::RoundRewardData(void)

// Function declaration index:
// DECL 0x836A14C advancealtar::RoundRewardData::~RoundRewardData
// DECL 0x83D1D72 advancealtar::RoundRewardData::RoundRewardData
// DECL 0x83DF710 advancealtar::RoundRewardData::operator=
// DECL 0x88F28EC advancealtar::RoundRewardData::RoundRewardData

#endif  // __IDA91_ADVANCEALTAR_ROUNDREWARDDATA_H__
