#include "advancealtar_RewardItemType.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x889ACAA
// IDA_NAME: _ZN12advancealtar14RewardItemType17getRewardItemTypeERKSsRNS0_1TE
// DEMANGLED: advancealtar::RewardItemType::getRewardItemType(std::string const&,advancealtar::RewardItemType::T &)
int __cdecl advancealtar::RewardItemType::getRewardItemType(std::string *a1, _DWORD *a2)
{
  if ( std::operator==<char>(a1, "normal") )
  {
    *a2 = 0;
    return 1;
  }
  else if ( std::operator==<char>(a1, "event") )
  {
    *a2 = 1;
    return 1;
  }
  else
  {
    return 0;
  }
}
