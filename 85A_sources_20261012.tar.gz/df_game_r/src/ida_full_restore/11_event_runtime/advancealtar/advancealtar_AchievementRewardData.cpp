#include "advancealtar_AchievementRewardData.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x889AD06
// IDA_NAME: _ZN12advancealtar21AchievementRewardDataC2Ev
// DEMANGLED: advancealtar::AchievementRewardData::AchievementRewardData(void)
std::string *__cdecl advancealtar::AchievementRewardData::AchievementRewardData(std::string *this)
{
  this->_M_dataplus.__vftable = 0;
  this[1]._M_dataplus.__vftable = (ustd::string::_Alloc_hider_vtbl *)-1;
  this[2]._M_dataplus.__vftable = 0;
  std::vector<advancealtar::_RewardItem>::vector((int)&this[4]);
  std::string::string(this + 7);
  std::string::string(this + 8);
  return std::string::string(this + 9);
}

// IDA_EA: 0x889ADBA
// IDA_NAME: _ZN12advancealtar21AchievementRewardDataD2Ev
// DEMANGLED: advancealtar::AchievementRewardData::~AchievementRewardData()
void __cdecl advancealtar::AchievementRewardData::~AchievementRewardData(advancealtar::AchievementRewardData *this)
{
  std::string::~string((_DWORD *)this + 9);
  std::string::~string((_DWORD *)this + 8);
  std::string::~string((_DWORD *)this + 7);
  std::vector<advancealtar::_RewardItem>::~vector((_DWORD *)this + 4);
}

// IDA_EA: 0x889AE56
// IDA_NAME: _ZN12advancealtar21AchievementRewardData5resetEv
// DEMANGLED: advancealtar::AchievementRewardData::reset(void)
unsigned int *__cdecl advancealtar::AchievementRewardData::reset(std::string *this)
{
  this->_M_dataplus.__vftable = 0;
  this[1]._M_dataplus.__vftable = (ustd::string::_Alloc_hider_vtbl *)-1;
  this[2]._M_dataplus.__vftable = 0;
  this[3]._M_dataplus.__vftable = (ustd::string::_Alloc_hider_vtbl *)-1;
  std::vector<advancealtar::_RewardItem>::clear(&this[4]._M_dataplus.__vftable);
  std::string::clear(this + 7);
  std::string::clear(this + 8);
  return std::string::clear(this + 9);
}

// IDA_EA: 0x889C4EC
// IDA_NAME: _ZN12advancealtar21AchievementRewardDataC2ERKS0_
// DEMANGLED: advancealtar::AchievementRewardData::AchievementRewardData(advancealtar::AchievementRewardData const&)
ustd::string::_Alloc_hider_vtbl *__cdecl advancealtar::AchievementRewardData::AchievementRewardData(
        advancealtar::AchievementRewardData *this,
        const std::string *a2)
{
  *(std::string *)this = (std::string)a2->_M_dataplus.__vftable;
  *((std::string *)this + 1) = a2[1];
  *((std::string *)this + 2) = a2[2];
  *((std::string *)this + 3) = a2[3];
  std::vector<advancealtar::_RewardItem>::vector((int *)this + 4, &a2[4]._M_dataplus.__vftable);
  std::string::string((std::string *)this + 7, a2 + 7);
  std::string::string((std::string *)this + 8, a2 + 8);
  return std::string::string((std::string *)this + 9, a2 + 9);
}
