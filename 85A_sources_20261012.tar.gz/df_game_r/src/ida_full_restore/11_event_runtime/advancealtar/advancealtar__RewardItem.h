#ifndef __IDA91_ADVANCEALTAR_REWARDITEM_H__
#define __IDA91_ADVANCEALTAR_REWARDITEM_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: advancealtar
// Source unit: advancealtar__RewardItem
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 1258

/* 1258 */
struct advancealtar::_RewardItem;

// Exported member functions:
// 0x813AA10	advancealtar::_RewardItem::~_RewardItem()
// 0x889B9C0	advancealtar::_RewardItem::_RewardItem(void)

// Function declaration index:
// DECL 0x813AA10 advancealtar::_RewardItem::~_RewardItem
// DECL 0x889B9C0 advancealtar::_RewardItem::_RewardItem

#endif  // __IDA91_ADVANCEALTAR_REWARDITEM_H__
