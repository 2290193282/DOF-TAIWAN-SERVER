#ifndef __IDA91_ADVANCEALTAR_REWARD_H__
#define __IDA91_ADVANCEALTAR_REWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: advancealtar
// Source unit: advancealtar__Reward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1244

/* 1244 */
struct advancealtar::_Reward;

// Exported member functions:
// 0x81344BE	advancealtar::_Reward::_Reward(void)

// Function declaration index:
// DECL 0x81344BE advancealtar::_Reward::_Reward

#endif  // __IDA91_ADVANCEALTAR_REWARD_H__
