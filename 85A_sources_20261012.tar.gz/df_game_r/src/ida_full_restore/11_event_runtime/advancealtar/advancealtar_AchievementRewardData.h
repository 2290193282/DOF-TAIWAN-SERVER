#ifndef __IDA91_ADVANCEALTAR_ACHIEVEMENTREWARDDATA_H__
#define __IDA91_ADVANCEALTAR_ACHIEVEMENTREWARDDATA_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: advancealtar
// Source unit: advancealtar_AchievementRewardData
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4543

/* 4543 */
struct advancealtar::AchievementRewardData;

// Exported member functions:
// 0x889AD06	advancealtar::AchievementRewardData::AchievementRewardData(void)
// 0x889ADBA	advancealtar::AchievementRewardData::~AchievementRewardData()
// 0x889AE56	advancealtar::AchievementRewardData::reset(void)
// 0x889C4EC	advancealtar::AchievementRewardData::AchievementRewardData(advancealtar::AchievementRewardData const&)

// Function declaration index:
// DECL 0x889AD06 advancealtar::AchievementRewardData::AchievementRewardData
// DECL 0x889ADBA advancealtar::AchievementRewardData::~AchievementRewardData
// DECL 0x889AE56 advancealtar::AchievementRewardData::reset
// DECL 0x889C4EC advancealtar::AchievementRewardData::AchievementRewardData

#endif  // __IDA91_ADVANCEALTAR_ACHIEVEMENTREWARDDATA_H__
