#ifndef __IDA91_ADVANCEALTAR_DISPATCHER_GETACHIEVEMENTREWARD_H__
#define __IDA91_ADVANCEALTAR_DISPATCHER_GETACHIEVEMENTREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: advancealtar
// Source unit: advancealtar_Dispatcher_GetAchievementReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 1263

/* 1263 */
struct advancealtar::Dispatcher_GetAchievementReward;

// Exported member functions:
// 0x8140C64	advancealtar::Dispatcher_GetAchievementReward::dispatch_sig(CUser *,PacketBuf &)
// 0x8140D52	advancealtar::Dispatcher_GetAchievementReward::read_packet(PacketBuf &,CMDPacketStruct::STBaseRequest &)const
// 0x8140D80	advancealtar::Dispatcher_GetAchievementReward::check_error(CUser *,CMDPacketStruct::STBaseRequest &)const
// 0x8140DA0	advancealtar::Dispatcher_GetAchievementReward::process_packet(CUser *,CMDPacketStruct::STBaseRequest &,CMDPacketStruct::STBaseResponse &)const
// 0x8140DAA	advancealtar::Dispatcher_GetAchievementReward::send_packet(CUser *,CMDPacketStruct::STBaseResponse &)
// 0x8142424	advancealtar::Dispatcher_GetAchievementReward::~Dispatcher_GetAchievementReward()
// 0x8142454	advancealtar::Dispatcher_GetAchievementReward::~Dispatcher_GetAchievementReward()
// 0x8142472	advancealtar::Dispatcher_GetAchievementReward::read(PacketBuf &,MSG_BASE &)
// 0x814247C	advancealtar::Dispatcher_GetAchievementReward::process(CUser *,MSG_BASE &,ParamBase &)
// 0x8595794	advancealtar::Dispatcher_GetAchievementReward::Dispatcher_GetAchievementReward(void)

// Function declaration index:
// DECL 0x8140C64 advancealtar::Dispatcher_GetAchievementReward::dispatch_sig
// DECL 0x8140D52 advancealtar::Dispatcher_GetAchievementReward::read_packet
// DECL 0x8140D80 advancealtar::Dispatcher_GetAchievementReward::check_error
// DECL 0x8140DA0 advancealtar::Dispatcher_GetAchievementReward::process_packet
// DECL 0x8140DAA advancealtar::Dispatcher_GetAchievementReward::send_packet
// DECL 0x8142424 advancealtar::Dispatcher_GetAchievementReward::~Dispatcher_GetAchievementReward
// DECL 0x8142454 advancealtar::Dispatcher_GetAchievementReward::~Dispatcher_GetAchievementReward
// DECL 0x8142472 advancealtar::Dispatcher_GetAchievementReward::read
// DECL 0x814247C advancealtar::Dispatcher_GetAchievementReward::process
// DECL 0x8595794 advancealtar::Dispatcher_GetAchievementReward::Dispatcher_GetAchievementReward

#endif  // __IDA91_ADVANCEALTAR_DISPATCHER_GETACHIEVEMENTREWARD_H__
