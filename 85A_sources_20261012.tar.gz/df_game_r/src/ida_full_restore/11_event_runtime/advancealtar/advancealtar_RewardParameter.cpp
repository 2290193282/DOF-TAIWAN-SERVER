#include "advancealtar_RewardParameter.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x889AF74
// IDA_NAME: _ZN12advancealtar15RewardParameterC2Ev
// DEMANGLED: advancealtar::RewardParameter::RewardParameter(void)
int __cdecl advancealtar::RewardParameter::RewardParameter(advancealtar::RewardParameter *this)
{
  return std::map<int,advancealtar::AchievementRewardData>::map(this);
}

// IDA_EA: 0x889AF88
// IDA_NAME: _ZN12advancealtar15RewardParameterD2Ev
// DEMANGLED: advancealtar::RewardParameter::~RewardParameter()
void __cdecl advancealtar::RewardParameter::~RewardParameter(advancealtar::RewardParameter *this)
{
  std::map<int,advancealtar::AchievementRewardData>::~map(this);
}

// IDA_EA: 0x889AF9C
// IDA_NAME: _ZN12advancealtar15RewardParameter5resetEv
// DEMANGLED: advancealtar::RewardParameter::reset(void)
int __cdecl advancealtar::RewardParameter::reset(advancealtar::RewardParameter *this)
{
  return std::map<int,advancealtar::AchievementRewardData>::clear(this);
}

// IDA_EA: 0x889AFB0
// IDA_NAME: _ZN12advancealtar15RewardParameter32importAchievementRewardParameterEPKc
// DEMANGLED: advancealtar::RewardParameter::importAchievementRewardParameter(char const*)
int __usercall advancealtar::RewardParameter::importAchievementRewardParameter@<eax>(
        int n866@<ebx>,
        advancealtar::RewardParameter *this,
        TCHAR *filename)
{
  int v3; // esi
  int v4; // esi
  int n2; // esi
  std::string v7; // [esp+14h] [ebp-B4h] BYREF
  _DWORD v8[3]; // [esp+18h] [ebp-B0h] BYREF
  int v9; // [esp+24h] [ebp-A4h] BYREF
  std::string v10; // [esp+30h] [ebp-98h] BYREF
  std::string v11; // [esp+34h] [ebp-94h] BYREF
  std::string v12; // [esp+38h] [ebp-90h] BYREF
  bool RewardItemTypeERKSsRNS0_1TE; // [esp+3Fh] [ebp-89h] BYREF
  std::string v14; // [esp+40h] [ebp-88h] BYREF
  int v15[3]; // [esp+44h] [ebp-84h] BYREF
  std::string v16; // [esp+50h] [ebp-78h] BYREF
  bool v17; // [esp+57h] [ebp-71h] BYREF
  std::string v18; // [esp+58h] [ebp-70h] BYREF
  _BYTE v19[8]; // [esp+5Ch] [ebp-6Ch] BYREF
  _BYTE v20[44]; // [esp+64h] [ebp-64h] BYREF
  _BYTE v21[44]; // [esp+90h] [ebp-38h] BYREF
  int v22; // [esp+BCh] [ebp-Ch]

  std::string::string(&v18);
  v22 = 0;
  v17 = 0;
  advancealtar::RewardParameter::reset(this);
  if ( (unsigned __int8)loadRDARScriptFile((TCHAR *)&dir__5, filename) == 1 )
  {
    while ( (unsigned __int8)ScanType(&v18, 1) == 1 )
    {
      if ( std::operator==<char>(&v18, "[reward data]") )
      {
        advancealtar::AchievementRewardData::AchievementRewardData(&v7);
        while ( (unsigned __int8)ScanType(&v18, 1) == 1 )
        {
          if ( std::operator==<char>(&v18, "[/reward data]") )
          {
            std::make_pair<int &,advancealtar::AchievementRewardData &>(v21);
            std::pair<int const,advancealtar::AchievementRewardData>::pair<int,advancealtar::AchievementRewardData>(
              v20,
              v21);
            std::map<int,advancealtar::AchievementRewardData>::insert(v19);
            std::pair<int const,advancealtar::AchievementRewardData>::~pair(v20);
            std::pair<int,advancealtar::AchievementRewardData>::~pair(v21);
            break;
          }
          if ( std::operator==<char>(&v18, "[type]") )
          {
            v7._M_dataplus.__vftable = (ustd::string::_Alloc_hider_vtbl *)ScanInt(&v17);
            if ( !v17 )
            {
              n866 = 866;
              v3 = 0;
              goto LABEL_51;
            }
            if ( (int)v7._M_dataplus.__vftable <= 0 )
            {
              n866 = 868;
              v3 = 0;
              goto LABEL_51;
            }
          }
          else if ( std::operator==<char>(&v18, "[stage difficulty]") )
          {
            std::string::string(&v16);
            if ( (unsigned __int8)ScanStr(&v16) == 1 )
            {
              if ( (unsigned __int8)advancealtar::StageDifficulty::getDifficulty(&v16, v8) == 1 )
              {
                v4 = 1;
              }
              else
              {
                n866 = 877;
                v4 = 0;
              }
            }
            else
            {
              n866 = 874;
              v4 = 0;
            }
            std::string::~string(&v16);
            if ( !v4 )
            {
              v3 = 0;
              goto LABEL_51;
            }
          }
          else if ( std::operator==<char>(&v18, "[stage clear count]") )
          {
            v8[1] = ScanInt(&v17);
            if ( !v17 )
            {
              n866 = 883;
              v3 = 0;
              goto LABEL_51;
            }
          }
          else if ( std::operator==<char>(&v18, "[icon image]") )
          {
            v8[2] = ScanInt(&v17);
            if ( !v17 )
            {
              n866 = 890;
              v3 = 0;
              goto LABEL_51;
            }
          }
          else if ( std::operator==<char>(&v18, "[reward item]") )
          {
            while ( 1 )
            {
              advancealtar::_RewardItem::_RewardItem((advancealtar::_RewardItem *)v15);
              std::string::string(&v14);
              if ( (unsigned __int8)ScanStr(&v14) == 1 )
              {
                RewardItemTypeERKSsRNS0_1TE = advancealtar::RewardItemType::getRewardItemType(&v14, v15);
                if ( RewardItemTypeERKSsRNS0_1TE )
                {
                  v15[1] = ScanInt(&RewardItemTypeERKSsRNS0_1TE);
                  if ( RewardItemTypeERKSsRNS0_1TE )
                  {
                    v15[2] = ScanInt(&RewardItemTypeERKSsRNS0_1TE);
                    if ( RewardItemTypeERKSsRNS0_1TE )
                    {
                      std::vector<advancealtar::_RewardItem>::push_back((int)&v9, (int)v15);
                      n2 = 2;
                    }
                    else
                    {
                      n866 = 913;
                      n2 = 1;
                    }
                  }
                  else
                  {
                    n2 = 0;
                  }
                }
                else
                {
                  n2 = 0;
                }
              }
              else
              {
                n2 = 0;
              }
              std::string::~string(&v14);
              if ( !n2 )
                break;
              if ( n2 == 1 )
              {
                v3 = 0;
                goto LABEL_51;
              }
            }
          }
          else if ( std::operator==<char>(&v18, "[reward title]") )
          {
            if ( (unsigned __int8)ScanStr(&v10) != 1 )
            {
              n866 = 921;
              v3 = 0;
              goto LABEL_51;
            }
          }
          else if ( std::operator==<char>(&v18, "[postal title]") )
          {
            if ( (unsigned __int8)ScanStr(&v11) != 1 )
            {
              n866 = 926;
              v3 = 0;
              goto LABEL_51;
            }
          }
          else if ( std::operator==<char>(&v18, "[postal letter]") && (unsigned __int8)ScanStr(&v12) != 1 )
          {
            n866 = 931;
            v3 = 0;
            goto LABEL_51;
          }
        }
        v3 = 1;
LABEL_51:
        advancealtar::AchievementRewardData::~AchievementRewardData((advancealtar::AchievementRewardData *)&v7);
        if ( !v3 )
          goto LABEL_54;
      }
    }
    n866 = 0;
  }
  else
  {
    n866 = 0;
  }
LABEL_54:
  std::string::~string(&v18);
  return n866;
}

// IDA_EA: 0x889B544
// IDA_NAME: _ZNK12advancealtar15RewardParameter24getAchievementRewardDataEi
// DEMANGLED: advancealtar::RewardParameter::getAchievementRewardData(int)const
int __cdecl advancealtar::RewardParameter::getAchievementRewardData()
{
  _BYTE v1[4]; // [esp+18h] [ebp-10h] BYREF
  _BYTE v2[12]; // [esp+1Ch] [ebp-Ch] BYREF

  std::map<int,advancealtar::AchievementRewardData>::find(v1);
  std::map<int,advancealtar::AchievementRewardData>::end(v2);
  if ( (unsigned __int8)std::_Rb_tree_const_iterator<std::pair<int const,advancealtar::AchievementRewardData>>::operator==(
                          v1,
                          v2) )
    return 0;
  else
    return std::_Rb_tree_const_iterator<std::pair<int const,advancealtar::AchievementRewardData>>::operator->(v1) + 4;
}

// IDA_EA: 0x889B5A8
// IDA_NAME: _ZNK12advancealtar15RewardParameter24getAchievementRewardDataENS_15StageDifficulty1TEi
// DEMANGLED: advancealtar::RewardParameter::getAchievementRewardData(advancealtar::StageDifficulty::T,int)const
int __cdecl advancealtar::RewardParameter::getAchievementRewardData(int a1, int n2, int a3)
{
  _BYTE v5[4]; // [esp+14h] [ebp-14h] BYREF
  _BYTE v6[4]; // [esp+18h] [ebp-10h] BYREF
  _BYTE dest[12]; // [esp+1Ch] [ebp-Ch] BYREF

  std::map<int,advancealtar::AchievementRewardData>::begin(v5);
  while ( 1 )
  {
    std::map<int,advancealtar::AchievementRewardData>::end(v6);
    if ( !(unsigned __int8)std::_Rb_tree_const_iterator<std::pair<int const,advancealtar::AchievementRewardData>>::operator!=(
                             v5,
                             v6) )
      break;
    if ( *(_DWORD *)(std::_Rb_tree_const_iterator<std::pair<int const,advancealtar::AchievementRewardData>>::operator->(v5)
                   + 8) == n2
      && *(_DWORD *)(std::_Rb_tree_const_iterator<std::pair<int const,advancealtar::AchievementRewardData>>::operator->(v5)
                   + 12) == a3 )
    {
      return std::_Rb_tree_const_iterator<std::pair<int const,advancealtar::AchievementRewardData>>::operator->(v5) + 4;
    }
    std::_Rb_tree_const_iterator<std::pair<int const,advancealtar::AchievementRewardData>>::operator++(dest);
  }
  return 0;
}
