#include "advancealtar_SurvivalRewardData.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x836A162
// IDA_NAME: _ZN12advancealtar18SurvivalRewardDataC2Ev
// DEMANGLED: advancealtar::SurvivalRewardData::SurvivalRewardData(void)
int __cdecl advancealtar::SurvivalRewardData::SurvivalRewardData(advancealtar::SurvivalRewardData *this)
{
  return std::vector<advancealtar::RoundRewardData>::vector(this);
}

// IDA_EA: 0x836A176
// IDA_NAME: _ZN12advancealtar18SurvivalRewardDataD2Ev
// DEMANGLED: advancealtar::SurvivalRewardData::~SurvivalRewardData()
void __cdecl advancealtar::SurvivalRewardData::~SurvivalRewardData(advancealtar::SurvivalRewardData *this)
{
  std::vector<advancealtar::RoundRewardData>::~vector(this);
}

// IDA_EA: 0x8376CDE
// IDA_NAME: _ZN12advancealtar18SurvivalRewardDataaSERKS0_
// DEMANGLED: advancealtar::SurvivalRewardData::operator=(advancealtar::SurvivalRewardData const&)
int __cdecl advancealtar::SurvivalRewardData::operator=(int a1, int a2)
{
  std::vector<advancealtar::RoundRewardData>::operator=(a1, a2);
  return a1;
}

// IDA_EA: 0x889AEBE
// IDA_NAME: _ZNK12advancealtar18SurvivalRewardData18getRoundRewardDataEi
// DEMANGLED: advancealtar::SurvivalRewardData::getRoundRewardData(int)const
int __cdecl advancealtar::SurvivalRewardData::getRoundRewardData(advancealtar::SurvivalRewardData *this, int a2)
{
  int v4; // [esp+14h] [ebp-14h] BYREF
  int v5; // [esp+18h] [ebp-10h] BYREF
  _DWORD v6[3]; // [esp+1Ch] [ebp-Ch] BYREF

  std::vector<advancealtar::RoundRewardData>::begin((int)&v4, this);
  while ( 1 )
  {
    std::vector<advancealtar::RoundRewardData>::end((int)&v5, (int)this);
    if ( !__gnu_cxx::operator!=<advancealtar::RoundRewardData const*,std::vector<advancealtar::RoundRewardData>>(
            (int)&v4,
            (int)&v5) )
      break;
    if ( *(_DWORD *)__gnu_cxx::__normal_iterator<advancealtar::RoundRewardData const*,std::vector<advancealtar::RoundRewardData>>::operator->((int)&v4) <= a2
      && *(_DWORD *)(__gnu_cxx::__normal_iterator<advancealtar::RoundRewardData const*,std::vector<advancealtar::RoundRewardData>>::operator->((int)&v4)
                   + 4) >= a2 )
    {
      return __gnu_cxx::__normal_iterator<advancealtar::RoundRewardData const*,std::vector<advancealtar::RoundRewardData>>::operator->((int)&v4)
           + 8;
    }
    __gnu_cxx::__normal_iterator<advancealtar::RoundRewardData const*,std::vector<advancealtar::RoundRewardData>>::operator++(
      v6,
      &v4);
  }
  return 0;
}
