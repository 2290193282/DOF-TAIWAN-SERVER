#ifndef __IDA91_ADVANCEALTAR_SURVIVALREWARDDATA_H__
#define __IDA91_ADVANCEALTAR_SURVIVALREWARDDATA_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: advancealtar
// Source unit: advancealtar_SurvivalRewardData
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4352

/* 4352 */
struct advancealtar::SurvivalRewardData;

// Exported member functions:
// 0x836A162	advancealtar::SurvivalRewardData::SurvivalRewardData(void)
// 0x836A176	advancealtar::SurvivalRewardData::~SurvivalRewardData()
// 0x8376CDE	advancealtar::SurvivalRewardData::operator=(advancealtar::SurvivalRewardData const&)
// 0x889AEBE	advancealtar::SurvivalRewardData::getRoundRewardData(int)const

// Function declaration index:
// DECL 0x836A162 advancealtar::SurvivalRewardData::SurvivalRewardData
// DECL 0x836A176 advancealtar::SurvivalRewardData::~SurvivalRewardData
// DECL 0x8376CDE advancealtar::SurvivalRewardData::operator=
// DECL 0x889AEBE advancealtar::SurvivalRewardData::getRoundRewardData

#endif  // __IDA91_ADVANCEALTAR_SURVIVALREWARDDATA_H__
