#include "advancealtar__Reward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81344BE
// IDA_NAME: _ZN12advancealtar7_RewardC2Ev
// DEMANGLED: advancealtar::_Reward::_Reward(void)
void *__cdecl advancealtar::_Reward::_Reward(advancealtar::_Reward *this)
{
  return memset(this, 0, 5u);
}
