#ifndef __IDA91_ADVANCEALTAR_REWARDITEMTYPE_H__
#define __IDA91_ADVANCEALTAR_REWARDITEMTYPE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: advancealtar
// Source unit: advancealtar_RewardItemType
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// No matching local type was found; declare types manually during cleanup.

// Exported member functions:
// 0x889ACAA	advancealtar::RewardItemType::getRewardItemType(std::string const&,advancealtar::RewardItemType::T &)

// Function declaration index:
// DECL 0x889ACAA advancealtar::RewardItemType::getRewardItemType

#endif  // __IDA91_ADVANCEALTAR_REWARDITEMTYPE_H__
