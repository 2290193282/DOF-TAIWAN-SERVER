#include "advancealtar__RewardItem.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x813AA10
// IDA_NAME: _ZN12advancealtar11_RewardItemD2Ev
// DEMANGLED: advancealtar::_RewardItem::~_RewardItem()
void advancealtar::_RewardItem::~_RewardItem()
{
  ;
}

// IDA_EA: 0x889B9C0
// IDA_NAME: _ZN12advancealtar11_RewardItemC2Ev
// DEMANGLED: advancealtar::_RewardItem::_RewardItem(void)
void *__cdecl advancealtar::_RewardItem::_RewardItem(advancealtar::_RewardItem *this)
{
  return memset(this, 0, 0xCu);
}
