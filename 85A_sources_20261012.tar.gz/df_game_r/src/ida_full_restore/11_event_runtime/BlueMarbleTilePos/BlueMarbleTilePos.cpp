#include "BlueMarbleTilePos.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x88D95A0
// IDA_NAME: _ZN17BlueMarbleTilePosD2Ev
// DEMANGLED: BlueMarbleTilePos::~BlueMarbleTilePos()
void BlueMarbleTilePos::~BlueMarbleTilePos()
{
  ;
}
