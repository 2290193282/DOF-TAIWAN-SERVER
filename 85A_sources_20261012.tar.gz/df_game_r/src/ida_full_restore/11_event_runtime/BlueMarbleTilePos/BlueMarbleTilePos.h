#ifndef __IDA91_BLUEMARBLETILEPOS_H__
#define __IDA91_BLUEMARBLETILEPOS_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: BlueMarbleTilePos
// Source unit: BlueMarbleTilePos
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3865

/* 3865 */
struct BlueMarbleTilePos;

// Exported member functions:
// 0x88D95A0	BlueMarbleTilePos::~BlueMarbleTilePos()

// Function declaration index:
// DECL 0x88D95A0 BlueMarbleTilePos::~BlueMarbleTilePos

#endif  // __IDA91_BLUEMARBLETILEPOS_H__
