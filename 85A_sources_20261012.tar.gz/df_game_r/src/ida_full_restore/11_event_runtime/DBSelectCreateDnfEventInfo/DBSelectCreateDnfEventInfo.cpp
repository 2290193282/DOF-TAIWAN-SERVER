#include "DBSelectCreateDnfEventInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x815BA94
// IDA_NAME: _ZN26DBSelectCreateDnfEventInfo11makeRequestEv
// DEMANGLED: DBSelectCreateDnfEventInfo::makeRequest(void)
void DBSelectCreateDnfEventInfo::makeRequest()
{
  Stream *v1; // eax
  int v2[2]; // [esp+14h] [ebp-14h] BYREF
  int RepeatEvent; // [esp+1Ch] [ebp-Ch]

  RepeatEvent = CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 160);
  if ( RepeatEvent && (*(unsigned __int8 (__cdecl **)(int, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) == 1 )
  {
    v1 = (Stream *)StreamPool::Acquire(GlobalData::s_stream_pool, "localtaiwan/Dispatcher/Taiwan_DbThread.cpp", 484);
    CStreamGuard::CStreamGuard((CStreamGuard *)v2, v1, 1);
    Taiwan::internal_stream((int)v2, 9, -1);
    MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v2);
    CStreamGuard::~CStreamGuard((CStreamGuard *)v2);
  }
}

// IDA_EA: 0x815BB8C
// IDA_NAME: _ZN26DBSelectCreateDnfEventInfo8dispatchEiiP6Stream
// DEMANGLED: DBSelectCreateDnfEventInfo::dispatch(int,int,Stream *)
int DBSelectCreateDnfEventInfo::dispatch()
{
  _DWORD *exception; // eax
  _DWORD *v1; // eax
  _DWORD *v2; // eax
  _DWORD *v3; // eax
  _DWORD *v4; // eax
  _DWORD *v5; // eax
  _DWORD *v6; // eax
  char v7; // bl
  int v9; // [esp+Ch] [ebp-8Ch]
  int v10; // [esp+5Ch] [ebp-3Ch] BYREF
  char v11[4]; // [esp+60h] [ebp-38h] BYREF
  InterSelectCreateDnfEventInfo *v12; // [esp+64h] [ebp-34h] BYREF
  int v13[4]; // [esp+68h] [ebp-30h] BYREF
  MySQL *DBHandle; // [esp+78h] [ebp-20h]

  v12 = 0;
  *(_DWORD *)v11 = 0;
  v10 = 0;
  DBHandle = (MySQL *)DBMgr::GetDBHandle(GlobalData::s_db_mgr, 9, 0);
  if ( !DBHandle )
  {
    exception = _cxa_allocate_exception(4u);
    *exception = "handle null";
    _cxa_throw(exception, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  MySQL::set_query(
    DBHandle,
    "seLect rate, HOUR(CURTIME()), event_day FROM event_create_dnf_info WHERE occ_time=DATE_ADD(CURDATE(), INTERVAL HOUR("
    "CURTIME()) HOUR)");
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
  {
    v1 = _cxa_allocate_exception(4u);
    *v1 = "select_exec";
    _cxa_throw(v1, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  if ( !MySQL::get_n_rows(DBHandle) )
  {
    v2 = _cxa_allocate_exception(4u);
    *v2 = "get_n_rows=0";
    _cxa_throw(v2, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  if ( (unsigned __int8)MySQL::fetch(DBHandle) != 1 )
  {
    v3 = _cxa_allocate_exception(4u);
    *v3 = "fetch";
    _cxa_throw(v3, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  if ( (unsigned __int8)MySQL::get_int(DBHandle, 0, (int *)&v12) != 1 )
  {
    v4 = _cxa_allocate_exception(4u);
    *v4 = "get_int 0";
    _cxa_throw(v4, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  if ( (unsigned __int8)MySQL::get_int(DBHandle, 1, (int *)v11) != 1 )
  {
    v5 = _cxa_allocate_exception(4u);
    *v5 = "get_int 1";
    _cxa_throw(v5, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  if ( (unsigned __int8)MySQL::get_int(DBHandle, 2, &v10) != 1 )
  {
    v6 = _cxa_allocate_exception(4u);
    *v6 = "get_int 2";
    _cxa_throw(v6, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  InterSelectCreateDnfEventInfo::makeRequest(v12, *(int *)v11, v10, v9);
  v7 = v11[0];
  cMyTrace::cMyTrace((cMyTrace *)v13, "virtual bool DBSelectCreateDnfEventInfo::dispatch(int, int, Stream*)", 525, 0);
  cMyTrace::operator()((int)v13, "[Taiwan, Event] select event_create_dnf_info. hour:%d rate:%d event_day:%d", v7);
  return 1;
}

// IDA_EA: 0x815E2A4
// IDA_NAME: _ZN26DBSelectCreateDnfEventInfoC2Ev
// DEMANGLED: DBSelectCreateDnfEventInfo::DBSelectCreateDnfEventInfo(void)
void __cdecl DBSelectCreateDnfEventInfo::DBSelectCreateDnfEventInfo(DBSelectCreateDnfEventInfo *this)
{
  TaiwanInterfaceDBDispatcher::TaiwanInterfaceDBDispatcher(this, 9);
  *(_DWORD *)this = off_8B793D0;
}

// IDA_EA: 0x815E2C8
// IDA_NAME: _ZN26DBSelectCreateDnfEventInfoD2Ev
// DEMANGLED: DBSelectCreateDnfEventInfo::~DBSelectCreateDnfEventInfo()
void __cdecl DBSelectCreateDnfEventInfo::~DBSelectCreateDnfEventInfo(DBSelectCreateDnfEventInfo *this)
{
  *(_DWORD *)this = off_8B793D0;
  TaiwanInterfaceDBDispatcher::~TaiwanInterfaceDBDispatcher(this);
}

// IDA_EA: 0x815E2F8
// IDA_NAME: _ZN26DBSelectCreateDnfEventInfoD0Ev
// DEMANGLED: DBSelectCreateDnfEventInfo::~DBSelectCreateDnfEventInfo()
void __cdecl DBSelectCreateDnfEventInfo::~DBSelectCreateDnfEventInfo(DBSelectCreateDnfEventInfo *this)
{
  DBSelectCreateDnfEventInfo::~DBSelectCreateDnfEventInfo(this);
  operator delete(this);
}
