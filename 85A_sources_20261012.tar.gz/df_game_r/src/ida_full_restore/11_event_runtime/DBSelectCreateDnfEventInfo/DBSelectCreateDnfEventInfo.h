#ifndef __IDA91_DBSELECTCREATEDNFEVENTINFO_H__
#define __IDA91_DBSELECTCREATEDNFEVENTINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DBSelectCreateDnfEventInfo
// Source unit: DBSelectCreateDnfEventInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 1322

/* 1322 */
struct DBSelectCreateDnfEventInfo;

// Exported member functions:
// 0x815BA94	DBSelectCreateDnfEventInfo::makeRequest(void)
// 0x815BB8C	DBSelectCreateDnfEventInfo::dispatch(int,int,Stream *)
// 0x815E2A4	DBSelectCreateDnfEventInfo::DBSelectCreateDnfEventInfo(void)
// 0x815E2C8	DBSelectCreateDnfEventInfo::~DBSelectCreateDnfEventInfo()
// 0x815E2F8	DBSelectCreateDnfEventInfo::~DBSelectCreateDnfEventInfo()

// Function declaration index:
// DECL 0x815BA94 DBSelectCreateDnfEventInfo::makeRequest
// DECL 0x815BB8C DBSelectCreateDnfEventInfo::dispatch
// DECL 0x815E2A4 DBSelectCreateDnfEventInfo::DBSelectCreateDnfEventInfo
// DECL 0x815E2C8 DBSelectCreateDnfEventInfo::~DBSelectCreateDnfEventInfo
// DECL 0x815E2F8 DBSelectCreateDnfEventInfo::~DBSelectCreateDnfEventInfo

#endif  // __IDA91_DBSELECTCREATEDNFEVENTINFO_H__
