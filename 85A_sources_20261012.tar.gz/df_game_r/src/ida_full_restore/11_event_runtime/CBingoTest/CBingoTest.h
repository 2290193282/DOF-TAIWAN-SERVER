#ifndef __IDA91_CBINGOTEST_H__
#define __IDA91_CBINGOTEST_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CBingoTest
// Source unit: CBingoTest
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1094

/* 1094 */
struct CBingoTest;

// Exported member functions:
// 0x80CAECC	CBingoTest::CBingoTest(void)
// 0x80CAEE0	CBingoTest::~CBingoTest()
// 0x80CAEF4	CBingoTest::run(void)
// 0x80CAF3E	CBingoTest::getTimeFromString(std::string)
// 0x80CAF7C	CBingoTest::getToday(void)
// 0x80CB030	CBingoTest::resetBoard(void)
// 0x80CB036	CBingoTest::resetQuiz(void)
// 0x80CB03C	CBingoTest::calBoradMatchLine(void)
// 0x80CB06E	CBingoTest::calNewValue(void)
// 0x80CB07E	CBingoTest::getBingoRandomVaule(void)

// Function declaration index:
// DECL 0x80CAECC CBingoTest::CBingoTest
// DECL 0x80CAEE0 CBingoTest::~CBingoTest
// DECL 0x80CAEF4 CBingoTest::run
// DECL 0x80CAF3E CBingoTest::getTimeFromString
// DECL 0x80CAF7C CBingoTest::getToday
// DECL 0x80CB030 CBingoTest::resetBoard
// DECL 0x80CB036 CBingoTest::resetQuiz
// DECL 0x80CB03C CBingoTest::calBoradMatchLine
// DECL 0x80CB06E CBingoTest::calNewValue
// DECL 0x80CB07E CBingoTest::getBingoRandomVaule

#endif  // __IDA91_CBINGOTEST_H__
