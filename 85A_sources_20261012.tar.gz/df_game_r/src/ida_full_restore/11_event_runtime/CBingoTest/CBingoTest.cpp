#include "CBingoTest.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x80CAECC
// IDA_NAME: _ZN10CBingoTestC2Ev
// DEMANGLED: CBingoTest::CBingoTest(void)
void __cdecl CBingoTest::CBingoTest(CBingoTest *this)
{
  CBingo::CBingo(this);
}

// IDA_EA: 0x80CAEE0
// IDA_NAME: _ZN10CBingoTestD2Ev
// DEMANGLED: CBingoTest::~CBingoTest()
void __cdecl CBingoTest::~CBingoTest(CBingoTest *this)
{
  CBingo::~CBingo(this);
}

// IDA_EA: 0x80CAEF4
// IDA_NAME: _ZN10CBingoTest3runEv
// DEMANGLED: CBingoTest::run(void)
int __cdecl CBingoTest::run(CBingoTest *this)
{
  CBingoTest::getToday(this);
  CBingoTest::resetBoard(this);
  CBingoTest::resetQuiz(this);
  CBingoTest::calBoradMatchLine(this);
  CBingoTest::calNewValue(this);
  return CBingoTest::getBingoRandomVaule(this);
}

// IDA_EA: 0x80CAF3E
// IDA_NAME: _ZN10CBingoTest17getTimeFromStringESs
// DEMANGLED: CBingoTest::getTimeFromString(std::string)
time_t __cdecl CBingoTest::getTimeFromString(CBingoTest *this, std::string a2)
{
  struct tm tp; // [esp+1Ch] [ebp-3Ch] BYREF
  _BYTE v4[16]; // [esp+48h] [ebp-10h] BYREF

  boost::posix_time::time_from_string((boost::posix_time *)v4, (const std::string *)a2._M_dataplus.__vftable);
  boost::posix_time::to_tm((boost::gregorian *)&tp);
  return mktime(&tp);
}

// IDA_EA: 0x80CAF7C
// IDA_NAME: _ZN10CBingoTest8getTodayEv
// DEMANGLED: CBingoTest::getToday(void)
void CBingoTest::getToday()
{
  std::string v0; // [esp+1Ch] [ebp-Ch] BYREF

  std::string::string(&v0);
  std::string::operator=(&v0, "2012-07-19 05:00:00");
  std::string::operator=(&v0, "2012-07-19 06:00:00");
  std::string::operator=(&v0, "2012-07-20 12:00:00");
  std::string::operator=(&v0, "2012-07-31 11:00:00");
  std::string::operator=(&v0, "2012-08-01 05:00:00");
  std::string::operator=(&v0, "2012-08-01 07:00:00");
  std::string::~string(&v0);
}

// IDA_EA: 0x80CB030
// IDA_NAME: _ZN10CBingoTest10resetBoardEv
// DEMANGLED: CBingoTest::resetBoard(void)
void CBingoTest::resetBoard()
{
  ;
}

// IDA_EA: 0x80CB036
// IDA_NAME: _ZN10CBingoTest9resetQuizEv
// DEMANGLED: CBingoTest::resetQuiz(void)
void CBingoTest::resetQuiz()
{
  ;
}

// IDA_EA: 0x80CB03C
// IDA_NAME: _ZN10CBingoTest17calBoradMatchLineEv
// DEMANGLED: CBingoTest::calBoradMatchLine(void)
void CBingoTest::calBoradMatchLine()
{
  ;
}

// IDA_EA: 0x80CB06E
// IDA_NAME: _ZN10CBingoTest11calNewValueEv
// DEMANGLED: CBingoTest::calNewValue(void)
void CBingoTest::calNewValue()
{
  ;
}

// IDA_EA: 0x80CB07E
// IDA_NAME: _ZN10CBingoTest19getBingoRandomVauleEv
// DEMANGLED: CBingoTest::getBingoRandomVaule(void)
bool __cdecl CBingoTest::getBingoRandomVaule(CBingoTest *this)
{
  bool result; // al
  int n99; // [esp+1Ch] [ebp-1Ch]
  int n99_1; // [esp+20h] [ebp-18h]
  int n99_2; // [esp+24h] [ebp-14h]
  int n99_3; // [esp+28h] [ebp-10h]
  int n99_4; // [esp+2Ch] [ebp-Ch]

  for ( n99 = 0; n99 <= 99; ++n99 )
    CBingo::getBingoRandomVaule(this, 10);
  for ( n99_1 = 0; n99_1 <= 99; ++n99_1 )
    CBingo::getBingoRandomVaule(this, 20);
  for ( n99_2 = 0; n99_2 <= 99; ++n99_2 )
    CBingo::getBingoRandomVaule(this, 30);
  for ( n99_3 = 0; n99_3 <= 99; ++n99_3 )
    CBingo::getBingoRandomVaule(this, 40);
  for ( n99_4 = 0; ; ++n99_4 )
  {
    result = n99_4 <= 99;
    if ( n99_4 > 99 )
      break;
    CBingo::getBingoRandomVaule(this, 50);
  }
  return result;
}
