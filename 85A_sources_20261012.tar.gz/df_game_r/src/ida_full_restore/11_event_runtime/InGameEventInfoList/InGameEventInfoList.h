#ifndef __IDA91_INGAMEEVENTINFOLIST_H__
#define __IDA91_INGAMEEVENTINFOLIST_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: InGameEventInfoList
// Source unit: InGameEventInfoList
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4568

/* 4568 */
struct InGameEventInfoList;

// Exported member functions:
// 0x8110F10	InGameEventInfoList::InGameEventInfoList(void)
// 0x8110F24	InGameEventInfoList::~InGameEventInfoList()
// 0x897EB30	InGameEventInfoList::insertEventInfo(int,InGameEventInfo &)

// Function declaration index:
// DECL 0x8110F10 InGameEventInfoList::InGameEventInfoList
// DECL 0x8110F24 InGameEventInfoList::~InGameEventInfoList
// DECL 0x897EB30 InGameEventInfoList::insertEventInfo

#endif  // __IDA91_INGAMEEVENTINFOLIST_H__
