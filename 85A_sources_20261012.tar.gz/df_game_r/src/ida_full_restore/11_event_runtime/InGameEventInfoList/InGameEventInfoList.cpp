#include "InGameEventInfoList.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8110F10
// IDA_NAME: _ZN19InGameEventInfoListC2Ev
// DEMANGLED: InGameEventInfoList::InGameEventInfoList(void)
void __cdecl InGameEventInfoList::InGameEventInfoList(InGameEventInfoList *this)
{
  std::map<int,InGameEventInfo>::map(this);
}

// IDA_EA: 0x8110F24
// IDA_NAME: _ZN19InGameEventInfoListD2Ev
// DEMANGLED: InGameEventInfoList::~InGameEventInfoList()
void __cdecl InGameEventInfoList::~InGameEventInfoList(InGameEventInfoList *this)
{
  std::map<int,InGameEventInfo>::~map((int)this);
}

// IDA_EA: 0x897EB30
// IDA_NAME: _ZN19InGameEventInfoList15insertEventInfoEiR15InGameEventInfo
// DEMANGLED: InGameEventInfoList::insertEventInfo(int,InGameEventInfo &)
int __cdecl InGameEventInfoList::insertEventInfo(InGameEventInfoList *this, char a2, InGameEventInfo *a3)
{
  int v3; // eax

  v3 = std::map<int,InGameEventInfo>::operator[](this, &a2);
  return InGameEventInfo::operator=(v3, a3);
}
