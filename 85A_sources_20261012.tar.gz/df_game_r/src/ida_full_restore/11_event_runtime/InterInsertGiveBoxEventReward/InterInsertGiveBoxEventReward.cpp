#include "InterInsertGiveBoxEventReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8161A8A
// IDA_NAME: _ZN29InterInsertGiveBoxEventReward12dispatch_sigEP5CUserPci
// DEMANGLED: InterInsertGiveBoxEventReward::dispatch_sig(CUser *,char *,int)
int __cdecl InterInsertGiveBoxEventReward::dispatch_sig(InterInsertGiveBoxEventReward *this, CUser *a2, char *a3)
{
  int RepeatEvent; // eax
  CItemList **v5; // eax
  int ServerGroup; // ebx
  size_t v7; // esi
  int CurCharacNoEv; // eax
  char v9; // [esp+8h] [ebp-A0h]
  _BYTE v10[2]; // [esp+33h] [ebp-75h] BYREF
  int indexEv; // [esp+35h] [ebp-73h]
  int v12[4]; // [esp+70h] [ebp-38h] BYREF
  int v13[5]; // [esp+80h] [ebp-28h] BYREF
  CItem *item; // [esp+94h] [ebp-14h]
  char *src; // [esp+98h] [ebp-10h]
  char *s; // [esp+9Ch] [ebp-Ch]

  v13[4] = (int)a3;
  if ( a3 )
  {
    RepeatEvent = CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 165);
    if ( (*(unsigned __int8 (__cdecl **)(int, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) == 1 )
    {
      v5 = (CItemList **)G_CDataManager();
      item = (CItem *)CDataManager::find_item(v5, *(unsigned int *)EventGiveMeBox::kRewardItem_);
      if ( item )
      {
        Inven_Item::Inven_Item((Inven_Item *)v10);
        indexEv = CItem::get_index(item);
        (*(void (__cdecl **)(CItem *, _BYTE *))(*(_DWORD *)item + 8))(item, v10);
        Inven_Item::set_add_info((Inven_Item *)v10, 1);
        src = (char *)RDARScriptStringManager::findString(
                        (RDARScriptStringManager *)&g_scriptStringManager_,
                        4,
                        "tw_givemebox2_title",
                        0);
        s = (char *)RDARScriptStringManager::findString(
                      (RDARScriptStringManager *)&g_scriptStringManager_,
                      4,
                      "tw_givemebox2_mail",
                      0);
        ServerGroup = CUser::GetServerGroup(a2);
        v7 = strlen(s);
        CurCharacNoEv = CUserCharacInfo::getCurCharacNo(a2);
        WongWork::CMailBoxHelper::ReqDBSendNewSystemMail(
          src,
          (Inven_Item *)v10,
          0,
          CurCharacNoEv,
          s,
          v7,
          14,
          ServerGroup,
          0,
          0);
      }
      else
      {
        cMyTrace::cMyTrace(
          (cMyTrace *)v13,
          "virtual int InterInsertGiveBoxEventReward::dispatch_sig(CUser*, char*, int)",
          486,
          5);
        cMyTrace::operator()(
          (int)v13,
          "[Taiwan, GiveMeBoxEvent] Invalid item index. (%u)",
          EventGiveMeBox::kRewardItem_[0]);
      }
      return 0;
    }
    else
    {
      return 0;
    }
  }
  else
  {
    cMyTrace::cMyTrace(
      (cMyTrace *)v12,
      "virtual int InterInsertGiveBoxEventReward::dispatch_sig(CUser*, char*, int)",
      476,
      5);
    cMyTrace::operator()((int)v12, "[Taiwan, GiveMeBoxEvent] msg is null.", v9);
    return 477;
  }
}

// IDA_EA: 0x8162254
// IDA_NAME: _ZN29InterInsertGiveBoxEventRewardC2Ev
// DEMANGLED: InterInsertGiveBoxEventReward::InterInsertGiveBoxEventReward(void)
void __cdecl InterInsertGiveBoxEventReward::InterInsertGiveBoxEventReward(InterInsertGiveBoxEventReward *this)
{
  TaiwanInterfaceInterDispatcher::TaiwanInterfaceInterDispatcher(this, 16);
  *(_DWORD *)this = off_8B7AC30;
}

// IDA_EA: 0x8162278
// IDA_NAME: _ZN29InterInsertGiveBoxEventRewardD2Ev
// DEMANGLED: InterInsertGiveBoxEventReward::~InterInsertGiveBoxEventReward()
void __cdecl InterInsertGiveBoxEventReward::~InterInsertGiveBoxEventReward(InterInsertGiveBoxEventReward *this)
{
  *(_DWORD *)this = off_8B7AC30;
  TaiwanInterfaceInterDispatcher::~TaiwanInterfaceInterDispatcher(this);
}

// IDA_EA: 0x81622A8
// IDA_NAME: _ZN29InterInsertGiveBoxEventRewardD0Ev
// DEMANGLED: InterInsertGiveBoxEventReward::~InterInsertGiveBoxEventReward()
void __cdecl InterInsertGiveBoxEventReward::~InterInsertGiveBoxEventReward(InterInsertGiveBoxEventReward *this)
{
  InterInsertGiveBoxEventReward::~InterInsertGiveBoxEventReward(this);
  operator delete(this);
}
