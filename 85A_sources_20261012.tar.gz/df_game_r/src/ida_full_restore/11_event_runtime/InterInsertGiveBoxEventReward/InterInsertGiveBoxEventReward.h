#ifndef __IDA91_INTERINSERTGIVEBOXEVENTREWARD_H__
#define __IDA91_INTERINSERTGIVEBOXEVENTREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: InterInsertGiveBoxEventReward
// Source unit: InterInsertGiveBoxEventReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 1342

/* 1342 */
struct InterInsertGiveBoxEventReward;

// Exported member functions:
// 0x8161A8A	InterInsertGiveBoxEventReward::dispatch_sig(CUser *,char *,int)
// 0x8162254	InterInsertGiveBoxEventReward::InterInsertGiveBoxEventReward(void)
// 0x8162278	InterInsertGiveBoxEventReward::~InterInsertGiveBoxEventReward()
// 0x81622A8	InterInsertGiveBoxEventReward::~InterInsertGiveBoxEventReward()

// Function declaration index:
// DECL 0x8161A8A InterInsertGiveBoxEventReward::dispatch_sig
// DECL 0x8162254 InterInsertGiveBoxEventReward::InterInsertGiveBoxEventReward
// DECL 0x8162278 InterInsertGiveBoxEventReward::~InterInsertGiveBoxEventReward
// DECL 0x81622A8 InterInsertGiveBoxEventReward::~InterInsertGiveBoxEventReward

#endif  // __IDA91_INTERINSERTGIVEBOXEVENTREWARD_H__
