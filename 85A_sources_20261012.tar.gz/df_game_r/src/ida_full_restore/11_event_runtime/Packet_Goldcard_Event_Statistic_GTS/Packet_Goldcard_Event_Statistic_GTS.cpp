#include "Packet_Goldcard_Event_Statistic_GTS.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x85BEE96
// IDA_NAME: _ZN35Packet_Goldcard_Event_Statistic_GTSC2Ev
// DEMANGLED: Packet_Goldcard_Event_Statistic_GTS::Packet_Goldcard_Event_Statistic_GTS(void)
void __cdecl Packet_Goldcard_Event_Statistic_GTS::Packet_Goldcard_Event_Statistic_GTS(
        Packet_Goldcard_Event_Statistic_GTS *this)
{
  PacketHeader::PacketHeader(this, 0x1F46u, 0x13u);
  GoldCardEventStatistic::GoldCardEventStatistic((Packet_Goldcard_Event_Statistic_GTS *)((char *)this + 10));
}
