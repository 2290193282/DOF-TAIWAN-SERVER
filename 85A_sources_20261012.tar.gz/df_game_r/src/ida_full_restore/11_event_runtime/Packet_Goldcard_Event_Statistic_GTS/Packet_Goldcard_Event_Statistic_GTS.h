#ifndef __IDA91_PACKET_GOLDCARD_EVENT_STATISTIC_GTS_H__
#define __IDA91_PACKET_GOLDCARD_EVENT_STATISTIC_GTS_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Packet_Goldcard_Event_Statistic_GTS
// Source unit: Packet_Goldcard_Event_Statistic_GTS
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "network/PacketGuard.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 3337

/* 3337 */
struct Packet_Goldcard_Event_Statistic_GTS;

// Exported member functions:
// 0x85BEE96	Packet_Goldcard_Event_Statistic_GTS::Packet_Goldcard_Event_Statistic_GTS(void)

// Function declaration index:
// DECL 0x85BEE96 Packet_Goldcard_Event_Statistic_GTS::Packet_Goldcard_Event_Statistic_GTS

#endif  // __IDA91_PACKET_GOLDCARD_EVENT_STATISTIC_GTS_H__
