#include "STExpReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x85BED52
// IDA_NAME: _ZN11STExpRewardC2Ev
// DEMANGLED: STExpReward::STExpReward(void)
void __cdecl STExpReward::STExpReward(STExpReward *this)
{
  *((_BYTE *)this + 3) = 0;
  *((_BYTE *)this + 2) = *((_BYTE *)this + 3);
  *((_BYTE *)this + 1) = *((_BYTE *)this + 2);
  *(_BYTE *)this = *((_BYTE *)this + 1);
}

// IDA_EA: 0x8941CF6
// IDA_NAME: _ZN11STExpRewardD2Ev
// DEMANGLED: STExpReward::~STExpReward()
void STExpReward::~STExpReward()
{
  ;
}
