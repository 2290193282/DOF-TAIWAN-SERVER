#ifndef __IDA91_STEXPREWARD_H__
#define __IDA91_STEXPREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: STExpReward
// Source unit: STExpReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3331

/* 3331 */
struct STExpReward;

// Exported member functions:
// 0x85BED52	STExpReward::STExpReward(void)
// 0x8941CF6	STExpReward::~STExpReward()

// Function declaration index:
// DECL 0x85BED52 STExpReward::STExpReward
// DECL 0x8941CF6 STExpReward::~STExpReward

#endif  // __IDA91_STEXPREWARD_H__
