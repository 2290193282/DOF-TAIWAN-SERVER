#ifndef __IDA91_STTEMPREWARDINFO_H__
#define __IDA91_STTEMPREWARDINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stTempRewardInfo
// Source unit: stTempRewardInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3897

/* 3897 */
struct stTempRewardInfo;

// Exported member functions:
// 0x891B548	stTempRewardInfo::stTempRewardInfo(void)

// Function declaration index:
// DECL 0x891B548 stTempRewardInfo::stTempRewardInfo

#endif  // __IDA91_STTEMPREWARDINFO_H__
