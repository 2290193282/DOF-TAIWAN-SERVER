#include "stTempRewardInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x891B548
// IDA_NAME: _ZN16stTempRewardInfoC2Ev
// DEMANGLED: stTempRewardInfo::stTempRewardInfo(void)
void __cdecl stTempRewardInfo::stTempRewardInfo(stTempRewardInfo *this)
{
  *(_DWORD *)this = 3;
  *((_DWORD *)this + 1) = 1;
}
