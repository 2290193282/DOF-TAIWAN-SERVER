#include "STRewardDataList.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x831D412
// IDA_NAME: _ZN16STRewardDataListC2Ev
// DEMANGLED: STRewardDataList::STRewardDataList(void)
void __cdecl STRewardDataList::STRewardDataList(STRewardDataList *this)
{
  std::list<STRewardData>::list(this);
  std::list<STRewardData>::clear(this);
}

// IDA_EA: 0x831D55C
// IDA_NAME: _ZN16STRewardDataListD2Ev
// DEMANGLED: STRewardDataList::~STRewardDataList()
void __cdecl STRewardDataList::~STRewardDataList(STRewardDataList *this)
{
  std::list<STRewardData>::~list((int)this);
}

// IDA_EA: 0x831D7A0
// IDA_NAME: _ZN16STRewardDataListC2ERKS_
// DEMANGLED: STRewardDataList::STRewardDataList(STRewardDataList const&)
void __cdecl STRewardDataList::STRewardDataList(STRewardDataList *this, const STRewardDataList *a2)
{
  std::list<STRewardData>::list(this, a2);
}
