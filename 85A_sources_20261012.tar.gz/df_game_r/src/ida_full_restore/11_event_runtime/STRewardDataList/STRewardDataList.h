#ifndef __IDA91_STREWARDDATALIST_H__
#define __IDA91_STREWARDDATALIST_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: STRewardDataList
// Source unit: STRewardDataList
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4588

/* 4588 */
struct STRewardDataList;

// Exported member functions:
// 0x831D412	STRewardDataList::STRewardDataList(void)
// 0x831D55C	STRewardDataList::~STRewardDataList()
// 0x831D7A0	STRewardDataList::STRewardDataList(STRewardDataList const&)

// Function declaration index:
// DECL 0x831D412 STRewardDataList::STRewardDataList
// DECL 0x831D55C STRewardDataList::~STRewardDataList
// DECL 0x831D7A0 STRewardDataList::STRewardDataList

#endif  // __IDA91_STREWARDDATALIST_H__
