#ifndef __IDA91_CASSAULTONOFFEVENT_H__
#define __IDA91_CASSAULTONOFFEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CAssaultOnOffEvent
// Source unit: CAssaultOnOffEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4105

/* 4105 */
struct CAssaultOnOffEvent;

// Exported member functions:
// 0x811BAC2	CAssaultOnOffEvent::StartEvent(void)
// 0x811BB14	CAssaultOnOffEvent::StartEvent(Word_Param)
// 0x811BB2E	CAssaultOnOffEvent::EndEvent(void)
// 0x811BB80	CAssaultOnOffEvent::CAssaultOnOffEvent(void)
// 0x811BB9C	CAssaultOnOffEvent::~CAssaultOnOffEvent()
// 0x811BBCC	CAssaultOnOffEvent::~CAssaultOnOffEvent()

// Function declaration index:
// DECL 0x811BAC2 CAssaultOnOffEvent::StartEvent
// DECL 0x811BB14 CAssaultOnOffEvent::StartEvent
// DECL 0x811BB2E CAssaultOnOffEvent::EndEvent
// DECL 0x811BB80 CAssaultOnOffEvent::CAssaultOnOffEvent
// DECL 0x811BB9C CAssaultOnOffEvent::~CAssaultOnOffEvent
// DECL 0x811BBCC CAssaultOnOffEvent::~CAssaultOnOffEvent

#endif  // __IDA91_CASSAULTONOFFEVENT_H__
