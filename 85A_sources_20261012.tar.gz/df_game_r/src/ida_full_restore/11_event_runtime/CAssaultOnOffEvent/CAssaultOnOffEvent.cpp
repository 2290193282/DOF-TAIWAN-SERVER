#include "CAssaultOnOffEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x811BAC2
// IDA_NAME: _ZN18CAssaultOnOffEvent10StartEventEv
// DEMANGLED: CAssaultOnOffEvent::StartEvent(void)
int __cdecl CAssaultOnOffEvent::StartEvent(CAssaultOnOffEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CAssaultOnOffEvent::StartEvent()", 14, 0);
  return cMyTrace::operator()((int)v3, "Assault On Off Event Start!", v2);
}

// IDA_EA: 0x811BB14
// IDA_NAME: _ZN18CAssaultOnOffEvent10StartEventE10Word_Param
// DEMANGLED: CAssaultOnOffEvent::StartEvent(Word_Param)
int __cdecl CAssaultOnOffEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x811BB2E
// IDA_NAME: _ZN18CAssaultOnOffEvent8EndEventEv
// DEMANGLED: CAssaultOnOffEvent::EndEvent(void)
int __cdecl CAssaultOnOffEvent::EndEvent(CAssaultOnOffEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CAssaultOnOffEvent::EndEvent()", 24, 0);
  return cMyTrace::operator()((int)v3, "Assault On Off Event End!", v2);
}

// IDA_EA: 0x811BB80
// IDA_NAME: _ZN18CAssaultOnOffEventC2Ev
// DEMANGLED: CAssaultOnOffEvent::CAssaultOnOffEvent(void)
void __cdecl CAssaultOnOffEvent::CAssaultOnOffEvent(CAssaultOnOffEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B52288;
}

// IDA_EA: 0x811BB9C
// IDA_NAME: _ZN18CAssaultOnOffEventD2Ev
// DEMANGLED: CAssaultOnOffEvent::~CAssaultOnOffEvent()
void __cdecl CAssaultOnOffEvent::~CAssaultOnOffEvent(CAssaultOnOffEvent *this)
{
  *(_DWORD *)this = off_8B52288;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x811BBCC
// IDA_NAME: _ZN18CAssaultOnOffEventD0Ev
// DEMANGLED: CAssaultOnOffEvent::~CAssaultOnOffEvent()
void __cdecl CAssaultOnOffEvent::~CAssaultOnOffEvent(CAssaultOnOffEvent *this)
{
  CAssaultOnOffEvent::~CAssaultOnOffEvent(this);
  operator delete(this);
}
