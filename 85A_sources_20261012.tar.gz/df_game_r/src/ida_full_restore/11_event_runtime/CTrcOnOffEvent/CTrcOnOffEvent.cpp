#include "CTrcOnOffEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8285A44
// IDA_NAME: _ZN14CTrcOnOffEventC2Ev
// DEMANGLED: CTrcOnOffEvent::CTrcOnOffEvent(void)
void __cdecl CTrcOnOffEvent::CTrcOnOffEvent(CTrcOnOffEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8C0E428;
}

// IDA_EA: 0x8285A60
// IDA_NAME: _ZN14CTrcOnOffEventD2Ev
// DEMANGLED: CTrcOnOffEvent::~CTrcOnOffEvent()
void __cdecl CTrcOnOffEvent::~CTrcOnOffEvent(CTrcOnOffEvent *this)
{
  *(_DWORD *)this = off_8C0E428;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x8285A90
// IDA_NAME: _ZN14CTrcOnOffEventD0Ev
// DEMANGLED: CTrcOnOffEvent::~CTrcOnOffEvent()
void __cdecl CTrcOnOffEvent::~CTrcOnOffEvent(CTrcOnOffEvent *this)
{
  CTrcOnOffEvent::~CTrcOnOffEvent(this);
  operator delete(this);
}

// IDA_EA: 0x8285AAE
// IDA_NAME: _ZN14CTrcOnOffEvent10StartEventEv
// DEMANGLED: CTrcOnOffEvent::StartEvent(void)
int __cdecl CTrcOnOffEvent::StartEvent(CTrcOnOffEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 19, 0);
  return cMyTrace::operator()((int)v3, "Trc On Off Event Start!", v2);
}

// IDA_EA: 0x8285B00
// IDA_NAME: _ZN14CTrcOnOffEvent10StartEventE10Word_Param
// DEMANGLED: CTrcOnOffEvent::StartEvent(Word_Param)
int __cdecl CTrcOnOffEvent::StartEvent(CEventBase *a1)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 25, 0);
  return cMyTrace::operator()((int)v3, "Trc On Off Event Event Start!", v2);
}

// IDA_EA: 0x8285B52
// IDA_NAME: _ZN14CTrcOnOffEvent8EndEventEv
// DEMANGLED: CTrcOnOffEvent::EndEvent(void)
int __cdecl CTrcOnOffEvent::EndEvent(CTrcOnOffEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "EndEvent", 31, 0);
  return cMyTrace::operator()((int)v3, "Trc On Off Event Event End!", v2);
}

// IDA_EA: 0x8285BA4
// IDA_NAME: _ZNK14CTrcOnOffEvent10IsEventingEP5CUser
// DEMANGLED: CTrcOnOffEvent::IsEventing(CUser *)const
_BOOL4 __cdecl CTrcOnOffEvent::IsEventing(CTrcOnOffEvent *this)
{
  return (unsigned __int8)CEventBase::IsEventing(this) == 1;
}
