#ifndef __IDA91_CTRCONOFFEVENT_H__
#define __IDA91_CTRCONOFFEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CTrcOnOffEvent
// Source unit: CTrcOnOffEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 2164

/* 2164 */
struct CTrcOnOffEvent;

// Exported member functions:
// 0x8285A44	CTrcOnOffEvent::CTrcOnOffEvent(void)
// 0x8285A60	CTrcOnOffEvent::~CTrcOnOffEvent()
// 0x8285A90	CTrcOnOffEvent::~CTrcOnOffEvent()
// 0x8285AAE	CTrcOnOffEvent::StartEvent(void)
// 0x8285B00	CTrcOnOffEvent::StartEvent(Word_Param)
// 0x8285B52	CTrcOnOffEvent::EndEvent(void)
// 0x8285BA4	CTrcOnOffEvent::IsEventing(CUser *)const

// Function declaration index:
// DECL 0x8285A44 CTrcOnOffEvent::CTrcOnOffEvent
// DECL 0x8285A60 CTrcOnOffEvent::~CTrcOnOffEvent
// DECL 0x8285A90 CTrcOnOffEvent::~CTrcOnOffEvent
// DECL 0x8285AAE CTrcOnOffEvent::StartEvent
// DECL 0x8285B00 CTrcOnOffEvent::StartEvent
// DECL 0x8285B52 CTrcOnOffEvent::EndEvent
// DECL 0x8285BA4 CTrcOnOffEvent::IsEventing

#endif  // __IDA91_CTRCONOFFEVENT_H__
