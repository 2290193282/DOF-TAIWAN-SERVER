#include "Packet_Monitor_Event_Start.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84B4184
// IDA_NAME: _ZN26Packet_Monitor_Event_StartC2Ev
// DEMANGLED: Packet_Monitor_Event_Start::Packet_Monitor_Event_Start(void)
void __cdecl Packet_Monitor_Event_Start::Packet_Monitor_Event_Start(Packet_Monitor_Event_Start *this)
{
  PacketHeader::PacketHeader(this, 0x44Fu, 0x12u);
}
