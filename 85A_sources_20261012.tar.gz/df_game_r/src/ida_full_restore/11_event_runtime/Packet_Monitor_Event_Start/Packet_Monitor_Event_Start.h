#ifndef __IDA91_PACKET_MONITOR_EVENT_START_H__
#define __IDA91_PACKET_MONITOR_EVENT_START_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Packet_Monitor_Event_Start
// Source unit: Packet_Monitor_Event_Start
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "network/PacketGuard.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 2893

/* 2893 */
struct Packet_Monitor_Event_Start;

// Exported member functions:
// 0x84B4184	Packet_Monitor_Event_Start::Packet_Monitor_Event_Start(void)

// Function declaration index:
// DECL 0x84B4184 Packet_Monitor_Event_Start::Packet_Monitor_Event_Start

#endif  // __IDA91_PACKET_MONITOR_EVENT_START_H__
