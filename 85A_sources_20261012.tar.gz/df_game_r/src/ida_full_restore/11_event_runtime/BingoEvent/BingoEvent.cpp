#include "BingoEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x80C9984
// IDA_NAME: _ZN10BingoEventC2Ev
// DEMANGLED: BingoEvent::BingoEvent(void)
void __cdecl BingoEvent::BingoEvent(BingoEvent *this)
{
  CBingo *v1; // ebx

  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B27E48;
  v1 = (CBingo *)operator new(0x1Cu);
  CBingo::CBingo(v1);
  boost::shared_ptr<CBingo>::shared_ptr<CBingo>((int)this + 12, v1);
}

// IDA_EA: 0x80C9A06
// IDA_NAME: _ZN10BingoEventD2Ev
// DEMANGLED: BingoEvent::~BingoEvent()
void __cdecl BingoEvent::~BingoEvent(BingoEvent *this)
{
  *(_DWORD *)this = off_8B27E48;
  boost::shared_ptr<CBingo>::~shared_ptr((char *)this + 12);
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x80C9A68
// IDA_NAME: _ZN10BingoEventD0Ev
// DEMANGLED: BingoEvent::~BingoEvent()
void __cdecl BingoEvent::~BingoEvent(BingoEvent *this)
{
  BingoEvent::~BingoEvent(this);
  operator delete(this);
}

// IDA_EA: 0x80C9A86
// IDA_NAME: _ZN10BingoEvent10StartEventEv
// DEMANGLED: BingoEvent::StartEvent(void)
int __cdecl BingoEvent::StartEvent(BingoEvent *this)
{
  CBingo *v1; // eax
  int TodayEli; // eax
  CBingo *v3; // eax
  CBingo *v4; // eax
  int v5[4]; // [esp+14h] [ebp-24h] BYREF
  int v6; // [esp+24h] [ebp-14h]
  time_t timer; // [esp+28h] [ebp-10h]
  char v8[4]; // [esp+2Ch] [ebp-Ch]

  CEventBase::SetEventFlag(this, 1);
  v6 = *(_DWORD *)(G_CEnvironment() + 892);
  timer = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
  v1 = (CBingo *)boost::shared_ptr<CBingo>::operator->((char *)this + 12);
  TodayEli = CBingo::getToday(v1, timer, v6);
  *(_DWORD *)v8 = TodayEli;
  if ( TodayEli > 0 && *(int *)v8 <= 31 )
  {
    v3 = (CBingo *)boost::shared_ptr<CBingo>::operator->((char *)this + 12);
    CBingo::resetBoard(v3, *(int *)v8);
    v4 = (CBingo *)boost::shared_ptr<CBingo>::operator->((char *)this + 12);
    CBingo::resetQuiz(v4, *(int *)v8);
    cMyTrace::cMyTrace((cMyTrace *)v5, "virtual void BingoEvent::StartEvent()", 42, 0);
    return cMyTrace::operator()((int)v5, "BingoEvent Day(%d)", v8[0]);
  }
  return TodayEli;
}

// IDA_EA: 0x80C9B68
// IDA_NAME: _ZN10BingoEvent10StartEventE10Word_Param
// DEMANGLED: BingoEvent::StartEvent(Word_Param)
int __cdecl BingoEvent::StartEvent(int a1)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  (*(void (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void BingoEvent::StartEvent(Word_Param)", 48, 0);
  return cMyTrace::operator()((int)v3, "BingoEvent Event Start!", v2);
}

// IDA_EA: 0x80C9BB8
// IDA_NAME: _ZN10BingoEvent11StartActionEv
// DEMANGLED: BingoEvent::StartAction(void)
int BingoEvent::StartAction()
{
  int result; // eax
  int v1; // [esp+4h] [ebp-44h]
  _BYTE *v2; // [esp+4h] [ebp-44h]
  _BYTE *v3; // [esp+4h] [ebp-44h]
  bool *v4; // [esp+4h] [ebp-44h]
  char v5; // [esp+1Fh] [ebp-29h] BYREF
  _BYTE v6[4]; // [esp+20h] [ebp-28h] BYREF
  _BYTE v7[4]; // [esp+24h] [ebp-24h] BYREF
  _BYTE v8[4]; // [esp+28h] [ebp-20h] BYREF
  _BYTE *v9; // [esp+2Ch] [ebp-1Ch]
  _BYTE *v10; // [esp+30h] [ebp-18h]
  _BYTE *v11; // [esp+34h] [ebp-14h]
  int v12; // [esp+38h] [ebp-10h]
  CUser *v13; // [esp+3Ch] [ebp-Ch]

  v1 = G_CGameManager() + 556;
  boost::foreach_detail_::contain<std::map<unsigned int,CUser *>>((boost::foreach_detail_::auto_any_base *)v6);
  v9 = v6;
  result = boost::foreach_detail_::auto_any_base::operator bool(v6, v1, 0);
  if ( !(_BYTE)result )
  {
    v2 = v9;
    boost::foreach_detail_::begin<std::map<unsigned int,CUser *>,mpl_::bool_<false>>((boost::foreach_detail_::auto_any_base *)v7);
    v10 = v7;
    result = boost::foreach_detail_::auto_any_base::operator bool(v7, v2, 0);
    if ( !(_BYTE)result )
    {
      v3 = v9;
      boost::foreach_detail_::end<std::map<unsigned int,CUser *>,mpl_::bool_<false>>((boost::foreach_detail_::auto_any_base *)v8);
      v11 = v8;
      result = boost::foreach_detail_::auto_any_base::operator bool(v8, v3, 0);
      if ( !(_BYTE)result )
      {
        v5 = 1;
        while ( 1 )
        {
          result = v5
                && (unsigned __int8)boost::foreach_detail_::done<std::map<unsigned int,CUser *>,mpl_::bool_<false>>(
                                      v10,
                                      v11) != 1;
          if ( !(_BYTE)result )
            break;
          if ( !(unsigned __int8)boost::foreach_detail_::set_false((boost::foreach_detail_ *)&v5, v4) )
          {
            v4 = 0;
            v12 = boost::foreach_detail_::deref<std::map<unsigned int,CUser *>,mpl_::bool_<false>>(v10);
            while ( v5 != 1 )
            {
              v13 = *(CUser **)(v12 + 4);
              if ( v13 )
                CUser::sendBingoData(v13);
              v5 = 1;
            }
          }
          if ( v5 )
          {
            v4 = 0;
            boost::foreach_detail_::next<std::map<unsigned int,CUser *>,mpl_::bool_<false>>(v10);
          }
        }
      }
    }
  }
  return result;
}

// IDA_EA: 0x80C9D30
// IDA_NAME: _ZN10BingoEvent8EndEventEv
// DEMANGLED: BingoEvent::EndEvent(void)
int __cdecl BingoEvent::EndEvent(BingoEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void BingoEvent::EndEvent()", 63, 0);
  return cMyTrace::operator()((int)v3, "BingoEvent Event End!", v2);
}

// IDA_EA: 0x80C9D82
// IDA_NAME: _ZN10BingoEvent14dailyresetDataEv
// DEMANGLED: BingoEvent::dailyresetData(void)
int __cdecl BingoEvent::dailyresetData(BingoEvent *this)
{
  CBingo *v1; // eax
  CBingo *v2; // eax
  CBingo *v3; // eax
  int result; // eax
  BingoData *BingoDataEv; // eax
  int v6; // [esp+4h] [ebp-54h]
  _BYTE *v7; // [esp+4h] [ebp-54h]
  _BYTE *v8; // [esp+4h] [ebp-54h]
  bool *v9; // [esp+4h] [ebp-54h]
  char v10; // [esp+13h] [ebp-45h] BYREF
  int v11[4]; // [esp+14h] [ebp-44h] BYREF
  _BYTE v12[4]; // [esp+24h] [ebp-34h] BYREF
  _BYTE v13[4]; // [esp+28h] [ebp-30h] BYREF
  _BYTE v14[4]; // [esp+2Ch] [ebp-2Ch] BYREF
  int v15; // [esp+30h] [ebp-28h]
  time_t timer; // [esp+34h] [ebp-24h]
  char v17[4]; // [esp+38h] [ebp-20h]
  _BYTE *v18; // [esp+3Ch] [ebp-1Ch]
  _BYTE *v19; // [esp+40h] [ebp-18h]
  _BYTE *v20; // [esp+44h] [ebp-14h]
  int v21; // [esp+48h] [ebp-10h]
  CUser *v22; // [esp+4Ch] [ebp-Ch]

  v15 = *(_DWORD *)(G_CEnvironment() + 892);
  timer = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
  v1 = (CBingo *)boost::shared_ptr<CBingo>::operator->((char *)this + 12);
  *(_DWORD *)v17 = CBingo::getToday(v1, timer, v15);
  if ( *(int *)v17 > 0 && *(int *)v17 <= 31 )
  {
    v2 = (CBingo *)boost::shared_ptr<CBingo>::operator->((char *)this + 12);
    CBingo::resetBoard(v2, *(int *)v17);
    v3 = (CBingo *)boost::shared_ptr<CBingo>::operator->((char *)this + 12);
    CBingo::resetQuiz(v3, *(int *)v17);
    cMyTrace::cMyTrace((cMyTrace *)v11, "virtual void BingoEvent::dailyresetData()", 80, 0);
    cMyTrace::operator()((int)v11, "BingoEvent Day(%d)", v17[0]);
  }
  v6 = G_CGameManager() + 556;
  boost::foreach_detail_::contain<std::map<unsigned int,CUser *>>((boost::foreach_detail_::auto_any_base *)v12);
  v18 = v12;
  result = boost::foreach_detail_::auto_any_base::operator bool(v12, v6, 0);
  if ( !(_BYTE)result )
  {
    v7 = v18;
    boost::foreach_detail_::begin<std::map<unsigned int,CUser *>,mpl_::bool_<false>>((boost::foreach_detail_::auto_any_base *)v13);
    v19 = v13;
    result = boost::foreach_detail_::auto_any_base::operator bool(v13, v7, 0);
    if ( !(_BYTE)result )
    {
      v8 = v18;
      boost::foreach_detail_::end<std::map<unsigned int,CUser *>,mpl_::bool_<false>>((boost::foreach_detail_::auto_any_base *)v14);
      v20 = v14;
      result = boost::foreach_detail_::auto_any_base::operator bool(v14, v8, 0);
      if ( !(_BYTE)result )
      {
        v10 = 1;
        while ( 1 )
        {
          result = v10
                && (unsigned __int8)boost::foreach_detail_::done<std::map<unsigned int,CUser *>,mpl_::bool_<false>>(
                                      v19,
                                      v20) != 1;
          if ( !(_BYTE)result )
            break;
          if ( !(unsigned __int8)boost::foreach_detail_::set_false((boost::foreach_detail_ *)&v10, v9) )
          {
            v9 = 0;
            v21 = boost::foreach_detail_::deref<std::map<unsigned int,CUser *>,mpl_::bool_<false>>(v19);
            while ( v10 != 1 )
            {
              v22 = *(CUser **)(v21 + 4);
              if ( v22 )
              {
                BingoDataEv = (BingoData *)CUser::getBingoData(v22);
                BingoData::clear(BingoDataEv);
                CUser::sendBingoData(v22);
                CUser::sendDecorationObjectCnt(v22, 0);
              }
              v10 = 1;
            }
          }
          if ( v10 )
          {
            v9 = 0;
            boost::foreach_detail_::next<std::map<unsigned int,CUser *>,mpl_::bool_<false>>(v19);
          }
        }
      }
    }
  }
  return result;
}

// IDA_EA: 0x80C9FEA
// IDA_NAME: _ZN10BingoEvent14getBingoSystemEv
// DEMANGLED: BingoEvent::getBingoSystem(void)
char *__cdecl BingoEvent::getBingoSystem(BingoEvent *this)
{
  return (char *)this + 12;
}

// IDA_EA: 0x80C9FF6
// IDA_NAME: _ZN10BingoEvent12reqBingoMarkERN15StackableAction11input_paramE
// DEMANGLED: BingoEvent::reqBingoMark(StackableAction::input_param &)
int __cdecl BingoEvent::reqBingoMark(BingoEvent *a1, int a2)
{
  int v2; // ebx
  CBingo *v3; // eax
  unsigned int *BingoDataEv; // ebx
  CBingo *v5; // eax
  int n3; // eax
  int *BingoDataEv_1; // eax
  PacketBuf *v9[3]; // [esp+1Ch] [ebp-2Ch] BYREF
  int n50; // [esp+28h] [ebp-20h]
  int BingoRandomVauleEi; // [esp+2Ch] [ebp-1Ch]
  int v12; // [esp+30h] [ebp-18h]
  int v13; // [esp+34h] [ebp-14h]
  int n3_1; // [esp+38h] [ebp-10h]
  int n3_2; // [esp+3Ch] [ebp-Ch]

  if ( !*(_DWORD *)(a2 + 8) )
    return 19;
  if ( !*(_DWORD *)(a2 + 12) )
    return 19;
  if ( *(char *)(CUser::getBingoData(*(CUser **)(a2 + 8)) + 4) > 2 )
    return 7;
  n50 = *(_DWORD *)std::vector<int>::operator[]((_DWORD *)(*(_DWORD *)(a2 + 12) + 928), 0);
  if ( n50 <= 0 || n50 > 50 )
    return 23;
  v3 = (CBingo *)boost::shared_ptr<CBingo>::operator->((char *)a1 + 12);
  BingoRandomVauleEi = CBingo::getBingoRandomVaule(v3, n50);
  if ( !BingoRandomVauleEi )
    return 19;
  v12 = *(_DWORD *)CUser::getBingoData(*(CUser **)(a2 + 8));
  BingoDataEv = (unsigned int *)CUser::getBingoData(*(CUser **)(a2 + 8));
  v5 = (CBingo *)boost::shared_ptr<CBingo>::operator->((char *)a1 + 12);
  v13 = CBingo::calNewValue(v5, BingoDataEv, BingoRandomVauleEi);
  if ( *(_DWORD *)CUser::getBingoData(*(CUser **)(a2 + 8)) != v12 )
  {
    *(_BYTE *)(CUser::getBingoData(*(CUser **)(a2 + 8)) + 6) = 1;
    n3_1 = v13 - *(char *)(CUser::getBingoData(*(CUser **)(a2 + 8)) + 4);
    if ( n3_1 > 0 )
    {
      n3 = n3_1;
      if ( n3_1 > 3 )
        n3 = 3;
      n3_1 = n3;
      *(_BYTE *)(CUser::getBingoData(*(CUser **)(a2 + 8)) + 4) = v13;
      for ( n3_2 = 0; n3_2 < n3_1; ++n3_2 )
        BingoEvent::sendOneMatchLineReward(a1, *(CUser **)(a2 + 8));
    }
  }
  PacketGuard::PacketGuard((PacketGuard *)v9);
  InterfacePacketBuf::clear((InterfacePacketBuf *)v9);
  InterfacePacketBuf::put_header(v9, 0, 451);
  InterfacePacketBuf::put_byte((InterfacePacketBuf *)v9, BingoRandomVauleEi);
  BingoDataEv_1 = (int *)CUser::getBingoData(*(CUser **)(a2 + 8));
  InterfacePacketBuf::put_int((InterfacePacketBuf *)v9, *BingoDataEv_1);
  InterfacePacketBuf::finalize((InterfacePacketBuf *)v9, 1);
  CUser::Send(*(CUser **)(a2 + 8), (PacketGuard *)v9);
  v2 = 0;
  PacketGuard::~PacketGuard(v9);
  return v2;
}

// IDA_EA: 0x80CA262
// IDA_NAME: _ZN10BingoEvent16reqBingoQuizMarkER5CUseri
// DEMANGLED: BingoEvent::reqBingoQuizMark(CUser &,int)
int __cdecl BingoEvent::reqBingoQuizMark(BingoEvent *this, CUser *a2, int QuizValueEv)
{
  CBingo *v3; // eax
  CBingo *v5; // eax
  unsigned int *BingoDataEv; // eax
  unsigned int *BingoDataEv_1; // ebx
  CBingo *v8; // eax
  int BingoDataEv_2; // eax
  int n3; // eax
  int QuizIndexEv; // [esp+1Ch] [ebp-1Ch]
  int v12; // [esp+20h] [ebp-18h]
  int v13; // [esp+24h] [ebp-14h]
  int n3_1; // [esp+28h] [ebp-10h]
  int n3_2; // [esp+28h] [ebp-10h]
  int n3_3; // [esp+2Ch] [ebp-Ch]

  v3 = (CBingo *)boost::shared_ptr<CBingo>::operator->((char *)this + 12);
  if ( CBingo::getQuizValue(v3) != QuizValueEv )
    return 23;
  v5 = (CBingo *)boost::shared_ptr<CBingo>::operator->((char *)this + 12);
  QuizIndexEv = CBingo::getQuizIndex(v5);
  BingoDataEv = (unsigned int *)CUser::getBingoData(a2);
  if ( (unsigned __int8)isSetBit_Uint(*BingoDataEv, QuizIndexEv) )
    return 18;
  v12 = *(_DWORD *)CUser::getBingoData(a2);
  BingoDataEv_1 = (unsigned int *)CUser::getBingoData(a2);
  v8 = (CBingo *)boost::shared_ptr<CBingo>::operator->((char *)this + 12);
  v13 = CBingo::calNewValue(v8, BingoDataEv_1, 0);
  if ( *(_DWORD *)CUser::getBingoData(a2) != v12 )
  {
    *(_BYTE *)(CUser::getBingoData(a2) + 6) = 1;
    BingoDataEv_2 = CUser::getBingoData(a2);
    n3_1 = v13 - *(char *)(BingoDataEv_2 + 4);
    if ( n3_1 > 0 )
    {
      n3 = v13 - *(char *)(BingoDataEv_2 + 4);
      if ( n3_1 > 3 )
        n3 = 3;
      n3_2 = n3;
      *(_BYTE *)(CUser::getBingoData(a2) + 4) = v13;
      for ( n3_3 = 0; n3_3 < n3_2; ++n3_3 )
        BingoEvent::sendOneMatchLineReward(this, a2);
    }
  }
  return 0;
}

// IDA_EA: 0x80CA3D4
// IDA_NAME: _ZN10BingoEvent22sendOneMatchLineRewardER5CUser
// DEMANGLED: BingoEvent::sendOneMatchLineReward(CUser &)
int __cdecl BingoEvent::sendOneMatchLineReward(BingoEvent *this, CUser *a2)
{
  int result; // eax
  CItemList **v3; // eax
  const char *src; // eax
  const char *src_1; // eax
  int ServerGroup; // ebx
  size_t v7; // esi
  int CurCharacNoEv; // eax
  const char *v9; // [esp+14h] [ebp-194h]
  char s[256]; // [esp+32h] [ebp-176h] BYREF
  _BYTE v11[2]; // [esp+132h] [ebp-76h] BYREF
  int n2_1; // [esp+134h] [ebp-74h]
  int v13; // [esp+139h] [ebp-6Fh]
  __int16 v14; // [esp+13Dh] [ebp-6Bh]
  char dest[21]; // [esp+16Fh] [ebp-39h] BYREF
  _BYTE v16[4]; // [esp+184h] [ebp-24h] BYREF
  int v17; // [esp+188h] [ebp-20h] BYREF
  _BYTE v18[4]; // [esp+18Ch] [ebp-1Ch] BYREF
  int n2; // [esp+190h] [ebp-18h]
  int v20; // [esp+194h] [ebp-14h]
  int v21; // [esp+198h] [ebp-10h]
  int v22; // [esp+19Ch] [ebp-Ch]

  v17 = 1;
  G_CDataManager();
  std::map<int,std::pair<int,int>>::find(v16);
  G_CDataManager();
  std::map<int,std::pair<int,int>>::end(v18);
  if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,std::pair<int,int>>>::operator==(v16, v18) )
    return LogManager::logFormat(
             (LogManager *)1,
             (int)"BingoEvent.cpp",
             "void BingoEvent::sendOneMatchLineReward(CUser&)",
             (const char *)0xC0,
             "bingo script error",
             v9);
  n2 = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,std::pair<int,int>>>::operator->(v16) + 4);
  v20 = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,std::pair<int,int>>>::operator->(v16) + 8);
  Inven_Item::Inven_Item((Inven_Item *)v11);
  v21 = 0;
  if ( n2 )
  {
    if ( n2 == 1 )
    {
      n2_1 = 1;
      v11[1] = 2;
      v13 = v20;
      v14 = 1;
      Inven_Item::ResetItemAttr((Inven_Item *)v11);
    }
    else
    {
      v3 = (CItemList **)G_CDataManager();
      result = CDataManager::find_item(v3, n2);
      v22 = result;
      if ( !result )
        return result;
      n2_1 = n2;
      (*(void (__cdecl **)(int, _BYTE *, int *))(*(_DWORD *)v22 + 8))(v22, v11, &v17);
      Inven_Item::set_add_info((Inven_Item *)v11, v20);
    }
  }
  else
  {
    v21 = v20;
  }
  src = (const char *)RDARScriptStringManager::findString(
                        (RDARScriptStringManager *)&g_scriptStringManager_,
                        4,
                        "game_server_msg_292",
                        0);
  strncpy(dest, src, 0x14u);
  src_1 = (const char *)RDARScriptStringManager::findString(
                          (RDARScriptStringManager *)&g_scriptStringManager_,
                          4,
                          "game_server_msg_293",
                          0);
  strncpy(s, src_1, 0xFFu);
  ServerGroup = CUser::GetServerGroup(a2);
  v7 = strlen(s);
  CurCharacNoEv = CUserCharacInfo::getCurCharacNo(a2);
  return WongWork::CMailBoxHelper::ReqDBSendNewSystemMail(
           dest,
           (Inven_Item *)v11,
           v21,
           CurCharacNoEv,
           s,
           v7,
           0,
           ServerGroup,
           0,
           0);
}

// IDA_EA: 0x80CA622
// IDA_NAME: _ZN10BingoEvent22sendMaxMatchLineRewardER5CUser
// DEMANGLED: BingoEvent::sendMaxMatchLineReward(CUser &)
int __cdecl BingoEvent::sendMaxMatchLineReward(BingoEvent *this, CUser *a2)
{
  int result; // eax
  CItemList **v3; // eax
  const char *src; // eax
  const char *src_1; // eax
  int ServerGroup; // ebx
  size_t v7; // esi
  int CurCharacNoEv; // eax
  const char *v9; // [esp+14h] [ebp-194h]
  char s[256]; // [esp+3Ah] [ebp-16Eh] BYREF
  _BYTE v11[2]; // [esp+13Ah] [ebp-6Eh] BYREF
  int n2_1; // [esp+13Ch] [ebp-6Ch]
  char dest[21]; // [esp+177h] [ebp-31h] BYREF
  _BYTE v14[4]; // [esp+18Ch] [ebp-1Ch] BYREF
  _BYTE v15[4]; // [esp+190h] [ebp-18h] BYREF
  int n2; // [esp+194h] [ebp-14h]
  int v17; // [esp+198h] [ebp-10h]
  int v18; // [esp+19Ch] [ebp-Ch]

  G_CDataManager();
  std::map<int,std::pair<int,int>>::find(v14);
  G_CDataManager();
  std::map<int,std::pair<int,int>>::end(v15);
  if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,std::pair<int,int>>>::operator==(v14, v15) )
    return LogManager::logFormat(
             (LogManager *)1,
             (int)"BingoEvent.cpp",
             "void BingoEvent::sendMaxMatchLineReward(CUser&)",
             (const char *)0xEF,
             "bingo script error",
             v9);
  n2 = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,std::pair<int,int>>>::operator->(v14) + 4);
  v17 = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,std::pair<int,int>>>::operator->(v14) + 8);
  Inven_Item::Inven_Item((Inven_Item *)v11);
  v3 = (CItemList **)G_CDataManager();
  result = CDataManager::find_item(v3, n2);
  v18 = result;
  if ( result )
  {
    n2_1 = n2;
    (*(void (__cdecl **)(int, _BYTE *, void *))(*(_DWORD *)v18 + 8))(v18, v11, &kMaxMatchLine);
    Inven_Item::set_add_info((Inven_Item *)v11, v17);
    src = (const char *)RDARScriptStringManager::findString(
                          (RDARScriptStringManager *)&g_scriptStringManager_,
                          4,
                          "game_server_msg_292",
                          0);
    strncpy(dest, src, 0x14u);
    src_1 = (const char *)RDARScriptStringManager::findString(
                            (RDARScriptStringManager *)&g_scriptStringManager_,
                            4,
                            "game_server_msg_294",
                            0);
    strncpy(s, src_1, 0xFFu);
    ServerGroup = CUser::GetServerGroup(a2);
    v7 = strlen(s);
    CurCharacNoEv = CUserCharacInfo::getCurCharacNo(a2);
    return WongWork::CMailBoxHelper::ReqDBSendNewSystemMail(
             dest,
             (Inven_Item *)v11,
             0,
             CurCharacNoEv,
             s,
             v7,
             0,
             ServerGroup,
             0,
             0);
  }
  return result;
}
