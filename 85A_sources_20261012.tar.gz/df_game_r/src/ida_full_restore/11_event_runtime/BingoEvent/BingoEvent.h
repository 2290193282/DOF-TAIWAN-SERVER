#ifndef __IDA91_BINGOEVENT_H__
#define __IDA91_BINGOEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: BingoEvent
// Source unit: BingoEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 1092

/* 1092 */
struct BingoEvent;

// Exported member functions:
// 0x80C9984	BingoEvent::BingoEvent(void)
// 0x80C9A06	BingoEvent::~BingoEvent()
// 0x80C9A68	BingoEvent::~BingoEvent()
// 0x80C9A86	BingoEvent::StartEvent(void)
// 0x80C9B68	BingoEvent::StartEvent(Word_Param)
// 0x80C9BB8	BingoEvent::StartAction(void)
// 0x80C9D30	BingoEvent::EndEvent(void)
// 0x80C9D82	BingoEvent::dailyresetData(void)
// 0x80C9FEA	BingoEvent::getBingoSystem(void)
// 0x80C9FF6	BingoEvent::reqBingoMark(StackableAction::input_param &)
// 0x80CA262	BingoEvent::reqBingoQuizMark(CUser &,int)
// 0x80CA3D4	BingoEvent::sendOneMatchLineReward(CUser &)
// 0x80CA622	BingoEvent::sendMaxMatchLineReward(CUser &)

// Function declaration index:
// DECL 0x80C9984 BingoEvent::BingoEvent
// DECL 0x80C9A06 BingoEvent::~BingoEvent
// DECL 0x80C9A68 BingoEvent::~BingoEvent
// DECL 0x80C9A86 BingoEvent::StartEvent
// DECL 0x80C9B68 BingoEvent::StartEvent
// DECL 0x80C9BB8 BingoEvent::StartAction
// DECL 0x80C9D30 BingoEvent::EndEvent
// DECL 0x80C9D82 BingoEvent::dailyresetData
// DECL 0x80C9FEA BingoEvent::getBingoSystem
// DECL 0x80C9FF6 BingoEvent::reqBingoMark
// DECL 0x80CA262 BingoEvent::reqBingoQuizMark
// DECL 0x80CA3D4 BingoEvent::sendOneMatchLineReward
// DECL 0x80CA622 BingoEvent::sendMaxMatchLineReward

#endif  // __IDA91_BINGOEVENT_H__
