#ifndef __IDA91_STTITLEREWARDBASIS_H__
#define __IDA91_STTITLEREWARDBASIS_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stTitleRewardBasis
// Source unit: stTitleRewardBasis
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4049

/* 4049 */
struct stTitleRewardBasis;

// Exported member functions:
// 0x8AA9632	stTitleRewardBasis::stTitleRewardBasis(void)
// 0x8AA9652	stTitleRewardBasis::~stTitleRewardBasis()

// Function declaration index:
// DECL 0x8AA9632 stTitleRewardBasis::stTitleRewardBasis
// DECL 0x8AA9652 stTitleRewardBasis::~stTitleRewardBasis

#endif  // __IDA91_STTITLEREWARDBASIS_H__
