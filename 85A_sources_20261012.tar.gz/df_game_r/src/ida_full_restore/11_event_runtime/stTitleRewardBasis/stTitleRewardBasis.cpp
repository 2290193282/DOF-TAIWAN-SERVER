#include "stTitleRewardBasis.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8AA9632
// IDA_NAME: _ZN18stTitleRewardBasisC2Ev
// DEMANGLED: stTitleRewardBasis::stTitleRewardBasis(void)
void __cdecl stTitleRewardBasis::stTitleRewardBasis(stTitleRewardBasis *this)
{
  *(_DWORD *)this = 4;
  *((_BYTE *)this + 4) = 0;
  *((_DWORD *)this + 2) = 0;
}

// IDA_EA: 0x8AA9652
// IDA_NAME: _ZN18stTitleRewardBasisD2Ev
// DEMANGLED: stTitleRewardBasis::~stTitleRewardBasis()
void __cdecl stTitleRewardBasis::~stTitleRewardBasis(stTitleRewardBasis *this)
{
  if ( *((_DWORD *)this + 2) )
    (*(void (__cdecl **)(_DWORD))(**((_DWORD **)this + 2) + 12))(*((_DWORD *)this + 2));
  *((_DWORD *)this + 2) = 0;
}
