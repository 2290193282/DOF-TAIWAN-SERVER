#ifndef __IDA91_LEVELUPREWARDITEMTABLEKEY_H__
#define __IDA91_LEVELUPREWARDITEMTABLEKEY_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: LevelUpRewardItemTableKey
// Source unit: LevelUpRewardItemTableKey
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 1474

/* 1474 */
struct LevelUpRewardItemTableKey;

// Exported member functions:
// 0x81B8830	LevelUpRewardItemTableKey::operator<(LevelUpRewardItemTableKey const&)const
// 0x81B8896	LevelUpRewardItemTableKey::LevelUpRewardItemTableKey(int,int,int)
// 0x891BAC0	LevelUpRewardItemTableKey::LevelUpRewardItemTableKey(void)
// 0x891BAD4	LevelUpRewardItemTableKey::clear(void)

// Function declaration index:
// DECL 0x81B8830 LevelUpRewardItemTableKey::operator<
// DECL 0x81B8896 LevelUpRewardItemTableKey::LevelUpRewardItemTableKey
// DECL 0x891BAC0 LevelUpRewardItemTableKey::LevelUpRewardItemTableKey
// DECL 0x891BAD4 LevelUpRewardItemTableKey::clear

#endif  // __IDA91_LEVELUPREWARDITEMTABLEKEY_H__
