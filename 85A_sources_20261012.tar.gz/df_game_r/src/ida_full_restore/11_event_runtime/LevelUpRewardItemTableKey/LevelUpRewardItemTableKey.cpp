#include "LevelUpRewardItemTableKey.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81B8830
// IDA_NAME: _ZNK25LevelUpRewardItemTableKeyltERKS_
// DEMANGLED: LevelUpRewardItemTableKey::operator<(LevelUpRewardItemTableKey const&)const
bool __cdecl LevelUpRewardItemTableKey::operator<(int a1, int a2)
{
  if ( *(_BYTE *)(a1 + 2) != *(_BYTE *)(a2 + 2) )
    return *(_BYTE *)(a1 + 2) < *(_BYTE *)(a2 + 2);
  if ( *(_BYTE *)(a1 + 3) == *(_BYTE *)(a2 + 3) )
    return *(_WORD *)a1 < *(_WORD *)a2;
  return *(_BYTE *)(a1 + 3) < *(_BYTE *)(a2 + 3);
}

// IDA_EA: 0x81B8896
// IDA_NAME: _ZN25LevelUpRewardItemTableKeyC2Eiii
// DEMANGLED: LevelUpRewardItemTableKey::LevelUpRewardItemTableKey(int,int,int)
void __cdecl LevelUpRewardItemTableKey::LevelUpRewardItemTableKey(
        LevelUpRewardItemTableKey *this,
        __int16 charac_levelEv,
        char charac_jobEv,
        char CurCharFirstGrowTypeEv)
{
  *(_WORD *)this = charac_levelEv;
  *((_BYTE *)this + 2) = charac_jobEv;
  *((_BYTE *)this + 3) = CurCharFirstGrowTypeEv;
}

// IDA_EA: 0x891BAC0
// IDA_NAME: _ZN25LevelUpRewardItemTableKeyC2Ev
// DEMANGLED: LevelUpRewardItemTableKey::LevelUpRewardItemTableKey(void)
void __cdecl LevelUpRewardItemTableKey::LevelUpRewardItemTableKey(LevelUpRewardItemTableKey *this)
{
  LevelUpRewardItemTableKey::clear(this);
}

// IDA_EA: 0x891BAD4
// IDA_NAME: _ZN25LevelUpRewardItemTableKey5clearEv
// DEMANGLED: LevelUpRewardItemTableKey::clear(void)
LevelUpRewardItemTableKey *__cdecl LevelUpRewardItemTableKey::clear(LevelUpRewardItemTableKey *this)
{
  LevelUpRewardItemTableKey *this_1; // eax

  *((_BYTE *)this + 3) = 0;
  *((_BYTE *)this + 2) = 11;
  this_1 = this;
  *(_WORD *)this = 200;
  return this_1;
}
