#ifndef __IDA91_APSYSTEM_INTER_LOADREWARDMEDAL_H__
#define __IDA91_APSYSTEM_INTER_LOADREWARDMEDAL_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: APSystem
// Source unit: APSystem_Inter_LoadRewardMedal
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 1223

/* 1223 */
struct APSystem::Inter_LoadRewardMedal;

// Exported member functions:
// 0x8124E2A	APSystem::Inter_LoadRewardMedal::dispatch_sig(CUser *,char *,int)
// 0x8124EA0	APSystem::Inter_LoadRewardMedal::SendMail(CUser &,unsigned int)
// 0x8125620	APSystem::Inter_LoadRewardMedal::~Inter_LoadRewardMedal()
// 0x8125650	APSystem::Inter_LoadRewardMedal::~Inter_LoadRewardMedal()
// 0x84ED448	APSystem::Inter_LoadRewardMedal::Inter_LoadRewardMedal(void)

// Function declaration index:
// DECL 0x8124E2A APSystem::Inter_LoadRewardMedal::dispatch_sig
// DECL 0x8124EA0 APSystem::Inter_LoadRewardMedal::SendMail
// DECL 0x8125620 APSystem::Inter_LoadRewardMedal::~Inter_LoadRewardMedal
// DECL 0x8125650 APSystem::Inter_LoadRewardMedal::~Inter_LoadRewardMedal
// DECL 0x84ED448 APSystem::Inter_LoadRewardMedal::Inter_LoadRewardMedal

#endif  // __IDA91_APSYSTEM_INTER_LOADREWARDMEDAL_H__
