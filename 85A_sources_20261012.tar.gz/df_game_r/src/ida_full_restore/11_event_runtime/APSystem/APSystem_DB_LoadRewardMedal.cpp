#include "APSystem_DB_LoadRewardMedal.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x812487A
// IDA_NAME: _ZN8APSystem18DB_LoadRewardMedal11makeRequestEij
// DEMANGLED: APSystem::DB_LoadRewardMedal::makeRequest(int,unsigned int)
void APSystem::DB_LoadRewardMedal::makeRequest()
{
  ;
}

// IDA_EA: 0x8124882
// IDA_NAME: _ZN8APSystem18DB_LoadRewardMedal8dispatchEiiP6Stream
// DEMANGLED: APSystem::DB_LoadRewardMedal::dispatch(int,int,Stream *)
int __cdecl APSystem::DB_LoadRewardMedal::dispatch(APSystem::DB_LoadRewardMedal *this, int src, int a3, Stream *a4)
{
  void *v5; // [esp+1Ch] [ebp-Ch]

  if ( (unsigned __int8)DBDispatcher::dispatch(this, src, a3, a4) != 1 )
    return 0;
  v5 = (void *)Stream::GetOutBuffer<APSystem::_SIG_LOAD_REWARD_MEDAL>(a4);
  if ( !v5 )
    return 0;
  if ( (unsigned __int8)APSystem::DB_LoadRewardMedal::Select(this, v5) )
    return APSystem::DB_LoadRewardMedal::SendResult((int)this, src, a3, v5);
  return 0;
}

// IDA_EA: 0x8124910
// IDA_NAME: _ZN8APSystem18DB_LoadRewardMedal6SelectERNS_22_SIG_LOAD_REWARD_MEDALE
// DEMANGLED: APSystem::DB_LoadRewardMedal::Select(APSystem::_SIG_LOAD_REWARD_MEDAL &)
_BOOL4 __cdecl APSystem::DB_LoadRewardMedal::Select(APSystem::DB_LoadRewardMedal *this, char *a2)
{
  char _ZN8APSystem19CActionPointManager7_IsGMOnE; // bl
  CDataManager *v3; // eax
  unsigned __int16 *v4; // eax
  struct tm tp_; // [esp+24h] [ebp-A4h] BYREF
  struct tm tp; // [esp+50h] [ebp-78h] BYREF
  char s_[16]; // [esp+7Ch] [ebp-4Ch] BYREF
  char s[16]; // [esp+8Ch] [ebp-3Ch] BYREF
  time_t timer_; // [esp+9Ch] [ebp-2Ch] BYREF
  time_t timer; // [esp+A0h] [ebp-28h] BYREF
  MySQL *DBHandle; // [esp+A4h] [ebp-24h]
  int v13; // [esp+A8h] [ebp-20h]
  char *v14; // [esp+ACh] [ebp-1Ch]
  unsigned int v15; // [esp+B0h] [ebp-18h]
  int n99999; // [esp+B4h] [ebp-14h]
  int n_rowsEv; // [esp+B8h] [ebp-10h]
  unsigned int i; // [esp+BCh] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle(GlobalData::s_db_mgr, 2, 0);
  v13 = *(_DWORD *)(G_CEnvironment() + 892);
  timer = getDailyInitializeTime(v13, 0, 0);
  timer_ = timer - 604800;
  localtime_r(&timer, &tp);
  localtime_r(&timer_, &tp_);
  sprintf(s, "%04d-%02d-%02d", tp.tm_year + 1900, tp.tm_mon + 1, tp.tm_mday);
  sprintf(s_, "%04d-%02d-%02d", tp_.tm_year + 1900, tp_.tm_mon + 1, tp_.tm_mday);
  _ZN8APSystem19CActionPointManager7_IsGMOnE = APSystem::CActionPointManager::_IsGMOn;
  v3 = (CDataManager *)G_CDataManager();
  v14 = CDataManager::GetActionPointEtcParameter(v3, _ZN8APSystem19CActionPointManager7_IsGMOnE) + 96;
  v15 = std::vector<APSystem::_MedalRewardItem>::size(v14);
  n99999 = 99999;
  for ( i = 0; i < v15; ++i )
  {
    v4 = (unsigned __int16 *)std::vector<APSystem::_MedalRewardItem>::operator[](v14, i);
    if ( *v4 < n99999 )
      n99999 = *(unsigned __int16 *)std::vector<APSystem::_MedalRewardItem>::operator[](v14, i);
  }
  MySQL::set_query(
    DBHandle,
    "select occ_date, ap_sum  \t\t\t\t\tfrom charac_action_point\t\t\t\t\t\twhere charac_no = %u\t\t\t\t\t\tand is_reward"
    "_medal = %u \t\t\t\t\tand occ_date < '%s'\t\t\t\t\t\tand occ_date >= '%s'\t\t\t\t\t\tand ap_sum >= %d",
    *(_DWORD *)a2,
    0,
    s,
    s_,
    n99999);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
    return 0;
  n_rowsEv = MySQL::get_n_rows(DBHandle);
  if ( n_rowsEv <= 0 )
    return 0;
  if ( (unsigned __int8)MySQL::fetch(DBHandle) != 1 )
    return 0;
  if ( (unsigned __int8)MySQL::get_str(DBHandle, 0, a2 + 8, 11) == 1 )
    return (unsigned __int8)MySQL::get_uint(DBHandle, 1, (unsigned int *)a2 + 1) == 1;
  return 0;
}

// IDA_EA: 0x8124B8E
// IDA_NAME: _ZN8APSystem18DB_LoadRewardMedal10SendResultEiiRNS_22_SIG_LOAD_REWARD_MEDALE
// DEMANGLED: APSystem::DB_LoadRewardMedal::SendResult(int,int,APSystem::_SIG_LOAD_REWARD_MEDAL &)
int __cdecl APSystem::DB_LoadRewardMedal::SendResult(int this, char src, char src_1, void *src_2)
{
  Stream *v4; // eax
  Stream **v5; // eax
  Stream **v6; // eax
  Stream **v7; // eax
  _BYTE v9[16]; // [esp+18h] [ebp-10h] BYREF

  v4 = (Stream *)StreamPool::Acquire(
                   GlobalData::s_stream_pool,
                   "localchina/localchina_ActionPointSystem_Dispatcher.cpp",
                   448);
  CStreamGuard::CStreamGuard((CStreamGuard *)v9, v4, 1);
  v5 = (Stream **)CStreamGuard::operator*((int)v9);
  CStreamGuard::operator<<(v5, src);
  v6 = (Stream **)CStreamGuard::operator*((int)v9);
  CStreamGuard::operator<<(v6, src_1);
  v7 = (Stream **)CStreamGuard::operator->((int)v9);
  CStreamGuard::put_binary(v7, src_2, 0x13u);
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 1, (CStreamGuard *)v9);
  CStreamGuard::~CStreamGuard((CStreamGuard *)v9);
  return 1;
}

// IDA_EA: 0x81254E8
// IDA_NAME: _ZN8APSystem18DB_LoadRewardMedalD2Ev
// DEMANGLED: APSystem::DB_LoadRewardMedal::~DB_LoadRewardMedal()
void __cdecl APSystem::DB_LoadRewardMedal::~DB_LoadRewardMedal(APSystem::DB_LoadRewardMedal *this)
{
  *(_DWORD *)this = &off_8B5F470;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x8125518
// IDA_NAME: _ZN8APSystem18DB_LoadRewardMedalD0Ev
// DEMANGLED: APSystem::DB_LoadRewardMedal::~DB_LoadRewardMedal()
void __cdecl APSystem::DB_LoadRewardMedal::~DB_LoadRewardMedal(APSystem::DB_LoadRewardMedal *this)
{
  APSystem::DB_LoadRewardMedal::~DB_LoadRewardMedal(this);
  operator delete(this);
}

// IDA_EA: 0x844DDB2
// IDA_NAME: _ZN8APSystem18DB_LoadRewardMedalC2Ev
// DEMANGLED: APSystem::DB_LoadRewardMedal::DB_LoadRewardMedal(void)
APSystem::DB_LoadRewardMedal *__cdecl APSystem::DB_LoadRewardMedal::DB_LoadRewardMedal(
        APSystem::DB_LoadRewardMedal *this)
{
  APSystem::DB_LoadRewardMedal *this_1; // eax

  DBDispatcher::DBDispatcher(this);
  this_1 = this;
  *(_DWORD *)this = &off_8B5F470;
  return this_1;
}
