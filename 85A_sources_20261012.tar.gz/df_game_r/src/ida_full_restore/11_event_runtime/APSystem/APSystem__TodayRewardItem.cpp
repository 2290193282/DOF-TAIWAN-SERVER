#include "APSystem__TodayRewardItem.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8895736
// IDA_NAME: _ZN8APSystem16_TodayRewardItemC2Ev
// DEMANGLED: APSystem::_TodayRewardItem::_TodayRewardItem(void)
void *__cdecl APSystem::_TodayRewardItem::_TodayRewardItem(APSystem::_TodayRewardItem *this)
{
  return memset(this, 0, 0xEu);
}

// IDA_EA: 0x8897D76
// IDA_NAME: _ZN8APSystem16_TodayRewardItemD2Ev
// DEMANGLED: APSystem::_TodayRewardItem::~_TodayRewardItem()
void APSystem::_TodayRewardItem::~_TodayRewardItem()
{
  ;
}
