#include "APSystem__MedalRewardItem.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8895712
// IDA_NAME: _ZN8APSystem16_MedalRewardItemC2Ev
// DEMANGLED: APSystem::_MedalRewardItem::_MedalRewardItem(void)
void *__cdecl APSystem::_MedalRewardItem::_MedalRewardItem(APSystem::_MedalRewardItem *this)
{
  return memset(this, 0, 0xAu);
}

// IDA_EA: 0x8897B24
// IDA_NAME: _ZN8APSystem16_MedalRewardItemD2Ev
// DEMANGLED: APSystem::_MedalRewardItem::~_MedalRewardItem()
void APSystem::_MedalRewardItem::~_MedalRewardItem()
{
  ;
}
