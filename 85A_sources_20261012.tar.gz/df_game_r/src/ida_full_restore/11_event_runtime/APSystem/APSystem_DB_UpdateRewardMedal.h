#ifndef __IDA91_APSYSTEM_DB_UPDATEREWARDMEDAL_H__
#define __IDA91_APSYSTEM_DB_UPDATEREWARDMEDAL_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: APSystem
// Source unit: APSystem_DB_UpdateRewardMedal
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2454

/* 2454 */
struct APSystem::DB_UpdateRewardMedal;

// Exported member functions:
// 0x8124C70	APSystem::DB_UpdateRewardMedal::makeRequest(int,APSystem::_SIG_LOAD_REWARD_MEDAL const&)
// 0x8124C78	APSystem::DB_UpdateRewardMedal::dispatch(int,int,Stream *)
// 0x8124CB2	APSystem::DB_UpdateRewardMedal::Update(APSystem::_SIG_UPDATE_REWARD_MEDAL &)
// 0x8125536	APSystem::DB_UpdateRewardMedal::~DB_UpdateRewardMedal()
// 0x8125566	APSystem::DB_UpdateRewardMedal::~DB_UpdateRewardMedal()
// 0x844DDCE	APSystem::DB_UpdateRewardMedal::DB_UpdateRewardMedal(void)

// Function declaration index:
// DECL 0x8124C70 APSystem::DB_UpdateRewardMedal::makeRequest
// DECL 0x8124C78 APSystem::DB_UpdateRewardMedal::dispatch
// DECL 0x8124CB2 APSystem::DB_UpdateRewardMedal::Update
// DECL 0x8125536 APSystem::DB_UpdateRewardMedal::~DB_UpdateRewardMedal
// DECL 0x8125566 APSystem::DB_UpdateRewardMedal::~DB_UpdateRewardMedal
// DECL 0x844DDCE APSystem::DB_UpdateRewardMedal::DB_UpdateRewardMedal

#endif  // __IDA91_APSYSTEM_DB_UPDATEREWARDMEDAL_H__
