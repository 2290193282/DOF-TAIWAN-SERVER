#ifndef __IDA91_APSYSTEM_DISPATCHER_GETTODAYREWARD_H__
#define __IDA91_APSYSTEM_DISPATCHER_GETTODAYREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: APSystem
// Source unit: APSystem_Dispatcher_GetTodayReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 3328

/* 3328 */
struct APSystem::Dispatcher_GetTodayReward;

// Exported member functions:
// 0x81251DA	APSystem::Dispatcher_GetTodayReward::dispatch_sig(CUser *,PacketBuf &)
// 0x8125682	APSystem::Dispatcher_GetTodayReward::read(PacketBuf &,MSG_BASE &)
// 0x812568C	APSystem::Dispatcher_GetTodayReward::process(CUser *,MSG_BASE &,ParamBase &)
// 0x812581A	APSystem::Dispatcher_GetTodayReward::~Dispatcher_GetTodayReward()
// 0x812584A	APSystem::Dispatcher_GetTodayReward::~Dispatcher_GetTodayReward()
// 0x8597576	APSystem::Dispatcher_GetTodayReward::Dispatcher_GetTodayReward(void)

// Function declaration index:
// DECL 0x81251DA APSystem::Dispatcher_GetTodayReward::dispatch_sig
// DECL 0x8125682 APSystem::Dispatcher_GetTodayReward::read
// DECL 0x812568C APSystem::Dispatcher_GetTodayReward::process
// DECL 0x812581A APSystem::Dispatcher_GetTodayReward::~Dispatcher_GetTodayReward
// DECL 0x812584A APSystem::Dispatcher_GetTodayReward::~Dispatcher_GetTodayReward
// DECL 0x8597576 APSystem::Dispatcher_GetTodayReward::Dispatcher_GetTodayReward

#endif  // __IDA91_APSYSTEM_DISPATCHER_GETTODAYREWARD_H__
