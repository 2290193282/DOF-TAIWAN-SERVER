#include "APSystem_Dispatcher_GetTodayReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81251DA
// IDA_NAME: _ZN8APSystem25Dispatcher_GetTodayReward12dispatch_sigEP5CUserR9PacketBuf
// DEMANGLED: APSystem::Dispatcher_GetTodayReward::dispatch_sig(CUser *,PacketBuf &)
int __cdecl APSystem::Dispatcher_GetTodayReward::dispatch_sig(
        APSystem::Dispatcher_GetTodayReward *this,
        CUser *a2,
        PacketBuf *a3)
{
  char v5; // [esp+1Bh] [ebp-Dh] BYREF

  if ( !a2 || CUser::get_state(a2) <= 2 || !CUserCharacInfo::getCurCharacR(a2) )
    return 647;
  if ( (unsigned __int8)PacketBuf::get_binary(a3, &v5, 5) != 1 )
    return 651;
  APSystem::CUserProc::GetTodayRewardAndSendPostal();
  return 0;
}

// IDA_EA: 0x8125682
// IDA_NAME: _ZN8APSystem25Dispatcher_GetTodayReward4readER9PacketBufR8MSG_BASE
// DEMANGLED: APSystem::Dispatcher_GetTodayReward::read(PacketBuf &,MSG_BASE &)
int APSystem::Dispatcher_GetTodayReward::read()
{
  return 0;
}

// IDA_EA: 0x812568C
// IDA_NAME: _ZN8APSystem25Dispatcher_GetTodayReward7processEP5CUserR8MSG_BASER9ParamBase
// DEMANGLED: APSystem::Dispatcher_GetTodayReward::process(CUser *,MSG_BASE &,ParamBase &)
int APSystem::Dispatcher_GetTodayReward::process()
{
  return 0;
}

// IDA_EA: 0x812581A
// IDA_NAME: _ZN8APSystem25Dispatcher_GetTodayRewardD2Ev
// DEMANGLED: APSystem::Dispatcher_GetTodayReward::~Dispatcher_GetTodayReward()
void __cdecl APSystem::Dispatcher_GetTodayReward::~Dispatcher_GetTodayReward(APSystem::Dispatcher_GetTodayReward *this)
{
  *(_DWORD *)this = &off_8B5F3A8;
  IPacketDispatcher<MSG_BASE,ParamBase,(ch_state)0>::~IPacketDispatcher(this);
}

// IDA_EA: 0x812584A
// IDA_NAME: _ZN8APSystem25Dispatcher_GetTodayRewardD0Ev
// DEMANGLED: APSystem::Dispatcher_GetTodayReward::~Dispatcher_GetTodayReward()
void __cdecl APSystem::Dispatcher_GetTodayReward::~Dispatcher_GetTodayReward(APSystem::Dispatcher_GetTodayReward *this)
{
  APSystem::Dispatcher_GetTodayReward::~Dispatcher_GetTodayReward(this);
  operator delete(this);
}

// IDA_EA: 0x8597576
// IDA_NAME: _ZN8APSystem25Dispatcher_GetTodayRewardC2Ev
// DEMANGLED: APSystem::Dispatcher_GetTodayReward::Dispatcher_GetTodayReward(void)
APSystem::Dispatcher_GetTodayReward *__cdecl APSystem::Dispatcher_GetTodayReward::Dispatcher_GetTodayReward(
        APSystem::Dispatcher_GetTodayReward *this)
{
  APSystem::Dispatcher_GetTodayReward *this_1; // eax

  IPacketDispatcher<MSG_BASE,ParamBase,(ch_state)0>::IPacketDispatcher(this);
  this_1 = this;
  *(_DWORD *)this = &off_8B5F3A8;
  return this_1;
}
