#ifndef __IDA91_APSYSTEM_MEDALREWARDITEM_H__
#define __IDA91_APSYSTEM_MEDALREWARDITEM_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: APSystem
// Source unit: APSystem__MedalRewardItem
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 3827

/* 3827 */
struct APSystem::_MedalRewardItem;

// Exported member functions:
// 0x8895712	APSystem::_MedalRewardItem::_MedalRewardItem(void)
// 0x8897B24	APSystem::_MedalRewardItem::~_MedalRewardItem()

// Function declaration index:
// DECL 0x8895712 APSystem::_MedalRewardItem::_MedalRewardItem
// DECL 0x8897B24 APSystem::_MedalRewardItem::~_MedalRewardItem

#endif  // __IDA91_APSYSTEM_MEDALREWARDITEM_H__
