#include "APSystem_Inter_LoadRewardMedal.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8124E2A
// IDA_NAME: _ZN8APSystem21Inter_LoadRewardMedal12dispatch_sigEP5CUserPci
// DEMANGLED: APSystem::Inter_LoadRewardMedal::dispatch_sig(CUser *,char *,int)
int __cdecl APSystem::Inter_LoadRewardMedal::dispatch_sig(APSystem::Inter_LoadRewardMedal *this, CUser *a2, char *a3)
{
  if ( !a2 || !CUser::get_state(a2) || !CUserCharacInfo::getCurCharacR(a2) )
    return 550;
  if ( !a3 )
    return 555;
  CUser::GetUID(a2);
  APSystem::DB_UpdateRewardMedal::makeRequest();
  return 0;
}

// IDA_EA: 0x8124EA0
// IDA_NAME: _ZN8APSystem21Inter_LoadRewardMedal8SendMailER5CUserj
// DEMANGLED: APSystem::Inter_LoadRewardMedal::SendMail(CUser &,unsigned int)
int __cdecl APSystem::Inter_LoadRewardMedal::SendMail(
        APSystem::Inter_LoadRewardMedal *this,
        CUser *a2,
        unsigned int a3)
{
  char _ZN8APSystem19CActionPointManager7_IsGMOnE; // bl
  CDataManager *v4; // eax
  unsigned int n2; // ebx
  CItemList **v8; // eax
  const char *src; // eax
  const char *src_1; // eax
  int ServerGroup; // ebx
  size_t v12; // esi
  int charac_noEi; // eax
  char s[256]; // [esp+3Dh] [ebp-17Bh] BYREF
  _BYTE v16[2]; // [esp+13Dh] [ebp-7Bh] BYREF
  int v17; // [esp+13Fh] [ebp-79h]
  int v18; // [esp+144h] [ebp-74h]
  char dest[30]; // [esp+17Ah] [ebp-3Eh] BYREF
  char *v20; // [esp+198h] [ebp-20h]
  unsigned int v21; // [esp+19Ch] [ebp-1Ch]
  int v22; // [esp+1A0h] [ebp-18h]
  unsigned int i; // [esp+1A4h] [ebp-14h]
  int item; // [esp+1A8h] [ebp-10h]
  int n8; // [esp+1ACh] [ebp-Ch]

  _ZN8APSystem19CActionPointManager7_IsGMOnE = APSystem::CActionPointManager::_IsGMOn;
  v4 = (CDataManager *)G_CDataManager();
  v20 = CDataManager::GetActionPointEtcParameter(v4, _ZN8APSystem19CActionPointManager7_IsGMOnE) + 96;
  v21 = std::vector<APSystem::_MedalRewardItem>::size(v20);
  v22 = 0;
  for ( i = 0; i < v21; ++i )
  {
    if ( (*(unsigned __int16 *)std::vector<APSystem::_MedalRewardItem>::operator[](v20, i) > a3
       || *(unsigned __int16 *)(std::vector<APSystem::_MedalRewardItem>::operator[](v20, i) + 2) < a3)
      && (*(unsigned __int16 *)std::vector<APSystem::_MedalRewardItem>::operator[](v20, i) > a3
       || *(_WORD *)std::vector<APSystem::_MedalRewardItem>::operator[](v20, i) != 100) )
    {
      continue;
    }
    v22 = std::vector<APSystem::_MedalRewardItem>::operator[](v20, i);
    break;
  }
  if ( !v22 )
    return 0;
  n2 = *(_DWORD *)(v22 + 4);
  v8 = (CItemList **)G_CDataManager();
  item = CDataManager::find_item(v8, n2);
  Inven_Item::Inven_Item((Inven_Item *)v16);
  if ( !item )
    return 0;
  (*(void (__cdecl **)(int, _BYTE *))(*(_DWORD *)item + 8))(item, v16);
  v18 = *(unsigned __int16 *)(v22 + 8);
  v17 = *(_DWORD *)(v22 + 4);
  n8 = 8;
  src = (const char *)RDARScriptStringManager::findString(
                        (RDARScriptStringManager *)&g_scriptStringManager_,
                        4,
                        "chn_game_server_msg_82",
                        0);
  strncpy(dest, src, 0x1Du);
  src_1 = (const char *)RDARScriptStringManager::findString(
                          (RDARScriptStringManager *)&g_scriptStringManager_,
                          4,
                          "chn_game_server_msg_83",
                          0);
  strncpy(s, src_1, 0xFFu);
  ServerGroup = CUser::GetServerGroup(a2);
  v12 = strlen(s);
  charac_noEi = CUser::get_charac_no(a2, -1);
  WongWork::CMailBoxHelper::ReqDBSendNewSystemMail(
    dest,
    (Inven_Item *)v16,
    0,
    charac_noEi,
    s,
    v12,
    8,
    ServerGroup,
    0,
    0);
  return 1;
}

// IDA_EA: 0x8125620
// IDA_NAME: _ZN8APSystem21Inter_LoadRewardMedalD2Ev
// DEMANGLED: APSystem::Inter_LoadRewardMedal::~Inter_LoadRewardMedal()
void __cdecl APSystem::Inter_LoadRewardMedal::~Inter_LoadRewardMedal(APSystem::Inter_LoadRewardMedal *this)
{
  *(_DWORD *)this = &off_8B5F410;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x8125650
// IDA_NAME: _ZN8APSystem21Inter_LoadRewardMedalD0Ev
// DEMANGLED: APSystem::Inter_LoadRewardMedal::~Inter_LoadRewardMedal()
void __cdecl APSystem::Inter_LoadRewardMedal::~Inter_LoadRewardMedal(APSystem::Inter_LoadRewardMedal *this)
{
  APSystem::Inter_LoadRewardMedal::~Inter_LoadRewardMedal(this);
  operator delete(this);
}

// IDA_EA: 0x84ED448
// IDA_NAME: _ZN8APSystem21Inter_LoadRewardMedalC2Ev
// DEMANGLED: APSystem::Inter_LoadRewardMedal::Inter_LoadRewardMedal(void)
APSystem::Inter_LoadRewardMedal *__cdecl APSystem::Inter_LoadRewardMedal::Inter_LoadRewardMedal(
        APSystem::Inter_LoadRewardMedal *this)
{
  APSystem::Inter_LoadRewardMedal *this_1; // eax

  ISigDispatcher::ISigDispatcher(this);
  this_1 = this;
  *(_DWORD *)this = &off_8B5F410;
  return this_1;
}
