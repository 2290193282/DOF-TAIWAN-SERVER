#ifndef __IDA91_APSYSTEM_TODAYREWARDITEM_H__
#define __IDA91_APSYSTEM_TODAYREWARDITEM_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: APSystem
// Source unit: APSystem__TodayRewardItem
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 3828

/* 3828 */
struct APSystem::_TodayRewardItem;

// Exported member functions:
// 0x8895736	APSystem::_TodayRewardItem::_TodayRewardItem(void)
// 0x8897D76	APSystem::_TodayRewardItem::~_TodayRewardItem()

// Function declaration index:
// DECL 0x8895736 APSystem::_TodayRewardItem::_TodayRewardItem
// DECL 0x8897D76 APSystem::_TodayRewardItem::~_TodayRewardItem

#endif  // __IDA91_APSYSTEM_TODAYREWARDITEM_H__
