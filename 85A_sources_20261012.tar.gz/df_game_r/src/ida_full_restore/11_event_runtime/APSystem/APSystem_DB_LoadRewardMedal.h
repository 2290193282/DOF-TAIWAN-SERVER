#ifndef __IDA91_APSYSTEM_DB_LOADREWARDMEDAL_H__
#define __IDA91_APSYSTEM_DB_LOADREWARDMEDAL_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: APSystem
// Source unit: APSystem_DB_LoadRewardMedal
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 1222

/* 1222 */
struct APSystem::DB_LoadRewardMedal;

// Exported member functions:
// 0x812487A	APSystem::DB_LoadRewardMedal::makeRequest(int,unsigned int)
// 0x8124882	APSystem::DB_LoadRewardMedal::dispatch(int,int,Stream *)
// 0x8124910	APSystem::DB_LoadRewardMedal::Select(APSystem::_SIG_LOAD_REWARD_MEDAL &)
// 0x8124B8E	APSystem::DB_LoadRewardMedal::SendResult(int,int,APSystem::_SIG_LOAD_REWARD_MEDAL &)
// 0x81254E8	APSystem::DB_LoadRewardMedal::~DB_LoadRewardMedal()
// 0x8125518	APSystem::DB_LoadRewardMedal::~DB_LoadRewardMedal()
// 0x844DDB2	APSystem::DB_LoadRewardMedal::DB_LoadRewardMedal(void)

// Function declaration index:
// DECL 0x812487A APSystem::DB_LoadRewardMedal::makeRequest
// DECL 0x8124882 APSystem::DB_LoadRewardMedal::dispatch
// DECL 0x8124910 APSystem::DB_LoadRewardMedal::Select
// DECL 0x8124B8E APSystem::DB_LoadRewardMedal::SendResult
// DECL 0x81254E8 APSystem::DB_LoadRewardMedal::~DB_LoadRewardMedal
// DECL 0x8125518 APSystem::DB_LoadRewardMedal::~DB_LoadRewardMedal
// DECL 0x844DDB2 APSystem::DB_LoadRewardMedal::DB_LoadRewardMedal

#endif  // __IDA91_APSYSTEM_DB_LOADREWARDMEDAL_H__
