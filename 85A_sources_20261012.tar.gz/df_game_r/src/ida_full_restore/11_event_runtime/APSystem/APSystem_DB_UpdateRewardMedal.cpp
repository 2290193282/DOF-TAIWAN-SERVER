#include "APSystem_DB_UpdateRewardMedal.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8124C70
// IDA_NAME: _ZN8APSystem20DB_UpdateRewardMedal11makeRequestEiRKNS_22_SIG_LOAD_REWARD_MEDALE
// DEMANGLED: APSystem::DB_UpdateRewardMedal::makeRequest(int,APSystem::_SIG_LOAD_REWARD_MEDAL const&)
void APSystem::DB_UpdateRewardMedal::makeRequest()
{
  ;
}

// IDA_EA: 0x8124C78
// IDA_NAME: _ZN8APSystem20DB_UpdateRewardMedal8dispatchEiiP6Stream
// DEMANGLED: APSystem::DB_UpdateRewardMedal::dispatch(int,int,Stream *)
int __cdecl APSystem::DB_UpdateRewardMedal::dispatch(APSystem::DB_UpdateRewardMedal *this, int a2, int a3, Stream *a4)
{
  int v5; // [esp+1Ch] [ebp-Ch]

  v5 = Stream::GetOutBuffer<APSystem::_SIG_UPDATE_REWARD_MEDAL>(a4);
  if ( !v5 )
    return 0;
  APSystem::DB_UpdateRewardMedal::Update(this, v5);
  return 1;
}

// IDA_EA: 0x8124CB2
// IDA_NAME: _ZN8APSystem20DB_UpdateRewardMedal6UpdateERNS_24_SIG_UPDATE_REWARD_MEDALE
// DEMANGLED: APSystem::DB_UpdateRewardMedal::Update(APSystem::_SIG_UPDATE_REWARD_MEDAL &)
int __cdecl APSystem::DB_UpdateRewardMedal::Update(APSystem::DB_UpdateRewardMedal *this, int a2)
{
  MySQL *DBHandle; // [esp+28h] [ebp-10h]

  DBHandle = (MySQL *)DBMgr::GetDBHandle(GlobalData::s_db_mgr, 2, 0);
  MySQL::set_query(
    DBHandle,
    "update charac_action_point set is_reward_medal=%u \t\t\t\t\twhere charac_no = %u\t\t\t\t\t\tand is_reward_medal = %u"
    " \t\t\t\t\tand occ_date = '%s'",
    1,
    *(_DWORD *)a2,
    0,
    (const char *)(a2 + 4));
  return (unsigned __int8)MySQL::exec(DBHandle, 1);
}

// IDA_EA: 0x8125536
// IDA_NAME: _ZN8APSystem20DB_UpdateRewardMedalD2Ev
// DEMANGLED: APSystem::DB_UpdateRewardMedal::~DB_UpdateRewardMedal()
void __cdecl APSystem::DB_UpdateRewardMedal::~DB_UpdateRewardMedal(APSystem::DB_UpdateRewardMedal *this)
{
  *(_DWORD *)this = &off_8B5F458;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x8125566
// IDA_NAME: _ZN8APSystem20DB_UpdateRewardMedalD0Ev
// DEMANGLED: APSystem::DB_UpdateRewardMedal::~DB_UpdateRewardMedal()
void __cdecl APSystem::DB_UpdateRewardMedal::~DB_UpdateRewardMedal(APSystem::DB_UpdateRewardMedal *this)
{
  APSystem::DB_UpdateRewardMedal::~DB_UpdateRewardMedal(this);
  operator delete(this);
}

// IDA_EA: 0x844DDCE
// IDA_NAME: _ZN8APSystem20DB_UpdateRewardMedalC2Ev
// DEMANGLED: APSystem::DB_UpdateRewardMedal::DB_UpdateRewardMedal(void)
APSystem::DB_UpdateRewardMedal *__cdecl APSystem::DB_UpdateRewardMedal::DB_UpdateRewardMedal(
        APSystem::DB_UpdateRewardMedal *this)
{
  APSystem::DB_UpdateRewardMedal *this_1; // eax

  DBDispatcher::DBDispatcher(this);
  this_1 = this;
  *(_DWORD *)this = &off_8B5F458;
  return this_1;
}
