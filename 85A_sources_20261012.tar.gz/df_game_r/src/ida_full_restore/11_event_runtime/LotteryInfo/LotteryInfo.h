#ifndef __IDA91_LOTTERYINFO_H__
#define __IDA91_LOTTERYINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: LotteryInfo
// Source unit: LotteryInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4429

/* 4429 */
struct LotteryInfo;

// Exported member functions:
// 0x837069C	LotteryInfo::clear(void)
// 0x83706D4	LotteryInfo::LotteryInfo(void)
// 0x8374CFC	LotteryInfo::~LotteryInfo()

// Function declaration index:
// DECL 0x837069C LotteryInfo::clear
// DECL 0x83706D4 LotteryInfo::LotteryInfo
// DECL 0x8374CFC LotteryInfo::~LotteryInfo

#endif  // __IDA91_LOTTERYINFO_H__
