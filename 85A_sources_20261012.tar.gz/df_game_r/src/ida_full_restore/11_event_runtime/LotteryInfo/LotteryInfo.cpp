#include "LotteryInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x837069C
// IDA_NAME: _ZN11LotteryInfo5clearEv
// DEMANGLED: LotteryInfo::clear(void)
int __cdecl LotteryInfo::clear(LotteryInfo *this)
{
  *(_DWORD *)this = 0;
  std::vector<std::pair<int,int>>::clear((_DWORD *)this + 1);
  *((_DWORD *)this + 4) = 0;
  return std::vector<int>::clear((_DWORD *)this + 5);
}

// IDA_EA: 0x83706D4
// IDA_NAME: _ZN11LotteryInfoC2Ev
// DEMANGLED: LotteryInfo::LotteryInfo(void)
void __cdecl LotteryInfo::LotteryInfo(LotteryInfo *this)
{
  std::vector<std::pair<int,int>>::vector((int)this + 4);
  std::vector<int>::vector((int)this + 20);
  LotteryInfo::clear(this);
}

// IDA_EA: 0x8374CFC
// IDA_NAME: _ZN11LotteryInfoD2Ev
// DEMANGLED: LotteryInfo::~LotteryInfo()
void __cdecl LotteryInfo::~LotteryInfo(LotteryInfo *this)
{
  std::vector<int>::~vector((_DWORD *)this + 5);
  std::vector<std::pair<int,int>>::~vector((int *)this + 1);
}
