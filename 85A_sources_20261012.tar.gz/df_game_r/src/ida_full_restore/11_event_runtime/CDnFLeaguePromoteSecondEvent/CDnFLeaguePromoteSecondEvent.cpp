#include "CDnFLeaguePromoteSecondEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x811C1E2
// IDA_NAME: _ZN28CDnFLeaguePromoteSecondEventC2Ev
// DEMANGLED: CDnFLeaguePromoteSecondEvent::CDnFLeaguePromoteSecondEvent(void)
void __cdecl CDnFLeaguePromoteSecondEvent::CDnFLeaguePromoteSecondEvent(CDnFLeaguePromoteSecondEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B52108;
}

// IDA_EA: 0x811C1FE
// IDA_NAME: _ZN28CDnFLeaguePromoteSecondEventD2Ev
// DEMANGLED: CDnFLeaguePromoteSecondEvent::~CDnFLeaguePromoteSecondEvent()
void __cdecl CDnFLeaguePromoteSecondEvent::~CDnFLeaguePromoteSecondEvent(CDnFLeaguePromoteSecondEvent *this)
{
  *(_DWORD *)this = off_8B52108;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x811C22E
// IDA_NAME: _ZN28CDnFLeaguePromoteSecondEventD0Ev
// DEMANGLED: CDnFLeaguePromoteSecondEvent::~CDnFLeaguePromoteSecondEvent()
void __cdecl CDnFLeaguePromoteSecondEvent::~CDnFLeaguePromoteSecondEvent(CDnFLeaguePromoteSecondEvent *this)
{
  CDnFLeaguePromoteSecondEvent::~CDnFLeaguePromoteSecondEvent(this);
  operator delete(this);
}

// IDA_EA: 0x811C24C
// IDA_NAME: _ZN28CDnFLeaguePromoteSecondEvent10StartEventEv
// DEMANGLED: CDnFLeaguePromoteSecondEvent::StartEvent(void)
int __cdecl CDnFLeaguePromoteSecondEvent::StartEvent(CDnFLeaguePromoteSecondEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CDnFLeaguePromoteSecondEvent::StartEvent()", 43, 0);
  return cMyTrace::operator()((int)v3, "CDnFLeaguePromoteSecondEvent Event Start!", v2);
}

// IDA_EA: 0x811C29E
// IDA_NAME: _ZN28CDnFLeaguePromoteSecondEvent10StartEventE10Word_Param
// DEMANGLED: CDnFLeaguePromoteSecondEvent::StartEvent(Word_Param)
int __cdecl CDnFLeaguePromoteSecondEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x811C2B8
// IDA_NAME: _ZN28CDnFLeaguePromoteSecondEvent8EndEventEv
// DEMANGLED: CDnFLeaguePromoteSecondEvent::EndEvent(void)
int __cdecl CDnFLeaguePromoteSecondEvent::EndEvent(CDnFLeaguePromoteSecondEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CDnFLeaguePromoteSecondEvent::EndEvent()", 53, 0);
  return cMyTrace::operator()((int)v3, "CDnFLeaguePromoteSecondEvent Event End!", v2);
}
