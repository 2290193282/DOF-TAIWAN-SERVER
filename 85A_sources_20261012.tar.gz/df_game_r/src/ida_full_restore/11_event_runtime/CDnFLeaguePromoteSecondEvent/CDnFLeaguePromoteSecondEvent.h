#ifndef __IDA91_CDNFLEAGUEPROMOTESECONDEVENT_H__
#define __IDA91_CDNFLEAGUEPROMOTESECONDEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CDnFLeaguePromoteSecondEvent
// Source unit: CDnFLeaguePromoteSecondEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4109

/* 4109 */
struct CDnFLeaguePromoteSecondEvent;

// Exported member functions:
// 0x811C1E2	CDnFLeaguePromoteSecondEvent::CDnFLeaguePromoteSecondEvent(void)
// 0x811C1FE	CDnFLeaguePromoteSecondEvent::~CDnFLeaguePromoteSecondEvent()
// 0x811C22E	CDnFLeaguePromoteSecondEvent::~CDnFLeaguePromoteSecondEvent()
// 0x811C24C	CDnFLeaguePromoteSecondEvent::StartEvent(void)
// 0x811C29E	CDnFLeaguePromoteSecondEvent::StartEvent(Word_Param)
// 0x811C2B8	CDnFLeaguePromoteSecondEvent::EndEvent(void)

// Function declaration index:
// DECL 0x811C1E2 CDnFLeaguePromoteSecondEvent::CDnFLeaguePromoteSecondEvent
// DECL 0x811C1FE CDnFLeaguePromoteSecondEvent::~CDnFLeaguePromoteSecondEvent
// DECL 0x811C22E CDnFLeaguePromoteSecondEvent::~CDnFLeaguePromoteSecondEvent
// DECL 0x811C24C CDnFLeaguePromoteSecondEvent::StartEvent
// DECL 0x811C29E CDnFLeaguePromoteSecondEvent::StartEvent
// DECL 0x811C2B8 CDnFLeaguePromoteSecondEvent::EndEvent

#endif  // __IDA91_CDNFLEAGUEPROMOTESECONDEVENT_H__
