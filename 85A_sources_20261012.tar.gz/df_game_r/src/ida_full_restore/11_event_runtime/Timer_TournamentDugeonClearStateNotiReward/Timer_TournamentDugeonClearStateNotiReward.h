#ifndef __IDA91_TIMER_TOURNAMENTDUGEONCLEARSTATENOTIREWARD_H__
#define __IDA91_TIMER_TOURNAMENTDUGEONCLEARSTATENOTIREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Timer_TournamentDugeonClearStateNotiReward
// Source unit: Timer_TournamentDugeonClearStateNotiReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3586

/* 3586 */
struct Timer_TournamentDugeonClearStateNotiReward;

// Exported member functions:
// 0x863B2FE	Timer_TournamentDugeonClearStateNotiReward::dispatch_sig(int,int,unsigned int)
// 0x863D0BE	Timer_TournamentDugeonClearStateNotiReward::Timer_TournamentDugeonClearStateNotiReward(void)
// 0x863E5C2	Timer_TournamentDugeonClearStateNotiReward::~Timer_TournamentDugeonClearStateNotiReward()
// 0x863E5F2	Timer_TournamentDugeonClearStateNotiReward::~Timer_TournamentDugeonClearStateNotiReward()

// Function declaration index:
// DECL 0x863B2FE Timer_TournamentDugeonClearStateNotiReward::dispatch_sig
// DECL 0x863D0BE Timer_TournamentDugeonClearStateNotiReward::Timer_TournamentDugeonClearStateNotiReward
// DECL 0x863E5C2 Timer_TournamentDugeonClearStateNotiReward::~Timer_TournamentDugeonClearStateNotiReward
// DECL 0x863E5F2 Timer_TournamentDugeonClearStateNotiReward::~Timer_TournamentDugeonClearStateNotiReward

#endif  // __IDA91_TIMER_TOURNAMENTDUGEONCLEARSTATENOTIREWARD_H__
