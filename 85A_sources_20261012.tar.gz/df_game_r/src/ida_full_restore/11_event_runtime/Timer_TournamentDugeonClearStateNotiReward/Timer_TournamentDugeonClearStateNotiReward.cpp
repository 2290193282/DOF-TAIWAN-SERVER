#include "Timer_TournamentDugeonClearStateNotiReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x863B2FE
// IDA_NAME: _ZN42Timer_TournamentDugeonClearStateNotiReward12dispatch_sigEiij
// DEMANGLED: Timer_TournamentDugeonClearStateNotiReward::dispatch_sig(int,int,unsigned int)
int __cdecl Timer_TournamentDugeonClearStateNotiReward::dispatch_sig(
        Timer_TournamentDugeonClearStateNotiReward *this,
        char a2,
        int a3)
{
  CUser *userEi; // eax
  __int16 CurCharacTotalFatigueEv; // bx
  CUser *userEi_1; // eax
  PacketBuf *v7[3]; // [esp+1Ch] [ebp-1Ch] BYREF
  CParty *Party; // [esp+28h] [ebp-10h]
  int n3; // [esp+2Ch] [ebp-Ch]

  G_CGameManager();
  Party = (CParty *)CGameManager::GetParty();
  if ( !Party )
    return 0;
  if ( !CParty::check_timer_key((int)Party, 46, a3) )
    return 0;
  if ( (unsigned __int8)CParty::GetTournamentDungeonClearState(Party) == 1 )
  {
    PacketGuard::PacketGuard((PacketGuard *)v7);
    InterfacePacketBuf::clear(v7);
    InterfacePacketBuf::put_header(v7, 1, 458);
    InterfacePacketBuf::put_byte(v7, 1);
    for ( n3 = 0; n3 <= 3; ++n3 )
    {
      if ( CParty::get_user(Party, n3) )
      {
        userEi = (CUser *)CParty::get_user(Party, n3);
        CurCharacTotalFatigueEv = CUser::getCurCharacTotalFatigue(userEi);
        userEi_1 = (CUser *)CParty::get_user(Party, n3);
        if ( CurCharacTotalFatigueEv == (unsigned __int16)CUser::getCurCharacTotalMaxFatigue(userEi_1) )
          InterfacePacketBuf::put_byte(v7, 0);
        else
          InterfacePacketBuf::put_byte(v7, 1);
      }
      else
      {
        InterfacePacketBuf::put_byte(v7, -1);
      }
    }
    InterfacePacketBuf::finalize(v7, 1);
    CParty::send_to_party((CUser **)Party, (PacketGuard *)v7);
    CParty::SetTournamentDungeonClearState(Party, (CParty *)2);
    CParty::InsertTournamentDungeonTimer(Party, 47);
    PacketGuard::~PacketGuard(v7);
  }
  return 1;
}

// IDA_EA: 0x863D0BE
// IDA_NAME: _ZN42Timer_TournamentDugeonClearStateNotiRewardC2Ev
// DEMANGLED: Timer_TournamentDugeonClearStateNotiReward::Timer_TournamentDugeonClearStateNotiReward(void)
void __cdecl Timer_TournamentDugeonClearStateNotiReward::Timer_TournamentDugeonClearStateNotiReward(
        Timer_TournamentDugeonClearStateNotiReward *this)
{
  TimerSig::TimerSig(this);
  *(_DWORD *)this = &off_8CE8658;
}

// IDA_EA: 0x863E5C2
// IDA_NAME: _ZN42Timer_TournamentDugeonClearStateNotiRewardD2Ev
// DEMANGLED: Timer_TournamentDugeonClearStateNotiReward::~Timer_TournamentDugeonClearStateNotiReward()
void __cdecl Timer_TournamentDugeonClearStateNotiReward::~Timer_TournamentDugeonClearStateNotiReward(
        Timer_TournamentDugeonClearStateNotiReward *this)
{
  *(_DWORD *)this = &off_8CE8658;
  TimerSig::~TimerSig(this);
}

// IDA_EA: 0x863E5F2
// IDA_NAME: _ZN42Timer_TournamentDugeonClearStateNotiRewardD0Ev
// DEMANGLED: Timer_TournamentDugeonClearStateNotiReward::~Timer_TournamentDugeonClearStateNotiReward()
void __cdecl Timer_TournamentDugeonClearStateNotiReward::~Timer_TournamentDugeonClearStateNotiReward(
        Timer_TournamentDugeonClearStateNotiReward *this)
{
  Timer_TournamentDugeonClearStateNotiReward::~Timer_TournamentDugeonClearStateNotiReward(this);
  operator delete(this);
}
