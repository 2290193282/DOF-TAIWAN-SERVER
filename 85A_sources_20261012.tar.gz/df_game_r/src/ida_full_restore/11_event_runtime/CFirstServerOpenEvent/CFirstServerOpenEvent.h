#ifndef __IDA91_CFIRSTSERVEROPENEVENT_H__
#define __IDA91_CFIRSTSERVEROPENEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CFirstServerOpenEvent
// Source unit: CFirstServerOpenEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 1210

/* 1210 */
struct CFirstServerOpenEvent;

// Exported member functions:
// 0x811CA78	CFirstServerOpenEvent::CFirstServerOpenEvent(void)
// 0x811CA94	CFirstServerOpenEvent::~CFirstServerOpenEvent()
// 0x811CAC4	CFirstServerOpenEvent::~CFirstServerOpenEvent()
// 0x811CAE2	CFirstServerOpenEvent::StartEvent(void)
// 0x811CB34	CFirstServerOpenEvent::StartEvent(Word_Param)
// 0x811CB86	CFirstServerOpenEvent::EndEvent(void)
// 0x811CBD8	CFirstServerOpenEvent::IsEventing(CUser *)

// Function declaration index:
// DECL 0x811CA78 CFirstServerOpenEvent::CFirstServerOpenEvent
// DECL 0x811CA94 CFirstServerOpenEvent::~CFirstServerOpenEvent
// DECL 0x811CAC4 CFirstServerOpenEvent::~CFirstServerOpenEvent
// DECL 0x811CAE2 CFirstServerOpenEvent::StartEvent
// DECL 0x811CB34 CFirstServerOpenEvent::StartEvent
// DECL 0x811CB86 CFirstServerOpenEvent::EndEvent
// DECL 0x811CBD8 CFirstServerOpenEvent::IsEventing

#endif  // __IDA91_CFIRSTSERVEROPENEVENT_H__
