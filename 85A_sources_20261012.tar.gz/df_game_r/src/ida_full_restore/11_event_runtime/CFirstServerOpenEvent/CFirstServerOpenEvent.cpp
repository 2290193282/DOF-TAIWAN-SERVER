#include "CFirstServerOpenEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x811CA78
// IDA_NAME: _ZN21CFirstServerOpenEventC2Ev
// DEMANGLED: CFirstServerOpenEvent::CFirstServerOpenEvent(void)
void __cdecl CFirstServerOpenEvent::CFirstServerOpenEvent(CFirstServerOpenEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B530E8;
}

// IDA_EA: 0x811CA94
// IDA_NAME: _ZN21CFirstServerOpenEventD2Ev
// DEMANGLED: CFirstServerOpenEvent::~CFirstServerOpenEvent()
void __cdecl CFirstServerOpenEvent::~CFirstServerOpenEvent(CFirstServerOpenEvent *this)
{
  *(_DWORD *)this = off_8B530E8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x811CAC4
// IDA_NAME: _ZN21CFirstServerOpenEventD0Ev
// DEMANGLED: CFirstServerOpenEvent::~CFirstServerOpenEvent()
void __cdecl CFirstServerOpenEvent::~CFirstServerOpenEvent(CFirstServerOpenEvent *this)
{
  CFirstServerOpenEvent::~CFirstServerOpenEvent(this);
  operator delete(this);
}

// IDA_EA: 0x811CAE2
// IDA_NAME: _ZN21CFirstServerOpenEvent10StartEventEv
// DEMANGLED: CFirstServerOpenEvent::StartEvent(void)
int __cdecl CFirstServerOpenEvent::StartEvent(CFirstServerOpenEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 32, 0);
  return cMyTrace::operator()((int)v3, "First Server Open Event Start!", v2);
}

// IDA_EA: 0x811CB34
// IDA_NAME: _ZN21CFirstServerOpenEvent10StartEventE10Word_Param
// DEMANGLED: CFirstServerOpenEvent::StartEvent(Word_Param)
int __cdecl CFirstServerOpenEvent::StartEvent(CEventBase *a1)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 46, 0);
  return cMyTrace::operator()((int)v3, "First Server Open Event Start!", v2);
}

// IDA_EA: 0x811CB86
// IDA_NAME: _ZN21CFirstServerOpenEvent8EndEventEv
// DEMANGLED: CFirstServerOpenEvent::EndEvent(void)
int __cdecl CFirstServerOpenEvent::EndEvent(CFirstServerOpenEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "EndEvent", 52, 0);
  return cMyTrace::operator()((int)v3, "First Server Open Event End!", v2);
}

// IDA_EA: 0x811CBD8
// IDA_NAME: _ZN21CFirstServerOpenEvent10IsEventingEP5CUser
// DEMANGLED: CFirstServerOpenEvent::IsEventing(CUser *)
_BOOL4 __cdecl CFirstServerOpenEvent::IsEventing(CFirstServerOpenEvent *this)
{
  return (unsigned __int8)CEventBase::IsEventing(this) == 1;
}
