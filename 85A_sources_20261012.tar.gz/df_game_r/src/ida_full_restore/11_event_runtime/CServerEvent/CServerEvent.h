#ifndef __IDA91_CSERVEREVENT_H__
#define __IDA91_CSERVEREVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CServerEvent
// Source unit: CServerEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1294

/* 1294 */
struct CServerEvent;

// Exported member functions:
// 0x814A6E0	CServerEvent::GetExpRate(void)
// 0x84E9248	CServerEvent::AddExpRate(int)
// 0x84E925F	CServerEvent::TurnOnEvent(int,int)
// 0x84E927F	CServerEvent::IsEventing(int)
// 0x84E9294	CServerEvent::GetEventInterval(int)
// 0x863BC70	CServerEvent::SubExpRate(int)
// 0x863BC87	CServerEvent::TurnOffEvent(int)

// Function declaration index:
// DECL 0x814A6E0 CServerEvent::GetExpRate
// DECL 0x84E9248 CServerEvent::AddExpRate
// DECL 0x84E925F CServerEvent::TurnOnEvent
// DECL 0x84E927F CServerEvent::IsEventing
// DECL 0x84E9294 CServerEvent::GetEventInterval
// DECL 0x863BC70 CServerEvent::SubExpRate
// DECL 0x863BC87 CServerEvent::TurnOffEvent

#endif  // __IDA91_CSERVEREVENT_H__
