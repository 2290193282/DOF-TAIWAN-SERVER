#include "CServerEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x814A6E0
// IDA_NAME: _ZN12CServerEvent10GetExpRateEv
// DEMANGLED: CServerEvent::GetExpRate(void)
int CServerEvent::GetExpRate()
{
  return CServerEvent::m_nExpRate;
}

// IDA_EA: 0x84E9248
// IDA_NAME: _ZN12CServerEvent10AddExpRateEi
// DEMANGLED: CServerEvent::AddExpRate(int)
int __cdecl CServerEvent::AddExpRate(CServerEvent *this)
{
  CServerEvent::m_nExpRate += (int)this;
  return CServerEvent::m_nExpRate;
}

// IDA_EA: 0x84E925F
// IDA_NAME: _ZN12CServerEvent11TurnOnEventEii
// DEMANGLED: CServerEvent::TurnOnEvent(int,int)
CServerEvent *__cdecl CServerEvent::TurnOnEvent(CServerEvent *this, int a2)
{
  CServerEvent *this_1; // eax

  CServerEvent::m_nCurEvent[(_DWORD)this] = 1;
  this_1 = this;
  CServerEvent::m_nCurEventInterval[(_DWORD)this] = a2;
  return this_1;
}

// IDA_EA: 0x84E927F
// IDA_NAME: _ZN12CServerEvent10IsEventingEi
// DEMANGLED: CServerEvent::IsEventing(int)
bool __cdecl CServerEvent::IsEventing(CServerEvent *this)
{
  return CServerEvent::m_nCurEvent[(_DWORD)this] == 1;
}

// IDA_EA: 0x84E9294
// IDA_NAME: _ZN12CServerEvent16GetEventIntervalEi
// DEMANGLED: CServerEvent::GetEventInterval(int)
int __cdecl CServerEvent::GetEventInterval(CServerEvent *this)
{
  return CServerEvent::m_nCurEventInterval[(_DWORD)this];
}

// IDA_EA: 0x863BC70
// IDA_NAME: _ZN12CServerEvent10SubExpRateEi
// DEMANGLED: CServerEvent::SubExpRate(int)
int __cdecl CServerEvent::SubExpRate(CServerEvent *this)
{
  CServerEvent::m_nExpRate -= (int)this;
  return CServerEvent::m_nExpRate;
}

// IDA_EA: 0x863BC87
// IDA_NAME: _ZN12CServerEvent12TurnOffEventEi
// DEMANGLED: CServerEvent::TurnOffEvent(int)
CServerEvent *__cdecl CServerEvent::TurnOffEvent(CServerEvent *this)
{
  CServerEvent *this_1; // eax

  CServerEvent::m_nCurEvent[(_DWORD)this] = 0;
  this_1 = this;
  CServerEvent::m_nCurEventInterval[(_DWORD)this] = 0;
  return this_1;
}
