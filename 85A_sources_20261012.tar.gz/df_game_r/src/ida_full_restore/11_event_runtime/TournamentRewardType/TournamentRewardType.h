#ifndef __IDA91_TOURNAMENTREWARDTYPE_H__
#define __IDA91_TOURNAMENTREWARDTYPE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: TournamentRewardType
// Source unit: TournamentRewardType
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2162

/* 2162 */
struct TournamentRewardType;

// Exported member functions:
// 0x8284750	TournamentRewardType::Clear(void)
// 0x8285546	TournamentRewardType::TournamentRewardType(void)

// Function declaration index:
// DECL 0x8284750 TournamentRewardType::Clear
// DECL 0x8285546 TournamentRewardType::TournamentRewardType

#endif  // __IDA91_TOURNAMENTREWARDTYPE_H__
