#include "TournamentRewardType.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8284750
// IDA_NAME: _ZN20TournamentRewardType5ClearEv
// DEMANGLED: TournamentRewardType::Clear(void)
TournamentRewardType *__cdecl TournamentRewardType::Clear(TournamentRewardType *this)
{
  TournamentRewardType *this_1; // eax

  *(_DWORD *)this = -1;
  *((_DWORD *)this + 1) = 0;
  this_1 = this;
  *((_BYTE *)this + 8) = -1;
  return this_1;
}

// IDA_EA: 0x8285546
// IDA_NAME: _ZN20TournamentRewardTypeC2Ev
// DEMANGLED: TournamentRewardType::TournamentRewardType(void)
void __cdecl TournamentRewardType::TournamentRewardType(TournamentRewardType *this)
{
  TournamentRewardType::Clear(this);
}
