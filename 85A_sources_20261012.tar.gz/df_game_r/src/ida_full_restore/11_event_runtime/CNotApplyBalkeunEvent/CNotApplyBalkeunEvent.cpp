#include "CNotApplyBalkeunEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81B9D5C
// IDA_NAME: _ZN21CNotApplyBalkeunEventC2Ev
// DEMANGLED: CNotApplyBalkeunEvent::CNotApplyBalkeunEvent(void)
void __cdecl CNotApplyBalkeunEvent::CNotApplyBalkeunEvent(CNotApplyBalkeunEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8BBDEA8;
}

// IDA_EA: 0x81B9D78
// IDA_NAME: _ZN21CNotApplyBalkeunEventD2Ev
// DEMANGLED: CNotApplyBalkeunEvent::~CNotApplyBalkeunEvent()
void __cdecl CNotApplyBalkeunEvent::~CNotApplyBalkeunEvent(CNotApplyBalkeunEvent *this)
{
  *(_DWORD *)this = off_8BBDEA8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x81B9DA8
// IDA_NAME: _ZN21CNotApplyBalkeunEventD0Ev
// DEMANGLED: CNotApplyBalkeunEvent::~CNotApplyBalkeunEvent()
void __cdecl CNotApplyBalkeunEvent::~CNotApplyBalkeunEvent(CNotApplyBalkeunEvent *this)
{
  CNotApplyBalkeunEvent::~CNotApplyBalkeunEvent(this);
  operator delete(this);
}

// IDA_EA: 0x81B9DC6
// IDA_NAME: _ZN21CNotApplyBalkeunEvent10StartEventEv
// DEMANGLED: CNotApplyBalkeunEvent::StartEvent(void)
int __cdecl CNotApplyBalkeunEvent::StartEvent(CNotApplyBalkeunEvent *this)
{
  int result; // eax
  int v2; // ebx
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  result = (*(int (__cdecl **)(CNotApplyBalkeunEvent *, _DWORD))(*(_DWORD *)this + 52))(this, 0) ^ 1;
  if ( (_BYTE)result )
  {
    CEventBase::SetEventFlag(this, 1);
    v2 = *(_DWORD *)(G_CEnvironment() + 432);
    cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CNotApplyBalkeunEvent::StartEvent()", 22, 0);
    return cMyTrace::operator()((int)v3, "Not Apply Balkeun Event Start! server(%d)", v2);
  }
  return result;
}

// IDA_EA: 0x81B9E4C
// IDA_NAME: _ZN21CNotApplyBalkeunEvent10StartEventE10Word_Param
// DEMANGLED: CNotApplyBalkeunEvent::StartEvent(Word_Param)
int __cdecl CNotApplyBalkeunEvent::StartEvent(CEventBase *a1)
{
  int result; // eax
  int v2; // ebx
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  result = (*(int (__cdecl **)(CEventBase *, _DWORD))(*(_DWORD *)a1 + 52))(a1, 0) ^ 1;
  if ( (_BYTE)result )
  {
    CEventBase::SetEventFlag(a1, 1);
    v2 = *(_DWORD *)(G_CEnvironment() + 432);
    cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CNotApplyBalkeunEvent::StartEvent(Word_Param)", 31, 0);
    return cMyTrace::operator()((int)v3, "Not Apply Balkeun Event Start! server(%d)", v2);
  }
  return result;
}

// IDA_EA: 0x81B9ED2
// IDA_NAME: _ZN21CNotApplyBalkeunEvent8EndEventEv
// DEMANGLED: CNotApplyBalkeunEvent::EndEvent(void)
int __cdecl CNotApplyBalkeunEvent::EndEvent(CNotApplyBalkeunEvent *this)
{
  int result; // eax
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  result = (*(int (__cdecl **)(CNotApplyBalkeunEvent *, _DWORD))(*(_DWORD *)this + 52))(this, 0);
  if ( (_BYTE)result )
  {
    CEventBase::SetEventFlag(this, 0);
    cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CNotApplyBalkeunEvent::EndEvent()", 40, 0);
    return cMyTrace::operator()((int)v3, "Not Apply Balkeun Event End", v2);
  }
  return result;
}
