#ifndef __IDA91_CNOTAPPLYBALKEUNEVENT_H__
#define __IDA91_CNOTAPPLYBALKEUNEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CNotApplyBalkeunEvent
// Source unit: CNotApplyBalkeunEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4141

/* 4141 */
struct CNotApplyBalkeunEvent;

// Exported member functions:
// 0x81B9D5C	CNotApplyBalkeunEvent::CNotApplyBalkeunEvent(void)
// 0x81B9D78	CNotApplyBalkeunEvent::~CNotApplyBalkeunEvent()
// 0x81B9DA8	CNotApplyBalkeunEvent::~CNotApplyBalkeunEvent()
// 0x81B9DC6	CNotApplyBalkeunEvent::StartEvent(void)
// 0x81B9E4C	CNotApplyBalkeunEvent::StartEvent(Word_Param)
// 0x81B9ED2	CNotApplyBalkeunEvent::EndEvent(void)

// Function declaration index:
// DECL 0x81B9D5C CNotApplyBalkeunEvent::CNotApplyBalkeunEvent
// DECL 0x81B9D78 CNotApplyBalkeunEvent::~CNotApplyBalkeunEvent
// DECL 0x81B9DA8 CNotApplyBalkeunEvent::~CNotApplyBalkeunEvent
// DECL 0x81B9DC6 CNotApplyBalkeunEvent::StartEvent
// DECL 0x81B9E4C CNotApplyBalkeunEvent::StartEvent
// DECL 0x81B9ED2 CNotApplyBalkeunEvent::EndEvent

#endif  // __IDA91_CNOTAPPLYBALKEUNEVENT_H__
