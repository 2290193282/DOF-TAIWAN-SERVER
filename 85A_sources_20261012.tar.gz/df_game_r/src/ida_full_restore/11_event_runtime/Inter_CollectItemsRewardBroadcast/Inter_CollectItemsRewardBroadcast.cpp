#include "Inter_CollectItemsRewardBroadcast.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84E7598
// IDA_NAME: _ZN33Inter_CollectItemsRewardBroadcast12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_CollectItemsRewardBroadcast::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_CollectItemsRewardBroadcast::dispatch_sig(
        Inter_CollectItemsRewardBroadcast *this,
        CUser *a2,
        char *a3)
{
  GameWorld *v3; // eax
  __int16 NpcIndexEv; // ax
  size_t v5; // eax
  size_t v6; // eax
  GameWorld *v7; // eax
  _BYTE v9[4]; // [esp+1Ch] [ebp-1Ch] BYREF
  PacketBuf *v10[3]; // [esp+20h] [ebp-18h] BYREF
  char *v11; // [esp+2Ch] [ebp-Ch]

  v11 = a3;
  PacketGuard::PacketGuard((PacketGuard *)v10);
  InterfacePacketBuf::put_header(v10, 0, 86);
  InterfacePacketBuf::put_byte(v10, 11);
  InterfacePacketBuf::put_byte(v10, (unsigned __int8)v11[18]);
  if ( v11[18] == 2 )
  {
    CTimeGate::SetLevel(GlobalData::s_timeGate_, 100);
    CUserResetTimeGateQuest::CUserResetTimeGateQuest((CUserResetTimeGateQuest *)v9);
    v3 = (GameWorld *)G_GameWorld();
    GameWorld::modify_user(v3, (CUserModifier *)v9);
    NpcIndexEv = CTimeGate::getNpcIndex(GlobalData::s_timeGate_);
    InterfacePacketBuf::put_short(v10, NpcIndexEv);
  }
  else
  {
    InterfacePacketBuf::put_short(v10, 0);
  }
  v5 = strlen(v11 + 20);
  InterfacePacketBuf::put_int(v10, v5);
  v6 = strlen(v11 + 20);
  InterfacePacketBuf::put_str(v10, v11 + 20, v6);
  InterfacePacketBuf::finalize(v10, 1);
  v7 = (GameWorld *)G_GameWorld();
  GameWorld::send_all(v7, (PacketGuard *)v10);
  PacketGuard::~PacketGuard(v10);
  return 0;
}

// IDA_EA: 0x84EEDDC
// IDA_NAME: _ZN33Inter_CollectItemsRewardBroadcastC2Ev
// DEMANGLED: Inter_CollectItemsRewardBroadcast::Inter_CollectItemsRewardBroadcast(void)
void __cdecl Inter_CollectItemsRewardBroadcast::Inter_CollectItemsRewardBroadcast(
        Inter_CollectItemsRewardBroadcast *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8E4B8;
}

// IDA_EA: 0x84F5C22
// IDA_NAME: _ZN33Inter_CollectItemsRewardBroadcastD2Ev
// DEMANGLED: Inter_CollectItemsRewardBroadcast::~Inter_CollectItemsRewardBroadcast()
void __cdecl Inter_CollectItemsRewardBroadcast::~Inter_CollectItemsRewardBroadcast(
        Inter_CollectItemsRewardBroadcast *this)
{
  *(_DWORD *)this = &off_8C8E4B8;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84F5C52
// IDA_NAME: _ZN33Inter_CollectItemsRewardBroadcastD0Ev
// DEMANGLED: Inter_CollectItemsRewardBroadcast::~Inter_CollectItemsRewardBroadcast()
void __cdecl Inter_CollectItemsRewardBroadcast::~Inter_CollectItemsRewardBroadcast(
        Inter_CollectItemsRewardBroadcast *this)
{
  Inter_CollectItemsRewardBroadcast::~Inter_CollectItemsRewardBroadcast(this);
  operator delete(this);
}
