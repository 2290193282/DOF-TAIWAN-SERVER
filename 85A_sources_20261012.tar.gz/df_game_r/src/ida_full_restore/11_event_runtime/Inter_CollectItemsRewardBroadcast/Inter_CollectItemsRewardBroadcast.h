#ifndef __IDA91_INTER_COLLECTITEMSREWARDBROADCAST_H__
#define __IDA91_INTER_COLLECTITEMSREWARDBROADCAST_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_CollectItemsRewardBroadcast
// Source unit: Inter_CollectItemsRewardBroadcast
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 3229

/* 3229 */
struct Inter_CollectItemsRewardBroadcast;

// Exported member functions:
// 0x84E7598	Inter_CollectItemsRewardBroadcast::dispatch_sig(CUser *,char *,int)
// 0x84EEDDC	Inter_CollectItemsRewardBroadcast::Inter_CollectItemsRewardBroadcast(void)
// 0x84F5C22	Inter_CollectItemsRewardBroadcast::~Inter_CollectItemsRewardBroadcast()
// 0x84F5C52	Inter_CollectItemsRewardBroadcast::~Inter_CollectItemsRewardBroadcast()

// Function declaration index:
// DECL 0x84E7598 Inter_CollectItemsRewardBroadcast::dispatch_sig
// DECL 0x84EEDDC Inter_CollectItemsRewardBroadcast::Inter_CollectItemsRewardBroadcast
// DECL 0x84F5C22 Inter_CollectItemsRewardBroadcast::~Inter_CollectItemsRewardBroadcast
// DECL 0x84F5C52 Inter_CollectItemsRewardBroadcast::~Inter_CollectItemsRewardBroadcast

#endif  // __IDA91_INTER_COLLECTITEMSREWARDBROADCAST_H__
