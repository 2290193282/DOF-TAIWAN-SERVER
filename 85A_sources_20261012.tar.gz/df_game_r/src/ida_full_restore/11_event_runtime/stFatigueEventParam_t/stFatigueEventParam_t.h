#ifndef __IDA91_STFATIGUEEVENTPARAM_T_H__
#define __IDA91_STFATIGUEEVENTPARAM_T_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stFatigueEventParam_t
// Source unit: stFatigueEventParam_t
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4032

/* 4032 */
struct stFatigueEventParam_t;

// Exported member functions:
// 0x8A8CCC4	stFatigueEventParam_t::stFatigueEventParam_t(void)
// 0x8A91DFC	stFatigueEventParam_t::~stFatigueEventParam_t()

// Function declaration index:
// DECL 0x8A8CCC4 stFatigueEventParam_t::stFatigueEventParam_t
// DECL 0x8A91DFC stFatigueEventParam_t::~stFatigueEventParam_t

#endif  // __IDA91_STFATIGUEEVENTPARAM_T_H__
