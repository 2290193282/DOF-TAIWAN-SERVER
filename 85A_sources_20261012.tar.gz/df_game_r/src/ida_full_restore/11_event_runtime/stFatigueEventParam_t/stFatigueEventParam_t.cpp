#include "stFatigueEventParam_t.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8A8CCC4
// IDA_NAME: _ZN21stFatigueEventParam_tC2Ev
// DEMANGLED: stFatigueEventParam_t::stFatigueEventParam_t(void)
void __cdecl stFatigueEventParam_t::stFatigueEventParam_t(stFatigueEventParam_t *this)
{
  *(_WORD *)this = 0;
  *((_DWORD *)this + 1) = 0;
  memset((char *)this + 8, 0, 4u);
}

// IDA_EA: 0x8A91DFC
// IDA_NAME: _ZN21stFatigueEventParam_tD2Ev
// DEMANGLED: stFatigueEventParam_t::~stFatigueEventParam_t()
void stFatigueEventParam_t::~stFatigueEventParam_t()
{
  ;
}
