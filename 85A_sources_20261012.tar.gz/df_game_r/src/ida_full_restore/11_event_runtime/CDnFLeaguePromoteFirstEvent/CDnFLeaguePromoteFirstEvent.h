#ifndef __IDA91_CDNFLEAGUEPROMOTEFIRSTEVENT_H__
#define __IDA91_CDNFLEAGUEPROMOTEFIRSTEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CDnFLeaguePromoteFirstEvent
// Source unit: CDnFLeaguePromoteFirstEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4108

/* 4108 */
struct CDnFLeaguePromoteFirstEvent;

// Exported member functions:
// 0x811C0BA	CDnFLeaguePromoteFirstEvent::CDnFLeaguePromoteFirstEvent(void)
// 0x811C0D6	CDnFLeaguePromoteFirstEvent::~CDnFLeaguePromoteFirstEvent()
// 0x811C106	CDnFLeaguePromoteFirstEvent::~CDnFLeaguePromoteFirstEvent()
// 0x811C124	CDnFLeaguePromoteFirstEvent::StartEvent(void)
// 0x811C176	CDnFLeaguePromoteFirstEvent::StartEvent(Word_Param)
// 0x811C190	CDnFLeaguePromoteFirstEvent::EndEvent(void)

// Function declaration index:
// DECL 0x811C0BA CDnFLeaguePromoteFirstEvent::CDnFLeaguePromoteFirstEvent
// DECL 0x811C0D6 CDnFLeaguePromoteFirstEvent::~CDnFLeaguePromoteFirstEvent
// DECL 0x811C106 CDnFLeaguePromoteFirstEvent::~CDnFLeaguePromoteFirstEvent
// DECL 0x811C124 CDnFLeaguePromoteFirstEvent::StartEvent
// DECL 0x811C176 CDnFLeaguePromoteFirstEvent::StartEvent
// DECL 0x811C190 CDnFLeaguePromoteFirstEvent::EndEvent

#endif  // __IDA91_CDNFLEAGUEPROMOTEFIRSTEVENT_H__
