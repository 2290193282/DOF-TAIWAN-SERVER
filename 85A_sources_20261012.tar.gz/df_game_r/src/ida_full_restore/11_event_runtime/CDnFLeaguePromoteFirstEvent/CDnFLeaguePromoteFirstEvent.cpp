#include "CDnFLeaguePromoteFirstEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x811C0BA
// IDA_NAME: _ZN27CDnFLeaguePromoteFirstEventC2Ev
// DEMANGLED: CDnFLeaguePromoteFirstEvent::CDnFLeaguePromoteFirstEvent(void)
void __cdecl CDnFLeaguePromoteFirstEvent::CDnFLeaguePromoteFirstEvent(CDnFLeaguePromoteFirstEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B52148;
}

// IDA_EA: 0x811C0D6
// IDA_NAME: _ZN27CDnFLeaguePromoteFirstEventD2Ev
// DEMANGLED: CDnFLeaguePromoteFirstEvent::~CDnFLeaguePromoteFirstEvent()
void __cdecl CDnFLeaguePromoteFirstEvent::~CDnFLeaguePromoteFirstEvent(CDnFLeaguePromoteFirstEvent *this)
{
  *(_DWORD *)this = off_8B52148;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x811C106
// IDA_NAME: _ZN27CDnFLeaguePromoteFirstEventD0Ev
// DEMANGLED: CDnFLeaguePromoteFirstEvent::~CDnFLeaguePromoteFirstEvent()
void __cdecl CDnFLeaguePromoteFirstEvent::~CDnFLeaguePromoteFirstEvent(CDnFLeaguePromoteFirstEvent *this)
{
  CDnFLeaguePromoteFirstEvent::~CDnFLeaguePromoteFirstEvent(this);
  operator delete(this);
}

// IDA_EA: 0x811C124
// IDA_NAME: _ZN27CDnFLeaguePromoteFirstEvent10StartEventEv
// DEMANGLED: CDnFLeaguePromoteFirstEvent::StartEvent(void)
int __cdecl CDnFLeaguePromoteFirstEvent::StartEvent(CDnFLeaguePromoteFirstEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CDnFLeaguePromoteFirstEvent::StartEvent()", 19, 0);
  return cMyTrace::operator()((int)v3, "CDnFLeaguePromoteFirstEvent Event Start!", v2);
}

// IDA_EA: 0x811C176
// IDA_NAME: _ZN27CDnFLeaguePromoteFirstEvent10StartEventE10Word_Param
// DEMANGLED: CDnFLeaguePromoteFirstEvent::StartEvent(Word_Param)
int __cdecl CDnFLeaguePromoteFirstEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x811C190
// IDA_NAME: _ZN27CDnFLeaguePromoteFirstEvent8EndEventEv
// DEMANGLED: CDnFLeaguePromoteFirstEvent::EndEvent(void)
int __cdecl CDnFLeaguePromoteFirstEvent::EndEvent(CDnFLeaguePromoteFirstEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CDnFLeaguePromoteFirstEvent::EndEvent()", 29, 0);
  return cMyTrace::operator()((int)v3, "CDnFLeaguePromoteFirstEvent Event End!", v2);
}
