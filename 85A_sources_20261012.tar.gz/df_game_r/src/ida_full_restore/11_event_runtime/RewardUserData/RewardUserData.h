#ifndef __IDA91_REWARDUSERDATA_H__
#define __IDA91_REWARDUSERDATA_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: RewardUserData
// Source unit: RewardUserData
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1479

/* 1479 */
struct RewardUserData;

// Exported member functions:
// 0x81BBF82	RewardUserData::RewardUserData(void)

// Function declaration index:
// DECL 0x81BBF82 RewardUserData::RewardUserData

#endif  // __IDA91_REWARDUSERDATA_H__
