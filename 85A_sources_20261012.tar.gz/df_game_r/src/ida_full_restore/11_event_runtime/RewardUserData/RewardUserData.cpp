#include "RewardUserData.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81BBF82
// IDA_NAME: _ZN14RewardUserDataC2Ev
// DEMANGLED: RewardUserData::RewardUserData(void)
void __cdecl RewardUserData::RewardUserData(RewardUserData *this)
{
  *(_DWORD *)this = 0;
  *((_DWORD *)this + 1) = 0;
  *((_BYTE *)this + 8) = 0;
}
