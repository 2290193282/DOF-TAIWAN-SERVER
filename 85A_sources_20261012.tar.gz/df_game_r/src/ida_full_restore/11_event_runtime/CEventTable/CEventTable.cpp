#include "CEventTable.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x811A0C8
// IDA_NAME: _ZN11CEventTableC2Ev
// DEMANGLED: CEventTable::CEventTable(void)
void __cdecl CEventTable::CEventTable(CEventTable *this)
{
  ;
}

// IDA_EA: 0x811A0CE
// IDA_NAME: _ZN11CEventTableD2Ev
// DEMANGLED: CEventTable::~CEventTable()
void CEventTable::~CEventTable()
{
  ;
}

// IDA_EA: 0x811A0D4
// IDA_NAME: _ZN11CEventTable18GetEventTableCountEv
// DEMANGLED: CEventTable::GetEventTableCount(void)
int CEventTable::GetEventTableCount()
{
  return 79;
}

// IDA_EA: 0x811A0DE
// IDA_NAME: _ZN11CEventTable12GetEventBaseEi
// DEMANGLED: CEventTable::GetEventBase(int)
int __cdecl CEventTable::GetEventBase(CEventTable *this)
{
  if ( (int)this < 0 || CEventTable::GetEventTableCount() <= (int)this )
    return 0;
  else
    return dword_936FA68[5 * (_DWORD)this];
}

// IDA_EA: 0x811A11E
// IDA_NAME: _ZN11CEventTable10GetEventIdEi
// DEMANGLED: CEventTable::GetEventId(int)
int __cdecl CEventTable::GetEventId(CEventTable *this)
{
  if ( (int)this < 0 || CEventTable::GetEventTableCount() <= (int)this )
    return 0;
  else
    return events[5 * (_DWORD)this];
}

// IDA_EA: 0x811A1E0
// IDA_NAME: _ZN11CEventTable16VerifyEventTableERSt6vectorIiSaIiEE
// DEMANGLED: CEventTable::VerifyEventTable(std::vector<int,std::allocator<int>> &)
int __cdecl CEventTable::VerifyEventTable(CEventTable *a1)
{
  char *p_dest; // edx
  unsigned int n255; // ebx
  char *v3; // edi
  char *v4; // edx
  int v5; // ebx
  char dest; // [esp+19h] [ebp-16Fh] BYREF
  __int16 v8; // [esp+1Ah] [ebp-16Eh] BYREF
  int v9; // [esp+118h] [ebp-70h] BYREF
  int n_rowsEv_1; // [esp+11Ch] [ebp-6Ch] BYREF
  _BYTE v11[24]; // [esp+120h] [ebp-68h] BYREF
  int EventTable; // [esp+138h] [ebp-50h] BYREF
  bool v13; // [esp+13Fh] [ebp-49h] BYREF
  int v14; // [esp+140h] [ebp-48h] BYREF
  char v15[8]; // [esp+144h] [ebp-44h] BYREF
  int v16; // [esp+14Ch] [ebp-3Ch] BYREF
  _BYTE v17[8]; // [esp+154h] [ebp-34h] BYREF
  int v18; // [esp+15Ch] [ebp-2Ch] BYREF
  int v19; // [esp+160h] [ebp-28h] BYREF
  MySQL *DBHandle; // [esp+164h] [ebp-24h]
  char intEiRi; // [esp+16Bh] [ebp-1Dh]
  int n_rowsEv; // [esp+16Ch] [ebp-1Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle(GlobalData::s_db_mgr, 1, 0);
  intEiRi = 0;
  v14 = 0;
  p_dest = &dest;
  n255 = 255;
  if ( ((unsigned __int8)&dest & 1) != 0 )
  {
    dest = 0;
    p_dest = (char *)&v8;
    n255 = 254;
  }
  if ( ((unsigned __int8)p_dest & 2) != 0 )
  {
    *(_WORD *)p_dest = 0;
    p_dest += 2;
    n255 -= 2;
  }
  memset(p_dest, 0, 4 * (n255 >> 2));
  v3 = &p_dest[4 * (n255 >> 2)];
  v4 = v3;
  if ( (n255 & 2) != 0 )
  {
    *(_WORD *)v3 = 0;
    v4 = v3 + 2;
  }
  if ( (n255 & 1) != 0 )
    *v4 = 0;
  v13 = 0;
  EventTable = -1;
  std::map<int,int>::map((int)v11);
  MySQL::set_query(DBHandle, "seLect event_id, event_name from dnf_event_info");
  intEiRi = MySQL::exec(DBHandle, 1);
  if ( intEiRi == 1 )
  {
    n_rowsEv = MySQL::get_n_rows(DBHandle);
    for ( n_rowsEv_1 = 0; n_rowsEv_1 < n_rowsEv; ++n_rowsEv_1 )
    {
      intEiRi = MySQL::fetch(DBHandle);
      if ( intEiRi != 1 )
        break;
      intEiRi = MySQL::get_int(DBHandle, 0, &v14);
      if ( intEiRi != 1 )
      {
        v5 = 0;
        goto LABEL_29;
      }
      intEiRi = MySQL::get_str(DBHandle, 1, &dest, 255);
      if ( intEiRi != 1 )
      {
        v5 = 0;
        goto LABEL_29;
      }
      EventTable = _FindEventTable(v14, &dest, &v13);
      if ( EventTable >= 0 )
      {
        if ( v13 )
        {
          v5 = 0;
          goto LABEL_29;
        }
        v18 = 1;
        std::make_pair<int &,int>((int)v17, (int)&EventTable, (int)&v18);
        std::pair<int const,int>::pair<int,int>(&v16, (int)v17);
        std::map<int,int>::insert((int)v15);
      }
    }
    for ( n_rowsEv_1 = 0; CEventTable::GetEventTableCount() > n_rowsEv_1; ++n_rowsEv_1 )
    {
      std::map<int,int>::find((int)&v9);
      std::map<int,int>::end((int)&v19);
      if ( std::_Rb_tree_iterator<std::pair<int const,int>>::operator==(&v9, &v19) )
        std::vector<int>::push_back((int)a1, (int)&n_rowsEv_1);
    }
    v5 = 1;
  }
  else
  {
    v5 = 0;
  }
LABEL_29:
  std::map<int,int>::~map((int)v11);
  return v5;
}

// IDA_EA: 0x811A4D4
// IDA_NAME: _ZN11CEventTable16InsertEventTableERSt6vectorIiSaIiEE
// DEMANGLED: CEventTable::InsertEventTable(std::vector<int,std::allocator<int>> &)
int __usercall CEventTable::InsertEventTable@<eax>(int a1@<esi>, int a2)
{
  char *p_s; // edx
  unsigned int n255; // ebx
  char *v4; // edi
  char *v5; // edx
  _DWORD *v6; // eax
  const char *String; // ebx
  int v8; // edi
  _DWORD *v9; // eax
  const char *v10; // eax
  int v11; // ebx
  const char *v13; // [esp+2Ch] [ebp-13Ch]
  char s; // [esp+39h] [ebp-12Fh] BYREF
  __int16 v15; // [esp+3Ah] [ebp-12Eh] BYREF
  int v16; // [esp+138h] [ebp-30h] BYREF
  std::string v17; // [esp+13Ch] [ebp-2Ch] BYREF
  char v18[4]; // [esp+140h] [ebp-28h] BYREF
  char v19[4]; // [esp+144h] [ebp-24h] BYREF
  MySQL *DBHandle; // [esp+148h] [ebp-20h]
  char v21; // [esp+14Fh] [ebp-19h]

  if ( (unsigned __int8)std::vector<int>::empty(a2) == 1 )
    return 1;
  p_s = &s;
  n255 = 255;
  if ( ((unsigned __int8)&s & 1) != 0 )
  {
    s = 0;
    p_s = (char *)&v15;
    n255 = 254;
  }
  if ( ((unsigned __int8)p_s & 2) != 0 )
  {
    *(_WORD *)p_s = 0;
    p_s += 2;
    n255 -= 2;
  }
  memset(p_s, 0, 4 * (n255 >> 2));
  v4 = &p_s[4 * (n255 >> 2)];
  v5 = v4;
  if ( (n255 & 2) != 0 )
  {
    *(_WORD *)v4 = 0;
    v5 = v4 + 2;
  }
  if ( (n255 & 1) != 0 )
    *v5 = 0;
  std::string::string(&v17);
  std::vector<int>::begin((int)&v16, a2);
  while ( 1 )
  {
    std::vector<int>::end((int)v18, a2);
    if ( !__gnu_cxx::operator!=<int *,std::vector<int>>((int)&v16, (int)v18) )
      break;
    v6 = (_DWORD *)__gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator*((int)&v16);
    String = (const char *)RDARScriptStringManager::findString(
                             (RDARScriptStringManager *)&g_scriptStringManager_,
                             4,
                             (&off_936FA70)[5 * *v6],
                             0);                // "event_msg_01"
    v13 = off_936FA6C[5 * *(_DWORD *)__gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator*((int)&v16)];// "CUnlimitFatigueEvent"
    v8 = dword_936FA64[5 * *(_DWORD *)__gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator*((int)&v16)];
    v9 = (_DWORD *)__gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator*((int)&v16);
    sprintf(&s, "(%d,%d,'%s','%s')", events[5 * *v9], v8, v13, String);
    std::string::operator+=(&v17, &s);
    __gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator++(&v16);
    std::vector<int>::end((int)v19, a2);
    if ( __gnu_cxx::operator!=<int *,std::vector<int>>((int)&v16, (int)v19) )
      std::string::operator+=(&v17, ",");
  }
  DBHandle = (MySQL *)DBMgr::GetDBHandle(GlobalData::s_db_mgr, 1, 0);
  v21 = 0;
  v10 = (const char *)std::string::c_str(&v17);
  MySQL::set_query(
    DBHandle,
    "inSert into dnf_event_info(event_id, apply_type, event_name, event_explain) values%s",
    v10);
  v21 = MySQL::exec(DBHandle, 1);
  if ( v21 == 1 )
  {
    v11 = 1;
  }
  else
  {
    MySQL::getDBError(DBHandle);
    a1 = 0;
    v11 = 0;
  }
  std::string::~string(&v17);
  if ( v11 )
    return 1;
  return a1;
}
