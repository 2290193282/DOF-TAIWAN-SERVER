#ifndef __IDA91_CEVENTTABLE_H__
#define __IDA91_CEVENTTABLE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CEventTable
// Source unit: CEventTable
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1209

/* 1209 */
struct CEventTable;

// Exported member functions:
// 0x811A0C8	CEventTable::CEventTable(void)
// 0x811A0CE	CEventTable::~CEventTable()
// 0x811A0D4	CEventTable::GetEventTableCount(void)
// 0x811A0DE	CEventTable::GetEventBase(int)
// 0x811A11E	CEventTable::GetEventId(int)
// 0x811A1E0	CEventTable::VerifyEventTable(std::vector<int,std::allocator<int>> &)
// 0x811A4D4	CEventTable::InsertEventTable(std::vector<int,std::allocator<int>> &)

// Function declaration index:
// DECL 0x811A0C8 CEventTable::CEventTable
// DECL 0x811A0CE CEventTable::~CEventTable
// DECL 0x811A0D4 CEventTable::GetEventTableCount
// DECL 0x811A0DE CEventTable::GetEventBase
// DECL 0x811A11E CEventTable::GetEventId
// DECL 0x811A1E0 CEventTable::VerifyEventTable
// DECL 0x811A4D4 CEventTable::InsertEventTable

#endif  // __IDA91_CEVENTTABLE_H__
