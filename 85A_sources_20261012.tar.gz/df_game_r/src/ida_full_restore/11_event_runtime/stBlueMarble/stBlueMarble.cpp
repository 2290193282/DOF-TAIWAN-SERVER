#include "stBlueMarble.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8231D98
// IDA_NAME: _ZN12stBlueMarbleC2Ev
// DEMANGLED: stBlueMarble::stBlueMarble(void)
void __cdecl stBlueMarble::stBlueMarble(stBlueMarble *this)
{
  ParamBase::ParamBase(this);
  *(_DWORD *)this = off_8BDE890;
  *((_DWORD *)this + 1) = 0;
}

// IDA_EA: 0x8246612
// IDA_NAME: _ZN12stBlueMarbleD2Ev
// DEMANGLED: stBlueMarble::~stBlueMarble()
void __cdecl stBlueMarble::~stBlueMarble(stBlueMarble *this)
{
  *(_DWORD *)this = off_8BDE890;
  ParamBase::~ParamBase(this);
}

// IDA_EA: 0x8246642
// IDA_NAME: _ZN12stBlueMarbleD0Ev
// DEMANGLED: stBlueMarble::~stBlueMarble()
void __cdecl stBlueMarble::~stBlueMarble(stBlueMarble *this)
{
  stBlueMarble::~stBlueMarble(this);
  operator delete(this);
}
