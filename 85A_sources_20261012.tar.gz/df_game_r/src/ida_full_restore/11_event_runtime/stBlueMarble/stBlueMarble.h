#ifndef __IDA91_STBLUEMARBLE_H__
#define __IDA91_STBLUEMARBLE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stBlueMarble
// Source unit: stBlueMarble
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1815

/* 1815 */
struct stBlueMarble;

// Exported member functions:
// 0x8231D98	stBlueMarble::stBlueMarble(void)
// 0x8246612	stBlueMarble::~stBlueMarble()
// 0x8246642	stBlueMarble::~stBlueMarble()

// Function declaration index:
// DECL 0x8231D98 stBlueMarble::stBlueMarble
// DECL 0x8246612 stBlueMarble::~stBlueMarble
// DECL 0x8246642 stBlueMarble::~stBlueMarble

#endif  // __IDA91_STBLUEMARBLE_H__
