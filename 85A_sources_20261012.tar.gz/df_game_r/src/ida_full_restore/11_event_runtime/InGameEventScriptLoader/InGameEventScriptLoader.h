#ifndef __IDA91_INGAMEEVENTSCRIPTLOADER_H__
#define __IDA91_INGAMEEVENTSCRIPTLOADER_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: InGameEventScriptLoader
// Source unit: InGameEventScriptLoader
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4569

/* 4569 */
struct InGameEventScriptLoader;

// Exported member functions:
// 0x8110F4C	InGameEventScriptLoader::InGameEventScriptLoader(void)
// 0x8110F60	InGameEventScriptLoader::~InGameEventScriptLoader()
// 0x8982A4A	InGameEventScriptLoader::importInGameEventScript(int,std::string const&)
// 0x8982F10	InGameEventScriptLoader::insertEventScript(std::string const&,InGameEventScript *)
// 0x8982F38	InGameEventScriptLoader::getEventScript(int,std::string const&)

// Function declaration index:
// DECL 0x8110F4C InGameEventScriptLoader::InGameEventScriptLoader
// DECL 0x8110F60 InGameEventScriptLoader::~InGameEventScriptLoader
// DECL 0x8982A4A InGameEventScriptLoader::importInGameEventScript
// DECL 0x8982F10 InGameEventScriptLoader::insertEventScript
// DECL 0x8982F38 InGameEventScriptLoader::getEventScript

#endif  // __IDA91_INGAMEEVENTSCRIPTLOADER_H__
