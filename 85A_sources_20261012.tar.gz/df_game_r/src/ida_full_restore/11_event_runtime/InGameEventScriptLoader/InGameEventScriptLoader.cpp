#include "InGameEventScriptLoader.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8110F4C
// IDA_NAME: _ZN23InGameEventScriptLoaderC2Ev
// DEMANGLED: InGameEventScriptLoader::InGameEventScriptLoader(void)
void __cdecl InGameEventScriptLoader::InGameEventScriptLoader(InGameEventScriptLoader *this)
{
  std::map<std::string,InGameEventScript *>::map(this);
}

// IDA_EA: 0x8110F60
// IDA_NAME: _ZN23InGameEventScriptLoaderD2Ev
// DEMANGLED: InGameEventScriptLoader::~InGameEventScriptLoader()
void __cdecl InGameEventScriptLoader::~InGameEventScriptLoader(InGameEventScriptLoader *this)
{
  std::map<std::string,InGameEventScript *>::~map((int)this);
}

// IDA_EA: 0x8982A4A
// IDA_NAME: _ZN23InGameEventScriptLoader23importInGameEventScriptEiRKSs
// DEMANGLED: InGameEventScriptLoader::importInGameEventScript(int,std::string const&)
std::string *__cdecl InGameEventScriptLoader::importInGameEventScript(
        InGameEventScriptLoader *this,
        int n404,
        std::string *a3)
{
  std::string *ptr_6; // ebx
  TCHAR *filename_5; // eax
  std::string *ptr_5; // ebx
  TCHAR *filename_4; // eax
  std::string *ptr_1; // ebx
  TCHAR *filename; // eax
  std::string *ptr_11; // ebx
  TCHAR *filename_10; // eax
  std::string *ptr_10; // ebx
  TCHAR *filename_9; // eax
  std::string *ptr_7; // ebx
  TCHAR *filename_6; // eax
  std::string *ptr_9; // ebx
  TCHAR *filename_8; // eax
  std::string *ptr_8; // ebx
  TCHAR *filename_7; // eax
  std::string *ptr_3; // ebx
  TCHAR *filename_2; // eax
  std::string *ptr_4; // ebx
  TCHAR *filename_3; // eax
  std::string *ptr_2; // ebx
  TCHAR *filename_1; // eax
  std::string *ptr; // [esp+18h] [ebp-20h]
  char LoginEventScript; // [esp+1Fh] [ebp-19h]

  ptr = 0;
  LoginEventScript = 1;
  if ( n404 == 404 )
  {
    ptr_1 = (std::string *)operator new(0x6Cu);
    LevelUpRewardScript::LevelUpRewardScript(ptr_1);
    ptr = ptr_1;
    filename = (TCHAR *)std::string::c_str(a3);
    LoginEventScript = importLevelUpRewardScript((int)ptr_1, filename);
    goto LABEL_29;
  }
  if ( n404 <= 404 )
  {
    if ( n404 == 101 )
    {
      ptr_2 = (std::string *)operator new(0x64u);
      UsedFatigueGiveItemScript::UsedFatigueGiveItemScript(ptr_2);
      ptr = ptr_2;
      filename_1 = (TCHAR *)std::string::c_str(a3);
      LoginEventScript = importUsedFatigueGiveItemEventScript(ptr_2, filename_1);
      goto LABEL_29;
    }
    if ( n404 <= 101 )
    {
      if ( n404 == 86 )
      {
        ptr_3 = (std::string *)operator new(0x78u);
        AttendanceScript::AttendanceScript(ptr_3);
        ptr = ptr_3;
        filename_2 = (TCHAR *)std::string::c_str(a3);
        LoginEventScript = importAttendanceScript(ptr_3, filename_2);
      }
      else if ( n404 == 92 )
      {
        ptr_4 = (std::string *)operator new(0x18u);
        PcBangPlayTimeScript::PcBangPlayTimeScript(ptr_4);
        ptr = ptr_4;
        filename_3 = (TCHAR *)std::string::c_str(a3);
        LoginEventScript = importPcBangPlayTimeScript(ptr_4, filename_3);
      }
      goto LABEL_29;
    }
    if ( n404 < 401 )
      goto LABEL_29;
    if ( n404 > 402 )
    {
      ptr_5 = (std::string *)operator new(0x24u);
      AddItemCountDBScript::AddItemCountDBScript(ptr_5);
      ptr = ptr_5;
      filename_4 = (TCHAR *)std::string::c_str(a3);
      LoginEventScript = importAddItemCountDBEventScript(ptr_5, filename_4);
      goto LABEL_29;
    }
LABEL_19:
    ptr_6 = (std::string *)operator new(0x50u);
    AccountFirstLoginScript::AccountFirstLoginScript(ptr_6);
    ptr = ptr_6;
    filename_5 = (TCHAR *)std::string::c_str(a3);
    LoginEventScript = importAccountFirstLoginEventScript(ptr_6, filename_5);
    goto LABEL_29;
  }
  if ( n404 == 409 )
  {
    ptr_7 = (std::string *)operator new(0x10u);
    FatigueQuantityScript::FatigueQuantityScript(ptr_7);
    ptr = ptr_7;
    filename_6 = (TCHAR *)std::string::c_str(a3);
    LoginEventScript = importFatigueQuantityEventScript(ptr_7, filename_6);
    goto LABEL_29;
  }
  if ( n404 > 409 )
  {
    if ( n404 == 411 )
    {
      ptr_8 = (std::string *)operator new(0x34u);
      ObjectBringUpScript::ObjectBringUpScript(ptr_8);
      ptr = ptr_8;
      filename_7 = (TCHAR *)std::string::c_str(a3);
      LoginEventScript = importObjectBringUpEventScript(ptr_8, filename_7);
      goto LABEL_29;
    }
    if ( n404 < 411 )
    {
      ptr_9 = (std::string *)operator new(0x30u);
      PurchaseCashItemBonusScript::PurchaseCashItemBonusScript(ptr_9);
      ptr = ptr_9;
      filename_8 = (TCHAR *)std::string::c_str(a3);
      LoginEventScript = importPurchaseCashItemBonusEventScript(ptr_9, filename_8);
      goto LABEL_29;
    }
    if ( n404 != 412 )
      goto LABEL_29;
    goto LABEL_19;
  }
  if ( n404 == 407 )
  {
    ptr_10 = (std::string *)operator new(0x64u);
    AvatarDisjointRandomRewardScript::AvatarDisjointRandomRewardScript(ptr_10);
    ptr = ptr_10;
    filename_9 = (TCHAR *)std::string::c_str(a3);
    LoginEventScript = importAvatarDisjointRandomRewardScript(ptr_10, filename_9);
  }
  else if ( n404 == 406 )
  {
    ptr_11 = (std::string *)operator new(0x68u);
    ExchangeRandomItemRewardScript::ExchangeRandomItemRewardScript(ptr_11);
    ptr = ptr_11;
    filename_10 = (TCHAR *)std::string::c_str(a3);
    LoginEventScript = importExchangeRandomItemRewardScript(ptr_11, filename_10);
  }
LABEL_29:
  if ( LoginEventScript != 1 )
  {
    if ( ptr )
    {
      InGameEventScript::~InGameEventScript((InGameEventScript *)ptr);
      operator delete(ptr);
    }
    return 0;
  }
  return ptr;
}

// IDA_EA: 0x8982F10
// IDA_NAME: _ZN23InGameEventScriptLoader17insertEventScriptERKSsP17InGameEventScript
// DEMANGLED: InGameEventScriptLoader::insertEventScript(std::string const&,InGameEventScript *)
InGameEventScript *__cdecl InGameEventScriptLoader::insertEventScript(
        InGameEventScriptLoader *this,
        std::string *a2,
        InGameEventScript *a3)
{
  if ( a3 )
    *(_DWORD *)std::map<std::string,InGameEventScript *>::operator[]((int)this, a2) = a3;
  return a3;
}

// IDA_EA: 0x8982F38
// IDA_NAME: _ZN23InGameEventScriptLoader14getEventScriptEiRKSs
// DEMANGLED: InGameEventScriptLoader::getEventScript(int,std::string const&)
InGameEventScript *__cdecl InGameEventScriptLoader::getEventScript(
        InGameEventScriptLoader *this,
        int n404,
        std::string *a3)
{
  std::string *v4; // eax
  int v5; // [esp+18h] [ebp-10h] BYREF
  _DWORD v6[3]; // [esp+1Ch] [ebp-Ch] BYREF

  std::map<std::string,InGameEventScript *>::find(&v5);
  std::map<std::string,InGameEventScript *>::end((int)v6);
  if ( std::_Rb_tree_iterator<std::pair<std::string const,InGameEventScript *>>::operator!=(&v5, v6) )
    return *(InGameEventScript **)(std::_Rb_tree_iterator<std::pair<std::string const,InGameEventScript *>>::operator->(&v5)
                                 + 4);
  v4 = InGameEventScriptLoader::importInGameEventScript(this, n404, a3);
  return InGameEventScriptLoader::insertEventScript(this, a3, (InGameEventScript *)v4);
}
