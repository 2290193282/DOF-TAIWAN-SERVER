#include "ServerParameterScript_stPremiumGoldCardEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x836FC5A
// IDA_NAME: _ZN21ServerParameterScript22stPremiumGoldCardEventC2Ev
// DEMANGLED: ServerParameterScript::stPremiumGoldCardEvent::stPremiumGoldCardEvent(void)
bool __cdecl ServerParameterScript::stPremiumGoldCardEvent::stPremiumGoldCardEvent(
        ServerParameterScript::stPremiumGoldCardEvent *this)
{
  stLevelCond4PremiumGoldCard *v1; // ebx
  int n9; // esi
  bool result; // al

  v1 = (ServerParameterScript::stPremiumGoldCardEvent *)((char *)this + 8);
  for ( n9 = 9; ; --n9 )
  {
    result = n9 != -1;
    if ( n9 == -1 )
      break;
    stLevelCond4PremiumGoldCard::stLevelCond4PremiumGoldCard(v1);
    v1 = (stLevelCond4PremiumGoldCard *)((char *)v1 + 16);
  }
  return result;
}
