#ifndef __IDA91_SERVERPARAMETERSCRIPT_STPREMIUMGOLDCARDEVENT_H__
#define __IDA91_SERVERPARAMETERSCRIPT_STPREMIUMGOLDCARDEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: ServerParameterScript
// Source unit: ServerParameterScript_stPremiumGoldCardEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2376

/* 2376 */
struct ServerParameterScript::stPremiumGoldCardEvent;

// Exported member functions:
// 0x836FC5A	ServerParameterScript::stPremiumGoldCardEvent::stPremiumGoldCardEvent(void)

// Function declaration index:
// DECL 0x836FC5A ServerParameterScript::stPremiumGoldCardEvent::stPremiumGoldCardEvent

#endif  // __IDA91_SERVERPARAMETERSCRIPT_STPREMIUMGOLDCARDEVENT_H__
