#ifndef __IDA91_STEVENTADDINFO_H__
#define __IDA91_STEVENTADDINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stEVENTADDINFO
// Source unit: stEVENTADDINFO
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1208

/* 1208 */
struct stEVENTADDINFO;

// Exported member functions:
// 0x8118B56	stEVENTADDINFO::~stEVENTADDINFO()

// Function declaration index:
// DECL 0x8118B56 stEVENTADDINFO::~stEVENTADDINFO

#endif  // __IDA91_STEVENTADDINFO_H__
