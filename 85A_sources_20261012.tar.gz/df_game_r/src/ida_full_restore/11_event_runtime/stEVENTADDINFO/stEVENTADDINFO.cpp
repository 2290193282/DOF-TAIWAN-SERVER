#include "stEVENTADDINFO.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8118B56
// IDA_NAME: _ZN14stEVENTADDINFOD2Ev
// DEMANGLED: stEVENTADDINFO::~stEVENTADDINFO()
void stEVENTADDINFO::~stEVENTADDINFO()
{
  ;
}
