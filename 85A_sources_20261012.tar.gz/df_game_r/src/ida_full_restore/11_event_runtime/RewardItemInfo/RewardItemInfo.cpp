#include "RewardItemInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x836DE56
// IDA_NAME: _ZN14RewardItemInfoC2Ev
// DEMANGLED: RewardItemInfo::RewardItemInfo(void)
void __cdecl RewardItemInfo::RewardItemInfo(RewardItemInfo *this)
{
  *((_DWORD *)this + 1) = 0;
  *(_DWORD *)this = *((_DWORD *)this + 1);
  *((_DWORD *)this + 2) = 11;
  *((_DWORD *)this + 3) = -1;
}

// IDA_EA: 0x83C5056
// IDA_NAME: _ZN14RewardItemInfoD2Ev
// DEMANGLED: RewardItemInfo::~RewardItemInfo()
void RewardItemInfo::~RewardItemInfo()
{
  ;
}
