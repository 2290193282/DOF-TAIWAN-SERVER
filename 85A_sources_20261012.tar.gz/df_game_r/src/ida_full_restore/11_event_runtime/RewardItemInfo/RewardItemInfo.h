#ifndef __IDA91_REWARDITEMINFO_H__
#define __IDA91_REWARDITEMINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: RewardItemInfo
// Source unit: RewardItemInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 2370

/* 2370 */
struct RewardItemInfo;

// Exported member functions:
// 0x836DE56	RewardItemInfo::RewardItemInfo(void)
// 0x83C5056	RewardItemInfo::~RewardItemInfo()

// Function declaration index:
// DECL 0x836DE56 RewardItemInfo::RewardItemInfo
// DECL 0x83C5056 RewardItemInfo::~RewardItemInfo

#endif  // __IDA91_REWARDITEMINFO_H__
