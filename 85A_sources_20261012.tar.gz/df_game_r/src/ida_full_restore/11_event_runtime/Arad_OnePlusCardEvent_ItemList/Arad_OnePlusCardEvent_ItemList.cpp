#include "Arad_OnePlusCardEvent_ItemList.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8188D0A
// IDA_NAME: _ZN30Arad_OnePlusCardEvent_ItemListC2Ev
// DEMANGLED: Arad_OnePlusCardEvent_ItemList::Arad_OnePlusCardEvent_ItemList(void)
void __cdecl Arad_OnePlusCardEvent_ItemList::Arad_OnePlusCardEvent_ItemList(Arad_OnePlusCardEvent_ItemList *this)
{
  Arad_ScriptLoader::Arad_ScriptLoader(this);
  *(_DWORD *)this = off_8BAD7D0;
  std::vector<Arad_OnePlusCardEvent_ItemList::Data>::vector((char *)this + 4);
  std::vector<unsigned int>::vector((int)this + 16);
}

// IDA_EA: 0x8188D6A
// IDA_NAME: _ZN30Arad_OnePlusCardEvent_ItemListD2Ev
// DEMANGLED: Arad_OnePlusCardEvent_ItemList::~Arad_OnePlusCardEvent_ItemList()
void __cdecl Arad_OnePlusCardEvent_ItemList::~Arad_OnePlusCardEvent_ItemList(Arad_OnePlusCardEvent_ItemList *this)
{
  *(_DWORD *)this = off_8BAD7D0;
  std::vector<unsigned int>::~vector((_DWORD *)this + 4);
  std::vector<Arad_OnePlusCardEvent_ItemList::Data>::~vector((char *)this + 4);
}

// IDA_EA: 0x81A36FC
// IDA_NAME: _ZN30Arad_OnePlusCardEvent_ItemList7parsingEPc
// DEMANGLED: Arad_OnePlusCardEvent_ItemList::parsing(char *)
int __cdecl Arad_OnePlusCardEvent_ItemList::parsing(Arad_OnePlusCardEvent_ItemList *this, char *a2)
{
  int n491; // ebx
  int RowNum; // eax
  char *InputStreamBufferEv; // eax
  int v5; // eax
  void *v7[21]; // [esp+20h] [ebp-78h] BYREF
  char *v8; // [esp+74h] [ebp-24h] BYREF
  _BYTE v9[8]; // [esp+78h] [ebp-20h] BYREF
  int i; // [esp+80h] [ebp-18h]
  unsigned __int16 Int; // [esp+86h] [ebp-12h]
  unsigned int v12; // [esp+88h] [ebp-10h]
  int j; // [esp+8Ch] [ebp-Ch]

  Arad_Script::Arad_Script((Arad_Script *)v7);
  if ( (unsigned __int8)Arad_Script::Load((Arad_Script *)v7, a2, "item") == 1 )
  {
    if ( Arad_Script::GetRowNum((Arad_Script *)v7) )
    {
      for ( i = 0; ; ++i )
      {
        RowNum = Arad_Script::GetRowNum((Arad_Script *)v7);
        if ( RowNum <= i )
          break;
        Int = 0;
        v12 = -1;
        Int = Arad_Script::GetInt((Arad_Script *)v7, i, "web_id");
        v12 = Arad_Script::GetInt((Arad_Script *)v7, i, "item_index");
        if ( (unsigned __int8)Arad_OnePlusCardEvent_ItemList::find_item(this, Int) )
        {
          LogManager::logFormat(
            (LogManager *)1,
            (int)"localjapan/Arad_Script_Loader.cpp",
            "virtual int Arad_OnePlusCardEvent_ItemList::parsing(char*)",
            (const char *)0x1EA,
            "[ERROR] already exist data id OnePlusCardEvent(id:%d, item:%u)",
            (const char *)Int,
            v12);
          n491 = 491;
          goto LABEL_20;
        }
        Arad_OnePlusCardEvent_ItemList::Data::Data((Arad_OnePlusCardEvent_ItemList::Data *)v9, Int, v12);
        std::vector<Arad_OnePlusCardEvent_ItemList::Data>::push_back((char *)this + 4, v9);
      }
      InputStreamBufferEv = DNFLexWrapper::getInputStreamBuffer(&g_dnfLex);
      if ( (unsigned __int8)Arad_Script::Load((Arad_Script *)v7, InputStreamBufferEv, "limited_map") == 1 )
      {
        if ( Arad_Script::GetRowNum((Arad_Script *)v7) )
        {
          for ( j = 0; ; ++j )
          {
            v5 = Arad_Script::GetRowNum((Arad_Script *)v7);
            if ( v5 <= j )
              break;
            v8 = (char *)Arad_Script::GetInt((Arad_Script *)v7, j, "index");
            if ( (unsigned __int8)Arad_OnePlusCardEvent_ItemList::is_limited_map(this, (char)v8) )
            {
              LogManager::logFormat(
                (LogManager *)1,
                (int)"localjapan/Arad_Script_Loader.cpp",
                "virtual int Arad_OnePlusCardEvent_ItemList::parsing(char*)",
                (const char *)0x1FE,
                "[ERROR] already exist limited map index (map:%u)",
                v8);
              n491 = 511;
              goto LABEL_20;
            }
            std::vector<unsigned int>::push_back((int)this + 16, (int)&v8);
          }
          n491 = 0;
        }
        else
        {
          n491 = 0;
        }
      }
      else
      {
        n491 = 499;
      }
    }
    else
    {
      n491 = 0;
    }
  }
  else
  {
    n491 = 475;
  }
LABEL_20:
  Arad_Script::~Arad_Script(v7);
  return n491;
}

// IDA_EA: 0x81A398E
// IDA_NAME: _ZN30Arad_OnePlusCardEvent_ItemList9find_itemEtRNS_4DataE
// DEMANGLED: Arad_OnePlusCardEvent_ItemList::find_item(unsigned short,Arad_OnePlusCardEvent_ItemList::Data &)
int __cdecl Arad_OnePlusCardEvent_ItemList::find_item(
        Arad_OnePlusCardEvent_ItemList *this,
        unsigned __int16 a2,
        Arad_OnePlusCardEvent_ItemList::Data *a3)
{
  _BYTE v4[4]; // [esp+28h] [ebp-20h] BYREF
  _BYTE v5[8]; // [esp+2Ch] [ebp-1Ch] BYREF
  int v6; // [esp+34h] [ebp-14h] BYREF
  int v7; // [esp+38h] [ebp-10h] BYREF
  _BYTE v8[12]; // [esp+3Ch] [ebp-Ch] BYREF

  Arad_OnePlusCardEvent_ItemList::Data::Data((Arad_OnePlusCardEvent_ItemList::Data *)v5, a2, 0);
  std::vector<Arad_OnePlusCardEvent_ItemList::Data>::end(&v6);
  std::vector<Arad_OnePlusCardEvent_ItemList::Data>::begin(&v7);
  std::find<__gnu_cxx::__normal_iterator<Arad_OnePlusCardEvent_ItemList::Data *,std::vector<Arad_OnePlusCardEvent_ItemList::Data>>,Arad_OnePlusCardEvent_ItemList::Data>(v4);
  std::vector<Arad_OnePlusCardEvent_ItemList::Data>::end(v8);
  if ( (unsigned __int8)__gnu_cxx::operator==<Arad_OnePlusCardEvent_ItemList::Data *,std::vector<Arad_OnePlusCardEvent_ItemList::Data>>(
                          v4,
                          v8) )
    return 0;
  *(_WORD *)a3 = *(_WORD *)__gnu_cxx::__normal_iterator<Arad_OnePlusCardEvent_ItemList::Data *,std::vector<Arad_OnePlusCardEvent_ItemList::Data>>::operator->(v4);
  *((_DWORD *)a3 + 1) = *(_DWORD *)(__gnu_cxx::__normal_iterator<Arad_OnePlusCardEvent_ItemList::Data *,std::vector<Arad_OnePlusCardEvent_ItemList::Data>>::operator->(v4)
                                  + 4);
  return 1;
}

// IDA_EA: 0x81A3A6E
// IDA_NAME: _ZN30Arad_OnePlusCardEvent_ItemList9find_itemEt
// DEMANGLED: Arad_OnePlusCardEvent_ItemList::find_item(unsigned short)
int __cdecl Arad_OnePlusCardEvent_ItemList::find_item(Arad_OnePlusCardEvent_ItemList *this, unsigned __int16 a2)
{
  _BYTE v3[16]; // [esp+28h] [ebp-10h] BYREF

  Arad_OnePlusCardEvent_ItemList::Data::Data((Arad_OnePlusCardEvent_ItemList::Data *)v3, 0, 0);
  return Arad_OnePlusCardEvent_ItemList::find_item(this, a2, (Arad_OnePlusCardEvent_ItemList::Data *)v3);
}

// IDA_EA: 0x81A3AB2
// IDA_NAME: _ZN30Arad_OnePlusCardEvent_ItemList14is_limited_mapEj
// DEMANGLED: Arad_OnePlusCardEvent_ItemList::is_limited_map(unsigned int)
_BOOL4 __cdecl Arad_OnePlusCardEvent_ItemList::is_limited_map(Arad_OnePlusCardEvent_ItemList *this)
{
  _BYTE v2[4]; // [esp+10h] [ebp-18h] BYREF
  int v3; // [esp+14h] [ebp-14h] BYREF
  int v4; // [esp+18h] [ebp-10h] BYREF
  _BYTE v5[12]; // [esp+1Ch] [ebp-Ch] BYREF

  std::vector<unsigned int>::end((int)&v3, (int)this + 16);
  std::vector<unsigned int>::begin(&v4, (_DWORD *)this + 4);
  std::find<__gnu_cxx::__normal_iterator<unsigned int *,std::vector<unsigned int>>,unsigned int>((int)v2);
  std::vector<unsigned int>::end((int)v5, (int)this + 16);
  return (unsigned __int8)__gnu_cxx::operator==<unsigned int *,std::vector<unsigned int>>(v2, v5) == 0;
}
