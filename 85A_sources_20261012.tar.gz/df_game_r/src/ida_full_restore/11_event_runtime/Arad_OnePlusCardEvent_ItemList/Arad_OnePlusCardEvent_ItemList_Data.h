#ifndef __IDA91_ARAD_ONEPLUSCARDEVENT_ITEMLIST_DATA_H__
#define __IDA91_ARAD_ONEPLUSCARDEVENT_ITEMLIST_DATA_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Arad_OnePlusCardEvent_ItemList
// Source unit: Arad_OnePlusCardEvent_ItemList_Data
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 1453

/* 1453 */
struct Arad_OnePlusCardEvent_ItemList::Data;

// Exported member functions:
// 0x81A41E8	Arad_OnePlusCardEvent_ItemList::Data::Data(unsigned short,unsigned long)
// 0x81A420A	Arad_OnePlusCardEvent_ItemList::Data::operator==(Arad_OnePlusCardEvent_ItemList::Data const&)
// 0x81A80F0	Arad_OnePlusCardEvent_ItemList::Data::~Data()

// Function declaration index:
// DECL 0x81A41E8 Arad_OnePlusCardEvent_ItemList::Data::Data
// DECL 0x81A420A Arad_OnePlusCardEvent_ItemList::Data::operator==
// DECL 0x81A80F0 Arad_OnePlusCardEvent_ItemList::Data::~Data

#endif  // __IDA91_ARAD_ONEPLUSCARDEVENT_ITEMLIST_DATA_H__
