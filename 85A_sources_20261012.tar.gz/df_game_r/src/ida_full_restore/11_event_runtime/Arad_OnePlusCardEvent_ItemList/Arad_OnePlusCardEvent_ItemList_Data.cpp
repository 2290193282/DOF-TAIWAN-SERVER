#include "Arad_OnePlusCardEvent_ItemList_Data.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81A41E8
// IDA_NAME: _ZN30Arad_OnePlusCardEvent_ItemList4DataC2Etm
// DEMANGLED: Arad_OnePlusCardEvent_ItemList::Data::Data(unsigned short,unsigned long)
Arad_OnePlusCardEvent_ItemList::Data *__cdecl Arad_OnePlusCardEvent_ItemList::Data::Data(
        Arad_OnePlusCardEvent_ItemList::Data *this,
        unsigned __int16 a2,
        unsigned int a3)
{
  Arad_OnePlusCardEvent_ItemList::Data *this_1; // eax

  *(_WORD *)this = a2;
  this_1 = this;
  *((_DWORD *)this + 1) = a3;
  return this_1;
}

// IDA_EA: 0x81A420A
// IDA_NAME: _ZN30Arad_OnePlusCardEvent_ItemList4DataeqERKS0_
// DEMANGLED: Arad_OnePlusCardEvent_ItemList::Data::operator==(Arad_OnePlusCardEvent_ItemList::Data const&)
bool __cdecl Arad_OnePlusCardEvent_ItemList::Data::operator==(_WORD *a1, _WORD *a2)
{
  return *a1 == *a2;
}

// IDA_EA: 0x81A80F0
// IDA_NAME: _ZN30Arad_OnePlusCardEvent_ItemList4DataD2Ev
// DEMANGLED: Arad_OnePlusCardEvent_ItemList::Data::~Data()
void Arad_OnePlusCardEvent_ItemList::Data::~Data()
{
  ;
}
