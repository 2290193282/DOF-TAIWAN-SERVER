#ifndef __IDA91_ARAD_ONEPLUSCARDEVENT_ITEMLIST_H__
#define __IDA91_ARAD_ONEPLUSCARDEVENT_ITEMLIST_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Arad_OnePlusCardEvent_ItemList
// Source unit: Arad_OnePlusCardEvent_ItemList
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4136

/* 4136 */
struct Arad_OnePlusCardEvent_ItemList;

// Exported member functions:
// 0x8188D0A	Arad_OnePlusCardEvent_ItemList::Arad_OnePlusCardEvent_ItemList(void)
// 0x8188D6A	Arad_OnePlusCardEvent_ItemList::~Arad_OnePlusCardEvent_ItemList()
// 0x81A36FC	Arad_OnePlusCardEvent_ItemList::parsing(char *)
// 0x81A398E	Arad_OnePlusCardEvent_ItemList::find_item(unsigned short,Arad_OnePlusCardEvent_ItemList::Data &)
// 0x81A3A6E	Arad_OnePlusCardEvent_ItemList::find_item(unsigned short)
// 0x81A3AB2	Arad_OnePlusCardEvent_ItemList::is_limited_map(unsigned int)

// Function declaration index:
// DECL 0x8188D0A Arad_OnePlusCardEvent_ItemList::Arad_OnePlusCardEvent_ItemList
// DECL 0x8188D6A Arad_OnePlusCardEvent_ItemList::~Arad_OnePlusCardEvent_ItemList
// DECL 0x81A36FC Arad_OnePlusCardEvent_ItemList::parsing
// DECL 0x81A398E Arad_OnePlusCardEvent_ItemList::find_item
// DECL 0x81A3A6E Arad_OnePlusCardEvent_ItemList::find_item
// DECL 0x81A3AB2 Arad_OnePlusCardEvent_ItemList::is_limited_map

#endif  // __IDA91_ARAD_ONEPLUSCARDEVENT_ITEMLIST_H__
