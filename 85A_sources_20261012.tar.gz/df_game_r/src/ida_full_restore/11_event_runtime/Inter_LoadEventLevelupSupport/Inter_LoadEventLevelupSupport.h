#ifndef __IDA91_INTER_LOADEVENTLEVELUPSUPPORT_H__
#define __IDA91_INTER_LOADEVENTLEVELUPSUPPORT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_LoadEventLevelupSupport
// Source unit: Inter_LoadEventLevelupSupport
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 3239

/* 3239 */
struct Inter_LoadEventLevelupSupport;

// Exported member functions:
// 0x84E8CE4	Inter_LoadEventLevelupSupport::dispatch_sig(CUser *,char *,int)
// 0x84EEF10	Inter_LoadEventLevelupSupport::Inter_LoadEventLevelupSupport(void)
// 0x84F572C	Inter_LoadEventLevelupSupport::~Inter_LoadEventLevelupSupport()
// 0x84F575C	Inter_LoadEventLevelupSupport::~Inter_LoadEventLevelupSupport()

// Function declaration index:
// DECL 0x84E8CE4 Inter_LoadEventLevelupSupport::dispatch_sig
// DECL 0x84EEF10 Inter_LoadEventLevelupSupport::Inter_LoadEventLevelupSupport
// DECL 0x84F572C Inter_LoadEventLevelupSupport::~Inter_LoadEventLevelupSupport
// DECL 0x84F575C Inter_LoadEventLevelupSupport::~Inter_LoadEventLevelupSupport

#endif  // __IDA91_INTER_LOADEVENTLEVELUPSUPPORT_H__
