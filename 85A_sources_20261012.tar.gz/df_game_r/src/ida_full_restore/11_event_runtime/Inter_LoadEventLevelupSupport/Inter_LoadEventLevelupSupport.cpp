#include "Inter_LoadEventLevelupSupport.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84E8CE4
// IDA_NAME: _ZN29Inter_LoadEventLevelupSupport12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_LoadEventLevelupSupport::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_LoadEventLevelupSupport::dispatch_sig(Inter_LoadEventLevelupSupport *this, CUser *a2, char *a3)
{
  LevelupSupportEventManger *v4; // eax
  char *DefaultEventInfo; // eax
  int charac_levelEv; // ebx
  const char *CurCharacNoEv; // eax
  __int16 n2; // di
  __int16 src; // si
  char CurCharacNoEv_1; // bl
  DB_SaveEventLevelupSupport *UID; // eax
  int v12[4]; // [esp+20h] [ebp-38h] BYREF
  char *v13; // [esp+30h] [ebp-28h]
  unsigned int i; // [esp+34h] [ebp-24h]
  int j; // [esp+38h] [ebp-20h]
  unsigned int k; // [esp+3Ch] [ebp-1Ch]

  if ( a2 && a3 )
  {
    v13 = a3;
    std::vector<LevelupSupportEventManger::EventInfo>::clear((_DWORD *)a2 + 144441);
    v4 = (LevelupSupportEventManger *)ARAD::Singleton<LevelupSupportEventManger>::Get();
    DefaultEventInfo = LevelupSupportEventManger::GetDefaultEventInfo(v4);
    std::vector<LevelupSupportEventManger::EventInfo>::operator=((char *)a2 + 577764, DefaultEventInfo);
    for ( i = 0; std::vector<LevelupSupportEventManger::EventInfo>::size((_DWORD *)a2 + 144441) > i; ++i )
    {
      charac_levelEv = *(unsigned __int16 *)std::vector<LevelupSupportEventManger::EventInfo>::operator[](
                                              (_DWORD *)a2 + 144441,
                                              i);
      if ( charac_levelEv <= CUserCharacInfo::get_charac_level(a2) )
        *(_WORD *)(std::vector<LevelupSupportEventManger::EventInfo>::operator[]((_DWORD *)a2 + 144441, i) + 2) = 1;
    }
    for ( j = 0; *(_DWORD *)v13 > j; ++j )
    {
      if ( *(_WORD *)std::vector<LevelupSupportEventManger::EventInfo>::operator[]((_DWORD *)a2 + 144441, j) == *(_WORD *)&v13[4 * j + 4] )
      {
        *(_WORD *)(std::vector<LevelupSupportEventManger::EventInfo>::operator[]((_DWORD *)a2 + 144441, j) + 2) = *(_WORD *)&v13[4 * j + 6];
      }
      else
      {
        CurCharacNoEv = (const char *)CUserCharacInfo::getCurCharacNo(a2);
        LogManager::logFormat(
          (LogManager *)1,
          (int)"InterDispatcher.cpp",
          "virtual int Inter_LoadEventLevelupSupport::dispatch_sig(CUser*, char*, int)",
          (const char *)0x6E06,
          "Inter_LoadEventLevelupSupport diff state charac_no:%d",
          CurCharacNoEv);
      }
    }
    if ( !*(_DWORD *)v13 )
    {
      for ( k = 0; std::vector<LevelupSupportEventManger::EventInfo>::size((_DWORD *)a2 + 144441) > k; ++k )
      {
        n2 = *(_WORD *)(std::vector<LevelupSupportEventManger::EventInfo>::operator[]((_DWORD *)a2 + 144441, k) + 2);
        src = *(_WORD *)std::vector<LevelupSupportEventManger::EventInfo>::operator[]((_DWORD *)a2 + 144441, k);
        CurCharacNoEv_1 = CUserCharacInfo::getCurCharacNo(a2);
        UID = (DB_SaveEventLevelupSupport *)CUser::GetUID(a2);
        DB_SaveEventLevelupSupport::makeRequest(UID, CurCharacNoEv_1, src, n2);
      }
    }
    LevelupSupportEventManger::SendCharacState(a2, 0);
    return 0;
  }
  else
  {
    cMyTrace::cMyTrace(
      (cMyTrace *)v12,
      "virtual int Inter_LoadEventLevelupSupport::dispatch_sig(CUser*, char*, int)",
      28142,
      5);
    cMyTrace::operator()(
      (int)v12,
      "[%s] pUser or p is null.",
      (char)"virtual int Inter_LoadEventLevelupSupport::dispatch_sig(CUser*, char*, int)");
    return 28143;
  }
}

// IDA_EA: 0x84EEF10
// IDA_NAME: _ZN29Inter_LoadEventLevelupSupportC2Ev
// DEMANGLED: Inter_LoadEventLevelupSupport::Inter_LoadEventLevelupSupport(void)
void __cdecl Inter_LoadEventLevelupSupport::Inter_LoadEventLevelupSupport(Inter_LoadEventLevelupSupport *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8E338;
}

// IDA_EA: 0x84F572C
// IDA_NAME: _ZN29Inter_LoadEventLevelupSupportD2Ev
// DEMANGLED: Inter_LoadEventLevelupSupport::~Inter_LoadEventLevelupSupport()
void __cdecl Inter_LoadEventLevelupSupport::~Inter_LoadEventLevelupSupport(Inter_LoadEventLevelupSupport *this)
{
  *(_DWORD *)this = &off_8C8E338;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84F575C
// IDA_NAME: _ZN29Inter_LoadEventLevelupSupportD0Ev
// DEMANGLED: Inter_LoadEventLevelupSupport::~Inter_LoadEventLevelupSupport()
void __cdecl Inter_LoadEventLevelupSupport::~Inter_LoadEventLevelupSupport(Inter_LoadEventLevelupSupport *this)
{
  Inter_LoadEventLevelupSupport::~Inter_LoadEventLevelupSupport(this);
  operator delete(this);
}
