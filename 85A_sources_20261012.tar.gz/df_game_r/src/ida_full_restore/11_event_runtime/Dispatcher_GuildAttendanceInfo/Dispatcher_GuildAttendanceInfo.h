#ifndef __IDA91_DISPATCHER_GUILDATTENDANCEINFO_H__
#define __IDA91_DISPATCHER_GUILDATTENDANCEINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Dispatcher_GuildAttendanceInfo
// Source unit: Dispatcher_GuildAttendanceInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 4297

/* 4297 */
struct Dispatcher_GuildAttendanceInfo;

// Exported member functions:
// 0x81D543C	Dispatcher_GuildAttendanceInfo::read(PacketBuf &,MSG_BASE &)
// 0x81D5492	Dispatcher_GuildAttendanceInfo::process(CUser *,MSG_BASE &,ParamBase &)
// 0x8245022	Dispatcher_GuildAttendanceInfo::~Dispatcher_GuildAttendanceInfo()
// 0x8245052	Dispatcher_GuildAttendanceInfo::~Dispatcher_GuildAttendanceInfo()
// 0x8597522	Dispatcher_GuildAttendanceInfo::Dispatcher_GuildAttendanceInfo(void)

// Function declaration index:
// DECL 0x81D543C Dispatcher_GuildAttendanceInfo::read
// DECL 0x81D5492 Dispatcher_GuildAttendanceInfo::process
// DECL 0x8245022 Dispatcher_GuildAttendanceInfo::~Dispatcher_GuildAttendanceInfo
// DECL 0x8245052 Dispatcher_GuildAttendanceInfo::~Dispatcher_GuildAttendanceInfo
// DECL 0x8597522 Dispatcher_GuildAttendanceInfo::Dispatcher_GuildAttendanceInfo

#endif  // __IDA91_DISPATCHER_GUILDATTENDANCEINFO_H__
