#include "Dispatcher_GuildAttendanceInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81D543C
// IDA_NAME: _ZN30Dispatcher_GuildAttendanceInfo4readER9PacketBufR8MSG_BASE
// DEMANGLED: Dispatcher_GuildAttendanceInfo::read(PacketBuf &,MSG_BASE &)
int __cdecl Dispatcher_GuildAttendanceInfo::read(Dispatcher_GuildAttendanceInfo *this, PacketBuf *a2, MSG_BASE *a3)
{
  if ( (unsigned __int8)PacketBuf::get_byte(a2, (char *)a3 + 13) == 1 )
    return 0;
  else
    return LineFunc(13785, "virtual int Dispatcher_GuildAttendanceInfo::read(PacketBuf&, MSG_BASE&)", 0, 0);
}

// IDA_EA: 0x81D5492
// IDA_NAME: _ZN30Dispatcher_GuildAttendanceInfo7processEP5CUserR8MSG_BASER9ParamBase
// DEMANGLED: Dispatcher_GuildAttendanceInfo::process(CUser *,MSG_BASE &,ParamBase &)
int __cdecl Dispatcher_GuildAttendanceInfo::process(Dispatcher_GuildAttendanceInfo *this, CUser *a2, MSG_BASE *a3)
{
  size_t n; // esi
  int ServerGroup; // eax
  CGuildServerProxy *ServerProxy; // eax
  char src[2]; // [esp+19h] [ebp-1Fh] BYREF
  unsigned __int16 n_1; // [esp+1Bh] [ebp-1Dh]
  int charac_guildkeyEv; // [esp+23h] [ebp-15h]
  int CurCharacNoEv; // [esp+27h] [ebp-11h]
  char v11; // [esp+2Bh] [ebp-Dh]
  MSG_BASE *v12; // [esp+2Ch] [ebp-Ch]

  v12 = a3;
  if ( CUser::get_state(a2) <= 2 )
    return 0;
  if ( CUserCharacInfo::get_charac_guildkey(a2) )
  {
    Packet_Guild_Attendance_Info::Packet_Guild_Attendance_Info((Packet_Guild_Attendance_Info *)src);
    charac_guildkeyEv = CUserCharacInfo::get_charac_guildkey(a2);
    CurCharacNoEv = CUserCharacInfo::getCurCharacNo(a2);
    v11 = *((_BYTE *)v12 + 13);
    n = n_1;
    ServerGroup = CUser::GetServerGroup(a2);
    ServerProxy = (CGuildServerProxy *)CServerProxyMgr<CGuildServerProxy>::GetServerProxy(
                                         GlobalData::s_guild_proxy_mgr,
                                         ServerGroup);
    CGuildServerProxy::SendTcpPacket(ServerProxy, src, n);
  }
  return 0;
}

// IDA_EA: 0x8245022
// IDA_NAME: _ZN30Dispatcher_GuildAttendanceInfoD2Ev
// DEMANGLED: Dispatcher_GuildAttendanceInfo::~Dispatcher_GuildAttendanceInfo()
void __cdecl Dispatcher_GuildAttendanceInfo::~Dispatcher_GuildAttendanceInfo(Dispatcher_GuildAttendanceInfo *this)
{
  *(_DWORD *)this = &off_8BDAC88;
  IPacketDispatcher<MSG_GUILD_ATTENDANCE,ParamBase,(ch_state)0>::~IPacketDispatcher(this);
}

// IDA_EA: 0x8245052
// IDA_NAME: _ZN30Dispatcher_GuildAttendanceInfoD0Ev
// DEMANGLED: Dispatcher_GuildAttendanceInfo::~Dispatcher_GuildAttendanceInfo()
void __cdecl Dispatcher_GuildAttendanceInfo::~Dispatcher_GuildAttendanceInfo(Dispatcher_GuildAttendanceInfo *this)
{
  Dispatcher_GuildAttendanceInfo::~Dispatcher_GuildAttendanceInfo(this);
  operator delete(this);
}

// IDA_EA: 0x8597522
// IDA_NAME: _ZN30Dispatcher_GuildAttendanceInfoC2Ev
// DEMANGLED: Dispatcher_GuildAttendanceInfo::Dispatcher_GuildAttendanceInfo(void)
void __cdecl Dispatcher_GuildAttendanceInfo::Dispatcher_GuildAttendanceInfo(Dispatcher_GuildAttendanceInfo *this)
{
  IPacketDispatcher<MSG_GUILD_ATTENDANCE,ParamBase,(ch_state)0>::IPacketDispatcher(this);
  *(_DWORD *)this = &off_8BDAC88;
}
