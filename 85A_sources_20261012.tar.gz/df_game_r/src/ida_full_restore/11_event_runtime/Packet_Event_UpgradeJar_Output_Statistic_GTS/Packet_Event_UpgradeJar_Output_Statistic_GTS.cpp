#include "Packet_Event_UpgradeJar_Output_Statistic_GTS.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8694528
// IDA_NAME: _ZN44Packet_Event_UpgradeJar_Output_Statistic_GTSC2Ev
// DEMANGLED: Packet_Event_UpgradeJar_Output_Statistic_GTS::Packet_Event_UpgradeJar_Output_Statistic_GTS(void)
void __cdecl Packet_Event_UpgradeJar_Output_Statistic_GTS::Packet_Event_UpgradeJar_Output_Statistic_GTS(
        Packet_Event_UpgradeJar_Output_Statistic_GTS *this)
{
  PacketHeader::PacketHeader(this, 0x106Eu, 0x12u);
  *(_DWORD *)((char *)this + 10) = 0;
  *(_DWORD *)((char *)this + 14) = 0;
}
