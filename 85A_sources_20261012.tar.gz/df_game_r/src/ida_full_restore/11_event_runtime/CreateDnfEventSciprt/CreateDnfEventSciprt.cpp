#include "CreateDnfEventSciprt.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8AC000C
// IDA_NAME: _ZN20CreateDnfEventSciprtC2Ev
// DEMANGLED: CreateDnfEventSciprt::CreateDnfEventSciprt(void)
void __cdecl CreateDnfEventSciprt::CreateDnfEventSciprt(CreateDnfEventSciprt *this)
{
  std::map<int,std::vector<CreateDnfEventSciprt::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>>::map(this);
}

// IDA_EA: 0x8AC0020
// IDA_NAME: _ZN20CreateDnfEventSciprtD2Ev
// DEMANGLED: CreateDnfEventSciprt::~CreateDnfEventSciprt()
void __cdecl CreateDnfEventSciprt::~CreateDnfEventSciprt(CreateDnfEventSciprt *this)
{
  std::map<int,std::vector<CreateDnfEventSciprt::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>>::~map(this);
}

// IDA_EA: 0x8AC0034
// IDA_NAME: _ZN20CreateDnfEventSciprt10loadScriptEv
// DEMANGLED: CreateDnfEventSciprt::loadScript(void)
int __cdecl CreateDnfEventSciprt::loadScript()
{
  int v0; // ebx
  void *v1; // ebx
  void *v3; // [esp+1Ch] [ebp-5Ch] BYREF
  _BYTE v4[12]; // [esp+20h] [ebp-58h] BYREF
  int v5; // [esp+2Ch] [ebp-4Ch] BYREF
  bool v6; // [esp+32h] [ebp-46h] BYREF
  bool v7; // [esp+33h] [ebp-45h] BYREF
  std::string v8; // [esp+34h] [ebp-44h] BYREF
  _BYTE v9[8]; // [esp+38h] [ebp-40h] BYREF
  _BYTE v10[4]; // [esp+40h] [ebp-38h] BYREF
  _BYTE v11[4]; // [esp+44h] [ebp-34h] BYREF
  _BYTE v12[8]; // [esp+48h] [ebp-30h] BYREF
  _BYTE v13[8]; // [esp+50h] [ebp-28h] BYREF
  int v14; // [esp+58h] [ebp-20h]
  int v15; // [esp+5Ch] [ebp-1Ch]

  if ( !loadRDARScriptFile((TCHAR *)"Event/", (TCHAR *)"tw_CreateDnf.evt") )
    return -1;
  std::string::string(&v8);
  v7 = 0;
  v6 = 0;
  v5 = 0;
  std::vector<CreateDnfEventSciprt::ItemInfo>::vector(v4);
  while ( (unsigned __int8)ScanType(&v8, 1) == 1 )
  {
    if ( std::operator==<char>(&v8, "[step]") )
    {
      if ( (unsigned __int8)ScanType(&v8, 1) != 1 )
        break;
      if ( std::operator==<char>(&v8, "[day]") )
        v5 = ScanInt(0);
      if ( (unsigned __int8)ScanType(&v8, 1) != 1 )
        break;
      if ( std::operator==<char>(&v8, "[reward]") )
      {
        while ( 1 )
        {
          v14 = ScanTypeOrInt(&v7, &v8, &v6, 1);
          if ( v7 )
            break;
          v15 = ScanInt(0);
          CreateDnfEventSciprt::ItemInfo::ItemInfo((CreateDnfEventSciprt::ItemInfo *)v9, v14, v15);
          std::vector<CreateDnfEventSciprt::ItemInfo>::push_back(v4, v9);
        }
      }
      if ( (unsigned __int8)ScanType(&v8, 1) != 1 )
        break;
      if ( std::operator==<char>(&v8, "[/step]") )
      {
        std::map<int,std::vector<CreateDnfEventSciprt::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>>::end(v10);
        std::map<int,std::vector<CreateDnfEventSciprt::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>>::find(v11);
        if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>::operator!=(
                                v11,
                                v10) )
        {
          printf("duplicate [level] %d", v5);
          v0 = -1;
          goto LABEL_19;
        }
        v1 = operator new(0xCu);
        std::vector<CreateDnfEventSciprt::ItemInfo>::vector(v1);
        v3 = v1;
        std::vector<CreateDnfEventSciprt::ItemInfo>::swap(v1, v4);
        std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>::pair<int &,std::vector<CreateDnfEventSciprt::ItemInfo> *&>(
          v13,
          &v5,
          &v3);
        std::map<int,std::vector<CreateDnfEventSciprt::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>>::insert(v12);
      }
    }
  }
  unloadRDARScriptFile();
  v0 = 0;
LABEL_19:
  std::vector<CreateDnfEventSciprt::ItemInfo>::~vector(v4);
  std::string::~string(&v8);
  return v0;
}

// IDA_EA: 0x8AC032A
// IDA_NAME: _ZN20CreateDnfEventSciprt11clearScriptEv
// DEMANGLED: CreateDnfEventSciprt::clearScript(void)
int __cdecl CreateDnfEventSciprt::clearScript(CreateDnfEventSciprt *this)
{
  int v1; // eax
  void *ptr; // ebx
  _BYTE v4[4]; // [esp+18h] [ebp-10h] BYREF
  _BYTE v5[8]; // [esp+1Ch] [ebp-Ch] BYREF

  std::map<int,std::vector<CreateDnfEventSciprt::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>>::begin(v5);
  std::map<int,std::vector<CreateDnfEventSciprt::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>>::end(v4);
  while ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>::operator!=(
                             v5,
                             v4) )
  {
    v1 = std::_Rb_tree_iterator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>::operator->(v5);
    ptr = *(void **)(v1 + 4);
    if ( ptr )
    {
      std::vector<CreateDnfEventSciprt::ItemInfo>::~vector(*(_DWORD *)(v1 + 4));
      operator delete(ptr);
    }
  }
  return std::map<int,std::vector<CreateDnfEventSciprt::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>>::clear(this);
}

// IDA_EA: 0x8AC03A6
// IDA_NAME: _ZN20CreateDnfEventSciprt11GetItemInfoERSt6vectorISt4pairIiiESaIS2_EEi
// DEMANGLED: CreateDnfEventSciprt::GetItemInfo(std::vector<std::pair<int,int>,std::allocator<std::pair<int,int>>> &,int)
char __cdecl CreateDnfEventSciprt::GetItemInfo(int a1, _DWORD *a2)
{
  char result; // al
  int v3; // ebx
  unsigned int *__t_1; // eax
  _BYTE v5[4]; // [esp+1Ch] [ebp-2Ch] BYREF
  _BYTE v6[4]; // [esp+20h] [ebp-28h] BYREF
  int v7[2]; // [esp+24h] [ebp-24h] BYREF
  unsigned int __t[2]; // [esp+2Ch] [ebp-1Ch] BYREF
  int v9; // [esp+34h] [ebp-14h]
  unsigned int v10; // [esp+38h] [ebp-10h]
  unsigned int v11; // [esp+3Ch] [ebp-Ch]

  std::map<int,std::vector<CreateDnfEventSciprt::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>>::find(v5);
  std::map<int,std::vector<CreateDnfEventSciprt::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>>::end(v6);
  result = std::_Rb_tree_iterator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>::operator!=(
             v5,
             v6);
  if ( result )
  {
    std::vector<std::pair<int,int>>::clear(a2);
    v9 = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>::operator->(v5)
                   + 4);
    v10 = 0;
    v11 = std::vector<CreateDnfEventSciprt::ItemInfo>::size(v9);
    while ( 1 )
    {
      result = v10 < v11;
      if ( v10 >= v11 )
        break;
      v3 = std::vector<CreateDnfEventSciprt::ItemInfo>::at(v9, v10) + 4;
      __t_1 = (unsigned int *)std::vector<CreateDnfEventSciprt::ItemInfo>::at(v9, v10);
      std::make_pair<unsigned long &,short &>(__t, __t_1, v3);
      std::pair<int,int>::pair<unsigned long,short>((unsigned int *)v7, __t);
      std::vector<std::pair<int,int>>::push_back((int)a2, (int)v7);
      ++v10;
    }
  }
  return result;
}

// IDA_EA: 0x8AC04A4
// IDA_NAME: _ZN20CreateDnfEventSciprt11GetItemInfoERSt6vectorISt4pairIiiESaIS2_EE
// DEMANGLED: CreateDnfEventSciprt::GetItemInfo(std::vector<std::pair<int,int>,std::allocator<std::pair<int,int>>> &)
int __cdecl CreateDnfEventSciprt::GetItemInfo(int a1, _DWORD *a2)
{
  int v2; // eax
  int v3; // ebx
  unsigned int *__t_1; // eax
  int result; // eax
  _BYTE v6[4]; // [esp+14h] [ebp-34h] BYREF
  _BYTE v7[4]; // [esp+18h] [ebp-30h] BYREF
  _BYTE v8[4]; // [esp+1Ch] [ebp-2Ch] BYREF
  int v9[2]; // [esp+20h] [ebp-28h] BYREF
  unsigned int __t[2]; // [esp+28h] [ebp-20h] BYREF
  _BYTE dest[4]; // [esp+30h] [ebp-18h] BYREF
  unsigned int v12; // [esp+34h] [ebp-14h]
  unsigned int v13; // [esp+38h] [ebp-10h]
  int v14; // [esp+3Ch] [ebp-Ch]

  std::map<int,std::vector<CreateDnfEventSciprt::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>>::begin(v8);
  std::map<int,std::vector<CreateDnfEventSciprt::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>>::end(v7);
  std::vector<std::pair<int,int>>::clear(a2);
  std::map<int,std::vector<CreateDnfEventSciprt::ItemInfo> *,std::less<int>,std::allocator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>>::begin(v6);
  while ( 1 )
  {
    result = std::_Rb_tree_iterator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>::operator!=(
               v6,
               v7);
    if ( !(_BYTE)result )
      break;
    v12 = 0;
    v2 = std::_Rb_tree_iterator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>::operator->(v6);
    v13 = std::vector<CreateDnfEventSciprt::ItemInfo>::size(*(_DWORD *)(v2 + 4));
    while ( v12 < v13 )
    {
      v14 = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>::operator->(v6)
                      + 4);
      v3 = std::vector<CreateDnfEventSciprt::ItemInfo>::at(v14, v12) + 4;
      __t_1 = (unsigned int *)std::vector<CreateDnfEventSciprt::ItemInfo>::at(v14, v12);
      std::make_pair<unsigned long &,short &>(__t, __t_1, v3);
      std::pair<int,int>::pair<unsigned long,short>((unsigned int *)v9, __t);
      std::vector<std::pair<int,int>>::push_back((int)a2, (int)v9);
      ++v12;
    }
    std::_Rb_tree_iterator<std::pair<int const,std::vector<CreateDnfEventSciprt::ItemInfo> *>>::operator++(dest);
  }
  return result;
}
