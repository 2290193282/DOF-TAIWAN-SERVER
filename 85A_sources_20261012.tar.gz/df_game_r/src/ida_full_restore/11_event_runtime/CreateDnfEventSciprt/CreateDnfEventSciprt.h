#ifndef __IDA91_CREATEDNFEVENTSCIPRT_H__
#define __IDA91_CREATEDNFEVENTSCIPRT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CreateDnfEventSciprt
// Source unit: CreateDnfEventSciprt
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4671

/* 4671 */
struct CreateDnfEventSciprt;

// Exported member functions:
// 0x8AC000C	CreateDnfEventSciprt::CreateDnfEventSciprt(void)
// 0x8AC0020	CreateDnfEventSciprt::~CreateDnfEventSciprt()
// 0x8AC0034	CreateDnfEventSciprt::loadScript(void)
// 0x8AC032A	CreateDnfEventSciprt::clearScript(void)
// 0x8AC03A6	CreateDnfEventSciprt::GetItemInfo(std::vector<std::pair<int,int>,std::allocator<std::pair<int,int>>> &,int)
// 0x8AC04A4	CreateDnfEventSciprt::GetItemInfo(std::vector<std::pair<int,int>,std::allocator<std::pair<int,int>>> &)

// Function declaration index:
// DECL 0x8AC000C CreateDnfEventSciprt::CreateDnfEventSciprt
// DECL 0x8AC0020 CreateDnfEventSciprt::~CreateDnfEventSciprt
// DECL 0x8AC0034 CreateDnfEventSciprt::loadScript
// DECL 0x8AC032A CreateDnfEventSciprt::clearScript
// DECL 0x8AC03A6 CreateDnfEventSciprt::GetItemInfo
// DECL 0x8AC04A4 CreateDnfEventSciprt::GetItemInfo

#endif  // __IDA91_CREATEDNFEVENTSCIPRT_H__
