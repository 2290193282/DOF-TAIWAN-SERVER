#include "CreateDnfEventSciprt_ItemInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8AC063E
// IDA_NAME: _ZN20CreateDnfEventSciprt8ItemInfoC2Eii
// DEMANGLED: CreateDnfEventSciprt::ItemInfo::ItemInfo(int,int)
CreateDnfEventSciprt::ItemInfo *__cdecl CreateDnfEventSciprt::ItemInfo::ItemInfo(
        CreateDnfEventSciprt::ItemInfo *this,
        int a2,
        __int16 a3)
{
  CreateDnfEventSciprt::ItemInfo *this_1; // eax

  *(_DWORD *)this = a2;
  this_1 = this;
  *((_WORD *)this + 2) = a3;
  return this_1;
}

// IDA_EA: 0x8AC1884
// IDA_NAME: _ZN20CreateDnfEventSciprt8ItemInfoD2Ev
// DEMANGLED: CreateDnfEventSciprt::ItemInfo::~ItemInfo()
void CreateDnfEventSciprt::ItemInfo::~ItemInfo()
{
  ;
}
