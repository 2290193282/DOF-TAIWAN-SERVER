#ifndef __IDA91_CREATEDNFEVENTSCIPRT_ITEMINFO_H__
#define __IDA91_CREATEDNFEVENTSCIPRT_ITEMINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CreateDnfEventSciprt
// Source unit: CreateDnfEventSciprt_ItemInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4068

/* 4068 */
struct CreateDnfEventSciprt::ItemInfo;

// Exported member functions:
// 0x8AC063E	CreateDnfEventSciprt::ItemInfo::ItemInfo(int,int)
// 0x8AC1884	CreateDnfEventSciprt::ItemInfo::~ItemInfo()

// Function declaration index:
// DECL 0x8AC063E CreateDnfEventSciprt::ItemInfo::ItemInfo
// DECL 0x8AC1884 CreateDnfEventSciprt::ItemInfo::~ItemInfo

#endif  // __IDA91_CREATEDNFEVENTSCIPRT_ITEMINFO_H__
