#ifndef __IDA91_CWEEKENDBONUSEVENT_H__
#define __IDA91_CWEEKENDBONUSEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CWeekendBonusEvent
// Source unit: CWeekendBonusEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4101

/* 4101 */
struct CWeekendBonusEvent;

// Exported member functions:
// 0x8117550	CWeekendBonusEvent::CWeekendBonusEvent(void)
// 0x811756C	CWeekendBonusEvent::~CWeekendBonusEvent()
// 0x811759C	CWeekendBonusEvent::~CWeekendBonusEvent()
// 0x81175BA	CWeekendBonusEvent::StartEvent(void)
// 0x811760C	CWeekendBonusEvent::StartEvent(Word_Param)
// 0x8117626	CWeekendBonusEvent::EndEvent(void)

// Function declaration index:
// DECL 0x8117550 CWeekendBonusEvent::CWeekendBonusEvent
// DECL 0x811756C CWeekendBonusEvent::~CWeekendBonusEvent
// DECL 0x811759C CWeekendBonusEvent::~CWeekendBonusEvent
// DECL 0x81175BA CWeekendBonusEvent::StartEvent
// DECL 0x811760C CWeekendBonusEvent::StartEvent
// DECL 0x8117626 CWeekendBonusEvent::EndEvent

#endif  // __IDA91_CWEEKENDBONUSEVENT_H__
