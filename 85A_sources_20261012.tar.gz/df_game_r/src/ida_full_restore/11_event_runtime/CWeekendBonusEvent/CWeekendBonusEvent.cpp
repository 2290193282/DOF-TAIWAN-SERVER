#include "CWeekendBonusEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8117550
// IDA_NAME: _ZN18CWeekendBonusEventC2Ev
// DEMANGLED: CWeekendBonusEvent::CWeekendBonusEvent(void)
void __cdecl CWeekendBonusEvent::CWeekendBonusEvent(CWeekendBonusEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B4F2A8;
}

// IDA_EA: 0x811756C
// IDA_NAME: _ZN18CWeekendBonusEventD2Ev
// DEMANGLED: CWeekendBonusEvent::~CWeekendBonusEvent()
void __cdecl CWeekendBonusEvent::~CWeekendBonusEvent(CWeekendBonusEvent *this)
{
  *(_DWORD *)this = off_8B4F2A8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x811759C
// IDA_NAME: _ZN18CWeekendBonusEventD0Ev
// DEMANGLED: CWeekendBonusEvent::~CWeekendBonusEvent()
void __cdecl CWeekendBonusEvent::~CWeekendBonusEvent(CWeekendBonusEvent *this)
{
  CWeekendBonusEvent::~CWeekendBonusEvent(this);
  operator delete(this);
}

// IDA_EA: 0x81175BA
// IDA_NAME: _ZN18CWeekendBonusEvent10StartEventEv
// DEMANGLED: CWeekendBonusEvent::StartEvent(void)
int __cdecl CWeekendBonusEvent::StartEvent(CWeekendBonusEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CWeekendBonusEvent::StartEvent()", 18, 0);
  return cMyTrace::operator()((int)v3, "CWeekendBonusEvent Event Start!", v2);
}

// IDA_EA: 0x811760C
// IDA_NAME: _ZN18CWeekendBonusEvent10StartEventE10Word_Param
// DEMANGLED: CWeekendBonusEvent::StartEvent(Word_Param)
int __cdecl CWeekendBonusEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x8117626
// IDA_NAME: _ZN18CWeekendBonusEvent8EndEventEv
// DEMANGLED: CWeekendBonusEvent::EndEvent(void)
int __cdecl CWeekendBonusEvent::EndEvent(CWeekendBonusEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CWeekendBonusEvent::EndEvent()", 28, 0);
  return cMyTrace::operator()((int)v3, "CWeekendBonusEvent Event End!", v2);
}
