#ifndef __IDA91_USEDFATIGUEREWARDITEM_H__
#define __IDA91_USEDFATIGUEREWARDITEM_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: UsedFatigueRewardItem
// Source unit: UsedFatigueRewardItem
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4793

/* 4793 */
struct UsedFatigueRewardItem;

// Exported member functions:
// 0x81A25D2	UsedFatigueRewardItem::parsing(char *)
// 0x81A28E4	UsedFatigueRewardItem::find(int,int,UsedFatigueRewardItem::Data &)

// Function declaration index:
// DECL 0x81A25D2 UsedFatigueRewardItem::parsing
// DECL 0x81A28E4 UsedFatigueRewardItem::find

#endif  // __IDA91_USEDFATIGUEREWARDITEM_H__
