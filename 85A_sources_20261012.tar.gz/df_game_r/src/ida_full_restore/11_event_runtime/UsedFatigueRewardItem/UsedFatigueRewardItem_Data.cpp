#include "UsedFatigueRewardItem_Data.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81A40A0
// IDA_NAME: _ZN21UsedFatigueRewardItem4DataC2Ev
// DEMANGLED: UsedFatigueRewardItem::Data::Data(void)
void *__cdecl UsedFatigueRewardItem::Data::Data(UsedFatigueRewardItem::Data *this)
{
  *(_WORD *)this = 0;
  *((_WORD *)this + 1) = 0;
  *((_DWORD *)this + 69) = 0;
  memset((char *)this + 4, 0, 0xFFu);
  return memset((char *)this + 259, 0, 0x10u);
}

// IDA_EA: 0x81A6BF4
// IDA_NAME: _ZN21UsedFatigueRewardItem4DataD2Ev
// DEMANGLED: UsedFatigueRewardItem::Data::~Data()
void UsedFatigueRewardItem::Data::~Data()
{
  ;
}
