#include "UsedFatigueRewardItem.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81A25D2
// IDA_NAME: _ZN21UsedFatigueRewardItem7parsingEPc
// DEMANGLED: UsedFatigueRewardItem::parsing(char *)
int __cdecl UsedFatigueRewardItem::parsing(UsedFatigueRewardItem *this, char *a2)
{
  int n175; // ebx
  char *s; // eax
  bool v4; // bl
  const char *src; // eax
  const char *src_1; // eax
  int RowNum; // eax
  _WORD v9[2]; // [esp+10h] [ebp-188h] BYREF
  char dest_[255]; // [esp+14h] [ebp-184h] BYREF
  char dest__1[17]; // [esp+113h] [ebp-85h] BYREF
  int Int; // [esp+124h] [ebp-74h]
  void *v13[21]; // [esp+128h] [ebp-70h] BYREF
  std::string v14; // [esp+17Ch] [ebp-1Ch] BYREF
  std::string v15; // [esp+183h] [ebp-15h] BYREF
  _BYTE v16[13]; // [esp+18Bh] [ebp-Dh] BYREF

  Arad_Script::Arad_Script((Arad_Script *)v13);
  if ( (unsigned __int8)Arad_Script::Load((Arad_Script *)v13, a2, "on_off") == 1 )
  {
    if ( Arad_Script::GetRowNum((Arad_Script *)v13) )
    {
      *((_BYTE *)this + 4) = 0;
      std::allocator<char>::allocator(&v15);
      s = (char *)Arad_Script::GetString((Arad_Script *)v13, 0, "flag");
      std::string::string((int)&v14, s, (int)&v15);
      std::allocator<char>::~allocator(&v15);
      std::allocator<char>::allocator(v16);
      std::string::string((int)&v15._M_dataplus.__vftable + 1, "true", (int)v16);
      v4 = std::operator==<char>(&v14, (std::string *)((char *)&v15._M_dataplus.__vftable + 1));
      std::string::~string((char *)&v15._M_dataplus.__vftable + 1);
      std::allocator<char>::~allocator(v16);
      if ( v4 )
        *((_BYTE *)this + 4) = 1;
      if ( (unsigned __int8)Arad_Script::Load((Arad_Script *)v13, a2, "item_reward") == 1 )
      {
        if ( Arad_Script::GetRowNum((Arad_Script *)v13) )
        {
          UsedFatigueRewardItem::Data::Data((UsedFatigueRewardItem::Data *)v9);
          for ( *(_DWORD *)&v16[1] = 0; ; ++*(_DWORD *)&v16[1] )
          {
            RowNum = Arad_Script::GetRowNum((Arad_Script *)v13);
            if ( RowNum <= *(int *)&v16[1] )
              break;
            v9[0] = Arad_Script::GetInt((Arad_Script *)v13, *(int *)&v16[1], "fatigue");
            v9[1] = Arad_Script::GetInt((Arad_Script *)v13, *(int *)&v16[1], "item_count");
            Int = Arad_Script::GetInt((Arad_Script *)v13, *(int *)&v16[1], "item_id");
            src = (const char *)Arad_Script::GetString((Arad_Script *)v13, *(int *)&v16[1], "message");
            strncpy(dest_, src, 0xFFu);
            src_1 = (const char *)Arad_Script::GetString((Arad_Script *)v13, *(int *)&v16[1], "title");
            strncpy(dest__1, src_1, 0x10u);
            std::vector<UsedFatigueRewardItem::Data>::push_back((char *)this + 8, v9);
          }
          n175 = 0;
        }
        else
        {
          n175 = 175;
        }
      }
      else
      {
        n175 = 172;
      }
      std::string::~string(&v14);
    }
    else
    {
      n175 = 164;
    }
  }
  else
  {
    n175 = 161;
  }
  Arad_Script::~Arad_Script(v13);
  return n175;
}

// IDA_EA: 0x81A28E4
// IDA_NAME: _ZN21UsedFatigueRewardItem4findEiiRNS_4DataE
// DEMANGLED: UsedFatigueRewardItem::find(int,int,UsedFatigueRewardItem::Data &)
int __cdecl UsedFatigueRewardItem::find(UsedFatigueRewardItem *this, int a2, int a3, UsedFatigueRewardItem::Data *a4)
{
  int v5; // eax
  const char *src; // eax
  int v7; // eax
  const char *src_1; // eax
  int v10; // [esp+18h] [ebp-10h] BYREF
  _BYTE v11[12]; // [esp+1Ch] [ebp-Ch] BYREF

  std::vector<UsedFatigueRewardItem::Data>::end((int)v11, (int)this + 8);
  std::vector<UsedFatigueRewardItem::Data>::begin((int)&v10, (int)this + 8);
  while ( __gnu_cxx::operator!=<UsedFatigueRewardItem::Data *,std::vector<UsedFatigueRewardItem::Data>>(
            (int)&v10,
            (int)v11) )
  {
    if ( *(__int16 *)__gnu_cxx::__normal_iterator<UsedFatigueRewardItem::Data *,std::vector<UsedFatigueRewardItem::Data>>::operator->((int)&v10) >= a2
      && *(__int16 *)__gnu_cxx::__normal_iterator<UsedFatigueRewardItem::Data *,std::vector<UsedFatigueRewardItem::Data>>::operator->((int)&v10) < a3 )
    {
      *(_WORD *)a4 = *(_WORD *)__gnu_cxx::__normal_iterator<UsedFatigueRewardItem::Data *,std::vector<UsedFatigueRewardItem::Data>>::operator->((int)&v10);
      *((_DWORD *)a4 + 69) = *(_DWORD *)(__gnu_cxx::__normal_iterator<UsedFatigueRewardItem::Data *,std::vector<UsedFatigueRewardItem::Data>>::operator->((int)&v10)
                                       + 276);
      *((_WORD *)a4 + 1) = *(_WORD *)(__gnu_cxx::__normal_iterator<UsedFatigueRewardItem::Data *,std::vector<UsedFatigueRewardItem::Data>>::operator->((int)&v10)
                                    + 2);
      v5 = __gnu_cxx::__normal_iterator<UsedFatigueRewardItem::Data *,std::vector<UsedFatigueRewardItem::Data>>::operator->((int)&v10);
      src = RDARScriptStringManager::findString(
              (RDARScriptStringManager *)&g_scriptStringManager_,
              (char *)4,
              (char *)(v5 + 259),
              0);
      strncpy((char *)a4 + 259, src, 0x14u);
      v7 = __gnu_cxx::__normal_iterator<UsedFatigueRewardItem::Data *,std::vector<UsedFatigueRewardItem::Data>>::operator->((int)&v10);
      src_1 = RDARScriptStringManager::findString(
                (RDARScriptStringManager *)&g_scriptStringManager_,
                (char *)4,
                (char *)(v7 + 4),
                0);
      strncpy((char *)a4 + 4, src_1, 0xFFu);
      return 1;
    }
    __gnu_cxx::__normal_iterator<UsedFatigueRewardItem::Data *,std::vector<UsedFatigueRewardItem::Data>>::operator++(&v10);
  }
  return 0;
}
