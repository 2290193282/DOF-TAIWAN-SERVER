#ifndef __IDA91_USEDFATIGUEREWARDITEM_DATA_H__
#define __IDA91_USEDFATIGUEREWARDITEM_DATA_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: UsedFatigueRewardItem
// Source unit: UsedFatigueRewardItem_Data
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 1451

/* 1451 */
struct UsedFatigueRewardItem::Data;

// Exported member functions:
// 0x81A40A0	UsedFatigueRewardItem::Data::Data(void)
// 0x81A6BF4	UsedFatigueRewardItem::Data::~Data()

// Function declaration index:
// DECL 0x81A40A0 UsedFatigueRewardItem::Data::Data
// DECL 0x81A6BF4 UsedFatigueRewardItem::Data::~Data

#endif  // __IDA91_USEDFATIGUEREWARDITEM_DATA_H__
