#include "CConditionEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81848BC
// IDA_NAME: _ZN15CConditionEvent10StartEventEv
// DEMANGLED: CConditionEvent::StartEvent(void)
int __cdecl CConditionEvent::StartEvent(CConditionEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CConditionEvent::StartEvent()", 13, 0);
  return cMyTrace::operator()((int)v3, "[ConditionEvent] Start!", v2);
}

// IDA_EA: 0x818490E
// IDA_NAME: _ZN15CConditionEvent10StartEventE10Word_Param
// DEMANGLED: CConditionEvent::StartEvent(Word_Param)
int __cdecl CConditionEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x8184928
// IDA_NAME: _ZN15CConditionEvent8EndEventEv
// DEMANGLED: CConditionEvent::EndEvent(void)
CEventBase *__cdecl CConditionEvent::EndEvent(CConditionEvent *this)
{
  const char *v2; // [esp+14h] [ebp-14h]

  LogManager::logFormat(
    (LogManager *)1,
    (int)"localjapan/Arad_ConditionEvent.cpp",
    "virtual void CConditionEvent::EndEvent()",
    (const char *)0x17,
    "[CConditionEvent] End Event.",
    v2);
  return CEventBase::SetEventFlag(this, 0);
}

// IDA_EA: 0x8184970
// IDA_NAME: _ZN15CConditionEventC2Ev
// DEMANGLED: CConditionEvent::CConditionEvent(void)
void __cdecl CConditionEvent::CConditionEvent(CConditionEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B8E5C8;
}

// IDA_EA: 0x818498C
// IDA_NAME: _ZN15CConditionEventD2Ev
// DEMANGLED: CConditionEvent::~CConditionEvent()
void __cdecl CConditionEvent::~CConditionEvent(CConditionEvent *this)
{
  *(_DWORD *)this = off_8B8E5C8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x81849BC
// IDA_NAME: _ZN15CConditionEventD0Ev
// DEMANGLED: CConditionEvent::~CConditionEvent()
void __cdecl CConditionEvent::~CConditionEvent(CConditionEvent *this)
{
  CConditionEvent::~CConditionEvent(this);
  operator delete(this);
}
