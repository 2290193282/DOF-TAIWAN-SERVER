#ifndef __IDA91_CCONDITIONEVENT_H__
#define __IDA91_CCONDITIONEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CConditionEvent
// Source unit: CConditionEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4132

/* 4132 */
struct CConditionEvent;

// Exported member functions:
// 0x81848BC	CConditionEvent::StartEvent(void)
// 0x818490E	CConditionEvent::StartEvent(Word_Param)
// 0x8184928	CConditionEvent::EndEvent(void)
// 0x8184970	CConditionEvent::CConditionEvent(void)
// 0x818498C	CConditionEvent::~CConditionEvent()
// 0x81849BC	CConditionEvent::~CConditionEvent()

// Function declaration index:
// DECL 0x81848BC CConditionEvent::StartEvent
// DECL 0x818490E CConditionEvent::StartEvent
// DECL 0x8184928 CConditionEvent::EndEvent
// DECL 0x8184970 CConditionEvent::CConditionEvent
// DECL 0x818498C CConditionEvent::~CConditionEvent
// DECL 0x81849BC CConditionEvent::~CConditionEvent

#endif  // __IDA91_CCONDITIONEVENT_H__
