#include "CItemDropRatioEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x85331D0
// IDA_NAME: _ZN19CItemDropRatioEventC2Ev
// DEMANGLED: CItemDropRatioEvent::CItemDropRatioEvent(void)
void __cdecl CItemDropRatioEvent::CItemDropRatioEvent(CItemDropRatioEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8C99368;
  *((_DWORD *)this + 3) = 1;
}

// IDA_EA: 0x85331F6
// IDA_NAME: _ZN19CItemDropRatioEventD2Ev
// DEMANGLED: CItemDropRatioEvent::~CItemDropRatioEvent()
void __cdecl CItemDropRatioEvent::~CItemDropRatioEvent(CItemDropRatioEvent *this)
{
  *(_DWORD *)this = off_8C99368;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x8533226
// IDA_NAME: _ZN19CItemDropRatioEventD0Ev
// DEMANGLED: CItemDropRatioEvent::~CItemDropRatioEvent()
void __cdecl CItemDropRatioEvent::~CItemDropRatioEvent(CItemDropRatioEvent *this)
{
  CItemDropRatioEvent::~CItemDropRatioEvent(this);
  operator delete(this);
}

// IDA_EA: 0x8533244
// IDA_NAME: _ZN19CItemDropRatioEvent10StartEventEv
// DEMANGLED: CItemDropRatioEvent::StartEvent(void)
int __cdecl CItemDropRatioEvent::StartEvent(CItemDropRatioEvent *this)
{
  CDataManager *v1; // eax
  char v3; // [esp+8h] [ebp-20h]
  int v4[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  *((_DWORD *)this + 3) = 1;
  v1 = (CDataManager *)G_CDataManager();
  CDataManager::SetItemDropRate(v1, 1.0);
  cMyTrace::cMyTrace((cMyTrace *)v4, "virtual void CItemDropRatioEvent::StartEvent()", 22, 0);
  return cMyTrace::operator()((int)v4, "Item Drop Event Start!", v3);
}

// IDA_EA: 0x85332B6
// IDA_NAME: _ZN19CItemDropRatioEvent10StartEventE10Word_Param
// DEMANGLED: CItemDropRatioEvent::StartEvent(Word_Param)
int __cdecl CItemDropRatioEvent::StartEvent(CEventBase *a1, unsigned __int16 a2)
{
  CDataManager *v2; // eax
  char v4; // [esp+8h] [ebp-30h]
  float v5; // [esp+14h] [ebp-24h]
  int v6[6]; // [esp+20h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  *((_DWORD *)a1 + 3) = a2;
  v5 = (float)*((unsigned int *)a1 + 3);
  v2 = (CDataManager *)G_CDataManager();
  CDataManager::SetItemDropRate(v2, v5);
  cMyTrace::cMyTrace((cMyTrace *)v6, "virtual void CItemDropRatioEvent::StartEvent(Word_Param)", 31, 0);
  return cMyTrace::operator()((int)v6, "Item Drop Event Start!", v4);
}

// IDA_EA: 0x8533340
// IDA_NAME: _ZN19CItemDropRatioEvent8EndEventEv
// DEMANGLED: CItemDropRatioEvent::EndEvent(void)
int __cdecl CItemDropRatioEvent::EndEvent(CItemDropRatioEvent *this)
{
  CDataManager *v1; // eax
  char v3; // [esp+8h] [ebp-20h]
  int v4[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  *((_DWORD *)this + 3) = 1;
  v1 = (CDataManager *)G_CDataManager();
  CDataManager::SetItemDropRate(v1, 1.0);
  cMyTrace::cMyTrace((cMyTrace *)v4, "virtual void CItemDropRatioEvent::EndEvent()", 40, 0);
  return cMyTrace::operator()((int)v4, "Item Drop Event End!", v3);
}
