#ifndef __IDA91_CITEMDROPRATIOEVENT_H__
#define __IDA91_CITEMDROPRATIOEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CItemDropRatioEvent
// Source unit: CItemDropRatioEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4224

/* 4224 */
struct CItemDropRatioEvent;

// Exported member functions:
// 0x85331D0	CItemDropRatioEvent::CItemDropRatioEvent(void)
// 0x85331F6	CItemDropRatioEvent::~CItemDropRatioEvent()
// 0x8533226	CItemDropRatioEvent::~CItemDropRatioEvent()
// 0x8533244	CItemDropRatioEvent::StartEvent(void)
// 0x85332B6	CItemDropRatioEvent::StartEvent(Word_Param)
// 0x8533340	CItemDropRatioEvent::EndEvent(void)

// Function declaration index:
// DECL 0x85331D0 CItemDropRatioEvent::CItemDropRatioEvent
// DECL 0x85331F6 CItemDropRatioEvent::~CItemDropRatioEvent
// DECL 0x8533226 CItemDropRatioEvent::~CItemDropRatioEvent
// DECL 0x8533244 CItemDropRatioEvent::StartEvent
// DECL 0x85332B6 CItemDropRatioEvent::StartEvent
// DECL 0x8533340 CItemDropRatioEvent::EndEvent

#endif  // __IDA91_CITEMDROPRATIOEVENT_H__
