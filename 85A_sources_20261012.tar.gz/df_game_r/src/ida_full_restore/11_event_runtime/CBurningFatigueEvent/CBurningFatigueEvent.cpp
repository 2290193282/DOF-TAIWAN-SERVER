#include "CBurningFatigueEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8109FA4
// IDA_NAME: _ZN20CBurningFatigueEventC2Ev
// DEMANGLED: CBurningFatigueEvent::CBurningFatigueEvent(void)
void __cdecl CBurningFatigueEvent::CBurningFatigueEvent(CBurningFatigueEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B47CE8;
  *((_DWORD *)this + 3) = G_CDataManager() + 1268;
}

// IDA_EA: 0x8109FF4
// IDA_NAME: _ZN20CBurningFatigueEventD2Ev
// DEMANGLED: CBurningFatigueEvent::~CBurningFatigueEvent()
void __cdecl CBurningFatigueEvent::~CBurningFatigueEvent(CBurningFatigueEvent *this)
{
  *(_DWORD *)this = off_8B47CE8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x810A024
// IDA_NAME: _ZN20CBurningFatigueEventD0Ev
// DEMANGLED: CBurningFatigueEvent::~CBurningFatigueEvent()
void __cdecl CBurningFatigueEvent::~CBurningFatigueEvent(CBurningFatigueEvent *this)
{
  CBurningFatigueEvent::~CBurningFatigueEvent(this);
  operator delete(this);
}

// IDA_EA: 0x810A042
// IDA_NAME: _ZN20CBurningFatigueEvent10StartEventEv
// DEMANGLED: CBurningFatigueEvent::StartEvent(void)
void CBurningFatigueEvent::StartEvent()
{
  ;
}

// IDA_EA: 0x810A048
// IDA_NAME: _ZN20CBurningFatigueEvent10StartEventE10Word_Param
// DEMANGLED: CBurningFatigueEvent::StartEvent(Word_Param)
int __cdecl CBurningFatigueEvent::StartEvent(CEventBase *a1)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CBurningFatigueEvent::StartEvent(Word_Param)", 27, 0);
  return cMyTrace::operator()((int)v3, "Burning Fatigue Event Start", v2);
}

// IDA_EA: 0x810A09A
// IDA_NAME: _ZN20CBurningFatigueEvent8EndEventEv
// DEMANGLED: CBurningFatigueEvent::EndEvent(void)
int __cdecl CBurningFatigueEvent::EndEvent(CBurningFatigueEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CBurningFatigueEvent::EndEvent()", 33, 0);
  return cMyTrace::operator()((int)v3, "Burning Fatigue Event End", v2);
}

// IDA_EA: 0x810A0EC
// IDA_NAME: _ZNK20CBurningFatigueEvent15getBonusExpRateEt
// DEMANGLED: CBurningFatigueEvent::getBonusExpRate(unsigned short)const
int __cdecl CBurningFatigueEvent::getBonusExpRate(CBurningFatigueEvent *this, unsigned __int16 a2)
{
  unsigned int i; // [esp+2Ch] [ebp-Ch]

  for ( i = 1; std::vector<stBurningFatigueParam_t>::size(*((_DWORD *)this + 3)) > i; ++i )
  {
    if ( *(_WORD *)std::vector<stBurningFatigueParam_t>::operator[](*((_DWORD *)this + 3), i) > a2 )
      return *(_DWORD *)(std::vector<stBurningFatigueParam_t>::operator[](*((_DWORD *)this + 3), i - 1) + 4);
  }
  return 0;
}

// IDA_EA: 0x810A166
// IDA_NAME: _ZNK20CBurningFatigueEvent16getRefillFatigueEtt
// DEMANGLED: CBurningFatigueEvent::getRefillFatigue(unsigned short,unsigned short)const
int __cdecl CBurningFatigueEvent::getRefillFatigue(
        CBurningFatigueEvent *this,
        unsigned __int16 CurCharacUsedFatigueEv,
        unsigned __int16 a3)
{
  unsigned int i; // [esp+2Ch] [ebp-Ch]

  for ( i = 1; std::vector<stBurningFatigueParam_t>::size(*((_DWORD **)this + 3)) > i; ++i )
  {
    if ( *(_WORD *)std::vector<stBurningFatigueParam_t>::operator[](*((_DWORD **)this + 3), i) <= CurCharacUsedFatigueEv
      && *(unsigned __int16 *)std::vector<stBurningFatigueParam_t>::operator[](*((_DWORD **)this + 3), i) > CurCharacUsedFatigueEv - a3 )
    {
      return *(unsigned __int16 *)(std::vector<stBurningFatigueParam_t>::operator[](*((_DWORD **)this + 3), i) + 8);
    }
  }
  return 0;
}
