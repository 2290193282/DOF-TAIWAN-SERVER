#ifndef __IDA91_CBURNINGFATIGUEEVENT_H__
#define __IDA91_CBURNINGFATIGUEEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CBurningFatigueEvent
// Source unit: CBurningFatigueEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1181

/* 1181 */
struct CBurningFatigueEvent;

// Exported member functions:
// 0x8109FA4	CBurningFatigueEvent::CBurningFatigueEvent(void)
// 0x8109FF4	CBurningFatigueEvent::~CBurningFatigueEvent()
// 0x810A024	CBurningFatigueEvent::~CBurningFatigueEvent()
// 0x810A042	CBurningFatigueEvent::StartEvent(void)
// 0x810A048	CBurningFatigueEvent::StartEvent(Word_Param)
// 0x810A09A	CBurningFatigueEvent::EndEvent(void)
// 0x810A0EC	CBurningFatigueEvent::getBonusExpRate(unsigned short)const
// 0x810A166	CBurningFatigueEvent::getRefillFatigue(unsigned short,unsigned short)const

// Function declaration index:
// DECL 0x8109FA4 CBurningFatigueEvent::CBurningFatigueEvent
// DECL 0x8109FF4 CBurningFatigueEvent::~CBurningFatigueEvent
// DECL 0x810A024 CBurningFatigueEvent::~CBurningFatigueEvent
// DECL 0x810A042 CBurningFatigueEvent::StartEvent
// DECL 0x810A048 CBurningFatigueEvent::StartEvent
// DECL 0x810A09A CBurningFatigueEvent::EndEvent
// DECL 0x810A0EC CBurningFatigueEvent::getBonusExpRate
// DECL 0x810A166 CBurningFatigueEvent::getRefillFatigue

#endif  // __IDA91_CBURNINGFATIGUEEVENT_H__
