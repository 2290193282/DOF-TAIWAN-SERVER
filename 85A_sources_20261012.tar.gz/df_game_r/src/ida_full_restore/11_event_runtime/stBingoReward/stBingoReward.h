#ifndef __IDA91_STBINGOREWARD_H__
#define __IDA91_STBINGOREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stBingoReward
// Source unit: stBingoReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2107

/* 2107 */
struct stBingoReward;

// Exported member functions:
// 0x8261C24	stBingoReward::stBingoReward(void)
// 0x8261C40	stBingoReward::~stBingoReward()
// 0x8261C70	stBingoReward::~stBingoReward()

// Function declaration index:
// DECL 0x8261C24 stBingoReward::stBingoReward
// DECL 0x8261C40 stBingoReward::~stBingoReward
// DECL 0x8261C70 stBingoReward::~stBingoReward

#endif  // __IDA91_STBINGOREWARD_H__
