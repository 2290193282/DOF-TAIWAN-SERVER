#include "stBingoReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8261C24
// IDA_NAME: _ZN13stBingoRewardC2Ev
// DEMANGLED: stBingoReward::stBingoReward(void)
void __cdecl stBingoReward::stBingoReward(stBingoReward *this)
{
  ParamBase::ParamBase(this);
  *(_DWORD *)this = off_8BEA860;
}

// IDA_EA: 0x8261C40
// IDA_NAME: _ZN13stBingoRewardD2Ev
// DEMANGLED: stBingoReward::~stBingoReward()
void __cdecl stBingoReward::~stBingoReward(stBingoReward *this)
{
  *(_DWORD *)this = off_8BEA860;
  ParamBase::~ParamBase(this);
}

// IDA_EA: 0x8261C70
// IDA_NAME: _ZN13stBingoRewardD0Ev
// DEMANGLED: stBingoReward::~stBingoReward()
void __cdecl stBingoReward::~stBingoReward(stBingoReward *this)
{
  stBingoReward::~stBingoReward(this);
  operator delete(this);
}
