#include "CBreakAwayPreventEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8109DBC
// IDA_NAME: _ZN22CBreakAwayPreventEventC2Ev
// DEMANGLED: CBreakAwayPreventEvent::CBreakAwayPreventEvent(void)
void __cdecl CBreakAwayPreventEvent::CBreakAwayPreventEvent(CBreakAwayPreventEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B46FA8;
}

// IDA_EA: 0x8109DD8
// IDA_NAME: _ZN22CBreakAwayPreventEventD2Ev
// DEMANGLED: CBreakAwayPreventEvent::~CBreakAwayPreventEvent()
void __cdecl CBreakAwayPreventEvent::~CBreakAwayPreventEvent(CBreakAwayPreventEvent *this)
{
  *(_DWORD *)this = off_8B46FA8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x8109E08
// IDA_NAME: _ZN22CBreakAwayPreventEventD0Ev
// DEMANGLED: CBreakAwayPreventEvent::~CBreakAwayPreventEvent()
void __cdecl CBreakAwayPreventEvent::~CBreakAwayPreventEvent(CBreakAwayPreventEvent *this)
{
  CBreakAwayPreventEvent::~CBreakAwayPreventEvent(this);
  operator delete(this);
}

// IDA_EA: 0x8109E26
// IDA_NAME: _ZN22CBreakAwayPreventEvent10StartEventEv
// DEMANGLED: CBreakAwayPreventEvent::StartEvent(void)
int __cdecl CBreakAwayPreventEvent::StartEvent(CBreakAwayPreventEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 20, 0);
  return cMyTrace::operator()((int)v3, "CBreakAwayPreventEvent Start!", v2);
}

// IDA_EA: 0x8109E78
// IDA_NAME: _ZN22CBreakAwayPreventEvent10StartEventE10Word_Param
// DEMANGLED: CBreakAwayPreventEvent::StartEvent(Word_Param)
int __cdecl CBreakAwayPreventEvent::StartEvent(CEventBase *a1)
{
  bool v2; // [esp+4h] [ebp-24h]
  char v3; // [esp+8h] [ebp-20h]
  int v4[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  DB_LoadBreakAwayPreventData::makeRequest((DB_LoadBreakAwayPreventData *)1, v2);
  cMyTrace::cMyTrace((cMyTrace *)v4, "StartEvent", 27, 0);
  return cMyTrace::operator()((int)v4, "CBreakAwayPreventEvent Start!", v3);
}

// IDA_EA: 0x8109ED6
// IDA_NAME: _ZN22CBreakAwayPreventEvent8EndEventEv
// DEMANGLED: CBreakAwayPreventEvent::EndEvent(void)
int __cdecl CBreakAwayPreventEvent::EndEvent(CBreakAwayPreventEvent *this)
{
  bool v2; // [esp+4h] [ebp-24h]
  char v3; // [esp+8h] [ebp-20h]
  int v4[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  DB_LoadBreakAwayPreventData::makeRequest(0, v2);
  cMyTrace::cMyTrace((cMyTrace *)v4, "EndEvent", 35, 0);
  return cMyTrace::operator()((int)v4, "CBreakAwayPreventEvent End!", v3);
}
