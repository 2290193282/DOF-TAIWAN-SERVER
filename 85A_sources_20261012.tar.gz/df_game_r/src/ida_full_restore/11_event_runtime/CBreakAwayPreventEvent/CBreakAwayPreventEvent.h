#ifndef __IDA91_CBREAKAWAYPREVENTEVENT_H__
#define __IDA91_CBREAKAWAYPREVENTEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CBreakAwayPreventEvent
// Source unit: CBreakAwayPreventEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4371

/* 4371 */
struct CBreakAwayPreventEvent;

// Exported member functions:
// 0x8109DBC	CBreakAwayPreventEvent::CBreakAwayPreventEvent(void)
// 0x8109DD8	CBreakAwayPreventEvent::~CBreakAwayPreventEvent()
// 0x8109E08	CBreakAwayPreventEvent::~CBreakAwayPreventEvent()
// 0x8109E26	CBreakAwayPreventEvent::StartEvent(void)
// 0x8109E78	CBreakAwayPreventEvent::StartEvent(Word_Param)
// 0x8109ED6	CBreakAwayPreventEvent::EndEvent(void)

// Function declaration index:
// DECL 0x8109DBC CBreakAwayPreventEvent::CBreakAwayPreventEvent
// DECL 0x8109DD8 CBreakAwayPreventEvent::~CBreakAwayPreventEvent
// DECL 0x8109E08 CBreakAwayPreventEvent::~CBreakAwayPreventEvent
// DECL 0x8109E26 CBreakAwayPreventEvent::StartEvent
// DECL 0x8109E78 CBreakAwayPreventEvent::StartEvent
// DECL 0x8109ED6 CBreakAwayPreventEvent::EndEvent

#endif  // __IDA91_CBREAKAWAYPREVENTEVENT_H__
