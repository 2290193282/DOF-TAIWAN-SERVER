#ifndef __IDA91_TOURNAMENTREWARDRATE_H__
#define __IDA91_TOURNAMENTREWARDRATE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: TournamentRewardRate
// Source unit: TournamentRewardRate
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3873

/* 3873 */
struct TournamentRewardRate;

// Exported member functions:
// 0x88F2DA0	TournamentRewardRate::TournamentRewardRate(void)

// Function declaration index:
// DECL 0x88F2DA0 TournamentRewardRate::TournamentRewardRate

#endif  // __IDA91_TOURNAMENTREWARDRATE_H__
