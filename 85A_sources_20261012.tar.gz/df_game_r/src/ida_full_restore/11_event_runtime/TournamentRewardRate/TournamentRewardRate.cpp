#include "TournamentRewardRate.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x88F2DA0
// IDA_NAME: _ZN20TournamentRewardRateC2Ev
// DEMANGLED: TournamentRewardRate::TournamentRewardRate(void)
void __cdecl TournamentRewardRate::TournamentRewardRate(TournamentRewardRate *this)
{
  *(_DWORD *)this = 0;
  *((_DWORD *)this + 1) = 0;
  *((_DWORD *)this + 2) = 0;
  *((_DWORD *)this + 3) = 0;
}
