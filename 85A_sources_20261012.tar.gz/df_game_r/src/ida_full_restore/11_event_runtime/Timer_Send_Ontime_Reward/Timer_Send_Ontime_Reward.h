#ifndef __IDA91_TIMER_SEND_ONTIME_REWARD_H__
#define __IDA91_TIMER_SEND_ONTIME_REWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Timer_Send_Ontime_Reward
// Source unit: Timer_Send_Ontime_Reward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3580

/* 3580 */
struct Timer_Send_Ontime_Reward;

// Exported member functions:
// 0x863AA90	Timer_Send_Ontime_Reward::dispatch_sig(int,int,unsigned int)
// 0x863AB4C	Timer_Send_Ontime_Reward::RegistNextTimer(void)
// 0x863D016	Timer_Send_Ontime_Reward::Timer_Send_Ontime_Reward(void)
// 0x863E796	Timer_Send_Ontime_Reward::~Timer_Send_Ontime_Reward()
// 0x863E7C6	Timer_Send_Ontime_Reward::~Timer_Send_Ontime_Reward()

// Function declaration index:
// DECL 0x863AA90 Timer_Send_Ontime_Reward::dispatch_sig
// DECL 0x863AB4C Timer_Send_Ontime_Reward::RegistNextTimer
// DECL 0x863D016 Timer_Send_Ontime_Reward::Timer_Send_Ontime_Reward
// DECL 0x863E796 Timer_Send_Ontime_Reward::~Timer_Send_Ontime_Reward
// DECL 0x863E7C6 Timer_Send_Ontime_Reward::~Timer_Send_Ontime_Reward

#endif  // __IDA91_TIMER_SEND_ONTIME_REWARD_H__
