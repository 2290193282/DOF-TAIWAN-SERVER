#include "Timer_Send_Ontime_Reward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x863AA90
// IDA_NAME: _ZN24Timer_Send_Ontime_Reward12dispatch_sigEiij
// DEMANGLED: Timer_Send_Ontime_Reward::dispatch_sig(int,int,unsigned int)
int Timer_Send_Ontime_Reward::dispatch_sig()
{
  Timer_Send_Ontime_Reward *v2; // [esp+0h] [ebp-38h]
  char v3; // [esp+8h] [ebp-30h]
  int v4[4]; // [esp+1Ch] [ebp-1Ch] BYREF
  COnTimeEvent *RepeatEvent; // [esp+2Ch] [ebp-Ch]

  RepeatEvent = (COnTimeEvent *)CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 51);
  if ( RepeatEvent
    && (*(unsigned __int8 (__cdecl **)(COnTimeEvent *, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) )
  {
    COnTimeEvent::process_send_reward_to_user(RepeatEvent);
    if ( COnTimeEvent::get_ontime_reward_user_count(RepeatEvent) )
      Timer_Send_Ontime_Reward::RegistNextTimer(v2);
    return 1;
  }
  else
  {
    cMyTrace::cMyTrace(
      (cMyTrace *)v4,
      "virtual bool Timer_Send_Ontime_Reward::dispatch_sig(int, int, memberIdentificationNumber_t)",
      5688,
      5);
    cMyTrace::operator()((int)v4, "[ON_TIME_EVENT] Timer_Send_Ontime_Reward() error", v3);
    return 0;
  }
}

// IDA_EA: 0x863AB4C
// IDA_NAME: _ZN24Timer_Send_Ontime_Reward15RegistNextTimerEv
// DEMANGLED: Timer_Send_Ontime_Reward::RegistNextTimer(void)
int Timer_Send_Ontime_Reward::RegistNextTimer()
{
  TimerQueue *v0; // eax

  v0 = (TimerQueue *)G_TimerQueue();
  return TimerQueue::InsertTimer(v0, 2, 0, 155, 10, 0, 0);
}

// IDA_EA: 0x863D016
// IDA_NAME: _ZN24Timer_Send_Ontime_RewardC2Ev
// DEMANGLED: Timer_Send_Ontime_Reward::Timer_Send_Ontime_Reward(void)
void __cdecl Timer_Send_Ontime_Reward::Timer_Send_Ontime_Reward(Timer_Send_Ontime_Reward *this)
{
  TimerSig::TimerSig(this);
  *(_DWORD *)this = &off_8CE86E8;
}

// IDA_EA: 0x863E796
// IDA_NAME: _ZN24Timer_Send_Ontime_RewardD2Ev
// DEMANGLED: Timer_Send_Ontime_Reward::~Timer_Send_Ontime_Reward()
void __cdecl Timer_Send_Ontime_Reward::~Timer_Send_Ontime_Reward(Timer_Send_Ontime_Reward *this)
{
  *(_DWORD *)this = &off_8CE86E8;
  TimerSig::~TimerSig(this);
}

// IDA_EA: 0x863E7C6
// IDA_NAME: _ZN24Timer_Send_Ontime_RewardD0Ev
// DEMANGLED: Timer_Send_Ontime_Reward::~Timer_Send_Ontime_Reward()
void __cdecl Timer_Send_Ontime_Reward::~Timer_Send_Ontime_Reward(Timer_Send_Ontime_Reward *this)
{
  Timer_Send_Ontime_Reward::~Timer_Send_Ontime_Reward(this);
  operator delete(this);
}
