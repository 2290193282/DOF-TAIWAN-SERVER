#include "LevelupSupportEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81169F8
// IDA_NAME: _ZN19LevelupSupportEventC2Ev
// DEMANGLED: LevelupSupportEvent::LevelupSupportEvent(void)
void __cdecl LevelupSupportEvent::LevelupSupportEvent(LevelupSupportEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B4F4E8;
}

// IDA_EA: 0x8116A14
// IDA_NAME: _ZN19LevelupSupportEventD2Ev
// DEMANGLED: LevelupSupportEvent::~LevelupSupportEvent()
void __cdecl LevelupSupportEvent::~LevelupSupportEvent(LevelupSupportEvent *this)
{
  *(_DWORD *)this = off_8B4F4E8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x8116A44
// IDA_NAME: _ZN19LevelupSupportEventD0Ev
// DEMANGLED: LevelupSupportEvent::~LevelupSupportEvent()
void __cdecl LevelupSupportEvent::~LevelupSupportEvent(LevelupSupportEvent *this)
{
  LevelupSupportEvent::~LevelupSupportEvent(this);
  operator delete(this);
}

// IDA_EA: 0x8116A62
// IDA_NAME: _ZN19LevelupSupportEvent10StartEventEv
// DEMANGLED: LevelupSupportEvent::StartEvent(void)
int __cdecl LevelupSupportEvent::StartEvent(LevelupSupportEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 63, 0);
  return cMyTrace::operator()((int)v3, "LevelupSupportEvent Event Start!", v2);
}

// IDA_EA: 0x8116AB4
// IDA_NAME: _ZN19LevelupSupportEvent10StartEventE10Word_Param
// DEMANGLED: LevelupSupportEvent::StartEvent(Word_Param)
int __cdecl LevelupSupportEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x8116ACE
// IDA_NAME: _ZN19LevelupSupportEvent8EndEventEv
// DEMANGLED: LevelupSupportEvent::EndEvent(void)
int __cdecl LevelupSupportEvent::EndEvent(LevelupSupportEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "EndEvent", 73, 0);
  return cMyTrace::operator()((int)v3, "LevelupSupportEvent Event End!", v2);
}
