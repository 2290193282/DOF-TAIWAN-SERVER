#ifndef __IDA91_LEVELUPSUPPORTEVENT_H__
#define __IDA91_LEVELUPSUPPORTEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: LevelupSupportEvent
// Source unit: LevelupSupportEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4096

/* 4096 */
struct LevelupSupportEvent;

// Exported member functions:
// 0x81169F8	LevelupSupportEvent::LevelupSupportEvent(void)
// 0x8116A14	LevelupSupportEvent::~LevelupSupportEvent()
// 0x8116A44	LevelupSupportEvent::~LevelupSupportEvent()
// 0x8116A62	LevelupSupportEvent::StartEvent(void)
// 0x8116AB4	LevelupSupportEvent::StartEvent(Word_Param)
// 0x8116ACE	LevelupSupportEvent::EndEvent(void)

// Function declaration index:
// DECL 0x81169F8 LevelupSupportEvent::LevelupSupportEvent
// DECL 0x8116A14 LevelupSupportEvent::~LevelupSupportEvent
// DECL 0x8116A44 LevelupSupportEvent::~LevelupSupportEvent
// DECL 0x8116A62 LevelupSupportEvent::StartEvent
// DECL 0x8116AB4 LevelupSupportEvent::StartEvent
// DECL 0x8116ACE LevelupSupportEvent::EndEvent

#endif  // __IDA91_LEVELUPSUPPORTEVENT_H__
