#include "DB_UpdateFatigueAttendance.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84444EC
// IDA_NAME: _ZN26DB_UpdateFatigueAttendance8dispatchEiiP6Stream
// DEMANGLED: DB_UpdateFatigueAttendance::dispatch(int,int,Stream *)
int __cdecl DB_UpdateFatigueAttendance::dispatch(DB_UpdateFatigueAttendance *this, int a2, int a3, Stream *a4)
{
  CDataManager *v4; // eax
  EventClassify::CEventScriptMng *event_script_mngEv; // eax
  const std::string *db_table_nameEi; // eax
  const char *v7; // ebx
  int v8; // edi
  int v9; // esi
  const char *v10; // eax
  __int64 v11; // rax
  int v13; // edi
  const char *v14; // ebx
  int v15; // esi
  const char *v16; // eax
  _BYTE dest[3]; // [esp+2Ch] [ebp-5Ch] BYREF
  std::string v19; // [esp+2Fh] [ebp-59h] BYREF
  _BYTE v20[4]; // [esp+34h] [ebp-54h] BYREF
  _BYTE v21[4]; // [esp+38h] [ebp-50h] BYREF
  _BYTE v22[24]; // [esp+3Ch] [ebp-4Ch] BYREF
  int dest_; // [esp+54h] [ebp-34h] BYREF
  unsigned int v24; // [esp+58h] [ebp-30h] BYREF
  _BYTE v25[8]; // [esp+5Ch] [ebp-2Ch] BYREF
  _BYTE v26[4]; // [esp+64h] [ebp-24h] BYREF
  MySQL *DBHandle; // [esp+68h] [ebp-20h]
  int dest__1; // [esp+6Ch] [ebp-1Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 9, 0);
  v24 = 0;
  dest_ = 0;
  std::map<unsigned char,short>::map((int)v22);
  Stream::operator>>(a4, (int)&v24);
  Stream::operator>>(a4, &dest_);
  for ( dest__1 = 0; dest__1 < dest_; ++dest__1 )
  {
    Stream::operator>>(a4, (int)&v19);
    Stream::operator>>(a4, dest);
    std::pair<unsigned char const,short>::pair<unsigned char &,short &>(v26, &v19, dest);
    std::map<unsigned char,short>::insert(v25);
  }
  std::map<unsigned char,short>::begin(v21);
  std::map<unsigned char,short>::end(v20);
  v4 = (CDataManager *)G_CDataManager();
  event_script_mngEv = (EventClassify::CEventScriptMng *)CDataManager::get_event_script_mng(v4);
  db_table_nameEi = (const std::string *)EventClassify::CEventScriptMng::get_db_table_name(event_script_mngEv, 86);
  std::string::string((std::string *)((char *)&v19._M_dataplus.__vftable + 1), db_table_nameEi);
  while ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<unsigned char const,short>>::operator!=(v21, v20) )
  {
    if ( *(__int16 *)(std::_Rb_tree_iterator<std::pair<unsigned char const,short>>::operator->(v21) + 2) > 0 )
    {
      v7 = (const char *)NumberToString(v24, 0);
      v8 = *(unsigned __int8 *)std::_Rb_tree_iterator<std::pair<unsigned char const,short>>::operator->(v21);
      v9 = *(__int16 *)(std::_Rb_tree_iterator<std::pair<unsigned char const,short>>::operator->(v21) + 2);
      v10 = toTString((const std::string *const)((char *)&v19._M_dataplus.__vftable + 1));
      MySQL::set_query(
        DBHandle,
        "upDate %s set fatigue = fatigue + %d where occ_day = %d and m_id = %s",
        v10,
        v9,
        v8,
        v7);
      if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 || (LODWORD(v11) = MySQL::getAffectedRowCount(DBHandle), !v11) )
      {
        v13 = *(__int16 *)(std::_Rb_tree_iterator<std::pair<unsigned char const,short>>::operator->(v21) + 2);
        v14 = (const char *)NumberToString(v24, 0);
        v15 = *(unsigned __int8 *)std::_Rb_tree_iterator<std::pair<unsigned char const,short>>::operator->(v21);
        v16 = toTString((const std::string *const)((char *)&v19._M_dataplus.__vftable + 1));
        MySQL::set_query(DBHandle, "inSert into %s(occ_day,m_id,fatigue) values(%d,%s,%d)", v16, v15, v14, v13);
        MySQL::exec(DBHandle, 1);
      }
    }
    std::_Rb_tree_iterator<std::pair<unsigned char const,short>>::operator++(v21);
  }
  std::string::~string((char *)&v19._M_dataplus.__vftable + 1);
  std::map<unsigned char,short>::~map((int)v22);
  return 1;
}

// IDA_EA: 0x84447D6
// IDA_NAME: _ZN26DB_UpdateFatigueAttendance11makeRequestEjRKSt3mapIhsSt4lessIhESaISt4pairIKhsEEE
// DEMANGLED: DB_UpdateFatigueAttendance::makeRequest(unsigned int,std::map<unsigned char,short,std::less<unsigned char>,std::allocator<std::pair<unsigned char const,short>>> const&)
void __cdecl DB_UpdateFatigueAttendance::makeRequest(char src, int server_fatigue_day_dataEv)
{
  Stream *v2; // eax
  Stream **v3; // eax
  Stream **v4; // eax
  Stream **v5; // eax
  char src_1; // bl
  Stream **v7; // eax
  unsigned __int8 v8; // bl
  Stream **v9; // eax
  __int16 v10; // bx
  Stream **v11; // eax
  int v12; // [esp+10h] [ebp-18h] BYREF
  const std::_Rb_tree_node_base *v13; // [esp+14h] [ebp-14h] BYREF
  Stream *v14[4]; // [esp+18h] [ebp-10h] BYREF

  v2 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 43890);
  CStreamGuard::CStreamGuard((CStreamGuard *)v14, v2, 1);
  v3 = (Stream **)CStreamGuard::operator*((int)v14);
  CStreamGuard::operator<<(v3, 172);
  v4 = (Stream **)CStreamGuard::operator*((int)v14);
  CStreamGuard::operator<<(v4, -1);
  v5 = (Stream **)CStreamGuard::operator*((int)v14);
  CStreamGuard::operator<<(v5, src);
  src_1 = std::map<unsigned char,short>::size(server_fatigue_day_dataEv);
  v7 = (Stream **)CStreamGuard::operator*((int)v14);
  CStreamGuard::operator<<(v7, src_1);
  std::map<unsigned char,short>::begin((int)&v13);
  std::map<unsigned char,short>::end((int)&v12);
  while ( std::_Rb_tree_const_iterator<std::pair<unsigned char const,short>>::operator!=(&v13, &v12) )
  {
    v8 = *(_BYTE *)std::_Rb_tree_const_iterator<std::pair<unsigned char const,short>>::operator->(&v13);
    v9 = (Stream **)CStreamGuard::operator*((int)v14);
    CStreamGuard::operator<<(v9, v8);
    v10 = *(_WORD *)(std::_Rb_tree_const_iterator<std::pair<unsigned char const,short>>::operator->(&v13) + 2);
    v11 = (Stream **)CStreamGuard::operator*((int)v14);
    CStreamGuard::operator<<(v11, v10);
    std::_Rb_tree_const_iterator<std::pair<unsigned char const,short>>::operator++(&v13);
  }
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v14);
  CStreamGuard::~CStreamGuard(v14);
}

// IDA_EA: 0x844F9D2
// IDA_NAME: _ZN26DB_UpdateFatigueAttendanceC2Ev
// DEMANGLED: DB_UpdateFatigueAttendance::DB_UpdateFatigueAttendance(void)
void __cdecl DB_UpdateFatigueAttendance::DB_UpdateFatigueAttendance(DB_UpdateFatigueAttendance *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5E3A0;
}

// IDA_EA: 0x845B6AA
// IDA_NAME: _ZN26DB_UpdateFatigueAttendanceD2Ev
// DEMANGLED: DB_UpdateFatigueAttendance::~DB_UpdateFatigueAttendance()
void __cdecl DB_UpdateFatigueAttendance::~DB_UpdateFatigueAttendance(DB_UpdateFatigueAttendance *this)
{
  *(_DWORD *)this = &off_8C5E3A0;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845B6DA
// IDA_NAME: _ZN26DB_UpdateFatigueAttendanceD0Ev
// DEMANGLED: DB_UpdateFatigueAttendance::~DB_UpdateFatigueAttendance()
void __cdecl DB_UpdateFatigueAttendance::~DB_UpdateFatigueAttendance(DB_UpdateFatigueAttendance *this)
{
  DB_UpdateFatigueAttendance::~DB_UpdateFatigueAttendance(this);
  operator delete(this);
}
