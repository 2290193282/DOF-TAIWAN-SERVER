#ifndef __IDA91_DB_UPDATEFATIGUEATTENDANCE_H__
#define __IDA91_DB_UPDATEFATIGUEATTENDANCE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_UpdateFatigueAttendance
// Source unit: DB_UpdateFatigueAttendance
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2686

/* 2686 */
struct DB_UpdateFatigueAttendance;

// Exported member functions:
// 0x84444EC	DB_UpdateFatigueAttendance::dispatch(int,int,Stream *)
// 0x84447D6	DB_UpdateFatigueAttendance::makeRequest(unsigned int,std::map<unsigned char,short,std::less<unsigned char>,std::allocator<std::pair<unsigned char const,short>>> const&)
// 0x844F9D2	DB_UpdateFatigueAttendance::DB_UpdateFatigueAttendance(void)
// 0x845B6AA	DB_UpdateFatigueAttendance::~DB_UpdateFatigueAttendance()
// 0x845B6DA	DB_UpdateFatigueAttendance::~DB_UpdateFatigueAttendance()

// Function declaration index:
// DECL 0x84444EC DB_UpdateFatigueAttendance::dispatch
// DECL 0x84447D6 DB_UpdateFatigueAttendance::makeRequest
// DECL 0x844F9D2 DB_UpdateFatigueAttendance::DB_UpdateFatigueAttendance
// DECL 0x845B6AA DB_UpdateFatigueAttendance::~DB_UpdateFatigueAttendance
// DECL 0x845B6DA DB_UpdateFatigueAttendance::~DB_UpdateFatigueAttendance

#endif  // __IDA91_DB_UPDATEFATIGUEATTENDANCE_H__
