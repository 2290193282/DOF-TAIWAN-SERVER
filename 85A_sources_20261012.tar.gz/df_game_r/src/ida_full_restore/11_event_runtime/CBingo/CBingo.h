#ifndef __IDA91_CBINGO_H__
#define __IDA91_CBINGO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CBingo
// Source unit: CBingo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1093

/* 1093 */
struct CBingo;

// Exported member functions:
// 0x80CA82C	CBingo::CBingo(void)
// 0x80CA8F0	CBingo::~CBingo()
// 0x80CA936	CBingo::getToday(void)
// 0x80CA942	CBingo::getToday(long,int)
// 0x80CA9B8	CBingo::resetBoard(int)
// 0x80CAA64	CBingo::resetQuiz(int)
// 0x80CAAFA	CBingo::getIndexTodayBoard(int)
// 0x80CAB5A	CBingo::calBoradMatchLine(int)
// 0x80CAD4C	CBingo::calNewValue(unsigned int &,int)
// 0x80CADD4	CBingo::initUserData(BingoData &)
// 0x80CADFE	CBingo::resetUserData(BingoData &)
// 0x80CAE12	CBingo::getQuizValue(void)
// 0x80CAE1E	CBingo::getQuizIndex(void)
// 0x80CAE70	CBingo::getBingoRandomVaule(int)
// 0x80CAEC4	CBingo::getTodayBoard(void)

// Function declaration index:
// DECL 0x80CA82C CBingo::CBingo
// DECL 0x80CA8F0 CBingo::~CBingo
// DECL 0x80CA936 CBingo::getToday
// DECL 0x80CA942 CBingo::getToday
// DECL 0x80CA9B8 CBingo::resetBoard
// DECL 0x80CAA64 CBingo::resetQuiz
// DECL 0x80CAAFA CBingo::getIndexTodayBoard
// DECL 0x80CAB5A CBingo::calBoradMatchLine
// DECL 0x80CAD4C CBingo::calNewValue
// DECL 0x80CADD4 CBingo::initUserData
// DECL 0x80CADFE CBingo::resetUserData
// DECL 0x80CAE12 CBingo::getQuizValue
// DECL 0x80CAE1E CBingo::getQuizIndex
// DECL 0x80CAE70 CBingo::getBingoRandomVaule
// DECL 0x80CAEC4 CBingo::getTodayBoard

#endif  // __IDA91_CBINGO_H__
