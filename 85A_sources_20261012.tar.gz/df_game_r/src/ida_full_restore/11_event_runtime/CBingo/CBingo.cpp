#include "CBingo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x80CA82C
// IDA_NAME: _ZN6CBingoC2Ev
// DEMANGLED: CBingo::CBingo(void)
void __cdecl CBingo::CBingo(CBingo *this)
{
  CMTRand *v1; // ebx
  unsigned int v2[7]; // [esp+1Ch] [ebp-1Ch] BYREF

  std::vector<int>::vector((int)this);
  v2[0] = time(0);
  v1 = (CMTRand *)operator new(0x9C8u);
  CMTRand::CMTRand(v1, v2);
  boost::shared_ptr<CMTRand>::shared_ptr<CMTRand>((int)this + 16, v1);
  std::vector<int>::clear(this);
  *((_DWORD *)this + 3) = 0;
  *((_DWORD *)this + 6) = 0;
}

// IDA_EA: 0x80CA8F0
// IDA_NAME: _ZN6CBingoD2Ev
// DEMANGLED: CBingo::~CBingo()
void __cdecl CBingo::~CBingo(CBingo *this)
{
  boost::shared_ptr<CMTRand>::~shared_ptr((char *)this + 16);
  std::vector<int>::~vector(this);
}

// IDA_EA: 0x80CA936
// IDA_NAME: _ZN6CBingo8getTodayEv
// DEMANGLED: CBingo::getToday(void)
int __cdecl CBingo::getToday(CBingo *this)
{
  return *((_DWORD *)this + 6);
}

// IDA_EA: 0x80CA942
// IDA_NAME: _ZN6CBingo8getTodayEli
// DEMANGLED: CBingo::getToday(long,int)
int __cdecl CBingo::getToday(CBingo *this, time_t timer, int tm_hour)
{
  struct tm tp_; // [esp+1Ch] [ebp-6Ch] BYREF
  struct tm tp; // [esp+48h] [ebp-40h] BYREF
  time_t timer_; // [esp+74h] [ebp-14h] BYREF
  struct tm *v7; // [esp+78h] [ebp-10h]
  struct tm *v8; // [esp+7Ch] [ebp-Ch]

  timer_ = timer - 86400;
  v7 = localtime_r(&timer, &tp);
  v8 = localtime_r(&timer_, &tp_);
  if ( v7->tm_hour < 0 || v7->tm_hour >= tm_hour )
    *((_DWORD *)this + 6) = v7->tm_mday;
  else
    *((_DWORD *)this + 6) = v8->tm_mday;
  return *((_DWORD *)this + 6);
}

// IDA_EA: 0x80CA9B8
// IDA_NAME: _ZN6CBingo10resetBoardEi
// DEMANGLED: CBingo::resetBoard(int)
int __cdecl CBingo::resetBoard(CBingo *this)
{
  int v2; // eax
  _BYTE v3[4]; // [esp+18h] [ebp-10h] BYREF
  _BYTE v4[12]; // [esp+1Ch] [ebp-Ch] BYREF

  G_CDataManager();
  std::map<int,std::vector<int>>::find(v3);
  G_CDataManager();
  std::map<int,std::vector<int>>::end(v4);
  if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,std::vector<int>>>::operator==(v3, v4) )
    return 0;
  std::vector<int>::clear(this);
  v2 = std::_Rb_tree_iterator<std::pair<int const,std::vector<int>>>::operator->(v3);
  std::vector<int>::operator=(this, v2 + 4);
  return 1;
}

// IDA_EA: 0x80CAA64
// IDA_NAME: _ZN6CBingo9resetQuizEi
// DEMANGLED: CBingo::resetQuiz(int)
int __cdecl CBingo::resetQuiz(CBingo *this)
{
  int v2; // [esp+18h] [ebp-10h] BYREF
  _DWORD v3[3]; // [esp+1Ch] [ebp-Ch] BYREF

  G_CDataManager();
  std::map<int,int>::find(&v2);
  G_CDataManager();
  std::map<int,int>::end(v3);
  if ( std::_Rb_tree_iterator<std::pair<int const,int>>::operator==(&v2, v3) )
    return 0;
  *((_DWORD *)this + 3) = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v2) + 4);
  return 1;
}

// IDA_EA: 0x80CAAFA
// IDA_NAME: _ZN6CBingo18getIndexTodayBoardEi
// DEMANGLED: CBingo::getIndexTodayBoard(int)
int __cdecl CBingo::getIndexTodayBoard(CBingo *this, int BingoRandomVauleEi)
{
  int i; // [esp+1Ch] [ebp-Ch]

  if ( BingoRandomVauleEi < 0 )
    return -1;
  for ( i = 0; std::vector<int>::size(this) > i; ++i )
  {
    if ( *(_DWORD *)std::vector<int>::operator[](this, i) == BingoRandomVauleEi )
      return i;
  }
  return -1;
}

// IDA_EA: 0x80CAB5A
// IDA_NAME: _ZN6CBingo17calBoradMatchLineEi
// DEMANGLED: CBingo::calBoradMatchLine(int)
int __cdecl CBingo::calBoradMatchLine(CBingo *this, int a2)
{
  char v2; // bl
  char v3; // bl
  char v4; // bl
  char v5; // bl
  int v7; // [esp+8h] [ebp-60h]
  int v8; // [esp+8h] [ebp-60h]
  int v9; // [esp+8h] [ebp-60h]
  int v10; // [esp+8h] [ebp-60h]
  _BYTE v11[4]; // [esp+1Ch] [ebp-4Ch] BYREF
  _BYTE v12[8]; // [esp+20h] [ebp-48h] BYREF
  _BYTE v13[8]; // [esp+28h] [ebp-40h] BYREF
  _BYTE v14[8]; // [esp+30h] [ebp-38h] BYREF
  _BYTE v15[8]; // [esp+38h] [ebp-30h] BYREF
  int v16; // [esp+40h] [ebp-28h]
  int n5; // [esp+44h] [ebp-24h]
  int n5_1; // [esp+48h] [ebp-20h]
  int n5_2; // [esp+4Ch] [ebp-1Ch]
  int n5_3; // [esp+50h] [ebp-18h]
  int n5_4; // [esp+54h] [ebp-14h]
  int n4_1; // [esp+58h] [ebp-10h]
  int n4; // [esp+5Ch] [ebp-Ch]

  v16 = 0;
  n5 = 5;
  std::bitset<25u>::bitset(v11, a2);
  n5_1 = 0;
  n5_2 = 0;
  n5_3 = 0;
  n5_4 = 0;
  for ( n4_1 = 0; n4_1 <= 4; ++n4_1 )
  {
    n5_1 = 0;
    n5_2 = 0;
    for ( n4 = 0; n4 <= 4; ++n4 )
    {
      v7 = n4 + 5 * n4_1;
      std::bitset<25u>::operator[](v12);
      v2 = std::bitset<25u>::reference::operator bool(v12);
      std::bitset<25u>::reference::~reference(v12, v11, v7);
      if ( v2 )
        ++n5_1;
      v8 = n4_1 + 5 * n4;
      std::bitset<25u>::operator[](v13);
      v3 = std::bitset<25u>::reference::operator bool(v13);
      std::bitset<25u>::reference::~reference(v13, v11, v8);
      if ( v3 )
        ++n5_2;
      if ( n4 + 1 > n5_1 && n4 + 1 > n5_2 )
        break;
    }
    if ( n5_1 == 5 )
      ++v16;
    if ( n5_2 == 5 )
      ++v16;
    v9 = 6 * n4_1;
    std::bitset<25u>::operator[](v14);
    v4 = std::bitset<25u>::reference::operator bool(v14);
    std::bitset<25u>::reference::~reference(v14, v11, v9);
    if ( v4 )
      ++n5_3;
    v10 = 4 * (n4_1 + 1);
    std::bitset<25u>::operator[](v15);
    v5 = std::bitset<25u>::reference::operator bool(v15);
    std::bitset<25u>::reference::~reference(v15, v11, v10);
    if ( v5 )
      ++n5_4;
  }
  if ( n5_3 == 5 )
    ++v16;
  if ( n5_4 == 5 )
    ++v16;
  return v16;
}

// IDA_EA: 0x80CAD4C
// IDA_NAME: _ZN6CBingo11calNewValueERji
// DEMANGLED: CBingo::calNewValue(unsigned int &,int)
int __cdecl CBingo::calNewValue(CBingo *this, unsigned int *BingoDataEv, int BingoRandomVauleEi)
{
  int IndexTodayBoardEi; // [esp+1Ch] [ebp-Ch]

  IndexTodayBoardEi = CBingo::getIndexTodayBoard(this, BingoRandomVauleEi);
  if ( IndexTodayBoardEi == -1 )
    return 0;
  if ( IndexTodayBoardEi > 24 )
    return -1;
  if ( (unsigned __int8)isSetBit_Uint(*BingoDataEv, IndexTodayBoardEi) == 1 )
    return 0;
  setBit_Uint(BingoDataEv, 1, IndexTodayBoardEi);
  return CBingo::calBoradMatchLine(this, *BingoDataEv);
}

// IDA_EA: 0x80CADD4
// IDA_NAME: _ZN6CBingo12initUserDataER9BingoData
// DEMANGLED: CBingo::initUserData(BingoData &)
int __cdecl CBingo::initUserData(CBingo *this, BingoData *BingoDataEv)
{
  *((_BYTE *)BingoDataEv + 4) = CBingo::calBoradMatchLine(this, *(_DWORD *)BingoDataEv);
  return 1;
}

// IDA_EA: 0x80CADFE
// IDA_NAME: _ZN6CBingo13resetUserDataER9BingoData
// DEMANGLED: CBingo::resetUserData(BingoData &)
int __cdecl CBingo::resetUserData(CBingo *this, BingoData *a2)
{
  return BingoData::clear(a2);
}

// IDA_EA: 0x80CAE12
// IDA_NAME: _ZN6CBingo12getQuizValueEv
// DEMANGLED: CBingo::getQuizValue(void)
int __cdecl CBingo::getQuizValue(CBingo *this)
{
  return *((_DWORD *)this + 3);
}

// IDA_EA: 0x80CAE1E
// IDA_NAME: _ZN6CBingo12getQuizIndexEv
// DEMANGLED: CBingo::getQuizIndex(void)
int __cdecl CBingo::getQuizIndex(CBingo *this)
{
  int i; // [esp+1Ch] [ebp-Ch]

  for ( i = 0; std::vector<int>::size(this) > i; ++i )
  {
    if ( !*(_DWORD *)std::vector<int>::operator[](this, i) )
      return i;
  }
  return -1;
}

// IDA_EA: 0x80CAE70
// IDA_NAME: _ZN6CBingo19getBingoRandomVauleEi
// DEMANGLED: CBingo::getBingoRandomVaule(int)
int __cdecl CBingo::getBingoRandomVaule(CBingo *this, int a2)
{
  CMTRand *v2; // eax
  unsigned int n9; // [esp+18h] [ebp-10h] BYREF
  int n50; // [esp+1Ch] [ebp-Ch]

  n9 = 9;
  v2 = (CMTRand *)boost::shared_ptr<CMTRand>::operator->((char *)this + 16);
  n50 = a2 + CMTRand::randInt(v2, &n9) - 9;
  if ( n50 <= 0 || n50 > 50 )
    return 0;
  else
    return n50;
}

// IDA_EA: 0x80CAEC4
// IDA_NAME: _ZN6CBingo13getTodayBoardEv
// DEMANGLED: CBingo::getTodayBoard(void)
CBingo *__cdecl CBingo::getTodayBoard(CBingo *this)
{
  return this;
}
