#ifndef __IDA91_INTERCHECKSTAYTIMEEVENT_H__
#define __IDA91_INTERCHECKSTAYTIMEEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: InterCheckStayTimeEvent
// Source unit: InterCheckStayTimeEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 1336

/* 1336 */
struct InterCheckStayTimeEvent;

// Exported member functions:
// 0x8160A42	InterCheckStayTimeEvent::dispatch_sig(CUser *,char *,int)
// 0x8161FA8	InterCheckStayTimeEvent::InterCheckStayTimeEvent(void)
// 0x8161FCC	InterCheckStayTimeEvent::~InterCheckStayTimeEvent()
// 0x8161FFC	InterCheckStayTimeEvent::~InterCheckStayTimeEvent()

// Function declaration index:
// DECL 0x8160A42 InterCheckStayTimeEvent::dispatch_sig
// DECL 0x8161FA8 InterCheckStayTimeEvent::InterCheckStayTimeEvent
// DECL 0x8161FCC InterCheckStayTimeEvent::~InterCheckStayTimeEvent
// DECL 0x8161FFC InterCheckStayTimeEvent::~InterCheckStayTimeEvent

#endif  // __IDA91_INTERCHECKSTAYTIMEEVENT_H__
