#include "InterCheckStayTimeEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8160A42
// IDA_NAME: _ZN23InterCheckStayTimeEvent12dispatch_sigEP5CUserPci
// DEMANGLED: InterCheckStayTimeEvent::dispatch_sig(CUser *,char *,int)
int __cdecl InterCheckStayTimeEvent::dispatch_sig(InterCheckStayTimeEvent *this, CUser *a2, char *a3)
{
  int RepeatEvent; // eax
  CItemList **v5; // eax
  int ServerGroup; // ebx
  size_t v7; // esi
  int CurCharacNoEv; // eax
  char v9; // [esp+8h] [ebp-A0h]
  _BYTE v10[2]; // [esp+33h] [ebp-75h] BYREF
  int indexEv; // [esp+35h] [ebp-73h]
  int v12[4]; // [esp+70h] [ebp-38h] BYREF
  int v13[5]; // [esp+80h] [ebp-28h] BYREF
  CItem *item; // [esp+94h] [ebp-14h]
  char *src; // [esp+98h] [ebp-10h]
  char *s; // [esp+9Ch] [ebp-Ch]

  v13[4] = (int)a3;
  if ( a3 )
  {
    RepeatEvent = CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 159);
    if ( (*(unsigned __int8 (__cdecl **)(int, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) == 1 )
    {
      v5 = (CItemList **)G_CDataManager();
      item = (CItem *)CDataManager::find_item(v5, *(unsigned int *)CEventStayTime::kRewardItem_);
      if ( item )
      {
        Inven_Item::Inven_Item((Inven_Item *)v10);
        indexEv = CItem::get_index(item);
        (*(void (__cdecl **)(CItem *, _BYTE *))(*(_DWORD *)item + 8))(item, v10);
        Inven_Item::set_add_info((Inven_Item *)v10, 1);
        src = (char *)RDARScriptStringManager::findString(
                        (RDARScriptStringManager *)&g_scriptStringManager_,
                        4,
                        "tw_ccb_stress_title_01",
                        0);
        s = (char *)RDARScriptStringManager::findString(
                      (RDARScriptStringManager *)&g_scriptStringManager_,
                      4,
                      "tw_ccb_stress_mail_01",
                      0);
        ServerGroup = CUser::GetServerGroup(a2);
        v7 = strlen(s);
        CurCharacNoEv = CUserCharacInfo::getCurCharacNo(a2);
        WongWork::CMailBoxHelper::ReqDBSendNewSystemMail(
          src,
          (Inven_Item *)v10,
          0,
          CurCharacNoEv,
          s,
          v7,
          14,
          ServerGroup,
          0,
          0);
      }
      else
      {
        cMyTrace::cMyTrace(
          (cMyTrace *)v13,
          "virtual int InterCheckStayTimeEvent::dispatch_sig(CUser*, char*, int)",
          211,
          5);
        cMyTrace::operator()((int)v13, "[Taiwan, StayEvent] Invalid item index. (%u)", CEventStayTime::kRewardItem_[0]);
      }
      return 0;
    }
    else
    {
      return 0;
    }
  }
  else
  {
    cMyTrace::cMyTrace((cMyTrace *)v12, "virtual int InterCheckStayTimeEvent::dispatch_sig(CUser*, char*, int)", 201, 5);
    cMyTrace::operator()((int)v12, "[Taiwan, StayEvent] SigStayTimeEvent is null.", v9);
    return 202;
  }
}

// IDA_EA: 0x8161FA8
// IDA_NAME: _ZN23InterCheckStayTimeEventC2Ev
// DEMANGLED: InterCheckStayTimeEvent::InterCheckStayTimeEvent(void)
void __cdecl InterCheckStayTimeEvent::InterCheckStayTimeEvent(InterCheckStayTimeEvent *this)
{
  TaiwanInterfaceInterDispatcher::TaiwanInterfaceInterDispatcher(this, 5);
  *(_DWORD *)this = off_8B7ACC0;
}

// IDA_EA: 0x8161FCC
// IDA_NAME: _ZN23InterCheckStayTimeEventD2Ev
// DEMANGLED: InterCheckStayTimeEvent::~InterCheckStayTimeEvent()
void __cdecl InterCheckStayTimeEvent::~InterCheckStayTimeEvent(InterCheckStayTimeEvent *this)
{
  *(_DWORD *)this = off_8B7ACC0;
  TaiwanInterfaceInterDispatcher::~TaiwanInterfaceInterDispatcher(this);
}

// IDA_EA: 0x8161FFC
// IDA_NAME: _ZN23InterCheckStayTimeEventD0Ev
// DEMANGLED: InterCheckStayTimeEvent::~InterCheckStayTimeEvent()
void __cdecl InterCheckStayTimeEvent::~InterCheckStayTimeEvent(InterCheckStayTimeEvent *this)
{
  InterCheckStayTimeEvent::~InterCheckStayTimeEvent(this);
  operator delete(this);
}
