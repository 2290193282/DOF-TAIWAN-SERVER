#ifndef __IDA91_DB_UPDATEINGAMEEVENTHISTORY_H__
#define __IDA91_DB_UPDATEINGAMEEVENTHISTORY_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_UpdateInGameEventHistory
// Source unit: DB_UpdateInGameEventHistory
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2687

/* 2687 */
struct DB_UpdateInGameEventHistory;

// Exported member functions:
// 0x8444972	DB_UpdateInGameEventHistory::dispatch(int,int,Stream *)
// 0x8444AC4	DB_UpdateInGameEventHistory::makeRequest(unsigned int,int,int,int)
// 0x844F9EE	DB_UpdateInGameEventHistory::DB_UpdateInGameEventHistory(void)
// 0x845B65C	DB_UpdateInGameEventHistory::~DB_UpdateInGameEventHistory()
// 0x845B68C	DB_UpdateInGameEventHistory::~DB_UpdateInGameEventHistory()

// Function declaration index:
// DECL 0x8444972 DB_UpdateInGameEventHistory::dispatch
// DECL 0x8444AC4 DB_UpdateInGameEventHistory::makeRequest
// DECL 0x844F9EE DB_UpdateInGameEventHistory::DB_UpdateInGameEventHistory
// DECL 0x845B65C DB_UpdateInGameEventHistory::~DB_UpdateInGameEventHistory
// DECL 0x845B68C DB_UpdateInGameEventHistory::~DB_UpdateInGameEventHistory

#endif  // __IDA91_DB_UPDATEINGAMEEVENTHISTORY_H__
