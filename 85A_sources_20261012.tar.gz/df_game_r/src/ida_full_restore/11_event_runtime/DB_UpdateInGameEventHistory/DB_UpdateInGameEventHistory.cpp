#include "DB_UpdateInGameEventHistory.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8444972
// IDA_NAME: _ZN27DB_UpdateInGameEventHistory8dispatchEiiP6Stream
// DEMANGLED: DB_UpdateInGameEventHistory::dispatch(int,int,Stream *)
int __cdecl DB_UpdateInGameEventHistory::dispatch(DB_UpdateInGameEventHistory *this, int a2, int a3, Stream *a4)
{
  int dest_1; // ebx
  const char *v5; // eax
  __int64 v6; // rax
  int v8; // edi
  int v9; // esi
  int dest_2; // ebx
  const char *v11; // eax
  int v13; // [esp+2Ch] [ebp-2Ch] BYREF
  int v14; // [esp+30h] [ebp-28h] BYREF
  int dest; // [esp+34h] [ebp-24h] BYREF
  unsigned int v16; // [esp+38h] [ebp-20h] BYREF
  MySQL *DBHandle; // [esp+3Ch] [ebp-1Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 9, 0);
  v16 = 0;
  Stream::operator>>(a4, (int)&v16);
  Stream::operator>>(a4, &dest);
  Stream::operator>>(a4, (int)&v14);
  Stream::operator>>(a4, (int)&v13);
  dest_1 = dest;
  v5 = (const char *)NumberToString(v16, 0);
  MySQL::set_query(
    DBHandle,
    "upDate event_ingame_history set history_1 = %u,history_2 = %u where m_id=%s and type = %d",
    v14,
    v13,
    v5,
    dest_1);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 || (LODWORD(v6) = MySQL::getAffectedRowCount(DBHandle), !v6) )
  {
    v8 = v13;
    v9 = v14;
    dest_2 = dest;
    v11 = (const char *)NumberToString(v16, 0);
    MySQL::set_query(
      DBHandle,
      "inSert into event_ingame_history(m_id,type,history_1,history_2) values(%s,%d,%d,%d)",
      v11,
      dest_2,
      v9,
      v8);
    MySQL::exec(DBHandle, 1);
  }
  return 1;
}

// IDA_EA: 0x8444AC4
// IDA_NAME: _ZN27DB_UpdateInGameEventHistory11makeRequestEjiii
// DEMANGLED: DB_UpdateInGameEventHistory::makeRequest(unsigned int,int,int,int)
void __cdecl DB_UpdateInGameEventHistory::makeRequest(
        DB_UpdateInGameEventHistory *this,
        char src,
        char src_1,
        char src_2)
{
  Stream *v4; // eax
  Stream **v5; // eax
  Stream **v6; // eax
  Stream **v7; // eax
  Stream **v8; // eax
  Stream **v9; // eax
  Stream **v10; // eax
  _BYTE v11[16]; // [esp+18h] [ebp-10h] BYREF

  v4 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 43944);
  CStreamGuard::CStreamGuard((CStreamGuard *)v11, v4, 1);
  v5 = (Stream **)CStreamGuard::operator*((int)v11);
  CStreamGuard::operator<<(v5, 173);
  v6 = (Stream **)CStreamGuard::operator*((int)v11);
  CStreamGuard::operator<<(v6, -1);
  v7 = (Stream **)CStreamGuard::operator*((int)v11);
  CStreamGuard::operator<<(v7, (char)this);
  v8 = (Stream **)CStreamGuard::operator*((int)v11);
  CStreamGuard::operator<<(v8, src);
  v9 = (Stream **)CStreamGuard::operator*((int)v11);
  CStreamGuard::operator<<(v9, src_1);
  v10 = (Stream **)CStreamGuard::operator*((int)v11);
  CStreamGuard::operator<<(v10, src_2);
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v11);
  CStreamGuard::~CStreamGuard((CStreamGuard *)v11);
}

// IDA_EA: 0x844F9EE
// IDA_NAME: _ZN27DB_UpdateInGameEventHistoryC2Ev
// DEMANGLED: DB_UpdateInGameEventHistory::DB_UpdateInGameEventHistory(void)
void __cdecl DB_UpdateInGameEventHistory::DB_UpdateInGameEventHistory(DB_UpdateInGameEventHistory *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5E388;
}

// IDA_EA: 0x845B65C
// IDA_NAME: _ZN27DB_UpdateInGameEventHistoryD2Ev
// DEMANGLED: DB_UpdateInGameEventHistory::~DB_UpdateInGameEventHistory()
void __cdecl DB_UpdateInGameEventHistory::~DB_UpdateInGameEventHistory(DB_UpdateInGameEventHistory *this)
{
  *(_DWORD *)this = &off_8C5E388;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845B68C
// IDA_NAME: _ZN27DB_UpdateInGameEventHistoryD0Ev
// DEMANGLED: DB_UpdateInGameEventHistory::~DB_UpdateInGameEventHistory()
void __cdecl DB_UpdateInGameEventHistory::~DB_UpdateInGameEventHistory(DB_UpdateInGameEventHistory *this)
{
  DB_UpdateInGameEventHistory::~DB_UpdateInGameEventHistory(this);
  operator delete(this);
}
