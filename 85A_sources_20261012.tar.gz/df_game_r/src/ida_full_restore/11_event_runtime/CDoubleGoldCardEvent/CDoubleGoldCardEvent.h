#ifndef __IDA91_CDOUBLEGOLDCARDEVENT_H__
#define __IDA91_CDOUBLEGOLDCARDEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CDoubleGoldCardEvent
// Source unit: CDoubleGoldCardEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4110

/* 4110 */
struct CDoubleGoldCardEvent;

// Exported member functions:
// 0x811C30A	CDoubleGoldCardEvent::CDoubleGoldCardEvent(void)
// 0x811C326	CDoubleGoldCardEvent::~CDoubleGoldCardEvent()
// 0x811C356	CDoubleGoldCardEvent::~CDoubleGoldCardEvent()
// 0x811C374	CDoubleGoldCardEvent::StartEvent(void)
// 0x811C3C6	CDoubleGoldCardEvent::StartEvent(Word_Param)
// 0x811C3E0	CDoubleGoldCardEvent::EndEvent(void)

// Function declaration index:
// DECL 0x811C30A CDoubleGoldCardEvent::CDoubleGoldCardEvent
// DECL 0x811C326 CDoubleGoldCardEvent::~CDoubleGoldCardEvent
// DECL 0x811C356 CDoubleGoldCardEvent::~CDoubleGoldCardEvent
// DECL 0x811C374 CDoubleGoldCardEvent::StartEvent
// DECL 0x811C3C6 CDoubleGoldCardEvent::StartEvent
// DECL 0x811C3E0 CDoubleGoldCardEvent::EndEvent

#endif  // __IDA91_CDOUBLEGOLDCARDEVENT_H__
