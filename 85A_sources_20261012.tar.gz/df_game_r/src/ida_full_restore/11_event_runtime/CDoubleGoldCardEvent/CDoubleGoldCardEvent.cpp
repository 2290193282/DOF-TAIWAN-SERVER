#include "CDoubleGoldCardEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x811C30A
// IDA_NAME: _ZN20CDoubleGoldCardEventC2Ev
// DEMANGLED: CDoubleGoldCardEvent::CDoubleGoldCardEvent(void)
void __cdecl CDoubleGoldCardEvent::CDoubleGoldCardEvent(CDoubleGoldCardEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B520C8;
}

// IDA_EA: 0x811C326
// IDA_NAME: _ZN20CDoubleGoldCardEventD2Ev
// DEMANGLED: CDoubleGoldCardEvent::~CDoubleGoldCardEvent()
void __cdecl CDoubleGoldCardEvent::~CDoubleGoldCardEvent(CDoubleGoldCardEvent *this)
{
  *(_DWORD *)this = off_8B520C8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x811C356
// IDA_NAME: _ZN20CDoubleGoldCardEventD0Ev
// DEMANGLED: CDoubleGoldCardEvent::~CDoubleGoldCardEvent()
void __cdecl CDoubleGoldCardEvent::~CDoubleGoldCardEvent(CDoubleGoldCardEvent *this)
{
  CDoubleGoldCardEvent::~CDoubleGoldCardEvent(this);
  operator delete(this);
}

// IDA_EA: 0x811C374
// IDA_NAME: _ZN20CDoubleGoldCardEvent10StartEventEv
// DEMANGLED: CDoubleGoldCardEvent::StartEvent(void)
int __cdecl CDoubleGoldCardEvent::StartEvent(CDoubleGoldCardEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CDoubleGoldCardEvent::StartEvent()", 16, 0);
  return cMyTrace::operator()((int)v3, "CDoubleGoldCardEvent Event Start!", v2);
}

// IDA_EA: 0x811C3C6
// IDA_NAME: _ZN20CDoubleGoldCardEvent10StartEventE10Word_Param
// DEMANGLED: CDoubleGoldCardEvent::StartEvent(Word_Param)
int __cdecl CDoubleGoldCardEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x811C3E0
// IDA_NAME: _ZN20CDoubleGoldCardEvent8EndEventEv
// DEMANGLED: CDoubleGoldCardEvent::EndEvent(void)
int __cdecl CDoubleGoldCardEvent::EndEvent(CDoubleGoldCardEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CDoubleGoldCardEvent::EndEvent()", 26, 0);
  return cMyTrace::operator()((int)v3, "CDoubleGoldCardEvent Event End!", v2);
}
