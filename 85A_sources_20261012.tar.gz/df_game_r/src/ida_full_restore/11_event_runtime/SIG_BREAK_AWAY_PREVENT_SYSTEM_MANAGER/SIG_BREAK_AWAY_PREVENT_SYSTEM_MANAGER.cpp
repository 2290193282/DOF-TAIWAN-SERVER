#include "SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x831D2B0
// IDA_NAME: _ZN37SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGERC2Ev
// DEMANGLED: SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER::SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER(void)
void __cdecl SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER::SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER(
        SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER *this)
{
  SIG_BREAK_AWAY_PREVENT_REWARD_MANAGER *v1; // ebx
  int n29; // esi

  v1 = (SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER *)((char *)this + 16);
  for ( n29 = 29; n29 != -1; --n29 )
  {
    SIG_BREAK_AWAY_PREVENT_REWARD_MANAGER::SIG_BREAK_AWAY_PREVENT_REWARD_MANAGER(v1);
    v1 = (SIG_BREAK_AWAY_PREVENT_REWARD_MANAGER *)((char *)v1 + 24);
  }
  *(_WORD *)this = 0;
  *((_WORD *)this + 1) = 0;
  *((_WORD *)this + 2) = 0;
  *((_WORD *)this + 3) = 0;
  *((_WORD *)this + 4) = 0;
  *((_WORD *)this + 5) = 0;
  *((_WORD *)this + 6) = 0;
  *((_BYTE *)this + 14) = 0;
  *((_DWORD *)this + 184) = 0;
}
