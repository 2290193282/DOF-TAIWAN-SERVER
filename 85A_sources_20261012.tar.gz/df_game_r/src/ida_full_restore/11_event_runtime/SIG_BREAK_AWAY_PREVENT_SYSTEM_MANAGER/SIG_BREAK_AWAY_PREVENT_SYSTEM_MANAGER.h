#ifndef __IDA91_SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER_H__
#define __IDA91_SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER
// Source unit: SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2324

/* 2324 */
struct SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER;

// Exported member functions:
// 0x831D2B0	SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER::SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER(void)

// Function declaration index:
// DECL 0x831D2B0 SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER::SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER

#endif  // __IDA91_SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER_H__
