#ifndef __IDA91_MSG_BINGO_QUIZ_H__
#define __IDA91_MSG_BINGO_QUIZ_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: MSG_BINGO_QUIZ
// Source unit: MSG_BINGO_QUIZ
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2092

/* 2092 */
struct MSG_BINGO_QUIZ;

// Exported member functions:
// 0x8260386	MSG_BINGO_QUIZ::MSG_BINGO_QUIZ(void)

// Function declaration index:
// DECL 0x8260386 MSG_BINGO_QUIZ::MSG_BINGO_QUIZ

#endif  // __IDA91_MSG_BINGO_QUIZ_H__
