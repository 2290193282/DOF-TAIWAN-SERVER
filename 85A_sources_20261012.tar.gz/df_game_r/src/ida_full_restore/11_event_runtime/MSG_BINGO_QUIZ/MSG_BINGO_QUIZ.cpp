#include "MSG_BINGO_QUIZ.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8260386
// IDA_NAME: _ZN14MSG_BINGO_QUIZC2Ev
// DEMANGLED: MSG_BINGO_QUIZ::MSG_BINGO_QUIZ(void)
void __cdecl MSG_BINGO_QUIZ::MSG_BINGO_QUIZ(MSG_BINGO_QUIZ *this)
{
  MSG_BASE::MSG_BASE(this);
  *(_DWORD *)((char *)this + 13) = 0;
}
