#ifndef __IDA91_STUNLIMITCHALLENGEREWARDINFO_H__
#define __IDA91_STUNLIMITCHALLENGEREWARDINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stUnlimitChallengeRewardInfo
// Source unit: stUnlimitChallengeRewardInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3922

/* 3922 */
struct stUnlimitChallengeRewardInfo;

// Exported member functions:
// 0x893E3B6	stUnlimitChallengeRewardInfo::~stUnlimitChallengeRewardInfo()

// Function declaration index:
// DECL 0x893E3B6 stUnlimitChallengeRewardInfo::~stUnlimitChallengeRewardInfo

#endif  // __IDA91_STUNLIMITCHALLENGEREWARDINFO_H__
