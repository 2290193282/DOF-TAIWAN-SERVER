#include "stUnlimitChallengeRewardInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x893E3B6
// IDA_NAME: _ZN28stUnlimitChallengeRewardInfoD2Ev
// DEMANGLED: stUnlimitChallengeRewardInfo::~stUnlimitChallengeRewardInfo()
void stUnlimitChallengeRewardInfo::~stUnlimitChallengeRewardInfo()
{
  ;
}
