#ifndef __IDA91_DB_SAVECONDITIONEVENTINFO_H__
#define __IDA91_DB_SAVECONDITIONEVENTINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_SaveConditionEventInfo
// Source unit: DB_SaveConditionEventInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
// Local type ordinals: 2605

/* 2605 */
struct DB_SaveConditionEventInfo;

// Exported member functions:
// 0x8437930	DB_SaveConditionEventInfo::dispatch(int,int,Stream *)
// 0x844F0DA	DB_SaveConditionEventInfo::DB_SaveConditionEventInfo(void)
// 0x845D090	DB_SaveConditionEventInfo::~DB_SaveConditionEventInfo()
// 0x845D0C0	DB_SaveConditionEventInfo::~DB_SaveConditionEventInfo()

// Function declaration index:
// DECL 0x8437930 DB_SaveConditionEventInfo::dispatch
// DECL 0x844F0DA DB_SaveConditionEventInfo::DB_SaveConditionEventInfo
// DECL 0x845D090 DB_SaveConditionEventInfo::~DB_SaveConditionEventInfo
// DECL 0x845D0C0 DB_SaveConditionEventInfo::~DB_SaveConditionEventInfo

#endif  // __IDA91_DB_SAVECONDITIONEVENTINFO_H__
