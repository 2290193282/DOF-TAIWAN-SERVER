#include "DB_SaveConditionEventInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8437930
// IDA_NAME: _ZN25DB_SaveConditionEventInfo8dispatchEiiP6Stream
// DEMANGLED: DB_SaveConditionEventInfo::dispatch(int,int,Stream *)
_BOOL4 __cdecl DB_SaveConditionEventInfo::dispatch(DB_SaveConditionEventInfo *this, int a2, int a3, Stream *a4)
{
  _BOOL4 result; // eax
  __int64 v5; // rax
  MySQL *DBHandle; // [esp+28h] [ebp-10h]
  int Out; // [esp+2Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 2, 0);
  Out = Stream::GetOutBuffer<SIG_SAVE_CONDITION_EVENT>(a4);
  MySQL::set_query(
    DBHandle,
    "upDate event_conditionable_info set current_step=%d, reward_step=%d, update_time=now() where charac_no=%u",
    *(__int16 *)(Out + 4),
    *(__int16 *)(Out + 6),
    *(_DWORD *)Out);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
    return 0;
  LODWORD(v5) = MySQL::getAffectedRowCount(DBHandle);
  result = 1;
  if ( !v5 )
  {
    MySQL::set_query(
      DBHandle,
      "inSert into event_conditionable_info(charac_no, current_step, reward_step, update_time) values(%u, %d, %d, now())",
      *(_DWORD *)Out,
      *(__int16 *)(Out + 4),
      *(__int16 *)(Out + 6));
    if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
      return 0;
  }
  return result;
}

// IDA_EA: 0x844F0DA
// IDA_NAME: _ZN25DB_SaveConditionEventInfoC2Ev
// DEMANGLED: DB_SaveConditionEventInfo::DB_SaveConditionEventInfo(void)
void __cdecl DB_SaveConditionEventInfo::DB_SaveConditionEventInfo(DB_SaveConditionEventInfo *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5EB98;
}

// IDA_EA: 0x845D090
// IDA_NAME: _ZN25DB_SaveConditionEventInfoD2Ev
// DEMANGLED: DB_SaveConditionEventInfo::~DB_SaveConditionEventInfo()
void __cdecl DB_SaveConditionEventInfo::~DB_SaveConditionEventInfo(DB_SaveConditionEventInfo *this)
{
  *(_DWORD *)this = &off_8C5EB98;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845D0C0
// IDA_NAME: _ZN25DB_SaveConditionEventInfoD0Ev
// DEMANGLED: DB_SaveConditionEventInfo::~DB_SaveConditionEventInfo()
void __cdecl DB_SaveConditionEventInfo::~DB_SaveConditionEventInfo(DB_SaveConditionEventInfo *this)
{
  DB_SaveConditionEventInfo::~DB_SaveConditionEventInfo(this);
  operator delete(this);
}
