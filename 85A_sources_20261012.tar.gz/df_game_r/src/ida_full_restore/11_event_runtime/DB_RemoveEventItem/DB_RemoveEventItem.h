#ifndef __IDA91_DB_REMOVEEVENTITEM_H__
#define __IDA91_DB_REMOVEEVENTITEM_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_RemoveEventItem
// Source unit: DB_RemoveEventItem
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 2450

/* 2450 */
struct DB_RemoveEventItem;

// Exported member functions:
// 0x841AB30	DB_RemoveEventItem::dispatch(int,int,Stream *)
// 0x844DB42	DB_RemoveEventItem::DB_RemoveEventItem(void)
// 0x844DB5E	DB_RemoveEventItem::~DB_RemoveEventItem()
// 0x844DB8E	DB_RemoveEventItem::~DB_RemoveEventItem()

// Function declaration index:
// DECL 0x841AB30 DB_RemoveEventItem::dispatch
// DECL 0x844DB42 DB_RemoveEventItem::DB_RemoveEventItem
// DECL 0x844DB5E DB_RemoveEventItem::~DB_RemoveEventItem
// DECL 0x844DB8E DB_RemoveEventItem::~DB_RemoveEventItem

#endif  // __IDA91_DB_REMOVEEVENTITEM_H__
