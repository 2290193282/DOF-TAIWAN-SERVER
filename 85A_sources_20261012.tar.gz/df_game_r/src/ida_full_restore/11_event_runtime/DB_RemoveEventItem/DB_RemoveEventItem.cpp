#include "DB_RemoveEventItem.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x841AB30
// IDA_NAME: _ZN18DB_RemoveEventItem8dispatchEiiP6Stream
// DEMANGLED: DB_RemoveEventItem::dispatch(int,int,Stream *)
int __cdecl DB_RemoveEventItem::dispatch(DB_RemoveEventItem *this, int a2, int a3, Stream *a4)
{
  MySQL *DBHandle; // [esp+14h] [ebp-14h]
  _DWORD *Out; // [esp+18h] [ebp-10h]
  int i; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 3, 0);
  Out = (_DWORD *)Stream::GetOutBuffer<SIG_REMOVE_EVENTITEM>(a4);
  for ( i = 0; *Out > i; ++i )
  {
    MySQL::set_query(DBHandle, "upDate charac_event_items set delete_flag=1,delete_time=now() where id=%u", Out[i + 1]);
    MySQL::exec(DBHandle, 1);
  }
  return 1;
}

// IDA_EA: 0x844DB42
// IDA_NAME: _ZN18DB_RemoveEventItemC2Ev
// DEMANGLED: DB_RemoveEventItem::DB_RemoveEventItem(void)
void __cdecl DB_RemoveEventItem::DB_RemoveEventItem(DB_RemoveEventItem *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5F8E8;
}

// IDA_EA: 0x844DB5E
// IDA_NAME: _ZN18DB_RemoveEventItemD2Ev
// DEMANGLED: DB_RemoveEventItem::~DB_RemoveEventItem()
void __cdecl DB_RemoveEventItem::~DB_RemoveEventItem(DB_RemoveEventItem *this)
{
  *(_DWORD *)this = &off_8C5F8E8;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x844DB8E
// IDA_NAME: _ZN18DB_RemoveEventItemD0Ev
// DEMANGLED: DB_RemoveEventItem::~DB_RemoveEventItem()
void __cdecl DB_RemoveEventItem::~DB_RemoveEventItem(DB_RemoveEventItem *this)
{
  DB_RemoveEventItem::~DB_RemoveEventItem(this);
  operator delete(this);
}
