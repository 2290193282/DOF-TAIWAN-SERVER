#ifndef __IDA91_STCONDITIONEVENTREWARDINFO_H__
#define __IDA91_STCONDITIONEVENTREWARDINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stConditionEventRewardInfo
// Source unit: stConditionEventRewardInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2344

/* 2344 */
struct stConditionEventRewardInfo;

// Exported member functions:
// 0x83367BC	stConditionEventRewardInfo::~stConditionEventRewardInfo()
// 0x891B682	stConditionEventRewardInfo::stConditionEventRewardInfo(void)

// Function declaration index:
// DECL 0x83367BC stConditionEventRewardInfo::~stConditionEventRewardInfo
// DECL 0x891B682 stConditionEventRewardInfo::stConditionEventRewardInfo

#endif  // __IDA91_STCONDITIONEVENTREWARDINFO_H__
