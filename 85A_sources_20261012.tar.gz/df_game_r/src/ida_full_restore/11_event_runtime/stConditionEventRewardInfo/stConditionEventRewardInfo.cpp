#include "stConditionEventRewardInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x83367BC
// IDA_NAME: _ZN26stConditionEventRewardInfoD2Ev
// DEMANGLED: stConditionEventRewardInfo::~stConditionEventRewardInfo()
void stConditionEventRewardInfo::~stConditionEventRewardInfo()
{
  ;
}

// IDA_EA: 0x891B682
// IDA_NAME: _ZN26stConditionEventRewardInfoC2Ev
// DEMANGLED: stConditionEventRewardInfo::stConditionEventRewardInfo(void)
void __cdecl stConditionEventRewardInfo::stConditionEventRewardInfo(stConditionEventRewardInfo *this)
{
  *(_DWORD *)this = -1;
  *((_DWORD *)this + 1) = 0;
  *((_BYTE *)this + 8) = 0;
  *((_BYTE *)this + 9) = 0;
}
