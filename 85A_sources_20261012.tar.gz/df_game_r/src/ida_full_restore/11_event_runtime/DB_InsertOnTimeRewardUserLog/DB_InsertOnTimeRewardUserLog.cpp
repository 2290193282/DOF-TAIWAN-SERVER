#include "DB_InsertOnTimeRewardUserLog.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8442A56
// IDA_NAME: _ZN28DB_InsertOnTimeRewardUserLog8dispatchEiiP6Stream
// DEMANGLED: DB_InsertOnTimeRewardUserLog::dispatch(int,int,Stream *)
int __cdecl DB_InsertOnTimeRewardUserLog::dispatch(DB_InsertOnTimeRewardUserLog *this, int a2, int a3, Stream *a4)
{
  int dest_1; // ebx
  const char *v5; // eax
  int dest; // [esp+20h] [ebp-28h] BYREF
  unsigned int v8; // [esp+24h] [ebp-24h] BYREF
  int v9[4]; // [esp+28h] [ebp-20h] BYREF
  MySQL *DBHandle; // [esp+38h] [ebp-10h]
  char v11[4]; // [esp+3Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 13, 0);
  v8 = 0;
  dest = 0;
  Stream::operator>>(a4, (int)&v8);
  Stream::operator>>(a4, &dest);
  *(_DWORD *)v11 = "1112";
  dest_1 = dest;
  v5 = (const char *)NumberToString(v8, 0);
  MySQL::set_query(
    DBHandle,
    "inSert into event_%s_ontime_reward_user(m_id,recv_no) values(%s,%u)",
    *(const char **)v11,
    v5,
    dest_1);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) == 1 )
    return 1;
  NumberToString(v8, 0);
  cMyTrace::cMyTrace((cMyTrace *)v9, "virtual bool DB_InsertOnTimeRewardUserLog::dispatch(int, int, Stream*)", 42041, 5);
  cMyTrace::operator()((int)v9, "inSert into event_%s_ontime_reward_user(m_id,recv_no) failed at m_id(%s,%u) ", v11[0]);
  return 0;
}

// IDA_EA: 0x8442B7A
// IDA_NAME: _ZN28DB_InsertOnTimeRewardUserLog11makeRequestEiji
// DEMANGLED: DB_InsertOnTimeRewardUserLog::makeRequest(int,unsigned int,int)
void __cdecl DB_InsertOnTimeRewardUserLog::makeRequest(
        DB_InsertOnTimeRewardUserLog *this,
        char src,
        char ontime_reward_item_countEv)
{
  Stream *v3; // eax
  Stream **v4; // eax
  Stream **v5; // eax
  Stream **v6; // eax
  Stream **v7; // eax
  _BYTE v8[16]; // [esp+18h] [ebp-10h] BYREF

  v3 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 42053);
  CStreamGuard::CStreamGuard((CStreamGuard *)v8, v3, 1);
  v4 = (Stream **)CStreamGuard::operator*((int)v8);
  CStreamGuard::operator<<(v4, 152);
  v5 = (Stream **)CStreamGuard::operator*((int)v8);
  CStreamGuard::operator<<(v5, (char)this);
  v6 = (Stream **)CStreamGuard::operator*((int)v8);
  CStreamGuard::operator<<(v6, src);
  v7 = (Stream **)CStreamGuard::operator*((int)v8);
  CStreamGuard::operator<<(v7, ontime_reward_item_countEv);
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v8);
  CStreamGuard::~CStreamGuard((CStreamGuard *)v8);
}

// IDA_EA: 0x844F962
// IDA_NAME: _ZN28DB_InsertOnTimeRewardUserLogC2Ev
// DEMANGLED: DB_InsertOnTimeRewardUserLog::DB_InsertOnTimeRewardUserLog(void)
void __cdecl DB_InsertOnTimeRewardUserLog::DB_InsertOnTimeRewardUserLog(DB_InsertOnTimeRewardUserLog *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5E478;
}

// IDA_EA: 0x845B968
// IDA_NAME: _ZN28DB_InsertOnTimeRewardUserLogD2Ev
// DEMANGLED: DB_InsertOnTimeRewardUserLog::~DB_InsertOnTimeRewardUserLog()
void __cdecl DB_InsertOnTimeRewardUserLog::~DB_InsertOnTimeRewardUserLog(DB_InsertOnTimeRewardUserLog *this)
{
  *(_DWORD *)this = &off_8C5E478;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845B998
// IDA_NAME: _ZN28DB_InsertOnTimeRewardUserLogD0Ev
// DEMANGLED: DB_InsertOnTimeRewardUserLog::~DB_InsertOnTimeRewardUserLog()
void __cdecl DB_InsertOnTimeRewardUserLog::~DB_InsertOnTimeRewardUserLog(DB_InsertOnTimeRewardUserLog *this)
{
  DB_InsertOnTimeRewardUserLog::~DB_InsertOnTimeRewardUserLog(this);
  operator delete(this);
}
