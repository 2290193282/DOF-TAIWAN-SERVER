#ifndef __IDA91_DB_INSERTONTIMEREWARDUSERLOG_H__
#define __IDA91_DB_INSERTONTIMEREWARDUSERLOG_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_InsertOnTimeRewardUserLog
// Source unit: DB_InsertOnTimeRewardUserLog
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2682

/* 2682 */
struct DB_InsertOnTimeRewardUserLog;

// Exported member functions:
// 0x8442A56	DB_InsertOnTimeRewardUserLog::dispatch(int,int,Stream *)
// 0x8442B7A	DB_InsertOnTimeRewardUserLog::makeRequest(int,unsigned int,int)
// 0x844F962	DB_InsertOnTimeRewardUserLog::DB_InsertOnTimeRewardUserLog(void)
// 0x845B968	DB_InsertOnTimeRewardUserLog::~DB_InsertOnTimeRewardUserLog()
// 0x845B998	DB_InsertOnTimeRewardUserLog::~DB_InsertOnTimeRewardUserLog()

// Function declaration index:
// DECL 0x8442A56 DB_InsertOnTimeRewardUserLog::dispatch
// DECL 0x8442B7A DB_InsertOnTimeRewardUserLog::makeRequest
// DECL 0x844F962 DB_InsertOnTimeRewardUserLog::DB_InsertOnTimeRewardUserLog
// DECL 0x845B968 DB_InsertOnTimeRewardUserLog::~DB_InsertOnTimeRewardUserLog
// DECL 0x845B998 DB_InsertOnTimeRewardUserLog::~DB_InsertOnTimeRewardUserLog

#endif  // __IDA91_DB_INSERTONTIMEREWARDUSERLOG_H__
