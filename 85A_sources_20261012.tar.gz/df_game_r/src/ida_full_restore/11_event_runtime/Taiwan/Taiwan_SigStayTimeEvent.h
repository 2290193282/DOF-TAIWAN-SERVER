#ifndef __IDA91_TAIWAN_SIGSTAYTIMEEVENT_H__
#define __IDA91_TAIWAN_SIGSTAYTIMEEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Taiwan
// Source unit: Taiwan_SigStayTimeEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3450

/* 3450 */
struct Taiwan::SigStayTimeEvent;

// Exported member functions:
// 0x863BD76	Taiwan::SigStayTimeEvent::init(void)
// 0x863BD84	Taiwan::SigStayTimeEvent::set(unsigned int)

// Function declaration index:
// DECL 0x863BD76 Taiwan::SigStayTimeEvent::init
// DECL 0x863BD84 Taiwan::SigStayTimeEvent::set

#endif  // __IDA91_TAIWAN_SIGSTAYTIMEEVENT_H__
