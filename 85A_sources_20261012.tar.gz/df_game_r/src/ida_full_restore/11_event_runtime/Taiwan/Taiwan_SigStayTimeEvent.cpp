#include "Taiwan_SigStayTimeEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x863BD76
// IDA_NAME: _ZN6Taiwan16SigStayTimeEvent4initEv
// DEMANGLED: Taiwan::SigStayTimeEvent::init(void)
Taiwan::SigStayTimeEvent *__cdecl Taiwan::SigStayTimeEvent::init(Taiwan::SigStayTimeEvent *this)
{
  Taiwan::SigStayTimeEvent *this_1; // eax

  this_1 = this;
  *(_DWORD *)this = 0;
  return this_1;
}

// IDA_EA: 0x863BD84
// IDA_NAME: _ZN6Taiwan16SigStayTimeEvent3setEj
// DEMANGLED: Taiwan::SigStayTimeEvent::set(unsigned int)
Taiwan::SigStayTimeEvent *__cdecl Taiwan::SigStayTimeEvent::set(Taiwan::SigStayTimeEvent *this, unsigned int acc_idEv)
{
  Taiwan::SigStayTimeEvent *this_1; // eax

  this_1 = this;
  *(_DWORD *)this = acc_idEv;
  return this_1;
}
