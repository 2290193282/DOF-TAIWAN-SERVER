#ifndef __IDA91_INTER_TRIGGEREVENTEND_H__
#define __IDA91_INTER_TRIGGEREVENTEND_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_TriggerEventEnd
// Source unit: Inter_TriggerEventEnd
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 2991

/* 2991 */
struct Inter_TriggerEventEnd;

// Exported member functions:
// 0x84CE646	Inter_TriggerEventEnd::dispatch_sig(CUser *,char *,int)
// 0x84EB258	Inter_TriggerEventEnd::Inter_TriggerEventEnd(void)
// 0x84EB274	Inter_TriggerEventEnd::~Inter_TriggerEventEnd()
// 0x84EB2A4	Inter_TriggerEventEnd::~Inter_TriggerEventEnd()

// Function declaration index:
// DECL 0x84CE646 Inter_TriggerEventEnd::dispatch_sig
// DECL 0x84EB258 Inter_TriggerEventEnd::Inter_TriggerEventEnd
// DECL 0x84EB274 Inter_TriggerEventEnd::~Inter_TriggerEventEnd
// DECL 0x84EB2A4 Inter_TriggerEventEnd::~Inter_TriggerEventEnd

#endif  // __IDA91_INTER_TRIGGEREVENTEND_H__
