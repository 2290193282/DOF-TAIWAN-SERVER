#include "Inter_TriggerEventEnd.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84CE646
// IDA_NAME: _ZN21Inter_TriggerEventEnd12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_TriggerEventEnd::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_TriggerEventEnd::dispatch_sig(Inter_TriggerEventEnd *this, CUser *a2, char *a3)
{
  int v3; // ebx
  int v5[4]; // [esp+1Ch] [ebp-1Ch] BYREF
  char *v6; // [esp+2Ch] [ebp-Ch]

  v6 = a3;
  v3 = *(_DWORD *)(a3 + 10);
  cMyTrace::cMyTrace((cMyTrace *)v5, "virtual int Inter_TriggerEventEnd::dispatch_sig(CUser*, char*, int)", 10902, 0);
  cMyTrace::operator()((int)v5, "Inter_TriggerEventEnd::dispatch_sig\tevent code(%d), parameter(%d)", v3);
  if ( !GlobalData::s_event_manager )
    return 0;
  if ( (unsigned __int8)CEventManager::TriggerEventEnd(GlobalData::s_event_manager, *(_DWORD *)(v6 + 10)) )
    return 0;
  return 10906;
}

// IDA_EA: 0x84EB258
// IDA_NAME: _ZN21Inter_TriggerEventEndC2Ev
// DEMANGLED: Inter_TriggerEventEnd::Inter_TriggerEventEnd(void)
void __cdecl Inter_TriggerEventEnd::Inter_TriggerEventEnd(Inter_TriggerEventEnd *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8FA38;
}

// IDA_EA: 0x84EB274
// IDA_NAME: _ZN21Inter_TriggerEventEndD2Ev
// DEMANGLED: Inter_TriggerEventEnd::~Inter_TriggerEventEnd()
void __cdecl Inter_TriggerEventEnd::~Inter_TriggerEventEnd(Inter_TriggerEventEnd *this)
{
  *(_DWORD *)this = &off_8C8FA38;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84EB2A4
// IDA_NAME: _ZN21Inter_TriggerEventEndD0Ev
// DEMANGLED: Inter_TriggerEventEnd::~Inter_TriggerEventEnd()
void __cdecl Inter_TriggerEventEnd::~Inter_TriggerEventEnd(Inter_TriggerEventEnd *this)
{
  Inter_TriggerEventEnd::~Inter_TriggerEventEnd(this);
  operator delete(this);
}
