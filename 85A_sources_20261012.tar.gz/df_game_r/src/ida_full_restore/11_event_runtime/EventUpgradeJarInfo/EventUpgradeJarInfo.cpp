#include "EventUpgradeJarInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x80F50A4
// IDA_NAME: _ZN19EventUpgradeJarInfoC2Ev
// DEMANGLED: EventUpgradeJarInfo::EventUpgradeJarInfo(void)
void __cdecl EventUpgradeJarInfo::EventUpgradeJarInfo(EventUpgradeJarInfo *this)
{
  char *v1; // edi
  int n3; // ebx

  std::map<unsigned long,short>::map((char *)this + 4);
  std::map<std::pair<int,int>,unsigned long>::map((char *)this + 28);
  std::vector<unsigned long>::vector((char *)this + 52);
  v1 = (char *)this + 64;
  for ( n3 = 3; n3 != -1; --n3 )
  {
    std::vector<unsigned int>::vector((int)v1);
    v1 += 12;
  }
  std::vector<ST_Event_Upgrade_Jar_EventNPCs_Script>::vector((char *)this + 116);
}

// IDA_EA: 0x80F51D2
// IDA_NAME: _ZN19EventUpgradeJarInfoD2Ev
// DEMANGLED: EventUpgradeJarInfo::~EventUpgradeJarInfo()
void __cdecl EventUpgradeJarInfo::~EventUpgradeJarInfo(EventUpgradeJarInfo *this)
{
  _DWORD *i; // ebx

  std::vector<ST_Event_Upgrade_Jar_EventNPCs_Script>::~vector((char *)this + 116);
  if ( this != (EventUpgradeJarInfo *)-64 )
  {
    for ( i = (_DWORD *)((char *)this + 112); i != (_DWORD *)((char *)this + 64); std::vector<unsigned int>::~vector(i) )
      i -= 3;
  }
  std::vector<unsigned long>::~vector((char *)this + 52);
  std::map<std::pair<int,int>,unsigned long>::~map((int)this + 28);
  std::map<unsigned long,short>::~map((int)this + 4);
}
