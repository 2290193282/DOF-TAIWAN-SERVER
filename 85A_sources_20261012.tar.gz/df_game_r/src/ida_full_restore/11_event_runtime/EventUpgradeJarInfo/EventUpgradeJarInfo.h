#ifndef __IDA91_EVENTUPGRADEJARINFO_H__
#define __IDA91_EVENTUPGRADEJARINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: EventUpgradeJarInfo
// Source unit: EventUpgradeJarInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4673

/* 4673 */
struct EventUpgradeJarInfo;

// Exported member functions:
// 0x80F50A4	EventUpgradeJarInfo::EventUpgradeJarInfo(void)
// 0x80F51D2	EventUpgradeJarInfo::~EventUpgradeJarInfo()

// Function declaration index:
// DECL 0x80F50A4 EventUpgradeJarInfo::EventUpgradeJarInfo
// DECL 0x80F51D2 EventUpgradeJarInfo::~EventUpgradeJarInfo

#endif  // __IDA91_EVENTUPGRADEJARINFO_H__
