#ifndef __IDA91_CEXPDOUBLEEVENT_H__
#define __IDA91_CEXPDOUBLEEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CExpDoubleEvent
// Source unit: CExpDoubleEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1298

/* 1298 */
struct CExpDoubleEvent;

// Exported member functions:
// 0x814AAD8	CExpDoubleEvent::GetExpFactor(void)
// 0x849AC44	CExpDoubleEvent::CExpDoubleEvent(void)
// 0x849AC6A	CExpDoubleEvent::~CExpDoubleEvent()
// 0x849AC9A	CExpDoubleEvent::~CExpDoubleEvent()
// 0x849ACB8	CExpDoubleEvent::StartEvent(void)
// 0x849AD14	CExpDoubleEvent::StartEvent(Word_Param)
// 0x849AD72	CExpDoubleEvent::EndEvent(void)

// Function declaration index:
// DECL 0x814AAD8 CExpDoubleEvent::GetExpFactor
// DECL 0x849AC44 CExpDoubleEvent::CExpDoubleEvent
// DECL 0x849AC6A CExpDoubleEvent::~CExpDoubleEvent
// DECL 0x849AC9A CExpDoubleEvent::~CExpDoubleEvent
// DECL 0x849ACB8 CExpDoubleEvent::StartEvent
// DECL 0x849AD14 CExpDoubleEvent::StartEvent
// DECL 0x849AD72 CExpDoubleEvent::EndEvent

#endif  // __IDA91_CEXPDOUBLEEVENT_H__
