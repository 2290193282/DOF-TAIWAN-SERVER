#include "CExpDoubleEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x814AAD8
// IDA_NAME: _ZN15CExpDoubleEvent12GetExpFactorEv
// DEMANGLED: CExpDoubleEvent::GetExpFactor(void)
int __cdecl CExpDoubleEvent::GetExpFactor(CExpDoubleEvent *this)
{
  return *((_DWORD *)this + 3);
}

// IDA_EA: 0x849AC44
// IDA_NAME: _ZN15CExpDoubleEventC2Ev
// DEMANGLED: CExpDoubleEvent::CExpDoubleEvent(void)
void __cdecl CExpDoubleEvent::CExpDoubleEvent(CExpDoubleEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8C7B948;
  *((_DWORD *)this + 3) = 100;
}

// IDA_EA: 0x849AC6A
// IDA_NAME: _ZN15CExpDoubleEventD2Ev
// DEMANGLED: CExpDoubleEvent::~CExpDoubleEvent()
void __cdecl CExpDoubleEvent::~CExpDoubleEvent(CExpDoubleEvent *this)
{
  *(_DWORD *)this = off_8C7B948;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x849AC9A
// IDA_NAME: _ZN15CExpDoubleEventD0Ev
// DEMANGLED: CExpDoubleEvent::~CExpDoubleEvent()
void __cdecl CExpDoubleEvent::~CExpDoubleEvent(CExpDoubleEvent *this)
{
  CExpDoubleEvent::~CExpDoubleEvent(this);
  operator delete(this);
}

// IDA_EA: 0x849ACB8
// IDA_NAME: _ZN15CExpDoubleEvent10StartEventEv
// DEMANGLED: CExpDoubleEvent::StartEvent(void)
int __cdecl CExpDoubleEvent::StartEvent(CExpDoubleEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  *((_DWORD *)this + 3) = 100;
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 19, 0);
  return cMyTrace::operator()((int)v3, "Exp Double Event Start!", v2);
}

// IDA_EA: 0x849AD14
// IDA_NAME: _ZN15CExpDoubleEvent10StartEventE10Word_Param
// DEMANGLED: CExpDoubleEvent::StartEvent(Word_Param)
int __cdecl CExpDoubleEvent::StartEvent(CEventBase *a1, unsigned __int16 a2)
{
  char v3; // [esp+8h] [ebp-20h]
  int v4[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  *((_DWORD *)a1 + 3) = a2;
  cMyTrace::cMyTrace((cMyTrace *)v4, "StartEvent", 26, 0);
  return cMyTrace::operator()((int)v4, "Exp Double Event Start!", v3);
}

// IDA_EA: 0x849AD72
// IDA_NAME: _ZN15CExpDoubleEvent8EndEventEv
// DEMANGLED: CExpDoubleEvent::EndEvent(void)
int __cdecl CExpDoubleEvent::EndEvent(CExpDoubleEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  *((_DWORD *)this + 3) = 100;
  cMyTrace::cMyTrace((cMyTrace *)v3, "EndEvent", 33, 0);
  return cMyTrace::operator()((int)v3, "Exp Double Event End!", v2);
}
