#include "CNoNeedGoldOnGuildCreateEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81B9B8C
// IDA_NAME: _ZN29CNoNeedGoldOnGuildCreateEventC2Ev
// DEMANGLED: CNoNeedGoldOnGuildCreateEvent::CNoNeedGoldOnGuildCreateEvent(void)
void __cdecl CNoNeedGoldOnGuildCreateEvent::CNoNeedGoldOnGuildCreateEvent(CNoNeedGoldOnGuildCreateEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8BBD0C8;
}

// IDA_EA: 0x81B9BA8
// IDA_NAME: _ZN29CNoNeedGoldOnGuildCreateEventD2Ev
// DEMANGLED: CNoNeedGoldOnGuildCreateEvent::~CNoNeedGoldOnGuildCreateEvent()
void __cdecl CNoNeedGoldOnGuildCreateEvent::~CNoNeedGoldOnGuildCreateEvent(CNoNeedGoldOnGuildCreateEvent *this)
{
  *(_DWORD *)this = off_8BBD0C8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x81B9BD8
// IDA_NAME: _ZN29CNoNeedGoldOnGuildCreateEventD0Ev
// DEMANGLED: CNoNeedGoldOnGuildCreateEvent::~CNoNeedGoldOnGuildCreateEvent()
void __cdecl CNoNeedGoldOnGuildCreateEvent::~CNoNeedGoldOnGuildCreateEvent(CNoNeedGoldOnGuildCreateEvent *this)
{
  CNoNeedGoldOnGuildCreateEvent::~CNoNeedGoldOnGuildCreateEvent(this);
  operator delete(this);
}

// IDA_EA: 0x81B9BF6
// IDA_NAME: _ZN29CNoNeedGoldOnGuildCreateEvent10StartEventEv
// DEMANGLED: CNoNeedGoldOnGuildCreateEvent::StartEvent(void)
int __cdecl CNoNeedGoldOnGuildCreateEvent::StartEvent(CNoNeedGoldOnGuildCreateEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 18, 0);
  return cMyTrace::operator()((int)v3, "No Need Money On Guild Create Event Start!", v2);
}

// IDA_EA: 0x81B9C48
// IDA_NAME: _ZN29CNoNeedGoldOnGuildCreateEvent10StartEventE10Word_Param
// DEMANGLED: CNoNeedGoldOnGuildCreateEvent::StartEvent(Word_Param)
int __cdecl CNoNeedGoldOnGuildCreateEvent::StartEvent(CEventBase *a1)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 24, 0);
  return cMyTrace::operator()((int)v3, "No Need Money On Guild Create Event Start!", v2);
}

// IDA_EA: 0x81B9C9A
// IDA_NAME: _ZN29CNoNeedGoldOnGuildCreateEvent8EndEventEv
// DEMANGLED: CNoNeedGoldOnGuildCreateEvent::EndEvent(void)
int __cdecl CNoNeedGoldOnGuildCreateEvent::EndEvent(CNoNeedGoldOnGuildCreateEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "EndEvent", 30, 0);
  return cMyTrace::operator()((int)v3, "No Need Money On Guild Create Event End!", v2);
}
