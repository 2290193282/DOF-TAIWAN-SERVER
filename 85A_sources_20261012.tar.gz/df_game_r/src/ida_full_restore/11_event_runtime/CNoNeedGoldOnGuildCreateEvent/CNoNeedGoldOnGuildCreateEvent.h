#ifndef __IDA91_CNONEEDGOLDONGUILDCREATEEVENT_H__
#define __IDA91_CNONEEDGOLDONGUILDCREATEEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CNoNeedGoldOnGuildCreateEvent
// Source unit: CNoNeedGoldOnGuildCreateEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4140

/* 4140 */
struct CNoNeedGoldOnGuildCreateEvent;

// Exported member functions:
// 0x81B9B8C	CNoNeedGoldOnGuildCreateEvent::CNoNeedGoldOnGuildCreateEvent(void)
// 0x81B9BA8	CNoNeedGoldOnGuildCreateEvent::~CNoNeedGoldOnGuildCreateEvent()
// 0x81B9BD8	CNoNeedGoldOnGuildCreateEvent::~CNoNeedGoldOnGuildCreateEvent()
// 0x81B9BF6	CNoNeedGoldOnGuildCreateEvent::StartEvent(void)
// 0x81B9C48	CNoNeedGoldOnGuildCreateEvent::StartEvent(Word_Param)
// 0x81B9C9A	CNoNeedGoldOnGuildCreateEvent::EndEvent(void)

// Function declaration index:
// DECL 0x81B9B8C CNoNeedGoldOnGuildCreateEvent::CNoNeedGoldOnGuildCreateEvent
// DECL 0x81B9BA8 CNoNeedGoldOnGuildCreateEvent::~CNoNeedGoldOnGuildCreateEvent
// DECL 0x81B9BD8 CNoNeedGoldOnGuildCreateEvent::~CNoNeedGoldOnGuildCreateEvent
// DECL 0x81B9BF6 CNoNeedGoldOnGuildCreateEvent::StartEvent
// DECL 0x81B9C48 CNoNeedGoldOnGuildCreateEvent::StartEvent
// DECL 0x81B9C9A CNoNeedGoldOnGuildCreateEvent::EndEvent

#endif  // __IDA91_CNONEEDGOLDONGUILDCREATEEVENT_H__
