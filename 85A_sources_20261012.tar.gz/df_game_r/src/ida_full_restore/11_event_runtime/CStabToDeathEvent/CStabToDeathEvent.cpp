#include "CStabToDeathEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x827F508
// IDA_NAME: _ZN17CStabToDeathEventC2Ev
// DEMANGLED: CStabToDeathEvent::CStabToDeathEvent(void)
void __cdecl CStabToDeathEvent::CStabToDeathEvent(CStabToDeathEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8C09708;
}

// IDA_EA: 0x827F524
// IDA_NAME: _ZN17CStabToDeathEventD2Ev
// DEMANGLED: CStabToDeathEvent::~CStabToDeathEvent()
void __cdecl CStabToDeathEvent::~CStabToDeathEvent(CStabToDeathEvent *this)
{
  *(_DWORD *)this = off_8C09708;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x827F554
// IDA_NAME: _ZN17CStabToDeathEventD0Ev
// DEMANGLED: CStabToDeathEvent::~CStabToDeathEvent()
void __cdecl CStabToDeathEvent::~CStabToDeathEvent(CStabToDeathEvent *this)
{
  CStabToDeathEvent::~CStabToDeathEvent(this);
  operator delete(this);
}

// IDA_EA: 0x827F572
// IDA_NAME: _ZN17CStabToDeathEvent10StartEventEv
// DEMANGLED: CStabToDeathEvent::StartEvent(void)
int __cdecl CStabToDeathEvent::StartEvent(CStabToDeathEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 17, 0);
  return cMyTrace::operator()((int)v3, "CStabToDeathEvent Start!", v2);
}

// IDA_EA: 0x827F5C4
// IDA_NAME: _ZN17CStabToDeathEvent10StartEventE10Word_Param
// DEMANGLED: CStabToDeathEvent::StartEvent(Word_Param)
int __cdecl CStabToDeathEvent::StartEvent(CEventBase *a1)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 23, 0);
  return cMyTrace::operator()((int)v3, "CStabToDeathEvent Start!", v2);
}

// IDA_EA: 0x827F616
// IDA_NAME: _ZN17CStabToDeathEvent8EndEventEv
// DEMANGLED: CStabToDeathEvent::EndEvent(void)
int __cdecl CStabToDeathEvent::EndEvent(CStabToDeathEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "EndEvent", 29, 0);
  return cMyTrace::operator()((int)v3, "CStabToDeathEvent End!", v2);
}
