#ifndef __IDA91_CSTABTODEATHEVENT_H__
#define __IDA91_CSTABTODEATHEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CStabToDeathEvent
// Source unit: CStabToDeathEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4165

/* 4165 */
struct CStabToDeathEvent;

// Exported member functions:
// 0x827F508	CStabToDeathEvent::CStabToDeathEvent(void)
// 0x827F524	CStabToDeathEvent::~CStabToDeathEvent()
// 0x827F554	CStabToDeathEvent::~CStabToDeathEvent()
// 0x827F572	CStabToDeathEvent::StartEvent(void)
// 0x827F5C4	CStabToDeathEvent::StartEvent(Word_Param)
// 0x827F616	CStabToDeathEvent::EndEvent(void)

// Function declaration index:
// DECL 0x827F508 CStabToDeathEvent::CStabToDeathEvent
// DECL 0x827F524 CStabToDeathEvent::~CStabToDeathEvent
// DECL 0x827F554 CStabToDeathEvent::~CStabToDeathEvent
// DECL 0x827F572 CStabToDeathEvent::StartEvent
// DECL 0x827F5C4 CStabToDeathEvent::StartEvent
// DECL 0x827F616 CStabToDeathEvent::EndEvent

#endif  // __IDA91_CSTABTODEATHEVENT_H__
