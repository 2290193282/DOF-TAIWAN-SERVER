#ifndef __IDA91_STMERCENARYREWARDGROUP_H__
#define __IDA91_STMERCENARYREWARDGROUP_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stMercenaryRewardGroup
// Source unit: stMercenaryRewardGroup
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4443

/* 4443 */
struct stMercenaryRewardGroup;

// Exported member functions:
// 0x83DD67C	stMercenaryRewardGroup::~stMercenaryRewardGroup()
// 0x89F7A9C	stMercenaryRewardGroup::stMercenaryRewardGroup(void)
// 0x89F7F26	stMercenaryRewardGroup::stMercenaryRewardGroup(stMercenaryRewardGroup const&)
// 0x89F805A	stMercenaryRewardGroup::operator=(stMercenaryRewardGroup const&)

// Function declaration index:
// DECL 0x83DD67C stMercenaryRewardGroup::~stMercenaryRewardGroup
// DECL 0x89F7A9C stMercenaryRewardGroup::stMercenaryRewardGroup
// DECL 0x89F7F26 stMercenaryRewardGroup::stMercenaryRewardGroup
// DECL 0x89F805A stMercenaryRewardGroup::operator=

#endif  // __IDA91_STMERCENARYREWARDGROUP_H__
