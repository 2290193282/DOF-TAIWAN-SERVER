#include "stMercenaryRewardGroup.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x83DD67C
// IDA_NAME: _ZN22stMercenaryRewardGroupD2Ev
// DEMANGLED: stMercenaryRewardGroup::~stMercenaryRewardGroup()
void __cdecl stMercenaryRewardGroup::~stMercenaryRewardGroup(stMercenaryRewardGroup *this)
{
  std::vector<std::pair<int,int>>::~vector((int *)this + 5);
  std::vector<std::pair<int,int>>::~vector((int *)this + 2);
  std::string::~string((char *)this + 4);
}

// IDA_EA: 0x89F7A9C
// IDA_NAME: _ZN22stMercenaryRewardGroupC2Ev
// DEMANGLED: stMercenaryRewardGroup::stMercenaryRewardGroup(void)
void __cdecl stMercenaryRewardGroup::stMercenaryRewardGroup(stMercenaryRewardGroup *this)
{
  *(_DWORD *)this = 0;
  std::string::string((std::string *)this + 1);
  std::vector<std::pair<int,int>>::vector((int)this + 8);
  std::vector<std::pair<int,int>>::vector((int)this + 20);
  *((_DWORD *)this + 8) = 0;
  *((_DWORD *)this + 9) = 0;
}

// IDA_EA: 0x89F7F26
// IDA_NAME: _ZN22stMercenaryRewardGroupC2ERKS_
// DEMANGLED: stMercenaryRewardGroup::stMercenaryRewardGroup(stMercenaryRewardGroup const&)
void __cdecl stMercenaryRewardGroup::stMercenaryRewardGroup(stMercenaryRewardGroup *this, const std::string *a2)
{
  *(std::string *)this = (std::string)a2->_M_dataplus.__vftable;
  std::string::string((std::string *)this + 1, a2 + 1);
  std::vector<std::pair<int,int>>::vector((int *)this + 2, &a2[2]._M_dataplus.__vftable);
  std::vector<std::pair<int,int>>::vector((int *)this + 5, &a2[5]._M_dataplus.__vftable);
  *((std::string *)this + 8) = a2[8];
  *((std::string *)this + 9) = a2[9];
}

// IDA_EA: 0x89F805A
// IDA_NAME: _ZN22stMercenaryRewardGroupaSERKS_
// DEMANGLED: stMercenaryRewardGroup::operator=(stMercenaryRewardGroup const&)
int __cdecl stMercenaryRewardGroup::operator=(int a1, int a2)
{
  *(_DWORD *)a1 = *(_DWORD *)a2;
  std::string::operator=((std::string *)(a1 + 4), (const std::string *)(a2 + 4));
  std::vector<std::pair<int,int>>::operator=((int *)(a1 + 8), (int *)(a2 + 8));
  std::vector<std::pair<int,int>>::operator=((int *)(a1 + 20), (int *)(a2 + 20));
  *(_DWORD *)(a1 + 32) = *(_DWORD *)(a2 + 32);
  *(_DWORD *)(a1 + 36) = *(_DWORD *)(a2 + 36);
  return a1;
}
