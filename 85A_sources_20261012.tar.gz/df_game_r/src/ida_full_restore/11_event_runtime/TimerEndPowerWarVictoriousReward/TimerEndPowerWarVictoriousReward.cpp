#include "TimerEndPowerWarVictoriousReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x86394CE
// IDA_NAME: _ZN32TimerEndPowerWarVictoriousReward12dispatch_sigEiij
// DEMANGLED: TimerEndPowerWarVictoriousReward::dispatch_sig(int,int,unsigned int)
int TimerEndPowerWarVictoriousReward::dispatch_sig()
{
  CEventManager::TriggerEventEnd(GlobalData::s_event_manager, 53);
  return 1;
}

// IDA_EA: 0x863CE56
// IDA_NAME: _ZN32TimerEndPowerWarVictoriousRewardC2Ev
// DEMANGLED: TimerEndPowerWarVictoriousReward::TimerEndPowerWarVictoriousReward(void)
void __cdecl TimerEndPowerWarVictoriousReward::TimerEndPowerWarVictoriousReward(TimerEndPowerWarVictoriousReward *this)
{
  TimerSig::TimerSig(this);
  *(_DWORD *)this = &off_8CE8898;
}

// IDA_EA: 0x863ED12
// IDA_NAME: _ZN32TimerEndPowerWarVictoriousRewardD2Ev
// DEMANGLED: TimerEndPowerWarVictoriousReward::~TimerEndPowerWarVictoriousReward()
void __cdecl TimerEndPowerWarVictoriousReward::~TimerEndPowerWarVictoriousReward(
        TimerEndPowerWarVictoriousReward *this)
{
  *(_DWORD *)this = &off_8CE8898;
  TimerSig::~TimerSig(this);
}

// IDA_EA: 0x863ED42
// IDA_NAME: _ZN32TimerEndPowerWarVictoriousRewardD0Ev
// DEMANGLED: TimerEndPowerWarVictoriousReward::~TimerEndPowerWarVictoriousReward()
void __cdecl TimerEndPowerWarVictoriousReward::~TimerEndPowerWarVictoriousReward(
        TimerEndPowerWarVictoriousReward *this)
{
  TimerEndPowerWarVictoriousReward::~TimerEndPowerWarVictoriousReward(this);
  operator delete(this);
}
