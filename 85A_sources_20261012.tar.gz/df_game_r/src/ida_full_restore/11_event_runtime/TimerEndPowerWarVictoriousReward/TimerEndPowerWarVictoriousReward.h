#ifndef __IDA91_TIMERENDPOWERWARVICTORIOUSREWARD_H__
#define __IDA91_TIMERENDPOWERWARVICTORIOUSREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: TimerEndPowerWarVictoriousReward
// Source unit: TimerEndPowerWarVictoriousReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3564

/* 3564 */
struct TimerEndPowerWarVictoriousReward;

// Exported member functions:
// 0x86394CE	TimerEndPowerWarVictoriousReward::dispatch_sig(int,int,unsigned int)
// 0x863CE56	TimerEndPowerWarVictoriousReward::TimerEndPowerWarVictoriousReward(void)
// 0x863ED12	TimerEndPowerWarVictoriousReward::~TimerEndPowerWarVictoriousReward()
// 0x863ED42	TimerEndPowerWarVictoriousReward::~TimerEndPowerWarVictoriousReward()

// Function declaration index:
// DECL 0x86394CE TimerEndPowerWarVictoriousReward::dispatch_sig
// DECL 0x863CE56 TimerEndPowerWarVictoriousReward::TimerEndPowerWarVictoriousReward
// DECL 0x863ED12 TimerEndPowerWarVictoriousReward::~TimerEndPowerWarVictoriousReward
// DECL 0x863ED42 TimerEndPowerWarVictoriousReward::~TimerEndPowerWarVictoriousReward

#endif  // __IDA91_TIMERENDPOWERWARVICTORIOUSREWARD_H__
