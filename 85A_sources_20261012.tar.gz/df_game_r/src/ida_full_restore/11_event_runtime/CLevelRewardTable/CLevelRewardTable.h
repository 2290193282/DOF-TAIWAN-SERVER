#ifndef __IDA91_CLEVELREWARDTABLE_H__
#define __IDA91_CLEVELREWARDTABLE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CLevelRewardTable
// Source unit: CLevelRewardTable
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 3597

/* 3597 */
struct CLevelRewardTable;

// Exported member functions:
// 0x86876C8	CLevelRewardTable::GetProperLevelIndex(unsigned int)
// 0x8687E78	CLevelRewardTable::GetProperJobIndex(char)
// 0x86975FE	CLevelRewardTable::CLevelRewardTable(void)
// 0x86976F6	CLevelRewardTable::GetRewardItemNo(int,int)
// 0x8697712	CLevelRewardTable::GetItemCount(int,int)
// 0x8697730	CLevelRewardTable::GetMailTitle(int)
// 0x8697750	CLevelRewardTable::GetMailString(int)
// 0x8697766	CLevelRewardTable::SetJobAffection(bool)
// 0x8697782	CLevelRewardTable::GetJobAffection(void)

// Function declaration index:
// DECL 0x86876C8 CLevelRewardTable::GetProperLevelIndex
// DECL 0x8687E78 CLevelRewardTable::GetProperJobIndex
// DECL 0x86975FE CLevelRewardTable::CLevelRewardTable
// DECL 0x86976F6 CLevelRewardTable::GetRewardItemNo
// DECL 0x8697712 CLevelRewardTable::GetItemCount
// DECL 0x8697730 CLevelRewardTable::GetMailTitle
// DECL 0x8697750 CLevelRewardTable::GetMailString
// DECL 0x8697766 CLevelRewardTable::SetJobAffection
// DECL 0x8697782 CLevelRewardTable::GetJobAffection

#endif  // __IDA91_CLEVELREWARDTABLE_H__
