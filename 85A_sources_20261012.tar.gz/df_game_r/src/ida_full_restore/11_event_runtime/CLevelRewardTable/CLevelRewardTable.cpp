#include "CLevelRewardTable.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x86876C8
// IDA_NAME: _ZN17CLevelRewardTable19GetProperLevelIndexEj
// DEMANGLED: CLevelRewardTable::GetProperLevelIndex(unsigned int)
int __cdecl CLevelRewardTable::GetProperLevelIndex(CLevelRewardTable *this, unsigned int a2)
{
  int n69; // [esp+Ch] [ebp-4h]

  for ( n69 = 0; n69 <= 69 && *((_DWORD *)this + n69); ++n69 )
  {
    if ( *((_DWORD *)this + n69) == a2 )
      return n69;
  }
  return -1;
}

// IDA_EA: 0x8687E78
// IDA_NAME: _ZN17CLevelRewardTable17GetProperJobIndexEc
// DEMANGLED: CLevelRewardTable::GetProperJobIndex(char)
int __cdecl CLevelRewardTable::GetProperJobIndex(CLevelRewardTable *this, char n4)
{
  int n2; // eax

  if ( n4 < 0 )
    return -1;
  if ( (unsigned __int8)CLevelRewardTable::GetJobAffection(this) != 1 )
    return 0;
  switch ( n4 )
  {
    case 0:
      n2 = 1;
      break;
    case 1:
      n2 = 2;
      break;
    case 2:
      n2 = 3;
      break;
    case 3:
      n2 = 4;
      break;
    case 4:
      n2 = 5;
      break;
    case 5:
      n2 = 6;
      break;
    case 6:
      n2 = 7;
      break;
    case 7:
      n2 = 8;
      break;
    default:
      n2 = -1;
      break;
  }
  return n2;
}

// IDA_EA: 0x86975FE
// IDA_NAME: _ZN17CLevelRewardTableC2Ev
// DEMANGLED: CLevelRewardTable::CLevelRewardTable(void)
void __cdecl CLevelRewardTable::CLevelRewardTable(CLevelRewardTable *this)
{
  int n69; // [esp+14h] [ebp-14h]
  int n8; // [esp+18h] [ebp-10h]
  int n69_1; // [esp+1Ch] [ebp-Ch]

  for ( n69 = 0; n69 <= 69; ++n69 )
  {
    *((_DWORD *)this + n69) = 0;
    memcpy((char *)this + 21 * n69 + 5320, pszSrc__0, sizeof(char));
    memcpy((char *)this + 256 * n69 + 6790, pszSrc__0, sizeof(char));
  }
  for ( n8 = 0; n8 <= 8; ++n8 )
  {
    for ( n69_1 = 0; n69_1 <= 69; ++n69_1 )
    {
      *((_DWORD *)this + 70 * n8 + n69_1 + 70) = 0;
      *((_DWORD *)this + 70 * n8 + n69_1 + 700) = 0;
    }
  }
  *((_BYTE *)this + 24710) = 0;
}

// IDA_EA: 0x86976F6
// IDA_NAME: _ZN17CLevelRewardTable15GetRewardItemNoEii
// DEMANGLED: CLevelRewardTable::GetRewardItemNo(int,int)
int __cdecl CLevelRewardTable::GetRewardItemNo(CLevelRewardTable *this, int a2, int a3)
{
  return *((_DWORD *)this + 70 * a2 + a3 + 70);
}

// IDA_EA: 0x8697712
// IDA_NAME: _ZN17CLevelRewardTable12GetItemCountEii
// DEMANGLED: CLevelRewardTable::GetItemCount(int,int)
int __cdecl CLevelRewardTable::GetItemCount(CLevelRewardTable *this, int a2, int a3)
{
  return *((_DWORD *)this + 70 * a2 + a3 + 700);
}

// IDA_EA: 0x8697730
// IDA_NAME: _ZN17CLevelRewardTable12GetMailTitleEi
// DEMANGLED: CLevelRewardTable::GetMailTitle(int)
char *__cdecl CLevelRewardTable::GetMailTitle(CLevelRewardTable *this, int a2)
{
  return (char *)this + 21 * a2 + 5320;
}

// IDA_EA: 0x8697750
// IDA_NAME: _ZN17CLevelRewardTable13GetMailStringEi
// DEMANGLED: CLevelRewardTable::GetMailString(int)
char *__cdecl CLevelRewardTable::GetMailString(CLevelRewardTable *this, int a2)
{
  return (char *)this + 256 * a2 + 6790;
}

// IDA_EA: 0x8697766
// IDA_NAME: _ZN17CLevelRewardTable15SetJobAffectionEb
// DEMANGLED: CLevelRewardTable::SetJobAffection(bool)
CLevelRewardTable *__cdecl CLevelRewardTable::SetJobAffection(CLevelRewardTable *this, bool a2)
{
  CLevelRewardTable *this_1; // eax

  this_1 = this;
  *((_BYTE *)this + 24710) = a2;
  return this_1;
}

// IDA_EA: 0x8697782
// IDA_NAME: _ZN17CLevelRewardTable15GetJobAffectionEv
// DEMANGLED: CLevelRewardTable::GetJobAffection(void)
int __cdecl CLevelRewardTable::GetJobAffection(CLevelRewardTable *this)
{
  return *((unsigned __int8 *)this + 24710);
}
