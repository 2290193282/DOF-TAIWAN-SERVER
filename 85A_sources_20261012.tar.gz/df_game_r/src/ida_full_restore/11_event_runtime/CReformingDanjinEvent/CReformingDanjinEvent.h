#ifndef __IDA91_CREFORMINGDANJINEVENT_H__
#define __IDA91_CREFORMINGDANJINEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CReformingDanjinEvent
// Source unit: CReformingDanjinEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4163

/* 4163 */
struct CReformingDanjinEvent;

// Exported member functions:
// 0x826E92C	CReformingDanjinEvent::CReformingDanjinEvent(void)
// 0x826E948	CReformingDanjinEvent::~CReformingDanjinEvent()
// 0x826E978	CReformingDanjinEvent::~CReformingDanjinEvent()
// 0x826E996	CReformingDanjinEvent::StartEvent(void)
// 0x826E9E8	CReformingDanjinEvent::StartEvent(Word_Param)
// 0x826EA3A	CReformingDanjinEvent::EndEvent(void)

// Function declaration index:
// DECL 0x826E92C CReformingDanjinEvent::CReformingDanjinEvent
// DECL 0x826E948 CReformingDanjinEvent::~CReformingDanjinEvent
// DECL 0x826E978 CReformingDanjinEvent::~CReformingDanjinEvent
// DECL 0x826E996 CReformingDanjinEvent::StartEvent
// DECL 0x826E9E8 CReformingDanjinEvent::StartEvent
// DECL 0x826EA3A CReformingDanjinEvent::EndEvent

#endif  // __IDA91_CREFORMINGDANJINEVENT_H__
