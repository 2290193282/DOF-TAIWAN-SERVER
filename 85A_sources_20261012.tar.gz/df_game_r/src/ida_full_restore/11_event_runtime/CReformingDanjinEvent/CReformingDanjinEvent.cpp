#include "CReformingDanjinEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x826E92C
// IDA_NAME: _ZN21CReformingDanjinEventC2Ev
// DEMANGLED: CReformingDanjinEvent::CReformingDanjinEvent(void)
void __cdecl CReformingDanjinEvent::CReformingDanjinEvent(CReformingDanjinEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8BF8F48;
}

// IDA_EA: 0x826E948
// IDA_NAME: _ZN21CReformingDanjinEventD2Ev
// DEMANGLED: CReformingDanjinEvent::~CReformingDanjinEvent()
void __cdecl CReformingDanjinEvent::~CReformingDanjinEvent(CReformingDanjinEvent *this)
{
  *(_DWORD *)this = off_8BF8F48;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x826E978
// IDA_NAME: _ZN21CReformingDanjinEventD0Ev
// DEMANGLED: CReformingDanjinEvent::~CReformingDanjinEvent()
void __cdecl CReformingDanjinEvent::~CReformingDanjinEvent(CReformingDanjinEvent *this)
{
  CReformingDanjinEvent::~CReformingDanjinEvent(this);
  operator delete(this);
}

// IDA_EA: 0x826E996
// IDA_NAME: _ZN21CReformingDanjinEvent10StartEventEv
// DEMANGLED: CReformingDanjinEvent::StartEvent(void)
int __cdecl CReformingDanjinEvent::StartEvent(CReformingDanjinEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 19, 0);
  return cMyTrace::operator()((int)v3, "Reforming Danjin Event Start!", v2);
}

// IDA_EA: 0x826E9E8
// IDA_NAME: _ZN21CReformingDanjinEvent10StartEventE10Word_Param
// DEMANGLED: CReformingDanjinEvent::StartEvent(Word_Param)
int __cdecl CReformingDanjinEvent::StartEvent(CEventBase *a1)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 25, 0);
  return cMyTrace::operator()((int)v3, "Reforming Danjin Event Start!", v2);
}

// IDA_EA: 0x826EA3A
// IDA_NAME: _ZN21CReformingDanjinEvent8EndEventEv
// DEMANGLED: CReformingDanjinEvent::EndEvent(void)
int __cdecl CReformingDanjinEvent::EndEvent(CReformingDanjinEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "EndEvent", 31, 0);
  return cMyTrace::operator()((int)v3, "Reforming Danjin Event End!", v2);
}
