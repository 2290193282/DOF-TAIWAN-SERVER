#ifndef __IDA91_TIMEREVENTCOINREFILL_H__
#define __IDA91_TIMEREVENTCOINREFILL_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: TimerEventCoinRefill
// Source unit: TimerEventCoinRefill
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3512

/* 3512 */
struct TimerEventCoinRefill;

// Exported member functions:
// 0x86364C4	TimerEventCoinRefill::dispatch_sig(int,int,unsigned int)
// 0x863C816	TimerEventCoinRefill::TimerEventCoinRefill(void)
// 0x863FDE0	TimerEventCoinRefill::~TimerEventCoinRefill()
// 0x863FE10	TimerEventCoinRefill::~TimerEventCoinRefill()

// Function declaration index:
// DECL 0x86364C4 TimerEventCoinRefill::dispatch_sig
// DECL 0x863C816 TimerEventCoinRefill::TimerEventCoinRefill
// DECL 0x863FDE0 TimerEventCoinRefill::~TimerEventCoinRefill
// DECL 0x863FE10 TimerEventCoinRefill::~TimerEventCoinRefill

#endif  // __IDA91_TIMEREVENTCOINREFILL_H__
