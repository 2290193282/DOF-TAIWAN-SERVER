#include "TimerEventCoinRefill.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x86364C4
// IDA_NAME: _ZN20TimerEventCoinRefill12dispatch_sigEiij
// DEMANGLED: TimerEventCoinRefill::dispatch_sig(int,int,unsigned int)
int TimerEventCoinRefill::dispatch_sig()
{
  GameWorld *v0; // eax
  char v2; // [esp+8h] [ebp-30h]
  int v3[4]; // [esp+1Ch] [ebp-1Ch] BYREF
  CCoinRefillEvent *RepeatEvent; // [esp+2Ch] [ebp-Ch]

  RepeatEvent = (CCoinRefillEvent *)CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 13);
  if ( (*(unsigned __int8 (__cdecl **)(CCoinRefillEvent *, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) )
  {
    v0 = (GameWorld *)G_GameWorld();
    GameWorld::ResetAllCoins(v0);
    cMyTrace::cMyTrace(
      (cMyTrace *)v3,
      "virtual bool TimerEventCoinRefill::dispatch_sig(int, int, memberIdentificationNumber_t)",
      2780,
      0);
    cMyTrace::operator()((int)v3, "Coin refilled by event!", v2);
    CCoinRefillEvent::registNextRefillTimer(RepeatEvent);
  }
  return 1;
}

// IDA_EA: 0x863C816
// IDA_NAME: _ZN20TimerEventCoinRefillC2Ev
// DEMANGLED: TimerEventCoinRefill::TimerEventCoinRefill(void)
void __cdecl TimerEventCoinRefill::TimerEventCoinRefill(TimerEventCoinRefill *this)
{
  TimerSig::TimerSig(this);
  *(_DWORD *)this = &off_8CE8DA8;
}

// IDA_EA: 0x863FDE0
// IDA_NAME: _ZN20TimerEventCoinRefillD2Ev
// DEMANGLED: TimerEventCoinRefill::~TimerEventCoinRefill()
void __cdecl TimerEventCoinRefill::~TimerEventCoinRefill(TimerEventCoinRefill *this)
{
  *(_DWORD *)this = &off_8CE8DA8;
  TimerSig::~TimerSig(this);
}

// IDA_EA: 0x863FE10
// IDA_NAME: _ZN20TimerEventCoinRefillD0Ev
// DEMANGLED: TimerEventCoinRefill::~TimerEventCoinRefill()
void __cdecl TimerEventCoinRefill::~TimerEventCoinRefill(TimerEventCoinRefill *this)
{
  TimerEventCoinRefill::~TimerEventCoinRefill(this);
  operator delete(this);
}
