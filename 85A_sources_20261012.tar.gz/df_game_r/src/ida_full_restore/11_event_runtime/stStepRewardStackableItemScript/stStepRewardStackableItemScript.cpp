#include "stStepRewardStackableItemScript.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x83714C6
// IDA_NAME: _ZN31stStepRewardStackableItemScriptC2Ev
// DEMANGLED: stStepRewardStackableItemScript::stStepRewardStackableItemScript(void)
void __cdecl stStepRewardStackableItemScript::stStepRewardStackableItemScript(stStepRewardStackableItemScript *this)
{
  std::map<int,std::vector<StackableItemData>>::map(this);
  stStepRewardStackableItemScript::clear(this);
}

// IDA_EA: 0x8371508
// IDA_NAME: _ZN31stStepRewardStackableItemScript5clearEv
// DEMANGLED: stStepRewardStackableItemScript::clear(void)
int __cdecl stStepRewardStackableItemScript::clear(stStepRewardStackableItemScript *this)
{
  return std::map<int,std::vector<StackableItemData>>::clear(this);
}

// IDA_EA: 0x837151C
// IDA_NAME: _ZN31stStepRewardStackableItemScriptD2Ev
// DEMANGLED: stStepRewardStackableItemScript::~stStepRewardStackableItemScript()
void __cdecl stStepRewardStackableItemScript::~stStepRewardStackableItemScript(stStepRewardStackableItemScript *this)
{
  std::map<int,std::vector<StackableItemData>>::~map((int)this);
}

// IDA_EA: 0x891BD0E
// IDA_NAME: _ZN31stStepRewardStackableItemScript8set_dataEiR17StackableItemData
// DEMANGLED: stStepRewardStackableItemScript::set_data(int,StackableItemData &)
int __cdecl stStepRewardStackableItemScript::set_data(
        stStepRewardStackableItemScript *this,
        char a2,
        StackableItemData *a3)
{
  int v4; // eax
  _DWORD v5[3]; // [esp+14h] [ebp-44h] BYREF
  _BYTE v6[4]; // [esp+20h] [ebp-38h] BYREF
  _BYTE v7[4]; // [esp+24h] [ebp-34h] BYREF
  _BYTE v8[8]; // [esp+28h] [ebp-30h] BYREF
  _BYTE v9[16]; // [esp+30h] [ebp-28h] BYREF
  _BYTE v10[24]; // [esp+40h] [ebp-18h] BYREF

  std::map<int,std::vector<StackableItemData>>::find(v6);
  std::map<int,std::vector<StackableItemData>>::end(v7);
  if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,std::vector<StackableItemData>>>::operator==(v7, v6) )
  {
    std::vector<StackableItemData>::vector(v5);
    std::vector<StackableItemData>::push_back(v5, a3);
    std::make_pair<int const&,std::vector<StackableItemData> &>(v10);
    std::pair<int const,std::vector<StackableItemData>>::pair<int,std::vector<StackableItemData>>(v9, v10);
    std::map<int,std::vector<StackableItemData>>::insert(v8);
    std::pair<int const,std::vector<StackableItemData>>::~pair((int)v9);
    std::pair<int,std::vector<StackableItemData>>::~pair((int)v10);
    return std::vector<StackableItemData>::~vector(v5);
  }
  else
  {
    v4 = std::_Rb_tree_iterator<std::pair<int const,std::vector<StackableItemData>>>::operator->(v6);
    return std::vector<StackableItemData>::push_back(v4 + 4, a3);
  }
}
