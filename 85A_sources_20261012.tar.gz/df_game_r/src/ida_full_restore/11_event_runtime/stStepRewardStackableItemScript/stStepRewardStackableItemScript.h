#ifndef __IDA91_STSTEPREWARDSTACKABLEITEMSCRIPT_H__
#define __IDA91_STSTEPREWARDSTACKABLEITEMSCRIPT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stStepRewardStackableItemScript
// Source unit: stStepRewardStackableItemScript
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4731

/* 4731 */
struct stStepRewardStackableItemScript;

// Exported member functions:
// 0x83714C6	stStepRewardStackableItemScript::stStepRewardStackableItemScript(void)
// 0x8371508	stStepRewardStackableItemScript::clear(void)
// 0x837151C	stStepRewardStackableItemScript::~stStepRewardStackableItemScript()
// 0x891BD0E	stStepRewardStackableItemScript::set_data(int,StackableItemData &)

// Function declaration index:
// DECL 0x83714C6 stStepRewardStackableItemScript::stStepRewardStackableItemScript
// DECL 0x8371508 stStepRewardStackableItemScript::clear
// DECL 0x837151C stStepRewardStackableItemScript::~stStepRewardStackableItemScript
// DECL 0x891BD0E stStepRewardStackableItemScript::set_data

#endif  // __IDA91_STSTEPREWARDSTACKABLEITEMSCRIPT_H__
