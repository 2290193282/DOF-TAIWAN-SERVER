#ifndef __IDA91_TIMER_EVENTMANAGEMENT_H__
#define __IDA91_TIMER_EVENTMANAGEMENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Timer_EventManagement
// Source unit: Timer_EventManagement
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3581

/* 3581 */
struct Timer_EventManagement;

// Exported member functions:
// 0x863AB92	Timer_EventManagement::dispatch_sig(int,int,unsigned int)
// 0x863ABD4	Timer_EventManagement::RegistNextTimer(int)
// 0x863D032	Timer_EventManagement::Timer_EventManagement(void)
// 0x863E748	Timer_EventManagement::~Timer_EventManagement()
// 0x863E778	Timer_EventManagement::~Timer_EventManagement()

// Function declaration index:
// DECL 0x863AB92 Timer_EventManagement::dispatch_sig
// DECL 0x863ABD4 Timer_EventManagement::RegistNextTimer
// DECL 0x863D032 Timer_EventManagement::Timer_EventManagement
// DECL 0x863E748 Timer_EventManagement::~Timer_EventManagement
// DECL 0x863E778 Timer_EventManagement::~Timer_EventManagement

#endif  // __IDA91_TIMER_EVENTMANAGEMENT_H__
