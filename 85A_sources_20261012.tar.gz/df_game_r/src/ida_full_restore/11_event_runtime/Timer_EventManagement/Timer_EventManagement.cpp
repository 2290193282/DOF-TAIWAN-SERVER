#include "Timer_EventManagement.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x863AB92
// IDA_NAME: _ZN21Timer_EventManagement12dispatch_sigEiij
// DEMANGLED: Timer_EventManagement::dispatch_sig(int,int,unsigned int)
int Timer_EventManagement::dispatch_sig()
{
  int tm_hour; // ebx
  CDataManager *v1; // eax
  EventClassify::CEventScriptMng *event_script_mngEv; // eax
  int v4; // [esp+4h] [ebp-14h]

  tm_hour = *(_DWORD *)(G_CEnvironment() + 892);
  v1 = (CDataManager *)G_CDataManager();
  event_script_mngEv = (EventClassify::CEventScriptMng *)CDataManager::get_event_script_mng(v1);
  EventClassify::CEventScriptMng::update_time_values(event_script_mngEv, tm_hour);
  Timer_EventManagement::RegistNextTimer((Timer_EventManagement *)0x3C, v4);
  return 1;
}

// IDA_EA: 0x863ABD4
// IDA_NAME: _ZN21Timer_EventManagement15RegistNextTimerEi
// DEMANGLED: Timer_EventManagement::RegistNextTimer(int)
int __cdecl Timer_EventManagement::RegistNextTimer(Timer_EventManagement *this)
{
  TimerQueue *v1; // eax

  v1 = (TimerQueue *)G_TimerQueue();
  return TimerQueue::InsertTimer(v1, 2, 0, 156, (int)this, 0, 0);
}

// IDA_EA: 0x863D032
// IDA_NAME: _ZN21Timer_EventManagementC2Ev
// DEMANGLED: Timer_EventManagement::Timer_EventManagement(void)
void __cdecl Timer_EventManagement::Timer_EventManagement(Timer_EventManagement *this)
{
  TimerSig::TimerSig(this);
  *(_DWORD *)this = &off_8CE86D0;
}

// IDA_EA: 0x863E748
// IDA_NAME: _ZN21Timer_EventManagementD2Ev
// DEMANGLED: Timer_EventManagement::~Timer_EventManagement()
void __cdecl Timer_EventManagement::~Timer_EventManagement(Timer_EventManagement *this)
{
  *(_DWORD *)this = &off_8CE86D0;
  TimerSig::~TimerSig(this);
}

// IDA_EA: 0x863E778
// IDA_NAME: _ZN21Timer_EventManagementD0Ev
// DEMANGLED: Timer_EventManagement::~Timer_EventManagement()
void __cdecl Timer_EventManagement::~Timer_EventManagement(Timer_EventManagement *this)
{
  Timer_EventManagement::~Timer_EventManagement(this);
  operator delete(this);
}
