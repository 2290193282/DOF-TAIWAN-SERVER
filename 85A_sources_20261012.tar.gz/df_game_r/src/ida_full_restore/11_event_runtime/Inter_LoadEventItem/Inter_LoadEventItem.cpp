#include "Inter_LoadEventItem.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84CF0C4
// IDA_NAME: _ZN19Inter_LoadEventItem12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_LoadEventItem::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_LoadEventItem::dispatch_sig(Inter_LoadEventItem *this, CUser *a2, char *a3)
{
  unsigned int acc_idEv; // ebx
  CGameManager *v4; // eax
  int CurCharacNoEv; // eax
  bool v7; // al
  Stream *v8; // eax
  Stream **v9; // eax
  Stream **v10; // eax
  Stream **v11; // eax
  unsigned int v12; // [esp+14h] [ebp-44h]
  _BYTE v13[8]; // [esp+24h] [ebp-34h] BYREF
  _DWORD s[6]; // [esp+2Ch] [ebp-2Ch] BYREF
  char *v15; // [esp+44h] [ebp-14h]
  CUserCharacInfo *UserByAccId; // [esp+48h] [ebp-10h]
  int i; // [esp+4Ch] [ebp-Ch]

  v15 = a3;
  acc_idEv = *(_DWORD *)a3;
  v4 = (CGameManager *)G_CGameManager();
  UserByAccId = CGameManager::GetUserByAccId(v4, acc_idEv);
  if ( !UserByAccId )
    return 0;
  memset(s, 0, sizeof(s));
  for ( i = 0; *((_DWORD *)v15 + 2) > i; ++i )
  {
    v7 = 0;
    if ( *(_DWORD *)&v15[16 * i + 16] != 999 )
    {
      if ( CUser::get_state(UserByAccId) <= 2
        || (CurCharacNoEv = CUserCharacInfo::getCurCharacNo(UserByAccId), CurCharacNoEv != *((_DWORD *)v15 + 1)) )
      {
        v7 = 1;
      }
    }
    if ( !v7
      && (unsigned __int8)WongWork::CWebEvent::RecvInfoFromDB(
                            UserByAccId,
                            *(CUser **)&v15[16 * i + 16],
                            *(char **)&v15[16 * i + 20],
                            *(WongWork::CWebEvent **)&v15[16 * i + 24],
                            *(_DWORD *)&v15[16 * i + 12],
                            v12) )
    {
      s[++s[0]] = *(_DWORD *)&v15[16 * i + 12];
    }
  }
  if ( s[0] )
  {
    v8 = StreamPool::Acquire(GlobalData::s_stream_pool, "InterDispatcher.cpp", 11295);
    CStreamGuard::CStreamGuard((CStreamGuard *)v13, v8, 1);
    v9 = (Stream **)CStreamGuard::operator*((int)v13);
    CStreamGuard::operator<<(v9, 77);
    v10 = (Stream **)CStreamGuard::operator*((int)v13);
    CStreamGuard::operator<<(v10, -1);
    v11 = (Stream **)CStreamGuard::operator->((int)v13);
    CStreamGuard::put_binary(v11, s, 0x18u);
    MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v13);
    CStreamGuard::~CStreamGuard((CStreamGuard *)v13);
  }
  return 0;
}

// IDA_EA: 0x84EB400
// IDA_NAME: _ZN19Inter_LoadEventItemC2Ev
// DEMANGLED: Inter_LoadEventItem::Inter_LoadEventItem(void)
void __cdecl Inter_LoadEventItem::Inter_LoadEventItem(Inter_LoadEventItem *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8F990;
}

// IDA_EA: 0x84EB41C
// IDA_NAME: _ZN19Inter_LoadEventItemD2Ev
// DEMANGLED: Inter_LoadEventItem::~Inter_LoadEventItem()
void __cdecl Inter_LoadEventItem::~Inter_LoadEventItem(Inter_LoadEventItem *this)
{
  *(_DWORD *)this = &off_8C8F990;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84EB44C
// IDA_NAME: _ZN19Inter_LoadEventItemD0Ev
// DEMANGLED: Inter_LoadEventItem::~Inter_LoadEventItem()
void __cdecl Inter_LoadEventItem::~Inter_LoadEventItem(Inter_LoadEventItem *this)
{
  Inter_LoadEventItem::~Inter_LoadEventItem(this);
  operator delete(this);
}
