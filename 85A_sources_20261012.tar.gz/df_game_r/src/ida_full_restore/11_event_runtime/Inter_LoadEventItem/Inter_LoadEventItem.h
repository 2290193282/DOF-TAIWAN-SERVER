#ifndef __IDA91_INTER_LOADEVENTITEM_H__
#define __IDA91_INTER_LOADEVENTITEM_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_LoadEventItem
// Source unit: Inter_LoadEventItem
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 2995

/* 2995 */
struct Inter_LoadEventItem;

// Exported member functions:
// 0x84CF0C4	Inter_LoadEventItem::dispatch_sig(CUser *,char *,int)
// 0x84EB400	Inter_LoadEventItem::Inter_LoadEventItem(void)
// 0x84EB41C	Inter_LoadEventItem::~Inter_LoadEventItem()
// 0x84EB44C	Inter_LoadEventItem::~Inter_LoadEventItem()

// Function declaration index:
// DECL 0x84CF0C4 Inter_LoadEventItem::dispatch_sig
// DECL 0x84EB400 Inter_LoadEventItem::Inter_LoadEventItem
// DECL 0x84EB41C Inter_LoadEventItem::~Inter_LoadEventItem
// DECL 0x84EB44C Inter_LoadEventItem::~Inter_LoadEventItem

#endif  // __IDA91_INTER_LOADEVENTITEM_H__
