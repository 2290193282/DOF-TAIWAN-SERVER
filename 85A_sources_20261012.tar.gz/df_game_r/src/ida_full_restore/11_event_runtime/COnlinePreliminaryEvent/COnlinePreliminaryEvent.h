#ifndef __IDA91_CONLINEPRELIMINARYEVENT_H__
#define __IDA91_CONLINEPRELIMINARYEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: COnlinePreliminaryEvent
// Source unit: COnlinePreliminaryEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4142

/* 4142 */
struct COnlinePreliminaryEvent;

// Exported member functions:
// 0x81BB490	COnlinePreliminaryEvent::COnlinePreliminaryEvent(void)
// 0x81BB4AC	COnlinePreliminaryEvent::~COnlinePreliminaryEvent()
// 0x81BB4DC	COnlinePreliminaryEvent::~COnlinePreliminaryEvent()
// 0x81BB4FA	COnlinePreliminaryEvent::StartEvent(void)
// 0x81BB56E	COnlinePreliminaryEvent::StartEvent(Word_Param)
// 0x81BB5E2	COnlinePreliminaryEvent::EndEvent(void)

// Function declaration index:
// DECL 0x81BB490 COnlinePreliminaryEvent::COnlinePreliminaryEvent
// DECL 0x81BB4AC COnlinePreliminaryEvent::~COnlinePreliminaryEvent
// DECL 0x81BB4DC COnlinePreliminaryEvent::~COnlinePreliminaryEvent
// DECL 0x81BB4FA COnlinePreliminaryEvent::StartEvent
// DECL 0x81BB56E COnlinePreliminaryEvent::StartEvent
// DECL 0x81BB5E2 COnlinePreliminaryEvent::EndEvent

#endif  // __IDA91_CONLINEPRELIMINARYEVENT_H__
