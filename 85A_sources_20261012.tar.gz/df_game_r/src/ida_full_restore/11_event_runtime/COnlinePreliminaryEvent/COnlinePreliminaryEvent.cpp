#include "COnlinePreliminaryEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81BB490
// IDA_NAME: _ZN23COnlinePreliminaryEventC2Ev
// DEMANGLED: COnlinePreliminaryEvent::COnlinePreliminaryEvent(void)
void __cdecl COnlinePreliminaryEvent::COnlinePreliminaryEvent(COnlinePreliminaryEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8BBF968;
}

// IDA_EA: 0x81BB4AC
// IDA_NAME: _ZN23COnlinePreliminaryEventD2Ev
// DEMANGLED: COnlinePreliminaryEvent::~COnlinePreliminaryEvent()
void __cdecl COnlinePreliminaryEvent::~COnlinePreliminaryEvent(COnlinePreliminaryEvent *this)
{
  *(_DWORD *)this = off_8BBF968;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x81BB4DC
// IDA_NAME: _ZN23COnlinePreliminaryEventD0Ev
// DEMANGLED: COnlinePreliminaryEvent::~COnlinePreliminaryEvent()
void __cdecl COnlinePreliminaryEvent::~COnlinePreliminaryEvent(COnlinePreliminaryEvent *this)
{
  COnlinePreliminaryEvent::~COnlinePreliminaryEvent(this);
  operator delete(this);
}

// IDA_EA: 0x81BB4FA
// IDA_NAME: _ZN23COnlinePreliminaryEvent10StartEventEv
// DEMANGLED: COnlinePreliminaryEvent::StartEvent(void)
char __cdecl COnlinePreliminaryEvent::StartEvent(COnlinePreliminaryEvent *this)
{
  GameWorld *v1; // eax
  char result; // al
  bool v3; // [esp+4h] [ebp-24h]
  char v4; // [esp+8h] [ebp-20h]
  int v5[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v5, "virtual void COnlinePreliminaryEvent::StartEvent()", 21, 0);
  cMyTrace::operator()((int)v5, "COnlinePreliminaryEvent Start!", v4);
  v1 = (GameWorld *)G_GameWorld();
  result = GameWorld::GetChannelType(v1) == 14;
  if ( result )
    return online_preliminary::COnlinePreliminary::SetMatchAble((online_preliminary::COnlinePreliminary *)1, v3);
  return result;
}

// IDA_EA: 0x81BB56E
// IDA_NAME: _ZN23COnlinePreliminaryEvent10StartEventE10Word_Param
// DEMANGLED: COnlinePreliminaryEvent::StartEvent(Word_Param)
char __cdecl COnlinePreliminaryEvent::StartEvent(CEventBase *a1)
{
  GameWorld *v1; // eax
  char result; // al
  bool v3; // [esp+4h] [ebp-24h]
  char v4; // [esp+8h] [ebp-20h]
  int v5[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  cMyTrace::cMyTrace((cMyTrace *)v5, "virtual void COnlinePreliminaryEvent::StartEvent(Word_Param)", 31, 0);
  cMyTrace::operator()((int)v5, "COnlinePreliminaryEvent Start!", v4);
  v1 = (GameWorld *)G_GameWorld();
  result = GameWorld::GetChannelType(v1) == 14;
  if ( result )
    return online_preliminary::COnlinePreliminary::SetMatchAble((online_preliminary::COnlinePreliminary *)1, v3);
  return result;
}

// IDA_EA: 0x81BB5E2
// IDA_NAME: _ZN23COnlinePreliminaryEvent8EndEventEv
// DEMANGLED: COnlinePreliminaryEvent::EndEvent(void)
char __cdecl COnlinePreliminaryEvent::EndEvent(COnlinePreliminaryEvent *this)
{
  GameWorld *v1; // eax
  char result; // al
  bool v3; // [esp+4h] [ebp-14h]

  CEventBase::SetEventFlag(this, 0);
  v1 = (GameWorld *)G_GameWorld();
  result = GameWorld::GetChannelType(v1) == 14;
  if ( result )
    return online_preliminary::COnlinePreliminary::SetMatchAble(0, v3);
  return result;
}
