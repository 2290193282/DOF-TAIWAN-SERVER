#include "Inter_OnTimeEventRewardStart.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84E0DC6
// IDA_NAME: _ZN28Inter_OnTimeEventRewardStart12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_OnTimeEventRewardStart::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_OnTimeEventRewardStart::dispatch_sig(Inter_OnTimeEventRewardStart *this, CUser *a2, char *a3)
{
  int v3; // ebx
  int v5; // ebx
  GameWorld *v6; // eax
  PacketBuf *v8[3]; // [esp+2Ch] [ebp-3Ch] BYREF
  int v9[4]; // [esp+38h] [ebp-30h] BYREF
  int v10[4]; // [esp+48h] [ebp-20h] BYREF
  char *v11; // [esp+58h] [ebp-10h]
  COnTimeEvent *RepeatEvent; // [esp+5Ch] [ebp-Ch]

  v11 = a3;
  v3 = *(_DWORD *)(a3 + 14);
  cMyTrace::cMyTrace(
    (cMyTrace *)v9,
    "virtual int Inter_OnTimeEventRewardStart::dispatch_sig(CUser*, char*, int)",
    20410,
    0);
  cMyTrace::operator()((int)v9, "[ON_TIME_EVENT] Reward Start(remain time : %u)", v3);
  RepeatEvent = (COnTimeEvent *)CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 51);
  if ( RepeatEvent
    && (*(unsigned __int8 (__cdecl **)(COnTimeEvent *, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) )
  {
    COnTimeEvent::process_set_reward_start(
      RepeatEvent,
      *(_DWORD *)(v11 + 10),
      *(_DWORD *)(v11 + 18),
      *(_DWORD *)(v11 + 22),
      *(_DWORD *)(v11 + 14));
    PacketGuard::PacketGuard((PacketGuard *)v8);
    InterfacePacketBuf::put_header(v8, 0, 261);
    InterfacePacketBuf::put_int(v8, *(_DWORD *)(v11 + 14));
    InterfacePacketBuf::finalize(v8, 1);
    v6 = (GameWorld *)G_GameWorld();
    GameWorld::send_all_with_state(v6, (PacketGuard *)v8, 3);
    PacketGuard::~PacketGuard(v8);
  }
  else
  {
    v5 = *(_DWORD *)(v11 + 10);
    cMyTrace::cMyTrace(
      (cMyTrace *)v10,
      "virtual int Inter_OnTimeEventRewardStart::dispatch_sig(CUser*, char*, int)",
      20421,
      5);
    cMyTrace::operator()((int)v10, "[ON_TIME_EVENT] isEventing = not, event_no(%u)", v5);
  }
  return 0;
}

// IDA_EA: 0x84EE650
// IDA_NAME: _ZN28Inter_OnTimeEventRewardStartC2Ev
// DEMANGLED: Inter_OnTimeEventRewardStart::Inter_OnTimeEventRewardStart(void)
void __cdecl Inter_OnTimeEventRewardStart::Inter_OnTimeEventRewardStart(Inter_OnTimeEventRewardStart *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8EB50;
}

// IDA_EA: 0x84F70DA
// IDA_NAME: _ZN28Inter_OnTimeEventRewardStartD2Ev
// DEMANGLED: Inter_OnTimeEventRewardStart::~Inter_OnTimeEventRewardStart()
void __cdecl Inter_OnTimeEventRewardStart::~Inter_OnTimeEventRewardStart(Inter_OnTimeEventRewardStart *this)
{
  *(_DWORD *)this = &off_8C8EB50;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84F710A
// IDA_NAME: _ZN28Inter_OnTimeEventRewardStartD0Ev
// DEMANGLED: Inter_OnTimeEventRewardStart::~Inter_OnTimeEventRewardStart()
void __cdecl Inter_OnTimeEventRewardStart::~Inter_OnTimeEventRewardStart(Inter_OnTimeEventRewardStart *this)
{
  Inter_OnTimeEventRewardStart::~Inter_OnTimeEventRewardStart(this);
  operator delete(this);
}
