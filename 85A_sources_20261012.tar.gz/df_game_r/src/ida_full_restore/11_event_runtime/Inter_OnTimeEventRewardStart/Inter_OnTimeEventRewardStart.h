#ifndef __IDA91_INTER_ONTIMEEVENTREWARDSTART_H__
#define __IDA91_INTER_ONTIMEEVENTREWARDSTART_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_OnTimeEventRewardStart
// Source unit: Inter_OnTimeEventRewardStart
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 3163

/* 3163 */
struct Inter_OnTimeEventRewardStart;

// Exported member functions:
// 0x84E0DC6	Inter_OnTimeEventRewardStart::dispatch_sig(CUser *,char *,int)
// 0x84EE650	Inter_OnTimeEventRewardStart::Inter_OnTimeEventRewardStart(void)
// 0x84F70DA	Inter_OnTimeEventRewardStart::~Inter_OnTimeEventRewardStart()
// 0x84F710A	Inter_OnTimeEventRewardStart::~Inter_OnTimeEventRewardStart()

// Function declaration index:
// DECL 0x84E0DC6 Inter_OnTimeEventRewardStart::dispatch_sig
// DECL 0x84EE650 Inter_OnTimeEventRewardStart::Inter_OnTimeEventRewardStart
// DECL 0x84F70DA Inter_OnTimeEventRewardStart::~Inter_OnTimeEventRewardStart
// DECL 0x84F710A Inter_OnTimeEventRewardStart::~Inter_OnTimeEventRewardStart

#endif  // __IDA91_INTER_ONTIMEEVENTREWARDSTART_H__
