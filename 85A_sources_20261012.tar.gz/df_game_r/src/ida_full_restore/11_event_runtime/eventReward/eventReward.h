#ifndef __IDA91_EVENTREWARD_H__
#define __IDA91_EVENTREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: eventReward
// Source unit: eventReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
//   #include "items/CEquipItem.h"
// Local type ordinals: 4089

/* 4089 */
struct eventReward;

// Exported member functions:
// 0x80EF0C0	eventReward::getSubKeyType(std::string &)
// 0x80EF128	eventReward::getSubKeyAction(std::string &)
// 0x80EF190	eventReward::getOptionType(std::string &,itemData &)
// 0x80EF25C	eventReward::defaultOption(char,itemData &)
// 0x80EF29C	eventReward::importRewardTable(char const*,char const*)
// 0x80EF3A2	eventReward::ImportRewardScript(char const*,char const*)
// 0x80F0270	eventReward::createCharacInvenReward(Inven_Item *,rewardKey,int)
// 0x80F033C	eventReward::createCharacEquipReward(Inven_Item *,rewardKey,int)
// 0x80F0408	eventReward::rewardWriteUserInven(Inven_Item *,rewardKey,int)
// 0x80F06DA	eventReward::rewardWriteUserEquip(Inven_Item *,rewardKey,int)
// 0x80F0976	eventReward::sendPostalReward(CUser &,rewardKey,int,char const*,char const*)
// 0x80F0D22	eventReward::StartEndPos(Inven_Item::ITEM_TYPE,int &,int &,int)const
// 0x80F0D6E	eventReward::applyItemOption(Inven_Item &,CItem const*,itemData const&)
// 0x80F0E40	eventReward::unsealRandomOption(CItem const*,Inven_Item &)
// 0x83738A2	eventReward::eventReward(void)
// 0x837DFB2	eventReward::~eventReward()

// Function declaration index:
// DECL 0x80EF0C0 eventReward::getSubKeyType
// DECL 0x80EF128 eventReward::getSubKeyAction
// DECL 0x80EF190 eventReward::getOptionType
// DECL 0x80EF25C eventReward::defaultOption
// DECL 0x80EF29C eventReward::importRewardTable
// DECL 0x80EF3A2 eventReward::ImportRewardScript
// DECL 0x80F0270 eventReward::createCharacInvenReward
// DECL 0x80F033C eventReward::createCharacEquipReward
// DECL 0x80F0408 eventReward::rewardWriteUserInven
// DECL 0x80F06DA eventReward::rewardWriteUserEquip
// DECL 0x80F0976 eventReward::sendPostalReward
// DECL 0x80F0D22 eventReward::StartEndPos
// DECL 0x80F0D6E eventReward::applyItemOption
// DECL 0x80F0E40 eventReward::unsealRandomOption
// DECL 0x83738A2 eventReward::eventReward
// DECL 0x837DFB2 eventReward::~eventReward

#endif  // __IDA91_EVENTREWARD_H__
