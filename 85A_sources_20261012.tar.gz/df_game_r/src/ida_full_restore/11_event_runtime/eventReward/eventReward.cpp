#include "eventReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x80EF0C0
// IDA_NAME: _ZN11eventReward13getSubKeyTypeERSs
// DEMANGLED: eventReward::getSubKeyType(std::string &)
int __cdecl eventReward::getSubKeyType(eventReward *this, std::string *a2)
{
  if ( std::operator==<char>(a2, "common") )
    return 0;
  if ( std::operator==<char>(a2, "level") )
    return 1;
  if ( std::operator==<char>(a2, "fatigue") )
    return 2;
  return 0;
}

// IDA_EA: 0x80EF128
// IDA_NAME: _ZN11eventReward15getSubKeyActionERSs
// DEMANGLED: eventReward::getSubKeyAction(std::string &)
int __cdecl eventReward::getSubKeyAction(eventReward *this, std::string *a2)
{
  if ( std::operator==<char>(a2, "equip") )
    return 2;
  if ( std::operator==<char>(a2, "inven") )
    return 1;
  if ( std::operator==<char>(a2, "postal") )
    return 3;
  return 0;
}

// IDA_EA: 0x80EF190
// IDA_NAME: _ZN11eventReward13getOptionTypeERSsR8itemData
// DEMANGLED: eventReward::getOptionType(std::string &,itemData &)
_BOOL4 __cdecl eventReward::getOptionType(eventReward *this, std::string *a2, itemData *a3)
{
  bool v4; // [esp+1Fh] [ebp-9h] BYREF

  v4 = 1;
  if ( std::operator==<char>(a2, "unseal") )
  {
    *((_BYTE *)a3 + 1) = 0;
  }
  else if ( std::operator==<char>(a2, "seal") )
  {
    *((_BYTE *)a3 + 1) = 1;
  }
  else if ( std::operator==<char>(a2, "upgrade") )
  {
    *(_BYTE *)a3 = ScanInt(&v4);
    if ( !v4 )
      return 0;
  }
  else if ( std::operator==<char>(a2, "unsealROI") )
  {
    *((_BYTE *)a3 + 2) = 0;
  }
  else if ( std::operator==<char>(a2, "sealROI") )
  {
    *((_BYTE *)a3 + 2) = 1;
  }
  return v4;
}

// IDA_EA: 0x80EF25C
// IDA_NAME: _ZN11eventReward13defaultOptionEcR8itemData
// DEMANGLED: eventReward::defaultOption(char,itemData &)
itemData *__cdecl eventReward::defaultOption(eventReward *this, char n2, itemData *a3)
{
  itemData *result; // eax

  if ( n2 == 2 )
  {
    *((_DWORD *)a3 + 2) = 1;
    *((_BYTE *)a3 + 1) = 0;
    *((_BYTE *)a3 + 2) = 0;
  }
  result = (itemData *)*(unsigned __int8 *)a3;
  if ( !(_BYTE)result )
  {
    result = a3;
    *(_BYTE *)a3 = 1;
  }
  return result;
}

// IDA_EA: 0x80EF29C
// IDA_NAME: _ZN11eventReward17importRewardTableEPKcS1_
// DEMANGLED: eventReward::importRewardTable(char const*,char const*)
int __cdecl eventReward::importRewardTable(eventReward *this, TCHAR *Event_EventReward, TCHAR *p_reward.evt)
{
  std::string *v3; // eax
  TCHAR *filename; // eax
  int n113; // ebx
  int v7; // [esp+10h] [ebp-28h] BYREF
  std::_Rb_tree_node_base *v8; // [esp+14h] [ebp-24h] BYREF
  _BYTE v9[32]; // [esp+18h] [ebp-20h] BYREF

  STScriptFileList::STScriptFileList((STScriptFileList *)v9);
  if ( (unsigned __int8)loadRDARScriptListFile((STScriptFileList *)v9, Event_EventReward, p_reward.evt) )
  {
    std::map<int,std::string>::begin((int)&v8);
    std::map<int,std::string>::end((int)&v7);
    while ( std::_Rb_tree_iterator<std::pair<int const,std::string>>::operator!=(&v8, &v7) )
    {
      v3 = (std::string *)std::_Rb_tree_iterator<std::pair<int const,std::string>>::operator->(&v8);
      filename = (TCHAR *)std::string::c_str(v3 + 1);
      if ( !eventReward::ImportRewardScript(this, Event_EventReward, filename) )
      {
        n113 = 113;
        goto LABEL_9;
      }
      std::_Rb_tree_iterator<std::pair<int const,std::string>>::operator++(&v8);
    }
    n113 = 0;
  }
  else
  {
    n113 = 119;
  }
LABEL_9:
  STScriptFileList::~STScriptFileList(v9);
  return n113;
}

// IDA_EA: 0x80EF3A2
// IDA_NAME: _ZN11eventReward18ImportRewardScriptEPKcS1_
// DEMANGLED: eventReward::ImportRewardScript(char const*,char const*)
_BOOL4 __usercall eventReward::ImportRewardScript@<eax>(
        _BOOL4 a1@<ebx>,
        eventReward *this,
        TCHAR *dir,
        TCHAR *filename)
{
  int n175_2; // eax
  int v5; // esi
  _BOOL4 v6; // esi
  int v7; // esi
  int v8; // eax
  int v9; // eax
  _BYTE v11[12]; // [esp+1Ch] [ebp-20Ch] BYREF
  _BYTE v12[4]; // [esp+28h] [ebp-200h] BYREF
  int v13; // [esp+2Ch] [ebp-1FCh] BYREF
  int v14; // [esp+30h] [ebp-1F8h]
  int v15; // [esp+34h] [ebp-1F4h]
  int v16; // [esp+38h] [ebp-1F0h]
  _BYTE v17[12]; // [esp+3Ch] [ebp-1ECh] BYREF
  _BYTE v18[4]; // [esp+48h] [ebp-1E0h] BYREF
  int v19; // [esp+4Ch] [ebp-1DCh] BYREF
  int v20; // [esp+50h] [ebp-1D8h]
  int v21; // [esp+54h] [ebp-1D4h]
  int v22; // [esp+58h] [ebp-1D0h]
  std::string v23; // [esp+5Ch] [ebp-1CCh] BYREF
  std::string v24; // [esp+60h] [ebp-1C8h] BYREF
  std::string v25; // [esp+64h] [ebp-1C4h] BYREF
  std::string v26; // [esp+68h] [ebp-1C0h] BYREF
  _BYTE v27[4]; // [esp+6Ch] [ebp-1BCh] BYREF
  int v28; // [esp+70h] [ebp-1B8h] BYREF
  int v29; // [esp+74h] [ebp-1B4h]
  int v30; // [esp+78h] [ebp-1B0h]
  _BYTE v31[3]; // [esp+7Fh] [ebp-1A9h] BYREF
  char SubKeyTypeERSs; // [esp+82h] [ebp-1A6h] BYREF
  char SubKeyActionERSs; // [esp+83h] [ebp-1A5h]
  bool v34[27]; // [esp+84h] [ebp-1A4h] BYREF
  bool v35; // [esp+9Fh] [ebp-189h] BYREF
  std::string v36; // [esp+A0h] [ebp-188h] BYREF
  _BYTE v37[4]; // [esp+A4h] [ebp-184h] BYREF
  int v38; // [esp+A8h] [ebp-180h]
  _BYTE v39[4]; // [esp+ACh] [ebp-17Ch] BYREF
  _BYTE v40[4]; // [esp+B0h] [ebp-178h] BYREF
  _BYTE v41[8]; // [esp+B4h] [ebp-174h] BYREF
  _BYTE v42[8]; // [esp+BCh] [ebp-16Ch] BYREF
  int n143; // [esp+C4h] [ebp-164h] BYREF
  _BYTE v44[8]; // [esp+C8h] [ebp-160h] BYREF
  _BYTE v45[8]; // [esp+D0h] [ebp-158h] BYREF
  int n147; // [esp+D8h] [ebp-150h] BYREF
  _BYTE v47[8]; // [esp+DCh] [ebp-14Ch] BYREF
  _BYTE v48[8]; // [esp+E4h] [ebp-144h] BYREF
  int n163; // [esp+ECh] [ebp-13Ch] BYREF
  _BYTE v50[8]; // [esp+F0h] [ebp-138h] BYREF
  _BYTE v51[8]; // [esp+F8h] [ebp-130h] BYREF
  int n175_1; // [esp+100h] [ebp-128h] BYREF
  _BYTE v53[8]; // [esp+104h] [ebp-124h] BYREF
  _BYTE v54[8]; // [esp+10Ch] [ebp-11Ch] BYREF
  int n185; // [esp+114h] [ebp-114h] BYREF
  _BYTE v56[4]; // [esp+118h] [ebp-110h] BYREF
  _BYTE v57[8]; // [esp+11Ch] [ebp-10Ch] BYREF
  _BYTE v58[16]; // [esp+124h] [ebp-104h] BYREF
  _BYTE v59[16]; // [esp+134h] [ebp-F4h] BYREF
  _BYTE v60[8]; // [esp+144h] [ebp-E4h] BYREF
  _BYTE v61[8]; // [esp+14Ch] [ebp-DCh] BYREF
  int n216; // [esp+154h] [ebp-D4h] BYREF
  _BYTE v63[4]; // [esp+158h] [ebp-D0h] BYREF
  _BYTE v64[8]; // [esp+15Ch] [ebp-CCh] BYREF
  _BYTE v65[16]; // [esp+164h] [ebp-C4h] BYREF
  _BYTE v66[16]; // [esp+174h] [ebp-B4h] BYREF
  _BYTE v67[8]; // [esp+184h] [ebp-A4h] BYREF
  _BYTE v68[8]; // [esp+18Ch] [ebp-9Ch] BYREF
  int n252; // [esp+194h] [ebp-94h] BYREF
  _BYTE v70[8]; // [esp+198h] [ebp-90h] BYREF
  _BYTE v71[32]; // [esp+1A0h] [ebp-88h] BYREF
  _BYTE v72[32]; // [esp+1C0h] [ebp-68h] BYREF
  _BYTE v73[8]; // [esp+1E0h] [ebp-48h] BYREF
  _BYTE v74[8]; // [esp+1E8h] [ebp-40h] BYREF
  int n258; // [esp+1F0h] [ebp-38h] BYREF
  _BYTE v76[8]; // [esp+1F4h] [ebp-34h] BYREF
  _BYTE v77[8]; // [esp+1FCh] [ebp-2Ch] BYREF
  _DWORD v78[2]; // [esp+204h] [ebp-24h] BYREF
  int n175; // [esp+20Ch] [ebp-1Ch]

  if ( (unsigned __int8)loadRDARScriptFile(dir, filename) != 1 )
    return 0;
  std::string::string(&v36);
  v35 = 0;
  std::map<int,std::vector<itemData>>::map(v34);
  rewardKey::rewardKey((rewardKey *)v31);
  v78[1] = 0;
  itemData::itemData((itemData *)&v28);
LABEL_4:
  if ( (unsigned __int8)ScanType(&v36, 1) == 1 )
  {
    while ( 1 )
    {
      while ( 1 )
      {
        if ( !(_BYTE)`guard variable for'eventReward::ImportRewardScript(char const*,char const*)::__lookup
          && _cxa_guard_acquire(&`guard variable for'eventReward::ImportRewardScript(char const*,char const*)::__lookup) )
        {
          std::map<char const*,int,less_TCHAR,std::allocator<std::pair<char const* const,int>>>::map(&eventReward::ImportRewardScript(char const*,char const*)::__lookup);
          _cxa_guard_release(&`guard variable for'eventReward::ImportRewardScript(char const*,char const*)::__lookup);
          __cxa_atexit(
            std::map<char const*,int,less_TCHAR,std::allocator<std::pair<char const* const,int>>>::~map,
            &eventReward::ImportRewardScript(char const*,char const*)::__lookup,
            &_dso_handle);
        }
        if ( !(_BYTE)`guard variable for'eventReward::ImportRewardScript(char const*,char const*)::__init_lock
          && _cxa_guard_acquire(&`guard variable for'eventReward::ImportRewardScript(char const*,char const*)::__init_lock) )
        {
          SpinLock::SpinLock(&eventReward::ImportRewardScript(char const*,char const*)::__init_lock);
          _cxa_guard_release(&`guard variable for'eventReward::ImportRewardScript(char const*,char const*)::__init_lock);
          __cxa_atexit(
            (void (*)(void *))SpinLock::~SpinLock,
            &eventReward::ImportRewardScript(char const*,char const*)::__init_lock,
            &_dso_handle);
        }
        if ( !eventReward::ImportRewardScript(char const*,char const*)::__inited )
          break;
        v38 = std::string::c_str(&v36);
        std::map<char const*,int,less_TCHAR,std::allocator<std::pair<char const* const,int>>>::find(v37);
        std::_Rb_tree_const_iterator<std::pair<char const* const,int>>::_Rb_tree_const_iterator(v27, v37);
        std::map<char const*,int,less_TCHAR,std::allocator<std::pair<char const* const,int>>>::end(v40);
        std::_Rb_tree_const_iterator<std::pair<char const* const,int>>::_Rb_tree_const_iterator(v39, v40);
        if ( (unsigned __int8)std::_Rb_tree_const_iterator<std::pair<char const* const,int>>::operator!=(v27, v39) )
          n175_2 = *(_DWORD *)(std::_Rb_tree_const_iterator<std::pair<char const* const,int>>::operator->(v27) + 4);
        else
          n175_2 = -1;
        n175 = n175_2;
LABEL_19:
        if ( n175 == 175 )
          goto LABEL_60;
        if ( n175 <= 175 )
        {
          if ( n175 == 143 )
            goto LABEL_36;
          if ( n175 > 143 )
          {
            if ( n175 == 147 )
              goto LABEL_39;
            if ( n175 != 163 )
              goto LABEL_91;
          }
          else
          {
            if ( n175 )
              goto LABEL_91;
LABEL_36:
            if ( eventReward::ImportRewardScript(char const*,char const*)::__inited == 1 )
            {
              a1 = 1;
              goto LABEL_94;
            }
            n143 = 143;
            std::pair<char const* const,int>::pair<char const(&)[10],int>(v42, "[/reward]", &n143);
            std::map<char const*,int,less_TCHAR,std::allocator<std::pair<char const* const,int>>>::insert(v41);
LABEL_39:
            if ( eventReward::ImportRewardScript(char const*,char const*)::__inited == 1 )
            {
              std::string::string(&v26);
              if ( (unsigned __int8)ScanStr(&v26) == 1 )
              {
                v31[0] = getCharacterJobToEnumValue(&v26);
                v31[1] = ScanInt(&v35);
                if ( v35 )
                {
                  v31[2] = ScanInt(&v35);
                  if ( v35 )
                  {
                    v5 = 1;
                  }
                  else
                  {
                    a1 = 0;
                    v5 = 0;
                  }
                }
                else
                {
                  a1 = 0;
                  v5 = 0;
                }
              }
              else
              {
                a1 = 0;
                v5 = 0;
              }
              std::string::~string(&v26);
              if ( !v5 )
                goto LABEL_94;
              goto LABEL_91;
            }
            n147 = 147;
            std::pair<char const* const,int>::pair<char const(&)[11],int>(v45, "[job type]", &n147);
            std::map<char const*,int,less_TCHAR,std::allocator<std::pair<char const* const,int>>>::insert(v44);
          }
          if ( eventReward::ImportRewardScript(char const*,char const*)::__inited == 1 )
          {
            std::string::string(&v25);
            if ( (unsigned __int8)ScanStr(&v25) == 1 )
            {
              SubKeyTypeERSs = eventReward::getSubKeyType(this, &v25);
              std::string::string(&v24);
              if ( (unsigned __int8)ScanStr(&v24) == 1 )
              {
                SubKeyActionERSs = eventReward::getSubKeyAction(this, &v24);
                v7 = 1;
              }
              else
              {
                a1 = 0;
                v7 = 0;
              }
              std::string::~string(&v24);
              v6 = v7 != 0;
            }
            else
            {
              a1 = 0;
              v6 = 0;
            }
            std::string::~string(&v25);
            if ( !v6 )
              goto LABEL_94;
            goto LABEL_91;
          }
          n163 = 163;
          std::pair<char const* const,int>::pair<char const(&)[11],int>(v48, "[sub type]", &n163);
          std::map<char const*,int,less_TCHAR,std::allocator<std::pair<char const* const,int>>>::insert(v47);
LABEL_60:
          if ( eventReward::ImportRewardScript(char const*,char const*)::__inited == 1 )
          {
            std::string::string(&v23);
            if ( (unsigned __int8)ScanStr(&v23) == 1 )
              eventReward::getOptionType(this, &v23, (itemData *)&v28);
            std::string::~string(&v23);
            goto LABEL_91;
          }
          n175_1 = 175;
          std::pair<char const* const,int>::pair<char const(&)[9],int>(v51, "[option]", &n175_1);
          std::map<char const*,int,less_TCHAR,std::allocator<std::pair<char const* const,int>>>::insert(v50);
LABEL_65:
          if ( eventReward::ImportRewardScript(char const*,char const*)::__inited == 1 )
          {
            eventReward::defaultOption(this, SubKeyActionERSs, (itemData *)&v28);
            while ( 1 )
            {
              v22 = 0;
              v19 = v28;
              v20 = v29;
              v21 = v30;
              v22 = ScanInt(&v35);
              if ( !v35 )
                break;
              v20 = ScanInt(&v35);
              if ( !v35 )
                break;
              std::map<int,std::vector<itemData>>::find(v18);
              std::map<int,std::vector<itemData>>::end(v56);
              if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,std::vector<itemData>>>::operator!=(
                                      v18,
                                      v56) )
              {
                v8 = std::_Rb_tree_iterator<std::pair<int const,std::vector<itemData>>>::operator->(v18);
                std::vector<itemData>::push_back(v8 + 4, &v19);
              }
              else
              {
                std::vector<itemData>::vector(v17);
                std::vector<itemData>::push_back(v17, &v19);
                std::make_pair<int &,std::vector<itemData> &>(v59);
                std::pair<int const,std::vector<itemData>>::pair<int,std::vector<itemData>>(v58, v59);
                std::map<int,std::vector<itemData>>::insert(v57);
                std::pair<int const,std::vector<itemData>>::~pair(v58);
                std::pair<int,std::vector<itemData>>::~pair(v59);
                std::vector<itemData>::~vector(v17);
              }
            }
            goto LABEL_91;
          }
          n185 = 185;
          std::pair<char const* const,int>::pair<char const(&)[17],int>(v54, "[equipment item]", &n185);
          std::map<char const*,int,less_TCHAR,std::allocator<std::pair<char const* const,int>>>::insert(v53);
          goto LABEL_73;
        }
        if ( n175 == 252 )
          goto LABEL_82;
        if ( n175 > 252 )
        {
          if ( n175 != 258 )
          {
            if ( n175 != 263 )
              goto LABEL_91;
            goto LABEL_88;
          }
LABEL_85:
          if ( eventReward::ImportRewardScript(char const*,char const*)::__inited == 1 )
          {
            rewardKey::clear((rewardKey *)v31);
            std::map<int,std::vector<itemData>>::clear(v34);
            goto LABEL_91;
          }
          n258 = 258;
          std::pair<char const* const,int>::pair<char const(&)[12],int>(v74, "[/job type]", &n258);
          std::map<char const*,int,less_TCHAR,std::allocator<std::pair<char const* const,int>>>::insert(v73);
LABEL_88:
          if ( eventReward::ImportRewardScript(char const*,char const*)::__inited == 1 )
          {
            itemData::clear((itemData *)&v28);
          }
          else
          {
            v78[0] = 263;
            std::pair<char const* const,int>::pair<char const(&)[10],int>(v77, "[/option]", v78);
            std::map<char const*,int,less_TCHAR,std::allocator<std::pair<char const* const,int>>>::insert(v76);
          }
          goto LABEL_91;
        }
        if ( n175 == 185 )
          goto LABEL_65;
        if ( n175 != 216 )
          goto LABEL_91;
LABEL_73:
        if ( eventReward::ImportRewardScript(char const*,char const*)::__inited != 1 )
        {
          n216 = 216;
          std::pair<char const* const,int>::pair<char const(&)[17],int>(v61, "[stackable item]", &n216);
          std::map<char const*,int,less_TCHAR,std::allocator<std::pair<char const* const,int>>>::insert(v60);
LABEL_82:
          if ( eventReward::ImportRewardScript(char const*,char const*)::__inited == 1 )
          {
            std::make_pair<rewardKey &,std::map<int,std::vector<itemData>> &>(v72);
            std::pair<rewardKey const,std::map<int,std::vector<itemData>>>::pair<rewardKey,std::map<int,std::vector<itemData>>>(
              v71,
              v72);
            std::map<rewardKey,std::map<int,std::vector<itemData>>>::insert(v70);
            std::pair<rewardKey const,std::map<int,std::vector<itemData>>>::~pair(v71);
            std::pair<rewardKey,std::map<int,std::vector<itemData>>>::~pair(v72);
            rewardSubKey::clear((rewardSubKey *)&SubKeyTypeERSs);
            std::map<int,std::vector<itemData>>::clear(v34);
            goto LABEL_91;
          }
          n252 = 252;
          std::pair<char const* const,int>::pair<char const(&)[12],int>(v68, "[/sub type]", &n252);
          std::map<char const*,int,less_TCHAR,std::allocator<std::pair<char const* const,int>>>::insert(v67);
          goto LABEL_85;
        }
        eventReward::defaultOption(this, SubKeyActionERSs, (itemData *)&v28);
        while ( 1 )
        {
          v16 = 0;
          v30 = 1;
          v13 = v28;
          v14 = v29;
          v15 = 1;
          v16 = ScanInt(&v35);
          if ( !v35 )
            break;
          v14 = ScanInt(&v35);
          if ( !v35 )
            break;
          v15 = ScanInt(&v35);
          if ( !v35 )
            break;
          std::map<int,std::vector<itemData>>::find(v12);
          std::map<int,std::vector<itemData>>::end(v63);
          if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,std::vector<itemData>>>::operator!=(v12, v63) )
          {
            v9 = std::_Rb_tree_iterator<std::pair<int const,std::vector<itemData>>>::operator->(v12);
            std::vector<itemData>::push_back(v9 + 4, &v13);
          }
          else
          {
            std::vector<itemData>::vector(v11);
            std::vector<itemData>::push_back(v11, &v13);
            std::make_pair<int &,std::vector<itemData> &>(v66);
            std::pair<int const,std::vector<itemData>>::pair<int,std::vector<itemData>>(v65, v66);
            std::map<int,std::vector<itemData>>::insert(v64);
            std::pair<int const,std::vector<itemData>>::~pair(v65);
            std::pair<int,std::vector<itemData>>::~pair(v66);
            std::vector<itemData>::~vector(v11);
          }
        }
LABEL_91:
        if ( eventReward::ImportRewardScript(char const*,char const*)::__inited == 1 )
          goto LABEL_4;
        SpinLock::leave(&eventReward::ImportRewardScript(char const*,char const*)::__init_lock);
        eventReward::ImportRewardScript(char const*,char const*)::__inited = 1;
      }
      SpinLock::enter(&eventReward::ImportRewardScript(char const*,char const*)::__init_lock);
      if ( !eventReward::ImportRewardScript(char const*,char const*)::__inited )
      {
        n175 = 0;
        goto LABEL_19;
      }
      SpinLock::leave(&eventReward::ImportRewardScript(char const*,char const*)::__init_lock);
    }
  }
  a1 = v35;
LABEL_94:
  std::map<int,std::vector<itemData>>::~map(v34);
  std::string::~string(&v36);
  return a1;
}

// IDA_EA: 0x80F0270
// IDA_NAME: _ZN11eventReward23createCharacInvenRewardEP10Inven_Item9rewardKeyi
// DEMANGLED: eventReward::createCharacInvenReward(Inven_Item *,rewardKey,int)
_BOOL4 __cdecl eventReward::createCharacInvenReward(int a1, int a2, int a3, char a4, int a5)
{
  int v5; // eax
  int v6; // eax
  int v7; // eax
  int v10; // [esp+Ch] [ebp-2Ch]
  int v11; // [esp+Ch] [ebp-2Ch]
  bool v12; // [esp+2Fh] [ebp-9h]

  v5 = G_CDataManager();
  v12 = (unsigned __int8)eventReward::rewardWriteUserInven(v5 + 46632, a2, a3, a4, a5) != 0;
  BYTE1(a3) = 0;
  v6 = G_CDataManager();
  LOBYTE(v10) = 1;
  if ( (unsigned __int8)eventReward::rewardWriteUserInven(v6 + 46632, a2, a3, v10, a5) )
    v12 = 1;
  LOWORD(a3) = 11;
  v7 = G_CDataManager();
  LOBYTE(v11) = 1;
  if ( (unsigned __int8)eventReward::rewardWriteUserInven(v7 + 46632, a2, a3, v11, a5) )
    return 1;
  return v12;
}

// IDA_EA: 0x80F033C
// IDA_NAME: _ZN11eventReward23createCharacEquipRewardEP10Inven_Item9rewardKeyi
// DEMANGLED: eventReward::createCharacEquipReward(Inven_Item *,rewardKey,int)
_BOOL4 __cdecl eventReward::createCharacEquipReward(int a1, int a2, int a3, char a4, int a5)
{
  int v5; // eax
  int v6; // eax
  int v7; // eax
  int v10; // [esp+Ch] [ebp-2Ch]
  int v11; // [esp+Ch] [ebp-2Ch]
  bool v12; // [esp+2Fh] [ebp-9h]

  v5 = G_CDataManager();
  v12 = (unsigned __int8)eventReward::rewardWriteUserEquip(v5 + 46632, a2, a3, a4, a5) != 0;
  BYTE1(a3) = 0;
  v6 = G_CDataManager();
  LOBYTE(v10) = 2;
  if ( (unsigned __int8)eventReward::rewardWriteUserEquip(v6 + 46632, a2, a3, v10, a5) )
    v12 = 1;
  LOWORD(a3) = 11;
  v7 = G_CDataManager();
  LOBYTE(v11) = 2;
  if ( (unsigned __int8)eventReward::rewardWriteUserEquip(v7 + 46632, a2, a3, v11, a5) )
    return 1;
  return v12;
}

// IDA_EA: 0x80F0408
// IDA_NAME: _ZN11eventReward20rewardWriteUserInvenEP10Inven_Item9rewardKeyi
// DEMANGLED: eventReward::rewardWriteUserInven(Inven_Item *,rewardKey,int)
int __cdecl eventReward::rewardWriteUserInven(eventReward *a1, int a2, int a3, int a4, char a5)
{
  unsigned int n2; // ebx
  CItemList **v7; // eax
  const itemData *v8; // eax
  int v9; // eax
  char *v10; // [esp+8h] [ebp-A0h]
  __int64 v11; // [esp+2Fh] [ebp-79h] BYREF
  int v12; // [esp+37h] [ebp-71h]
  int v13; // [esp+3Bh] [ebp-6Dh]
  int v14; // [esp+3Fh] [ebp-69h]
  int v15; // [esp+43h] [ebp-65h]
  int v16; // [esp+47h] [ebp-61h]
  int v17; // [esp+4Bh] [ebp-5Dh]
  int v18; // [esp+4Fh] [ebp-59h]
  int v19; // [esp+53h] [ebp-55h]
  int v20; // [esp+57h] [ebp-51h]
  int v21; // [esp+5Bh] [ebp-4Dh]
  int v22; // [esp+5Fh] [ebp-49h]
  int v23; // [esp+63h] [ebp-45h]
  int v24; // [esp+67h] [ebp-41h]
  char v25; // [esp+6Bh] [ebp-3Dh]
  int v26; // [esp+6Ch] [ebp-3Ch] BYREF
  int v27; // [esp+70h] [ebp-38h] BYREF
  _BYTE v28[4]; // [esp+74h] [ebp-34h] BYREF
  _BYTE v29[4]; // [esp+78h] [ebp-30h] BYREF
  _BYTE v30[4]; // [esp+7Ch] [ebp-2Ch] BYREF
  _BYTE v31[4]; // [esp+80h] [ebp-28h] BYREF
  _BYTE v32[4]; // [esp+84h] [ebp-24h] BYREF
  _BYTE v33[4]; // [esp+88h] [ebp-20h] BYREF
  _BYTE v34[4]; // [esp+8Ch] [ebp-1Ch] BYREF
  int v35; // [esp+90h] [ebp-18h]
  int v36; // [esp+94h] [ebp-14h]
  CItem *item; // [esp+98h] [ebp-10h]
  int i; // [esp+9Ch] [ebp-Ch]

  if ( (unsigned __int8)std::map<rewardKey,std::map<int,std::vector<itemData>>>::empty(a1) )
    return 0;
  std::map<rewardKey,std::map<int,std::vector<itemData>>>::find(v30);
  std::map<rewardKey,std::map<int,std::vector<itemData>>>::end(v31);
  if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<rewardKey const,std::map<int,std::vector<itemData>>>>::operator==(
                          v30,
                          v31) )
    return 0;
  v35 = std::_Rb_tree_iterator<std::pair<rewardKey const,std::map<int,std::vector<itemData>>>>::operator->(v30) + 8;
  v10 = &a5;
  std::map<int,std::vector<itemData>>::find(v29);
  std::map<int,std::vector<itemData>>::end(v32);
  if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,std::vector<itemData>>>::operator==(v29, v32) )
    return 0;
  v36 = std::_Rb_tree_iterator<std::pair<int const,std::vector<itemData>>>::operator->(v29) + 4;
  if ( (unsigned __int8)std::vector<itemData>::empty(v36) )
    return 0;
  std::vector<itemData>::begin(v28);
  while ( 1 )
  {
    std::vector<itemData>::end(v33);
    if ( !(unsigned __int8)__gnu_cxx::operator!=<itemData *,std::vector<itemData>>(v28, v33) )
      return 1;
    n2 = *(_DWORD *)(__gnu_cxx::__normal_iterator<itemData *,std::vector<itemData>>::operator->(v28) + 4);
    v7 = (CItemList **)G_CDataManager();
    item = (CItem *)CDataManager::find_item(v7, n2);
    if ( !item )
      return 0;
    Inven_Item::Inven_Item((Inven_Item *)&v11);
    *(_DWORD *)((char *)&v11 + 2) = *(_DWORD *)(__gnu_cxx::__normal_iterator<itemData *,std::vector<itemData>>::operator->(v28)
                                              + 4);
    (*(void (__cdecl **)(CItem *, __int64 *, char *))(*(_DWORD *)item + 8))(item, &v11, v10);
    v8 = (const itemData *)__gnu_cxx::__normal_iterator<itemData *,std::vector<itemData>>::operator*(v28);
    eventReward::applyItemOption(a1, (Inven_Item *)&v11, item, v8);
    v27 = 0;
    v26 = 0;
    eventReward::StartEndPos(a1, BYTE1(v11), &v27, &v26, 0);
    for ( i = v27; i <= v26; ++i )
    {
      if ( !*(_DWORD *)(a2 + 61 * i + 2) )
      {
        v9 = a2 + 61 * i;
        *(_QWORD *)v9 = v11;
        *(_DWORD *)(v9 + 8) = v12;
        *(_DWORD *)(v9 + 12) = v13;
        *(_DWORD *)(v9 + 16) = v14;
        *(_DWORD *)(v9 + 20) = v15;
        *(_DWORD *)(v9 + 24) = v16;
        *(_DWORD *)(v9 + 28) = v17;
        *(_DWORD *)(v9 + 32) = v18;
        *(_DWORD *)(v9 + 36) = v19;
        *(_DWORD *)(v9 + 40) = v20;
        *(_DWORD *)(v9 + 44) = v21;
        *(_DWORD *)(v9 + 48) = v22;
        *(_DWORD *)(v9 + 52) = v23;
        *(_DWORD *)(v9 + 56) = v24;
        *(_BYTE *)(v9 + 60) = v25;
        break;
      }
    }
    v10 = 0;
    __gnu_cxx::__normal_iterator<itemData *,std::vector<itemData>>::operator++(v34);
  }
}

// IDA_EA: 0x80F06DA
// IDA_NAME: _ZN11eventReward20rewardWriteUserEquipEP10Inven_Item9rewardKeyi
// DEMANGLED: eventReward::rewardWriteUserEquip(Inven_Item *,rewardKey,int)
int __cdecl eventReward::rewardWriteUserEquip(eventReward *a1, int a2, int a3, int a4, char a5)
{
  unsigned int n2; // ebx
  CItemList **v7; // eax
  const itemData *v8; // eax
  int v9; // eax
  char *v10; // [esp+8h] [ebp-80h]
  __int64 v11; // [esp+17h] [ebp-71h] BYREF
  int v12; // [esp+1Fh] [ebp-69h]
  int v13; // [esp+23h] [ebp-65h]
  int v14; // [esp+27h] [ebp-61h]
  int v15; // [esp+2Bh] [ebp-5Dh]
  int v16; // [esp+2Fh] [ebp-59h]
  int v17; // [esp+33h] [ebp-55h]
  int v18; // [esp+37h] [ebp-51h]
  int v19; // [esp+3Bh] [ebp-4Dh]
  int v20; // [esp+3Fh] [ebp-49h]
  int v21; // [esp+43h] [ebp-45h]
  int v22; // [esp+47h] [ebp-41h]
  int v23; // [esp+4Bh] [ebp-3Dh]
  int v24; // [esp+4Fh] [ebp-39h]
  char v25; // [esp+53h] [ebp-35h]
  _BYTE v26[4]; // [esp+54h] [ebp-34h] BYREF
  _BYTE v27[4]; // [esp+58h] [ebp-30h] BYREF
  _BYTE v28[4]; // [esp+5Ch] [ebp-2Ch] BYREF
  _BYTE v29[4]; // [esp+60h] [ebp-28h] BYREF
  _BYTE v30[4]; // [esp+64h] [ebp-24h] BYREF
  _BYTE v31[4]; // [esp+68h] [ebp-20h] BYREF
  _BYTE v32[4]; // [esp+6Ch] [ebp-1Ch] BYREF
  int v33; // [esp+70h] [ebp-18h]
  int v34; // [esp+74h] [ebp-14h]
  CItem *item; // [esp+78h] [ebp-10h]
  int v36; // [esp+7Ch] [ebp-Ch]

  if ( (unsigned __int8)std::map<rewardKey,std::map<int,std::vector<itemData>>>::empty(a1) )
    return 0;
  std::map<rewardKey,std::map<int,std::vector<itemData>>>::find(v28);
  std::map<rewardKey,std::map<int,std::vector<itemData>>>::end(v29);
  if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<rewardKey const,std::map<int,std::vector<itemData>>>>::operator==(
                          v28,
                          v29) )
    return 0;
  v33 = std::_Rb_tree_iterator<std::pair<rewardKey const,std::map<int,std::vector<itemData>>>>::operator->(v28) + 8;
  v10 = &a5;
  std::map<int,std::vector<itemData>>::find(v27);
  std::map<int,std::vector<itemData>>::end(v30);
  if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,std::vector<itemData>>>::operator==(v27, v30) )
    return 0;
  v34 = std::_Rb_tree_iterator<std::pair<int const,std::vector<itemData>>>::operator->(v27) + 4;
  if ( (unsigned __int8)std::vector<itemData>::empty(v34) )
    return 0;
  std::vector<itemData>::begin(v26);
  while ( 1 )
  {
    std::vector<itemData>::end(v31);
    if ( !(unsigned __int8)__gnu_cxx::operator!=<itemData *,std::vector<itemData>>(v26, v31) )
      break;
    n2 = *(_DWORD *)(__gnu_cxx::__normal_iterator<itemData *,std::vector<itemData>>::operator->(v26) + 4);
    v7 = (CItemList **)G_CDataManager();
    item = (CItem *)CDataManager::find_item(v7, n2);
    if ( !item )
      return 0;
    Inven_Item::Inven_Item((Inven_Item *)&v11);
    *(_DWORD *)((char *)&v11 + 2) = *(_DWORD *)(__gnu_cxx::__normal_iterator<itemData *,std::vector<itemData>>::operator->(v26)
                                              + 4);
    (*(void (__cdecl **)(CItem *, __int64 *, char *))(*(_DWORD *)item + 8))(item, &v11, v10);
    v8 = (const itemData *)__gnu_cxx::__normal_iterator<itemData *,std::vector<itemData>>::operator*(v26);
    eventReward::applyItemOption(a1, (Inven_Item *)&v11, item, v8);
    if ( (unsigned __int8)CItem::is_stackable(item) )
      return 0;
    v36 = (*(int (__cdecl **)(CItem *))(*(_DWORD *)item + 12))(item);
    v9 = a2 + 61 * v36 - 610;
    *(_QWORD *)v9 = v11;
    *(_DWORD *)(v9 + 8) = v12;
    *(_DWORD *)(v9 + 12) = v13;
    *(_DWORD *)(v9 + 16) = v14;
    *(_DWORD *)(v9 + 20) = v15;
    *(_DWORD *)(v9 + 24) = v16;
    *(_DWORD *)(v9 + 28) = v17;
    *(_DWORD *)(v9 + 32) = v18;
    *(_DWORD *)(v9 + 36) = v19;
    *(_DWORD *)(v9 + 40) = v20;
    *(_DWORD *)(v9 + 44) = v21;
    *(_DWORD *)(v9 + 48) = v22;
    *(_DWORD *)(v9 + 52) = v23;
    *(_DWORD *)(v9 + 56) = v24;
    *(_BYTE *)(v9 + 60) = v25;
    v10 = 0;
    __gnu_cxx::__normal_iterator<itemData *,std::vector<itemData>>::operator++(v32);
  }
  return 1;
}

// IDA_EA: 0x80F0976
// IDA_NAME: _ZN11eventReward16sendPostalRewardER5CUser9rewardKeyiPKcS4_
// DEMANGLED: eventReward::sendPostalReward(CUser &,rewardKey,int,char const*,char const*)
int __cdecl eventReward::sendPostalReward(
        eventReward *a1,
        CUser *a2,
        int a3,
        int a4,
        char a5,
        char *pszSrc_1,
        char *pszSrc)
{
  CItemList **v8; // eax
  GameWorld *v9; // eax
  const itemData *v10; // eax
  char *p_s; // edx
  unsigned int n256; // ebx
  char *v13; // edi
  char *v14; // edx
  const char *charac_levelEv; // ebx
  char *format; // eax
  size_t v18; // esi
  int CurCharacNoEv; // ebx
  char *src; // eax
  char *v21; // [esp+8h] [ebp-1C0h]
  char s; // [esp+3Fh] [ebp-189h] BYREF
  int v23; // [esp+40h] [ebp-188h] BYREF
  _BYTE v24[2]; // [esp+13Fh] [ebp-89h] BYREF
  int n2_1; // [esp+141h] [ebp-87h]
  char v26[4]; // [esp+17Ch] [ebp-4Ch] BYREF
  char v27[4]; // [esp+180h] [ebp-48h] BYREF
  char v28[4]; // [esp+184h] [ebp-44h] BYREF
  char v29[4]; // [esp+188h] [ebp-40h] BYREF
  char v30[4]; // [esp+18Ch] [ebp-3Ch] BYREF
  char v31[4]; // [esp+190h] [ebp-38h] BYREF
  char v32[4]; // [esp+194h] [ebp-34h] BYREF
  int v33; // [esp+198h] [ebp-30h]
  int v34; // [esp+19Ch] [ebp-2Ch]
  int n2; // [esp+1A0h] [ebp-28h]
  CItem *item; // [esp+1A4h] [ebp-24h]
  int ServerGroup; // [esp+1A8h] [ebp-20h]
  int ExpirationDateEv; // [esp+1ACh] [ebp-1Ch]

  if ( (unsigned __int8)std::map<rewardKey,std::map<int,std::vector<itemData>>>::empty(a1) )
    return 0;
  std::map<rewardKey,std::map<int,std::vector<itemData>>>::find(v28);
  std::map<rewardKey,std::map<int,std::vector<itemData>>>::end(v29);
  if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<rewardKey const,std::map<int,std::vector<itemData>>>>::operator==(
                          v28,
                          v29) )
    return 0;
  v33 = std::_Rb_tree_iterator<std::pair<rewardKey const,std::map<int,std::vector<itemData>>>>::operator->(v28) + 8;
  v21 = &a5;
  std::map<int,std::vector<itemData>>::find(v27);
  std::map<int,std::vector<itemData>>::end(v30);
  if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,std::vector<itemData>>>::operator==(v27, v30) )
    return 0;
  v34 = std::_Rb_tree_iterator<std::pair<int const,std::vector<itemData>>>::operator->(v27) + 4;
  if ( (unsigned __int8)std::vector<itemData>::empty(v34) )
    return 0;
  std::vector<itemData>::begin(v26);
  while ( 1 )
  {
    std::vector<itemData>::end(v31);
    if ( !(unsigned __int8)__gnu_cxx::operator!=<itemData *,std::vector<itemData>>(v26, v31) )
      break;
    n2 = *(_DWORD *)(__gnu_cxx::__normal_iterator<itemData *,std::vector<itemData>>::operator->(v26) + 4);
    Inven_Item::Inven_Item((Inven_Item *)v24);
    v8 = (CItemList **)G_CDataManager();
    item = (CItem *)CDataManager::find_item(v8, n2);
    ServerGroup = 0;
    v9 = (GameWorld *)G_GameWorld();
    if ( (unsigned __int8)GameWorld::IsIntegratedPvPBaseChannel(v9) )
      ServerGroup = CUser::GetServerGroup(a2);
    else
      ServerGroup = *(_DWORD *)(G_CEnvironment() + 888);
    if ( item )
    {
      n2_1 = n2;
      (*(void (__cdecl **)(CItem *, _BYTE *, char *))(*(_DWORD *)item + 8))(item, v24, v21);
      v10 = (const itemData *)__gnu_cxx::__normal_iterator<itemData *,std::vector<itemData>>::operator*(v26);
      eventReward::applyItemOption(a1, (Inven_Item *)v24, item, v10);
      p_s = &s;
      n256 = 256;
      if ( ((unsigned __int8)&s & 1) != 0 )
      {
        s = 0;
        p_s = (char *)&v23;
        n256 = 255;
      }
      if ( ((unsigned __int8)p_s & 2) != 0 )
      {
        *(_WORD *)p_s = 0;
        p_s += 2;
        n256 -= 2;
      }
      memset(p_s, 0, 4 * (n256 >> 2));
      v13 = &p_s[4 * (n256 >> 2)];
      v14 = v13;
      if ( (n256 & 2) != 0 )
      {
        *(_WORD *)v13 = 0;
        v14 = v13 + 2;
      }
      if ( (n256 & 1) != 0 )
        *v14 = 0;
      charac_levelEv = (const char *)CUserCharacInfo::get_charac_level(a2);
      format = (char *)RDARScriptStringManager::findString(
                         (RDARScriptStringManager *)&g_scriptStringManager_,
                         4,
                         pszSrc,
                         0);
      OS_API::snprintf((OS_API *)&s, 0xFFu, format, charac_levelEv);
      if ( n2_1 && (unsigned __int8)CItem::is_stackable(item) )
      {
        ExpirationDateEv = CItem::getExpirationDate(item);
        v18 = strlen(&s);
        CurCharacNoEv = CUserCharacInfo::getCurCharacNo(a2);
        src = (char *)RDARScriptStringManager::findString(
                        (RDARScriptStringManager *)&g_scriptStringManager_,
                        4,
                        pszSrc_1,
                        0);
        WongWork::CMailBoxHelper::ReqDBSendNewSystemMail(
          src,
          (Inven_Item *)v24,
          0,
          CurCharacNoEv,
          &s,
          v18,
          ExpirationDateEv,
          ServerGroup,
          0,
          1);
      }
    }
    v21 = 0;
    __gnu_cxx::__normal_iterator<itemData *,std::vector<itemData>>::operator++(v32);
  }
  return 1;
}

// IDA_EA: 0x80F0D22
// IDA_NAME: _ZNK11eventReward11StartEndPosEN10Inven_Item9ITEM_TYPEERiS2_i
// DEMANGLED: eventReward::StartEndPos(Inven_Item::ITEM_TYPE,int &,int &,int)const
int __cdecl eventReward::StartEndPos(int a1, int a2, _DWORD *a3, _DWORD *a4, int a5)
{
  int result; // eax

  result = CSlotBoundChecker::get_slot_bound(a1 + 24, a2, a5, a3, a4) ^ 1;
  if ( (_BYTE)result )
  {
    *a3 = 0;
    result = (int)a4;
    *a4 = 0;
  }
  return result;
}

// IDA_EA: 0x80F0D6E
// IDA_NAME: _ZN11eventReward15applyItemOptionER10Inven_ItemPK5CItemRK8itemData
// DEMANGLED: eventReward::applyItemOption(Inven_Item &,CItem const*,itemData const&)
Inven_Item *__cdecl eventReward::applyItemOption(
        eventReward *this,
        Inven_Item *a2,
        const CItem *a3,
        const itemData *a4)
{
  Inven_Item *result; // eax
  unsigned int n5; // eax

  if ( (unsigned __int8)CItem::is_stackable(a3) )
  {
    result = a2;
    *(_DWORD *)((char *)a2 + 7) = *((_DWORD *)a4 + 2);
  }
  else
  {
    *(_BYTE *)a2 = *((_BYTE *)a4 + 1);
    n5 = CItem::GetAttachType(a3);
    if ( n5 <= 5 && ((1 << n5) & 0x27) != 0 )
      *(_BYTE *)a2 = 0;
    if ( *(char *)a4 > 1 )
      Inven_Item::SetUpgrade(a2, *(_BYTE *)a4);
    result = (Inven_Item *)((*(unsigned __int8 (__cdecl **)(const CItem *))(*(_DWORD *)a3 + 76))(a3)
                         && *((_BYTE *)a4 + 2) != 1);
    if ( (_BYTE)result )
      return (Inven_Item *)eventReward::unsealRandomOption(this, a3, a2);
  }
  return result;
}

// IDA_EA: 0x80F0E40
// IDA_NAME: _ZN11eventReward18unsealRandomOptionEPK5CItemR10Inven_Item
// DEMANGLED: eventReward::unsealRandomOption(CItem const*,Inven_Item &)
int __cdecl eventReward::unsealRandomOption(eventReward *this, const CItem *a2, Inven_Item *a3)
{
  int v4; // edi
  int ItemGroupNameEv; // esi
  int UsableLevelEv; // ebx
  int rarityEv; // eax

  if ( !a2 )
    return 0;
  if ( (*(unsigned __int8 (__cdecl **)(const CItem *))(*(_DWORD *)a2 + 76))(a2) != 1 )
    return 0;
  v4 = (*(int (__cdecl **)(const CItem *))(*(_DWORD *)a2 + 80))(a2);
  ItemGroupNameEv = CItem::getItemGroupName(a2);
  UsableLevelEv = CItem::getUsableLevel(a2);
  rarityEv = CItem::get_rarity(a2);
  if ( (unsigned __int8)random_option::CRandomOptionItemHandle::give_option(
                          GlobalData::g_randomOptionHandle,
                          *(_DWORD *)((char *)a3 + 2),
                          rarityEv,
                          UsableLevelEv,
                          ItemGroupNameEv,
                          v4,
                          (int)a3 + 37) != 1 )
    LogManager::logFormat(
      (LogManager *)1,
      (int)"eventReward.cpp",
      "bool eventReward::unsealRandomOption(const CItem*, Inven_Item&)",
      (const char *)0x240,
      "autoUnsealItem : %d",
      *(const char **)((char *)a3 + 2));
  return 1;
}

// IDA_EA: 0x83738A2
// IDA_NAME: _ZN11eventRewardC2Ev
// DEMANGLED: eventReward::eventReward(void)
void __cdecl eventReward::eventReward(eventReward *this)
{
  std::map<rewardKey,std::map<int,std::vector<itemData>>>::map(this);
  CSlotBoundChecker::CSlotBoundChecker((eventReward *)((char *)this + 24));
  std::map<rewardKey,std::map<int,std::vector<itemData>>>::clear(this);
}

// IDA_EA: 0x837DFB2
// IDA_NAME: _ZN11eventRewardD2Ev
// DEMANGLED: eventReward::~eventReward()
void __cdecl eventReward::~eventReward(eventReward *this)
{
  CSlotBoundChecker::~CSlotBoundChecker((char *)this + 24);
  std::map<rewardKey,std::map<int,std::vector<itemData>>>::~map((int)this);
}
