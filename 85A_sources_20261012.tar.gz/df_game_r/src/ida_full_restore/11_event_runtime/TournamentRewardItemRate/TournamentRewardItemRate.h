#ifndef __IDA91_TOURNAMENTREWARDITEMRATE_H__
#define __IDA91_TOURNAMENTREWARDITEMRATE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: TournamentRewardItemRate
// Source unit: TournamentRewardItemRate
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4594

/* 4594 */
struct TournamentRewardItemRate;

// Exported member functions:
// 0x836AB66	TournamentRewardItemRate::Clear(void)
// 0x836AB84	TournamentRewardItemRate::TournamentRewardItemRate(void)
// 0x836B5A6	TournamentRewardItemRate::~TournamentRewardItemRate()
// 0x8376D28	TournamentRewardItemRate::operator=(TournamentRewardItemRate const&)

// Function declaration index:
// DECL 0x836AB66 TournamentRewardItemRate::Clear
// DECL 0x836AB84 TournamentRewardItemRate::TournamentRewardItemRate
// DECL 0x836B5A6 TournamentRewardItemRate::~TournamentRewardItemRate
// DECL 0x8376D28 TournamentRewardItemRate::operator=

#endif  // __IDA91_TOURNAMENTREWARDITEMRATE_H__
