#include "TournamentRewardItemRate.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x836AB66
// IDA_NAME: _ZN24TournamentRewardItemRate5ClearEv
// DEMANGLED: TournamentRewardItemRate::Clear(void)
int __cdecl TournamentRewardItemRate::Clear(TournamentRewardItemRate *this)
{
  *((_DWORD *)this + 3) = 0;
  return std::vector<TournamentRewardItem>::clear(this);
}

// IDA_EA: 0x836AB84
// IDA_NAME: _ZN24TournamentRewardItemRateC2Ev
// DEMANGLED: TournamentRewardItemRate::TournamentRewardItemRate(void)
void __cdecl TournamentRewardItemRate::TournamentRewardItemRate(TournamentRewardItemRate *this)
{
  std::vector<TournamentRewardItem>::vector(this);
  TournamentRewardItemRate::Clear(this);
}

// IDA_EA: 0x836B5A6
// IDA_NAME: _ZN24TournamentRewardItemRateD2Ev
// DEMANGLED: TournamentRewardItemRate::~TournamentRewardItemRate()
void __cdecl TournamentRewardItemRate::~TournamentRewardItemRate(TournamentRewardItemRate *this)
{
  std::vector<TournamentRewardItem>::~vector(this);
}

// IDA_EA: 0x8376D28
// IDA_NAME: _ZN24TournamentRewardItemRateaSERKS_
// DEMANGLED: TournamentRewardItemRate::operator=(TournamentRewardItemRate const&)
int __cdecl TournamentRewardItemRate::operator=(int a1, int a2)
{
  std::vector<TournamentRewardItem>::operator=(a1, a2);
  *(_DWORD *)(a1 + 12) = *(_DWORD *)(a2 + 12);
  return a1;
}
