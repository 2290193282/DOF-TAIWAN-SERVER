#ifndef __IDA91_BLUEMARBLERANDOMITEMINFO_H__
#define __IDA91_BLUEMARBLERANDOMITEMINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: BlueMarbleRandomItemInfo
// Source unit: BlueMarbleRandomItemInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 3863

/* 3863 */
struct BlueMarbleRandomItemInfo;

// Exported member functions:
// 0x88D9120	BlueMarbleRandomItemInfo::~BlueMarbleRandomItemInfo()

// Function declaration index:
// DECL 0x88D9120 BlueMarbleRandomItemInfo::~BlueMarbleRandomItemInfo

#endif  // __IDA91_BLUEMARBLERANDOMITEMINFO_H__
