#include "Inter_LoadBreakAwayPreventMessage.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84D92B4
// IDA_NAME: _ZN33Inter_LoadBreakAwayPreventMessage12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_LoadBreakAwayPreventMessage::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_LoadBreakAwayPreventMessage::dispatch_sig(
        Inter_LoadBreakAwayPreventMessage *this,
        CUser *a2,
        char *a3)
{
  PacketBuf *v4[3]; // [esp+10h] [ebp-38h] BYREF
  PacketBuf *v5[3]; // [esp+1Ch] [ebp-2Ch] BYREF
  PacketBuf *v6[4]; // [esp+28h] [ebp-20h] BYREF
  int n2; // [esp+38h] [ebp-10h]
  unsigned int v8; // [esp+3Ch] [ebp-Ch]

  if ( !a2 )
    return 0;
  v6[3] = (PacketBuf *)a3;
  n2 = *((_DWORD *)a3 + 1);
  v8 = *(_DWORD *)a3;
  if ( n2 && n2 != 2 )
  {
    PacketGuard::PacketGuard((PacketGuard *)v4);
    InterfacePacketBuf::put_header(v4, 0, 273);
    InterfacePacketBuf::put_byte(v4, n2);
    InterfacePacketBuf::finalize(v4, 1);
    CUser::Send(a2, (PacketGuard *)v4);
    PacketGuard::~PacketGuard(v4);
  }
  else
  {
    PacketGuard::PacketGuard((PacketGuard *)v6);
    InterfacePacketBuf::put_header(v6, 0, 273);
    InterfacePacketBuf::put_byte(v6, n2);
    InterfacePacketBuf::finalize(v6, 1);
    CUser::Send(a2, (PacketGuard *)v6);
    PacketGuard::PacketGuard((PacketGuard *)v5);
    InterfacePacketBuf::put_header(v5, 0, 310);
    InterfacePacketBuf::put_int(v5, 86400);
    InterfacePacketBuf::put_byte(v5, 0);
    InterfacePacketBuf::finalize(v5, 1);
    CUser::Send(a2, (PacketGuard *)v5);
    CUser::setBreakAwayDungeonClearCnt(a2, 3);
    CUser::setBreakAwayQuestTime(a2, v8);
    PacketGuard::~PacketGuard(v5);
    PacketGuard::~PacketGuard(v6);
  }
  return 0;
}

// IDA_EA: 0x84EDF34
// IDA_NAME: _ZN33Inter_LoadBreakAwayPreventMessageC2Ev
// DEMANGLED: Inter_LoadBreakAwayPreventMessage::Inter_LoadBreakAwayPreventMessage(void)
void __cdecl Inter_LoadBreakAwayPreventMessage::Inter_LoadBreakAwayPreventMessage(
        Inter_LoadBreakAwayPreventMessage *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8F0A8;
}

// IDA_EA: 0x84F8238
// IDA_NAME: _ZN33Inter_LoadBreakAwayPreventMessageD2Ev
// DEMANGLED: Inter_LoadBreakAwayPreventMessage::~Inter_LoadBreakAwayPreventMessage()
void __cdecl Inter_LoadBreakAwayPreventMessage::~Inter_LoadBreakAwayPreventMessage(
        Inter_LoadBreakAwayPreventMessage *this)
{
  *(_DWORD *)this = &off_8C8F0A8;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84F8268
// IDA_NAME: _ZN33Inter_LoadBreakAwayPreventMessageD0Ev
// DEMANGLED: Inter_LoadBreakAwayPreventMessage::~Inter_LoadBreakAwayPreventMessage()
void __cdecl Inter_LoadBreakAwayPreventMessage::~Inter_LoadBreakAwayPreventMessage(
        Inter_LoadBreakAwayPreventMessage *this)
{
  Inter_LoadBreakAwayPreventMessage::~Inter_LoadBreakAwayPreventMessage(this);
  operator delete(this);
}
