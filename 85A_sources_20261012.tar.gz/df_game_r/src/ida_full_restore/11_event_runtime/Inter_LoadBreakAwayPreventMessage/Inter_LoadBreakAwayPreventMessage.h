#ifndef __IDA91_INTER_LOADBREAKAWAYPREVENTMESSAGE_H__
#define __IDA91_INTER_LOADBREAKAWAYPREVENTMESSAGE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_LoadBreakAwayPreventMessage
// Source unit: Inter_LoadBreakAwayPreventMessage
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 3099

/* 3099 */
struct Inter_LoadBreakAwayPreventMessage;

// Exported member functions:
// 0x84D92B4	Inter_LoadBreakAwayPreventMessage::dispatch_sig(CUser *,char *,int)
// 0x84EDF34	Inter_LoadBreakAwayPreventMessage::Inter_LoadBreakAwayPreventMessage(void)
// 0x84F8238	Inter_LoadBreakAwayPreventMessage::~Inter_LoadBreakAwayPreventMessage()
// 0x84F8268	Inter_LoadBreakAwayPreventMessage::~Inter_LoadBreakAwayPreventMessage()

// Function declaration index:
// DECL 0x84D92B4 Inter_LoadBreakAwayPreventMessage::dispatch_sig
// DECL 0x84EDF34 Inter_LoadBreakAwayPreventMessage::Inter_LoadBreakAwayPreventMessage
// DECL 0x84F8238 Inter_LoadBreakAwayPreventMessage::~Inter_LoadBreakAwayPreventMessage
// DECL 0x84F8268 Inter_LoadBreakAwayPreventMessage::~Inter_LoadBreakAwayPreventMessage

#endif  // __IDA91_INTER_LOADBREAKAWAYPREVENTMESSAGE_H__
