#include "EventGiveMeBox.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81649B0
// IDA_NAME: _ZN14EventGiveMeBoxC2Ev
// DEMANGLED: EventGiveMeBox::EventGiveMeBox(void)
void __cdecl EventGiveMeBox::EventGiveMeBox(EventGiveMeBox *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B7DA48;
}

// IDA_EA: 0x81649CC
// IDA_NAME: _ZN14EventGiveMeBoxD2Ev
// DEMANGLED: EventGiveMeBox::~EventGiveMeBox()
void __cdecl EventGiveMeBox::~EventGiveMeBox(EventGiveMeBox *this)
{
  *(_DWORD *)this = off_8B7DA48;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x81649FC
// IDA_NAME: _ZN14EventGiveMeBoxD0Ev
// DEMANGLED: EventGiveMeBox::~EventGiveMeBox()
void __cdecl EventGiveMeBox::~EventGiveMeBox(EventGiveMeBox *this)
{
  EventGiveMeBox::~EventGiveMeBox(this);
  operator delete(this);
}

// IDA_EA: 0x8164A1A
// IDA_NAME: _ZN14EventGiveMeBox10StartEventEv
// DEMANGLED: EventGiveMeBox::StartEvent(void)
int __cdecl EventGiveMeBox::StartEvent(EventGiveMeBox *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void EventGiveMeBox::StartEvent()", 18, 0);
  return cMyTrace::operator()((int)v3, "[Taiwan, EventGiveMeBox] Event start!", v2);
}

// IDA_EA: 0x8164A6C
// IDA_NAME: _ZN14EventGiveMeBox10StartEventE10Word_Param
// DEMANGLED: EventGiveMeBox::StartEvent(Word_Param)
int __cdecl EventGiveMeBox::StartEvent(CEventBase *a1)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void EventGiveMeBox::StartEvent(Word_Param)", 23, 0);
  return cMyTrace::operator()((int)v3, "[Taiwan, EventGiveMeBox] Event start!", v2);
}

// IDA_EA: 0x8164ABE
// IDA_NAME: _ZN14EventGiveMeBox8EndEventEv
// DEMANGLED: EventGiveMeBox::EndEvent(void)
int __cdecl EventGiveMeBox::EndEvent(EventGiveMeBox *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void EventGiveMeBox::EndEvent()", 29, 0);
  return cMyTrace::operator()((int)v3, "[Taiwan, EventGiveMeBox] Event stop!", v2);
}
