#ifndef __IDA91_EVENTGIVEMEBOX_H__
#define __IDA91_EVENTGIVEMEBOX_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: EventGiveMeBox
// Source unit: EventGiveMeBox
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4122

/* 4122 */
struct EventGiveMeBox;

// Exported member functions:
// 0x81649B0	EventGiveMeBox::EventGiveMeBox(void)
// 0x81649CC	EventGiveMeBox::~EventGiveMeBox()
// 0x81649FC	EventGiveMeBox::~EventGiveMeBox()
// 0x8164A1A	EventGiveMeBox::StartEvent(void)
// 0x8164A6C	EventGiveMeBox::StartEvent(Word_Param)
// 0x8164ABE	EventGiveMeBox::EndEvent(void)

// Function declaration index:
// DECL 0x81649B0 EventGiveMeBox::EventGiveMeBox
// DECL 0x81649CC EventGiveMeBox::~EventGiveMeBox
// DECL 0x81649FC EventGiveMeBox::~EventGiveMeBox
// DECL 0x8164A1A EventGiveMeBox::StartEvent
// DECL 0x8164A6C EventGiveMeBox::StartEvent
// DECL 0x8164ABE EventGiveMeBox::EndEvent

#endif  // __IDA91_EVENTGIVEMEBOX_H__
