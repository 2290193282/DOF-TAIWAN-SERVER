#include "Dispatcher_BingoReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x825E682
// IDA_NAME: _ZN22Dispatcher_BingoReward4readER9PacketBufR8MSG_BASE
// DEMANGLED: Dispatcher_BingoReward::read(PacketBuf &,MSG_BASE &)
int Dispatcher_BingoReward::read()
{
  return 0;
}

// IDA_EA: 0x825E68C
// IDA_NAME: _ZN22Dispatcher_BingoReward7processEP5CUserR8MSG_BASER9ParamBase
// DEMANGLED: Dispatcher_BingoReward::process(CUser *,MSG_BASE &,ParamBase &)
int __cdecl Dispatcher_BingoReward::process(Dispatcher_BingoReward *this, CUser *a2, MSG_BASE *a3, ParamBase *a4)
{
  BingoEvent *RepeatEvent; // [esp+2Ch] [ebp-Ch]

  *((_DWORD *)a4 + 1) = Dispatcher_BingoReward::check_error(this, a2, a3);
  if ( a2 )
    *((_DWORD *)a4 + 2) = *(_DWORD *)CUser::getBingoData(a2);
  if ( *((int *)a4 + 1) > 0 )
    return 0;
  if ( *((int *)a4 + 1) >= 0 )
  {
    *(_BYTE *)(CUser::getBingoData(a2) + 6) = 1;
    *(_BYTE *)(CUser::getBingoData(a2) + 5) = 1;
    RepeatEvent = (BingoEvent *)CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 106);
    if ( RepeatEvent )
    {
      BingoEvent::sendMaxMatchLineReward(RepeatEvent, a2);
      CUser::sendDecorationObjectCnt(a2, 1);
    }
    return 0;
  }
  else
  {
    LogManager::logFormat(
      (LogManager *)1,
      (int)"PacketDispatcher_Impl_2.cpp",
      "virtual int Dispatcher_BingoReward::process(CUser*, MSG_BASE&, ParamBase&)",
      (const char *)0x19A,
      "Dispatcher Check_Error No(%d)",
      *((const char **)a4 + 1));
    return LineFunc(411, "virtual int Dispatcher_BingoReward::process(CUser*, MSG_BASE&, ParamBase&)", 0, 0);
  }
}

// IDA_EA: 0x825E7B2
// IDA_NAME: _ZN22Dispatcher_BingoReward11check_errorEP5CUserR8MSG_BASE
// DEMANGLED: Dispatcher_BingoReward::check_error(CUser *,MSG_BASE &)
int __cdecl Dispatcher_BingoReward::check_error(Dispatcher_BingoReward *this, CUser *a2)
{
  int RepeatEvent; // eax

  if ( !a2 || !CUserCharacInfo::getCurCharacR(a2) )
    return -1;
  if ( CUser::get_state(a2) != 3 )
    return 30;
  RepeatEvent = CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 106);
  if ( (*(unsigned __int8 (__cdecl **)(int, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) != 1 )
    return 19;
  if ( *(_BYTE *)(CUser::getBingoData(a2) + 5) )
    return 18;
  if ( *(char *)(CUser::getBingoData(a2) + 4) > 2 )
    return 0;
  return 22;
}

// IDA_EA: 0x825E87A
// IDA_NAME: _ZN22Dispatcher_BingoReward4sendEP5CUserR9ParamBase
// DEMANGLED: Dispatcher_BingoReward::send(CUser *,ParamBase &)
void __cdecl Dispatcher_BingoReward::send(Dispatcher_BingoReward *this, CUser *a2, ParamBase *a3)
{
  PacketBuf *v3[3]; // [esp+10h] [ebp-18h] BYREF
  ParamBase *v4; // [esp+1Ch] [ebp-Ch]

  v4 = a3;
  if ( *((_DWORD *)a3 + 1) )
  {
    PacketGuard::PacketGuard((PacketGuard *)v3);
    InterfacePacketBuf::put_header(v3, 1, 514);
    InterfacePacketBuf::put_byte(v3, 0);
    InterfacePacketBuf::put_byte(v3, *((_DWORD *)v4 + 1));
    InterfacePacketBuf::put_int(v3, *((_DWORD *)v4 + 2));
    InterfacePacketBuf::finalize(v3, 1);
    CUser::Send(a2, (PacketGuard *)v3);
    PacketGuard::~PacketGuard(v3);
  }
  else
  {
    CUser::SendCmdOkPacket(a2, 514);
  }
}

// IDA_EA: 0x8260B2A
// IDA_NAME: _ZN22Dispatcher_BingoRewardD2Ev
// DEMANGLED: Dispatcher_BingoReward::~Dispatcher_BingoReward()
void __cdecl Dispatcher_BingoReward::~Dispatcher_BingoReward(Dispatcher_BingoReward *this)
{
  *(_DWORD *)this = &off_8BEA4E8;
  IPacketDispatcher<MSG_BASE,stBingoReward,(ch_state)3>::~IPacketDispatcher(this);
}

// IDA_EA: 0x8260B5A
// IDA_NAME: _ZN22Dispatcher_BingoRewardD0Ev
// DEMANGLED: Dispatcher_BingoReward::~Dispatcher_BingoReward()
void __cdecl Dispatcher_BingoReward::~Dispatcher_BingoReward(Dispatcher_BingoReward *this)
{
  Dispatcher_BingoReward::~Dispatcher_BingoReward(this);
  operator delete(this);
}

// IDA_EA: 0x8595858
// IDA_NAME: _ZN22Dispatcher_BingoRewardC2Ev
// DEMANGLED: Dispatcher_BingoReward::Dispatcher_BingoReward(void)
void __cdecl Dispatcher_BingoReward::Dispatcher_BingoReward(Dispatcher_BingoReward *this)
{
  IPacketDispatcher<MSG_BASE,stBingoReward,(ch_state)3>::IPacketDispatcher(this);
  *(_DWORD *)this = &off_8BEA4E8;
}
