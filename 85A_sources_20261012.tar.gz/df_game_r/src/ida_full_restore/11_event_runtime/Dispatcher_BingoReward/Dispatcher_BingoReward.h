#ifndef __IDA91_DISPATCHER_BINGOREWARD_H__
#define __IDA91_DISPATCHER_BINGOREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Dispatcher_BingoReward
// Source unit: Dispatcher_BingoReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 2084

/* 2084 */
struct Dispatcher_BingoReward;

// Exported member functions:
// 0x825E682	Dispatcher_BingoReward::read(PacketBuf &,MSG_BASE &)
// 0x825E68C	Dispatcher_BingoReward::process(CUser *,MSG_BASE &,ParamBase &)
// 0x825E7B2	Dispatcher_BingoReward::check_error(CUser *,MSG_BASE &)
// 0x825E87A	Dispatcher_BingoReward::send(CUser *,ParamBase &)
// 0x8260B2A	Dispatcher_BingoReward::~Dispatcher_BingoReward()
// 0x8260B5A	Dispatcher_BingoReward::~Dispatcher_BingoReward()
// 0x8595858	Dispatcher_BingoReward::Dispatcher_BingoReward(void)

// Function declaration index:
// DECL 0x825E682 Dispatcher_BingoReward::read
// DECL 0x825E68C Dispatcher_BingoReward::process
// DECL 0x825E7B2 Dispatcher_BingoReward::check_error
// DECL 0x825E87A Dispatcher_BingoReward::send
// DECL 0x8260B2A Dispatcher_BingoReward::~Dispatcher_BingoReward
// DECL 0x8260B5A Dispatcher_BingoReward::~Dispatcher_BingoReward
// DECL 0x8595858 Dispatcher_BingoReward::Dispatcher_BingoReward

#endif  // __IDA91_DISPATCHER_BINGOREWARD_H__
