#ifndef __IDA91_INTER_MONITOREVENTITEMUPDATE_H__
#define __IDA91_INTER_MONITOREVENTITEMUPDATE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_MonitorEventItemUpdate
// Source unit: Inter_MonitorEventItemUpdate
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 2994

/* 2994 */
struct Inter_MonitorEventItemUpdate;

// Exported member functions:
// 0x84CEFD2	Inter_MonitorEventItemUpdate::dispatch_sig(CUser *,char *,int)
// 0x84EB396	Inter_MonitorEventItemUpdate::Inter_MonitorEventItemUpdate(void)
// 0x84EB3B2	Inter_MonitorEventItemUpdate::~Inter_MonitorEventItemUpdate()
// 0x84EB3E2	Inter_MonitorEventItemUpdate::~Inter_MonitorEventItemUpdate()

// Function declaration index:
// DECL 0x84CEFD2 Inter_MonitorEventItemUpdate::dispatch_sig
// DECL 0x84EB396 Inter_MonitorEventItemUpdate::Inter_MonitorEventItemUpdate
// DECL 0x84EB3B2 Inter_MonitorEventItemUpdate::~Inter_MonitorEventItemUpdate
// DECL 0x84EB3E2 Inter_MonitorEventItemUpdate::~Inter_MonitorEventItemUpdate

#endif  // __IDA91_INTER_MONITOREVENTITEMUPDATE_H__
