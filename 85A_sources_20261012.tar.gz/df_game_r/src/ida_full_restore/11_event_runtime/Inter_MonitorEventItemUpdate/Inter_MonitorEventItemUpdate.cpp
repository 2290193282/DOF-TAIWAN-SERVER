#include "Inter_MonitorEventItemUpdate.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84CEFD2
// IDA_NAME: _ZN28Inter_MonitorEventItemUpdate12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_MonitorEventItemUpdate::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_MonitorEventItemUpdate::dispatch_sig(Inter_MonitorEventItemUpdate *this, CUser *a2, char *a3)
{
  unsigned int v3; // edi
  int v5[4]; // [esp+4Ch] [ebp-2Ch] BYREF
  char *v6; // [esp+5Ch] [ebp-1Ch]

  v6 = a3;
  v3 = *(_DWORD *)(a3 + 14);
  NumberToString(*(_DWORD *)(a3 + 10), 0);
  cMyTrace::cMyTrace(
    (cMyTrace *)v5,
    "virtual int Inter_MonitorEventItemUpdate::dispatch_sig(CUser*, char*, int)",
    11263,
    0);
  cMyTrace::operator()(
    (int)v5,
    aSD_36,
    (char)"virtual int Inter_MonitorEventItemUpdate::dispatch_sig(CUser*, char*, int)");
  WongWork::CWebEvent::RecvInfoFromWeb(
    *(WongWork::CWebEvent **)(v6 + 10),
    *(_DWORD *)(v6 + 14),
    *(_DWORD *)(v6 + 22),
    *(_DWORD *)(v6 + 26),
    *(_DWORD *)(v6 + 18),
    *(_DWORD *)(v6 + 30),
    v3);
  return 0;
}

// IDA_EA: 0x84EB396
// IDA_NAME: _ZN28Inter_MonitorEventItemUpdateC2Ev
// DEMANGLED: Inter_MonitorEventItemUpdate::Inter_MonitorEventItemUpdate(void)
void __cdecl Inter_MonitorEventItemUpdate::Inter_MonitorEventItemUpdate(Inter_MonitorEventItemUpdate *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8F9A8;
}

// IDA_EA: 0x84EB3B2
// IDA_NAME: _ZN28Inter_MonitorEventItemUpdateD2Ev
// DEMANGLED: Inter_MonitorEventItemUpdate::~Inter_MonitorEventItemUpdate()
void __cdecl Inter_MonitorEventItemUpdate::~Inter_MonitorEventItemUpdate(Inter_MonitorEventItemUpdate *this)
{
  *(_DWORD *)this = &off_8C8F9A8;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84EB3E2
// IDA_NAME: _ZN28Inter_MonitorEventItemUpdateD0Ev
// DEMANGLED: Inter_MonitorEventItemUpdate::~Inter_MonitorEventItemUpdate()
void __cdecl Inter_MonitorEventItemUpdate::~Inter_MonitorEventItemUpdate(Inter_MonitorEventItemUpdate *this)
{
  Inter_MonitorEventItemUpdate::~Inter_MonitorEventItemUpdate(this);
  operator delete(this);
}
