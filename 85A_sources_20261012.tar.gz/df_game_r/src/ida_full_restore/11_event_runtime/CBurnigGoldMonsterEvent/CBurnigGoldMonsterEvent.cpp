#include "CBurnigGoldMonsterEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8116EE6
// IDA_NAME: _ZN23CBurnigGoldMonsterEventC2Ev
// DEMANGLED: CBurnigGoldMonsterEvent::CBurnigGoldMonsterEvent(void)
void __cdecl CBurnigGoldMonsterEvent::CBurnigGoldMonsterEvent(CBurnigGoldMonsterEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B4F3E8;
}

// IDA_EA: 0x8116F02
// IDA_NAME: _ZN23CBurnigGoldMonsterEventD2Ev
// DEMANGLED: CBurnigGoldMonsterEvent::~CBurnigGoldMonsterEvent()
void __cdecl CBurnigGoldMonsterEvent::~CBurnigGoldMonsterEvent(CBurnigGoldMonsterEvent *this)
{
  *(_DWORD *)this = off_8B4F3E8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x8116F32
// IDA_NAME: _ZN23CBurnigGoldMonsterEventD0Ev
// DEMANGLED: CBurnigGoldMonsterEvent::~CBurnigGoldMonsterEvent()
void __cdecl CBurnigGoldMonsterEvent::~CBurnigGoldMonsterEvent(CBurnigGoldMonsterEvent *this)
{
  CBurnigGoldMonsterEvent::~CBurnigGoldMonsterEvent(this);
  operator delete(this);
}

// IDA_EA: 0x8116F50
// IDA_NAME: _ZN23CBurnigGoldMonsterEvent10StartEventEv
// DEMANGLED: CBurnigGoldMonsterEvent::StartEvent(void)
int __cdecl CBurnigGoldMonsterEvent::StartEvent(CBurnigGoldMonsterEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CBurnigGoldMonsterEvent::StartEvent()", 18, 0);
  return cMyTrace::operator()((int)v3, "CBurnigGoldMonsterEvent Event Start!", v2);
}

// IDA_EA: 0x8116FA2
// IDA_NAME: _ZN23CBurnigGoldMonsterEvent10StartEventE10Word_Param
// DEMANGLED: CBurnigGoldMonsterEvent::StartEvent(Word_Param)
int __cdecl CBurnigGoldMonsterEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x8116FBC
// IDA_NAME: _ZN23CBurnigGoldMonsterEvent8EndEventEv
// DEMANGLED: CBurnigGoldMonsterEvent::EndEvent(void)
int __cdecl CBurnigGoldMonsterEvent::EndEvent(CBurnigGoldMonsterEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CBurnigGoldMonsterEvent::EndEvent()", 28, 0);
  return cMyTrace::operator()((int)v3, "CBurnigGoldMonsterEvent Event End!", v2);
}
