#ifndef __IDA91_CBURNIGGOLDMONSTEREVENT_H__
#define __IDA91_CBURNIGGOLDMONSTEREVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CBurnigGoldMonsterEvent
// Source unit: CBurnigGoldMonsterEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4099

/* 4099 */
struct CBurnigGoldMonsterEvent;

// Exported member functions:
// 0x8116EE6	CBurnigGoldMonsterEvent::CBurnigGoldMonsterEvent(void)
// 0x8116F02	CBurnigGoldMonsterEvent::~CBurnigGoldMonsterEvent()
// 0x8116F32	CBurnigGoldMonsterEvent::~CBurnigGoldMonsterEvent()
// 0x8116F50	CBurnigGoldMonsterEvent::StartEvent(void)
// 0x8116FA2	CBurnigGoldMonsterEvent::StartEvent(Word_Param)
// 0x8116FBC	CBurnigGoldMonsterEvent::EndEvent(void)

// Function declaration index:
// DECL 0x8116EE6 CBurnigGoldMonsterEvent::CBurnigGoldMonsterEvent
// DECL 0x8116F02 CBurnigGoldMonsterEvent::~CBurnigGoldMonsterEvent
// DECL 0x8116F32 CBurnigGoldMonsterEvent::~CBurnigGoldMonsterEvent
// DECL 0x8116F50 CBurnigGoldMonsterEvent::StartEvent
// DECL 0x8116FA2 CBurnigGoldMonsterEvent::StartEvent
// DECL 0x8116FBC CBurnigGoldMonsterEvent::EndEvent

#endif  // __IDA91_CBURNIGGOLDMONSTEREVENT_H__
