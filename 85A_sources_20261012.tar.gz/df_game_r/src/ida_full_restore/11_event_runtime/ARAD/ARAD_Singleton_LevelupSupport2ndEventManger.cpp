#include "ARAD_Singleton_LevelupSupport2ndEventManger.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8147E44
// IDA_NAME: _ZN4ARAD9SingletonI28LevelupSupport2ndEventMangerEC2Ev
// DEMANGLED: ARAD::Singleton<LevelupSupport2ndEventManger>::Singleton(void)
void __cdecl ARAD::Singleton<LevelupSupport2ndEventManger>::Singleton()
{
  ;
}

// IDA_EA: 0x81A167C
// IDA_NAME: _ZN4ARAD9SingletonI28LevelupSupport2ndEventMangerE3GetEv
// DEMANGLED: ARAD::Singleton<LevelupSupport2ndEventManger>::Get(void)
void *ARAD::Singleton<LevelupSupport2ndEventManger>::Get()
{
  if ( !(_BYTE)`guard variable for'ARAD::Singleton<LevelupSupport2ndEventManger>::Get(void)::obj
    && _cxa_guard_acquire(&`guard variable for'ARAD::Singleton<LevelupSupport2ndEventManger>::Get(void)::obj) )
  {
    LevelupSupport2ndEventManger::LevelupSupport2ndEventManger((LevelupSupport2ndEventManger *)&ARAD::Singleton<LevelupSupport2ndEventManger>::Get(void)::obj);
    _cxa_guard_release(&`guard variable for'ARAD::Singleton<LevelupSupport2ndEventManger>::Get(void)::obj);
    __cxa_atexit(
      (void (*)(void *))LevelupSupport2ndEventManger::~LevelupSupport2ndEventManger,
      &ARAD::Singleton<LevelupSupport2ndEventManger>::Get(void)::obj,
      &_dso_handle);
  }
  return &ARAD::Singleton<LevelupSupport2ndEventManger>::Get(void)::obj;
}
