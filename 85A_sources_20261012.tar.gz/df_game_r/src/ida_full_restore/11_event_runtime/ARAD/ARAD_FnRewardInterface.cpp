#include "ARAD_FnRewardInterface.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8194AC8
// IDA_NAME: _ZN4ARAD17FnRewardInterfaceclEimsj
// DEMANGLED: ARAD::FnRewardInterface::operator()(int,unsigned long,short,unsigned int)
int __cdecl ARAD::FnRewardInterface::operator()(int a1, char *n155, ARAD::ARAD_ITEM *a3, __int16 a4, unsigned int a5)
{
  int v6; // ebx
  char *p_s; // edx
  unsigned int n256; // ebx
  char *v9; // edi
  char *v10; // edx
  char *src_2; // eax
  int n21; // edx
  unsigned int v13; // ebx
  char *v14; // eax
  int ServerGroup; // ebx
  size_t v16; // esi
  int charac_noEi; // eax
  int charac_noEi_1; // eax
  Stream *v19; // eax
  char src_1; // al
  Stream **v21; // eax
  char s; // [esp+4Bh] [ebp-19Dh] BYREF
  int v24; // [esp+4Ch] [ebp-19Ch] BYREF
  _BYTE v25[61]; // [esp+14Bh] [ebp-9Dh] BYREF
  int v26[2]; // [esp+188h] [ebp-60h] BYREF
  char src[22]; // [esp+192h] [ebp-56h] BYREF
  char v28[4]; // [esp+1A8h] [ebp-40h] BYREF
  unsigned int v29; // [esp+1ACh] [ebp-3Ch]
  unsigned int v30; // [esp+1B0h] [ebp-38h]
  char src_; // [esp+1B7h] [ebp-31h] BYREF
  int v32; // [esp+1B8h] [ebp-30h] BYREF

  if ( !*(_DWORD *)(a1 + 4) || !CUser::get_charac_no(*(CUser **)(a1 + 4), -1) )
    return 0;
  Inven_Item::Inven_Item((Inven_Item *)v25);
  if ( (unsigned __int8)ARAD::ARAD_ITEM::arad_make_item(a3, a4, (Inven_Item *)v25) != 1 )
    return 0;
  p_s = &s;
  n256 = 256;
  if ( ((unsigned __int8)&s & 1) != 0 )
  {
    s = 0;
    p_s = (char *)&v24;
    n256 = 255;
  }
  if ( ((unsigned __int8)p_s & 2) != 0 )
  {
    *(_WORD *)p_s = 0;
    p_s += 2;
    n256 -= 2;
  }
  memset(p_s, 0, 4 * (n256 >> 2));
  v9 = &p_s[4 * (n256 >> 2)];
  v10 = v9;
  if ( (n256 & 2) != 0 )
  {
    *(_WORD *)v9 = 0;
    v10 = v9 + 2;
  }
  if ( (n256 & 1) != 0 )
    *v10 = 0;
  src_2 = &src_;
  n21 = 21;
  if ( ((unsigned __int8)&src_ & 1) != 0 )
  {
    src_ = 0;
    src_2 = (char *)&v32;
    n21 = 20;
  }
  if ( ((unsigned __int8)src_2 & 2) != 0 )
  {
    *(_WORD *)src_2 = 0;
    src_2 += 2;
    n21 -= 2;
  }
  v13 = 0;
  do
  {
    *(_DWORD *)&src_2[v13] = 0;
    v13 += 4;
  }
  while ( v13 < (n21 & 0xFFFFFFFC) );
  v14 = &src_2[v13];
  if ( (n21 & 2) != 0 )
  {
    *(_WORD *)v14 = 0;
    v14 += 2;
  }
  if ( (n21 & 1) != 0 )
    *v14 = 0;
  (**(void (__cdecl ***)(int, char *, char *))a1)(a1, &s, &src_);
  ServerGroup = CUser::GetServerGroup(*(CUser **)(a1 + 4));
  v16 = strlen(&s);
  charac_noEi = CUser::get_charac_no(*(CUser **)(a1 + 4), -1);
  if ( WongWork::CMailBoxHelper::ReqDBSendNewSystemMail(
         &src_,
         (Inven_Item *)v25,
         0,
         charac_noEi,
         &s,
         v16,
         12,
         ServerGroup,
         0,
         0) )
  {
    charac_noEi_1 = CUser::get_charac_no(*(CUser **)(a1 + 4), -1);
    LogManager::logFormat(
      (LogManager *)1,
      (int)"localjapan/Arad_EventPeriodDataManager.cpp",
      "bool ARAD::FnRewardInterface::operator()(int, itemindex_t, short int, arad_uint32)",
      (const char *)0x2F,
      "[FnReward] send mail fail. (code:%u, charac:%u, item:%u, cnt:%d)",
      n155,
      charac_noEi_1,
      a3,
      a4);
    return 0;
  }
  else
  {
    ARAD::FnRewardInterface::make_data((ARAD::FnRewardInterface *)v28, a1, (int)n155);
    arad::SigSaveRewardEventItem::SigSaveRewardEventItem((arad::SigSaveRewardEventItem *)src);
    arad::SigSaveRewardEventItem::set(
      (arad::SigSaveRewardEventItem *)src,
      (int)n155,
      v29,
      v30,
      (unsigned int)a3,
      a4,
      a5);
    v19 = StreamPool::Acquire(GlobalData::s_stream_pool, "localjapan/Arad_EventPeriodDataManager.cpp", 54);
    CStreamGuard::CStreamGuard((CStreamGuard *)v26, v19, 1);
    src_1 = CUser::GetUID(*(CUser **)(a1 + 4));
    ARAD::DISPATCHER::make_internal_stream_jpn((int)v26, 39, src_1);
    v21 = (Stream **)CStreamGuard::operator->((int)v26);
    CStreamGuard::put_binary(v21, src, 0x16u);
    v6 = MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v26);
    CStreamGuard::~CStreamGuard((Stream **)v26);
  }
  return v6;
}

// IDA_EA: 0x8194E58
// IDA_NAME: _ZN4ARAD17FnRewardInterface9make_dataEi
// DEMANGLED: ARAD::FnRewardInterface::make_data(int)
ARAD::FnRewardInterface *__stdcall ARAD::FnRewardInterface::make_data(ARAD::FnRewardInterface *this, int a2, int n155)
{
  unsigned int charac_noEi; // esi
  unsigned int acc_idEv; // eax
  unsigned int acc_idEv_1; // eax

  if ( *(_BYTE *)(a2 + 8) )
  {
    charac_noEi = CUser::get_charac_no(*(CUser **)(a2 + 4), -1);
    acc_idEv = CUser::get_acc_id(*(CUser **)(a2 + 4));
    ARAD::EventRewardItemArad::EventRewardItemArad(this, n155, acc_idEv, charac_noEi);
  }
  else
  {
    acc_idEv_1 = CUser::get_acc_id(*(CUser **)(a2 + 4));
    ARAD::EventRewardItemArad::EventRewardItemArad(this, n155, acc_idEv_1, 0);
  }
  return this;
}

// IDA_EA: 0x819A8C8
// IDA_NAME: _ZN4ARAD17FnRewardInterfaceC2EP5CUserb
// DEMANGLED: ARAD::FnRewardInterface::FnRewardInterface(CUser *,bool)
ARAD::FnRewardInterface *__cdecl ARAD::FnRewardInterface::FnRewardInterface(
        ARAD::FnRewardInterface *this,
        CUser *a2,
        bool a3)
{
  ARAD::FnRewardInterface *this_1; // eax

  *(_DWORD *)this = &off_8BA3198;
  *((_DWORD *)this + 1) = a2;
  this_1 = this;
  *((_BYTE *)this + 8) = a3;
  return this_1;
}
