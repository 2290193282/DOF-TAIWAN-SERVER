#ifndef __IDA91_ARAD_ARAD_STATISTICSEVENTITEMLIST_H__
#define __IDA91_ARAD_ARAD_STATISTICSEVENTITEMLIST_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: ARAD
// Source unit: ARAD_Arad_StatisticsEventItemList
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4399

/* 4399 */
struct ARAD::Arad_StatisticsEventItemList;

// Exported member functions:
// 0x819CBE8	ARAD::Arad_StatisticsEventItemList::Arad_StatisticsEventItemList(void)
// 0x819CCAC	ARAD::Arad_StatisticsEventItemList::~Arad_StatisticsEventItemList()
// 0x819CD0E	ARAD::Arad_StatisticsEventItemList::~Arad_StatisticsEventItemList()
// 0x819CD2C	ARAD::Arad_StatisticsEventItemList::loadScriptData(void)
// 0x819D084	ARAD::Arad_StatisticsEventItemList::clearScriptData(void)
// 0x819D09A	ARAD::Arad_StatisticsEventItemList::needStatistics(unsigned long)

// Function declaration index:
// DECL 0x819CBE8 ARAD::Arad_StatisticsEventItemList::Arad_StatisticsEventItemList
// DECL 0x819CCAC ARAD::Arad_StatisticsEventItemList::~Arad_StatisticsEventItemList
// DECL 0x819CD0E ARAD::Arad_StatisticsEventItemList::~Arad_StatisticsEventItemList
// DECL 0x819CD2C ARAD::Arad_StatisticsEventItemList::loadScriptData
// DECL 0x819D084 ARAD::Arad_StatisticsEventItemList::clearScriptData
// DECL 0x819D09A ARAD::Arad_StatisticsEventItemList::needStatistics

#endif  // __IDA91_ARAD_ARAD_STATISTICSEVENTITEMLIST_H__
