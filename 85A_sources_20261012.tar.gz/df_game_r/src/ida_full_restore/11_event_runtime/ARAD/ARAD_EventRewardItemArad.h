#ifndef __IDA91_ARAD_EVENTREWARDITEMARAD_H__
#define __IDA91_ARAD_EVENTREWARDITEMARAD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: ARAD
// Source unit: ARAD_EventRewardItemArad
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 1409

/* 1409 */
struct ARAD::EventRewardItemArad;

// Exported member functions:
// 0x8195D94	ARAD::EventRewardItemArad::EventRewardItemArad(int,unsigned int,unsigned int)
// 0x8195DB4	ARAD::EventRewardItemArad::operator==(ARAD::EventRewardItemArad const&)const

// Function declaration index:
// DECL 0x8195D94 ARAD::EventRewardItemArad::EventRewardItemArad
// DECL 0x8195DB4 ARAD::EventRewardItemArad::operator==

#endif  // __IDA91_ARAD_EVENTREWARDITEMARAD_H__
