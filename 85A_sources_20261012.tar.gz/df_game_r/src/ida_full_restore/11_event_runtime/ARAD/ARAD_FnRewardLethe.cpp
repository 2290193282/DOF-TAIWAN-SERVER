#include "ARAD_FnRewardLethe.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8194EE2
// IDA_NAME: _ZN4ARAD13FnRewardLetheclEimsj
// DEMANGLED: ARAD::FnRewardLethe::operator()(int,unsigned long,short,unsigned int)
int __cdecl ARAD::FnRewardLethe::operator()(CUser **a1, int n96, ARAD::ARAD_ITEM *a3, __int16 a4, unsigned int a5)
{
  int v6; // ebx
  char *p_s; // edx
  unsigned int n256; // ebx
  char *v9; // edi
  char *v10; // edx
  char *p_dest; // eax
  int n21; // edx
  unsigned int v13; // ebx
  char *v14; // eax
  const char *src_1; // eax
  const char *src_3; // eax
  const char *src_2; // eax
  int ServerGroup; // ebx
  size_t v19; // esi
  int charac_noEi; // eax
  const char *charac_noEi_1; // eax
  Stream *v22; // eax
  char src_4; // al
  Stream **v24; // eax
  Inven_Item *v26; // [esp+Ch] [ebp-1DCh]
  char s; // [esp+4Bh] [ebp-19Dh] BYREF
  int v28; // [esp+4Ch] [ebp-19Ch] BYREF
  _BYTE v29[61]; // [esp+14Bh] [ebp-9Dh] BYREF
  int v30[2]; // [esp+188h] [ebp-60h] BYREF
  _BYTE src[22]; // [esp+192h] [ebp-56h] BYREF
  char v32[4]; // [esp+1A8h] [ebp-40h] BYREF
  unsigned int v33; // [esp+1ACh] [ebp-3Ch]
  unsigned int v34; // [esp+1B0h] [ebp-38h]
  char dest; // [esp+1B7h] [ebp-31h] BYREF
  int v36; // [esp+1B8h] [ebp-30h] BYREF

  if ( !*a1 || !CUser::get_charac_no(*a1, -1) )
    return 0;
  Inven_Item::Inven_Item((Inven_Item *)v29);
  if ( (unsigned __int8)ARAD::ARAD_ITEM::arad_make_item(a3, a4, (Inven_Item *)v29, v26) != 1 )
    return 0;
  p_s = &s;
  n256 = 256;
  if ( ((unsigned __int8)&s & 1) != 0 )
  {
    s = 0;
    p_s = (char *)&v28;
    n256 = 255;
  }
  if ( ((unsigned __int8)p_s & 2) != 0 )
  {
    *(_WORD *)p_s = 0;
    p_s += 2;
    n256 -= 2;
  }
  memset(p_s, 0, 4 * (n256 >> 2));
  v9 = &p_s[4 * (n256 >> 2)];
  v10 = v9;
  if ( (n256 & 2) != 0 )
  {
    *(_WORD *)v9 = 0;
    v10 = v9 + 2;
  }
  if ( (n256 & 1) != 0 )
    *v10 = 0;
  p_dest = &dest;
  n21 = 21;
  if ( ((unsigned __int8)&dest & 1) != 0 )
  {
    dest = 0;
    p_dest = (char *)&v36;
    n21 = 20;
  }
  if ( ((unsigned __int8)p_dest & 2) != 0 )
  {
    *(_WORD *)p_dest = 0;
    p_dest += 2;
    n21 -= 2;
  }
  v13 = 0;
  do
  {
    *(_DWORD *)&p_dest[v13] = 0;
    v13 += 4;
  }
  while ( v13 < (n21 & 0xFFFFFFFC) );
  v14 = &p_dest[v13];
  if ( (n21 & 2) != 0 )
  {
    *(_WORD *)v14 = 0;
    v14 += 2;
  }
  if ( (n21 & 1) != 0 )
    *v14 = 0;
  if ( n96 == 96 )
  {
    src_1 = (const char *)RDARScriptStringManager::findString(
                            (RDARScriptStringManager *)&g_scriptStringManager_,
                            4,
                            "2012_soccer_goldmedal_title",
                            0);
    strncpy(&dest, src_1, 0x14u);
    src_3 = (const char *)RDARScriptStringManager::findString(
                            (RDARScriptStringManager *)&g_scriptStringManager_,
                            4,
                            "2012_soccer_goldmedal_mail",
                            0);
  }
  else
  {
    src_2 = (const char *)RDARScriptStringManager::findString(
                            (RDARScriptStringManager *)&g_scriptStringManager_,
                            4,
                            "lethe_2012_summer_event_title",
                            0);
    strncpy(&dest, src_2, 0x14u);
    src_3 = (const char *)RDARScriptStringManager::findString(
                            (RDARScriptStringManager *)&g_scriptStringManager_,
                            4,
                            "lethe_2012_summer_event_mail",
                            0);
  }
  strncpy(&s, src_3, 0xFFu);
  ServerGroup = CUser::GetServerGroup(*a1);
  v19 = strlen(&s);
  charac_noEi = CUser::get_charac_no(*a1, -1);
  if ( WongWork::CMailBoxHelper::ReqDBSendNewSystemMail(
         &dest,
         (Inven_Item *)v29,
         0,
         charac_noEi,
         &s,
         v19,
         12,
         ServerGroup,
         0,
         0) )
  {
    charac_noEi_1 = (const char *)CUser::get_charac_no(*a1, -1);
    LogManager::logFormat(
      (LogManager *)1,
      (int)"localjapan/Arad_EventPeriodDataManager.cpp",
      "bool ARAD::FnRewardLethe::operator()(int, itemindex_t, short int, arad_uint32)",
      (const char *)0x66,
      "[RewardLethe] send mail fail. (charac:%u, item:%u, cnt:%d)",
      charac_noEi_1,
      a3,
      a4);
    return 0;
  }
  else
  {
    ARAD::FnRewardLethe::make_data((ARAD::FnRewardLethe *)v32, (int)a1);
    arad::SigSaveRewardEventItem::SigSaveRewardEventItem((arad::SigSaveRewardEventItem *)src);
    arad::SigSaveRewardEventItem::set((arad::SigSaveRewardEventItem *)src, n96, v33, v34, (unsigned int)a3, a4, a5);
    v22 = (Stream *)StreamPool::Acquire(GlobalData::s_stream_pool, "localjapan/Arad_EventPeriodDataManager.cpp", 109);
    CStreamGuard::CStreamGuard((CStreamGuard *)v30, v22, 1);
    src_4 = CUser::GetUID(*a1);
    ARAD::DISPATCHER::make_internal_stream_jpn((int)v30, 39, src_4);
    v24 = (Stream **)CStreamGuard::operator->((int)v30);
    CStreamGuard::put_binary(v24, src, 0x16u);
    v6 = MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v30);
    CStreamGuard::~CStreamGuard((CStreamGuard *)v30);
  }
  return v6;
}

// IDA_EA: 0x8195340
// IDA_NAME: _ZN4ARAD13FnRewardLethe9make_dataEi
// DEMANGLED: ARAD::FnRewardLethe::make_data(int)
ARAD::FnRewardLethe *__stdcall ARAD::FnRewardLethe::make_data(ARAD::FnRewardLethe *this, CUser **a2, int n143)
{
  unsigned int acc_idEv; // eax

  acc_idEv = CUser::get_acc_id(*a2);
  ARAD::EventRewardItemArad::EventRewardItemArad(this, n143, acc_idEv, 0);
  return this;
}

// IDA_EA: 0x819A8F2
// IDA_NAME: _ZN4ARAD13FnRewardLetheC2EP5CUser
// DEMANGLED: ARAD::FnRewardLethe::FnRewardLethe(CUser *)
ARAD::FnRewardLethe *__cdecl ARAD::FnRewardLethe::FnRewardLethe(ARAD::FnRewardLethe *this, CUser *a2)
{
  ARAD::FnRewardLethe *this_1; // eax

  this_1 = this;
  *(_DWORD *)this = a2;
  return this_1;
}
