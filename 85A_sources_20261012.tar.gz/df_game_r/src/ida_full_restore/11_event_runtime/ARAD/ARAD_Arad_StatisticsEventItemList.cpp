#include "ARAD_Arad_StatisticsEventItemList.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x819CBE8
// IDA_NAME: _ZN4ARAD28Arad_StatisticsEventItemListC2Ev
// DEMANGLED: ARAD::Arad_StatisticsEventItemList::Arad_StatisticsEventItemList(void)
int __cdecl ARAD::Arad_StatisticsEventItemList::Arad_StatisticsEventItemList(std::string *this)
{
  std::string v2; // [esp+18h] [ebp-10h] BYREF
  int v3[2]; // [esp+1Fh] [ebp-9h] BYREF

  std::allocator<char>::allocator(v3);
  std::string::string((int)&v2, "Arad_StatisticsEventItemList", (int)v3);
  ARAD::Arad_InterfaceGameScript::Arad_InterfaceGameScript(this, (std::string)&v2);
  std::string::~string(&v2);
  std::allocator<char>::~allocator(v3);
  this->_M_dataplus.__vftable = (ustd::string::_Alloc_hider_vtbl *)std::basic_string_char_std::char_traits_char__std::allocator_char___::_Alloc_hider_vtbl38_;
  return std::vector<unsigned long>::vector((int)&this[2]);
}

// IDA_EA: 0x819CCAC
// IDA_NAME: _ZN4ARAD28Arad_StatisticsEventItemListD2Ev
// DEMANGLED: ARAD::Arad_StatisticsEventItemList::~Arad_StatisticsEventItemList()
void __cdecl ARAD::Arad_StatisticsEventItemList::~Arad_StatisticsEventItemList(
        ARAD::Arad_StatisticsEventItemList *this)
{
  *(_DWORD *)this = std::basic_string_char_std::char_traits_char__std::allocator_char___::_Alloc_hider_vtbl38_;
  std::vector<unsigned long>::~vector((_DWORD *)this + 2);
  ARAD::Arad_InterfaceGameScript::~Arad_InterfaceGameScript(this);
}

// IDA_EA: 0x819CD0E
// IDA_NAME: _ZN4ARAD28Arad_StatisticsEventItemListD0Ev
// DEMANGLED: ARAD::Arad_StatisticsEventItemList::~Arad_StatisticsEventItemList()
void __cdecl ARAD::Arad_StatisticsEventItemList::~Arad_StatisticsEventItemList(
        ARAD::Arad_StatisticsEventItemList *this)
{
  ARAD::Arad_StatisticsEventItemList::~Arad_StatisticsEventItemList(this);
  operator delete(this);
}

// IDA_EA: 0x819CD2C
// IDA_NAME: _ZN4ARAD28Arad_StatisticsEventItemList14loadScriptDataEv
// DEMANGLED: ARAD::Arad_StatisticsEventItemList::loadScriptData(void)
int __cdecl ARAD::Arad_StatisticsEventItemList::loadScriptData(ARAD::Arad_StatisticsEventItemList *this)
{
  unsigned int __t; // [esp+18h] [ebp-80h] BYREF
  unsigned int n2675620; // [esp+1Ch] [ebp-7Ch] BYREF
  unsigned int n26710; // [esp+20h] [ebp-78h] BYREF
  unsigned int n26711; // [esp+24h] [ebp-74h] BYREF
  unsigned int n26712; // [esp+28h] [ebp-70h] BYREF
  unsigned int n26713; // [esp+2Ch] [ebp-6Ch] BYREF
  unsigned int n26714; // [esp+30h] [ebp-68h] BYREF
  unsigned int n26715; // [esp+34h] [ebp-64h] BYREF
  unsigned int n26716; // [esp+38h] [ebp-60h] BYREF
  unsigned int n7576; // [esp+3Ch] [ebp-5Ch] BYREF
  unsigned int n2675765; // [esp+40h] [ebp-58h] BYREF
  unsigned int n2675766; // [esp+44h] [ebp-54h] BYREF
  unsigned int n2675767; // [esp+48h] [ebp-50h] BYREF
  unsigned int n2675768; // [esp+4Ch] [ebp-4Ch] BYREF
  unsigned int n2675769; // [esp+50h] [ebp-48h] BYREF
  unsigned int n7573; // [esp+54h] [ebp-44h] BYREF
  unsigned int n2675021; // [esp+58h] [ebp-40h] BYREF
  unsigned int n2674093; // [esp+5Ch] [ebp-3Ch] BYREF
  unsigned int n2674092; // [esp+60h] [ebp-38h] BYREF
  unsigned int n2675847; // [esp+64h] [ebp-34h] BYREF
  unsigned int n2675903; // [esp+68h] [ebp-30h] BYREF
  unsigned int n2770012; // [esp+6Ch] [ebp-2Ch] BYREF
  unsigned int n2771612; // [esp+70h] [ebp-28h] BYREF
  unsigned int n2781222; // [esp+74h] [ebp-24h] BYREF
  unsigned int n2778012; // [esp+78h] [ebp-20h] BYREF
  unsigned int n2773212; // [esp+7Ch] [ebp-1Ch] BYREF
  unsigned int n2774812; // [esp+80h] [ebp-18h] BYREF
  unsigned int n2782816; // [esp+84h] [ebp-14h] BYREF
  unsigned int n2776419; // [esp+88h] [ebp-10h] BYREF
  unsigned int __t_[3]; // [esp+8Ch] [ebp-Ch] BYREF

  __t = 2675626;
  std::vector<unsigned long>::push_back((int)this + 8, &__t);
  n2675620 = 2675620;
  std::vector<unsigned long>::push_back((int)this + 8, &n2675620);
  n26710 = 26710;
  std::vector<unsigned long>::push_back((int)this + 8, &n26710);
  n26711 = 26711;
  std::vector<unsigned long>::push_back((int)this + 8, &n26711);
  n26712 = 26712;
  std::vector<unsigned long>::push_back((int)this + 8, &n26712);
  n26713 = 26713;
  std::vector<unsigned long>::push_back((int)this + 8, &n26713);
  n26714 = 26714;
  std::vector<unsigned long>::push_back((int)this + 8, &n26714);
  n26715 = 26715;
  std::vector<unsigned long>::push_back((int)this + 8, &n26715);
  n26716 = 26716;
  std::vector<unsigned long>::push_back((int)this + 8, &n26716);
  n7576 = 7576;
  std::vector<unsigned long>::push_back((int)this + 8, &n7576);
  n2675765 = 2675765;
  std::vector<unsigned long>::push_back((int)this + 8, &n2675765);
  n2675766 = 2675766;
  std::vector<unsigned long>::push_back((int)this + 8, &n2675766);
  n2675767 = 2675767;
  std::vector<unsigned long>::push_back((int)this + 8, &n2675767);
  n2675768 = 2675768;
  std::vector<unsigned long>::push_back((int)this + 8, &n2675768);
  n2675769 = 2675769;
  std::vector<unsigned long>::push_back((int)this + 8, &n2675769);
  n7573 = 7573;
  std::vector<unsigned long>::push_back((int)this + 8, &n7573);
  n2675021 = 2675021;
  std::vector<unsigned long>::push_back((int)this + 8, &n2675021);
  n2674093 = 2674093;
  std::vector<unsigned long>::push_back((int)this + 8, &n2674093);
  n2674092 = 2674092;
  std::vector<unsigned long>::push_back((int)this + 8, &n2674092);
  n2675847 = 2675847;
  std::vector<unsigned long>::push_back((int)this + 8, &n2675847);
  n2675903 = 2675903;
  std::vector<unsigned long>::push_back((int)this + 8, &n2675903);
  n2770012 = 2770012;
  std::vector<unsigned long>::push_back((int)this + 8, &n2770012);
  n2771612 = 2771612;
  std::vector<unsigned long>::push_back((int)this + 8, &n2771612);
  n2781222 = 2781222;
  std::vector<unsigned long>::push_back((int)this + 8, &n2781222);
  n2778012 = 2778012;
  std::vector<unsigned long>::push_back((int)this + 8, &n2778012);
  n2773212 = 2773212;
  std::vector<unsigned long>::push_back((int)this + 8, &n2773212);
  n2774812 = 2774812;
  std::vector<unsigned long>::push_back((int)this + 8, &n2774812);
  n2782816 = 2782816;
  std::vector<unsigned long>::push_back((int)this + 8, &n2782816);
  n2776419 = 2776419;
  std::vector<unsigned long>::push_back((int)this + 8, &n2776419);
  __t_[0] = 2779613;
  std::vector<unsigned long>::push_back((int)this + 8, __t_);
  return 1;
}

// IDA_EA: 0x819D084
// IDA_NAME: _ZN4ARAD28Arad_StatisticsEventItemList15clearScriptDataEv
// DEMANGLED: ARAD::Arad_StatisticsEventItemList::clearScriptData(void)
int __cdecl ARAD::Arad_StatisticsEventItemList::clearScriptData(ARAD::Arad_StatisticsEventItemList *this)
{
  return std::vector<unsigned long>::clear((_DWORD *)this + 2);
}

// IDA_EA: 0x819D09A
// IDA_NAME: _ZN4ARAD28Arad_StatisticsEventItemList14needStatisticsEm
// DEMANGLED: ARAD::Arad_StatisticsEventItemList::needStatistics(unsigned long)
_BOOL4 __cdecl ARAD::Arad_StatisticsEventItemList::needStatistics()
{
  _BYTE v1[4]; // [esp+10h] [ebp-18h] BYREF
  _BYTE v2[4]; // [esp+14h] [ebp-14h] BYREF
  int v3; // [esp+18h] [ebp-10h] BYREF
  _DWORD v4[3]; // [esp+1Ch] [ebp-Ch] BYREF

  std::vector<unsigned long>::end(v1);
  std::vector<unsigned long>::end(&v3);
  std::vector<unsigned long>::begin(v4);
  std::find<__gnu_cxx::__normal_iterator<unsigned long *,std::vector<unsigned long>>,unsigned long>(v2);
  return (unsigned __int8)__gnu_cxx::operator!=<unsigned long *,std::vector<unsigned long>>(v2, v1) != 0;
}
