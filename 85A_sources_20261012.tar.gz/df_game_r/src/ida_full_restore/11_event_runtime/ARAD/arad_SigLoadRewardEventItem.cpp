#include "arad_SigLoadRewardEventItem.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8186686
// IDA_NAME: _ZN4arad22SigLoadRewardEventItemC2Ev
// DEMANGLED: arad::SigLoadRewardEventItem::SigLoadRewardEventItem(void)
int __cdecl arad::SigLoadRewardEventItem::SigLoadRewardEventItem(arad::SigLoadRewardEventItem *this)
{
  return arad::SigLoadRewardEventItem::init(this);
}

// IDA_EA: 0x818669A
// IDA_NAME: _ZN4arad22SigLoadRewardEventItem4initEv
// DEMANGLED: arad::SigLoadRewardEventItem::init(void)
int __cdecl arad::SigLoadRewardEventItem::init(arad::SigLoadRewardEventItem *this)
{
  return arad::SigLoadRewardEventItem::set(this, 0);
}

// IDA_EA: 0x81866B6
// IDA_NAME: _ZN4arad22SigLoadRewardEventItem3setEj
// DEMANGLED: arad::SigLoadRewardEventItem::set(unsigned int)
void *__cdecl arad::SigLoadRewardEventItem::set(arad::SigLoadRewardEventItem *this, unsigned int acc_idEv)
{
  *(_DWORD *)this = acc_idEv;
  *((_WORD *)this + 2) = 0;
  memset((char *)this + 46, 0, 0x28u);
  return memset((char *)this + 6, 0, 0x28u);
}
