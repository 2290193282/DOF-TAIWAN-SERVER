#include "ARAD_Singleton_CreateDnfEventSciprtServer.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8164902
// IDA_NAME: _ZN4ARAD9SingletonI26CreateDnfEventSciprtServerEC2Ev
// DEMANGLED: ARAD::Singleton<CreateDnfEventSciprtServer>::Singleton(void)
void __cdecl ARAD::Singleton<CreateDnfEventSciprtServer>::Singleton()
{
  ;
}

// IDA_EA: 0x8164907
// IDA_NAME: _ZN4ARAD9SingletonI26CreateDnfEventSciprtServerE3GetEv
// DEMANGLED: ARAD::Singleton<CreateDnfEventSciprtServer>::Get(void)
void *ARAD::Singleton<CreateDnfEventSciprtServer>::Get()
{
  if ( !(_BYTE)`guard variable for'ARAD::Singleton<CreateDnfEventSciprtServer>::Get(void)::obj
    && _cxa_guard_acquire(&`guard variable for'ARAD::Singleton<CreateDnfEventSciprtServer>::Get(void)::obj) )
  {
    CreateDnfEventSciprtServer::CreateDnfEventSciprtServer((CreateDnfEventSciprtServer *)&ARAD::Singleton<CreateDnfEventSciprtServer>::Get(void)::obj);
    _cxa_guard_release(&`guard variable for'ARAD::Singleton<CreateDnfEventSciprtServer>::Get(void)::obj);
    __cxa_atexit(
      (void (*)(void *))CreateDnfEventSciprtServer::~CreateDnfEventSciprtServer,
      &ARAD::Singleton<CreateDnfEventSciprtServer>::Get(void)::obj,
      &_dso_handle);
  }
  return &ARAD::Singleton<CreateDnfEventSciprtServer>::Get(void)::obj;
}
