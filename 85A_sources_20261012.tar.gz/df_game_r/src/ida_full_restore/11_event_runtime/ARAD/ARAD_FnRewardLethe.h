#ifndef __IDA91_ARAD_FNREWARDLETHE_H__
#define __IDA91_ARAD_FNREWARDLETHE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: ARAD
// Source unit: ARAD_FnRewardLethe
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 1428

/* 1428 */
struct ARAD::FnRewardLethe;

// Exported member functions:
// 0x8194EE2	ARAD::FnRewardLethe::operator()(int,unsigned long,short,unsigned int)
// 0x8195340	ARAD::FnRewardLethe::make_data(int)
// 0x819A8F2	ARAD::FnRewardLethe::FnRewardLethe(CUser *)

// Function declaration index:
// DECL 0x8194EE2 ARAD::FnRewardLethe::operator
// DECL 0x8195340 ARAD::FnRewardLethe::make_data
// DECL 0x819A8F2 ARAD::FnRewardLethe::FnRewardLethe

#endif  // __IDA91_ARAD_FNREWARDLETHE_H__
