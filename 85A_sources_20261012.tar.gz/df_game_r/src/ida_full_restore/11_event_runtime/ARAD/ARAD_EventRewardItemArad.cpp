#include "ARAD_EventRewardItemArad.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8195D94
// IDA_NAME: _ZN4ARAD19EventRewardItemAradC2Eijj
// DEMANGLED: ARAD::EventRewardItemArad::EventRewardItemArad(int,unsigned int,unsigned int)
ARAD::EventRewardItemArad *__cdecl ARAD::EventRewardItemArad::EventRewardItemArad(
        ARAD::EventRewardItemArad *this,
        int n155,
        unsigned int acc_idEv,
        unsigned int charac_noEi)
{
  ARAD::EventRewardItemArad *this_1; // eax

  *(_DWORD *)this = n155;
  *((_DWORD *)this + 1) = acc_idEv;
  this_1 = this;
  *((_DWORD *)this + 2) = charac_noEi;
  return this_1;
}

// IDA_EA: 0x8195DB4
// IDA_NAME: _ZNK4ARAD19EventRewardItemAradeqERKS0_
// DEMANGLED: ARAD::EventRewardItemArad::operator==(ARAD::EventRewardItemArad const&)const
_BOOL4 __cdecl ARAD::EventRewardItemArad::operator==(_DWORD *a1, _DWORD *a2)
{
  return *a1 == *a2 && a1[1] == a2[1] && a1[2] == a2[2];
}
