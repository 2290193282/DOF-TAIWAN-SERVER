#ifndef __IDA91_ARAD_SINGLETON_LEVELUPSUPPORT2NDEVENTMANGER_H__
#define __IDA91_ARAD_SINGLETON_LEVELUPSUPPORT2NDEVENTMANGER_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: ARAD
// Source unit: ARAD_Singleton<LevelupSupport2ndEventManger>
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
// No matching local type was found; declare types manually during cleanup.

// Exported member functions:
// 0x8147E44	ARAD::Singleton<LevelupSupport2ndEventManger>::Singleton(void)
// 0x81A167C	ARAD::Singleton<LevelupSupport2ndEventManger>::Get(void)

// Function declaration index:
// DECL 0x8147E44 ARAD::Singleton<LevelupSupport2ndEventManger>::Singleton
// DECL 0x81A167C ARAD::Singleton<LevelupSupport2ndEventManger>::Get

#endif  // __IDA91_ARAD_SINGLETON_LEVELUPSUPPORT2NDEVENTMANGER_H__
