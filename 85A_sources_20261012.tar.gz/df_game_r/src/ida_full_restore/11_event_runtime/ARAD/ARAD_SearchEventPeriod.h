#ifndef __IDA91_ARAD_SEARCHEVENTPERIOD_H__
#define __IDA91_ARAD_SEARCHEVENTPERIOD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: ARAD
// Source unit: ARAD_SearchEventPeriod
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
// No matching local type was found; declare types manually during cleanup.

// Exported member functions:
// 0x8195D72	ARAD::SearchEventPeriod::SearchEventPeriod(ENUM_REPEAT_EVENT_CODE)
// 0x8195D80	ARAD::SearchEventPeriod::operator()(ARAD::SCRIPT::SEventPeriodData const&)const
// 0x819A8B4	ARAD::SearchEventPeriod::operator()(ARAD::SCRIPT::SRewardPeriodData const&)const

// Function declaration index:
// DECL 0x8195D72 ARAD::SearchEventPeriod::SearchEventPeriod
// DECL 0x8195D80 ARAD::SearchEventPeriod::operator
// DECL 0x819A8B4 ARAD::SearchEventPeriod::operator

#endif  // __IDA91_ARAD_SEARCHEVENTPERIOD_H__
