#ifndef __IDA91_ARAD_FNREWARDMOMOJI_H__
#define __IDA91_ARAD_FNREWARDMOMOJI_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: ARAD
// Source unit: ARAD_FnRewardMomoji
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 1429

/* 1429 */
struct ARAD::FnRewardMomoji;

// Exported member functions:
// 0x819537C	ARAD::FnRewardMomoji::GetMailString(char *,char *)
// 0x819A900	ARAD::FnRewardMomoji::FnRewardMomoji(CUser *)

// Function declaration index:
// DECL 0x819537C ARAD::FnRewardMomoji::GetMailString
// DECL 0x819A900 ARAD::FnRewardMomoji::FnRewardMomoji

#endif  // __IDA91_ARAD_FNREWARDMOMOJI_H__
