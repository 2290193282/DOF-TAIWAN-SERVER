#ifndef __IDA91_ARAD_SIGARADEVENTITEMLOG_H__
#define __IDA91_ARAD_SIGARADEVENTITEMLOG_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: arad
// Source unit: arad_SigAradEventItemLog
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 3619

/* 3619 */
struct arad::SigAradEventItemLog;

// Exported member functions:
// 0x8694F14	arad::SigAradEventItemLog::SigAradEventItemLog(void)
// 0x8694F28	arad::SigAradEventItemLog::init(void)

// Function declaration index:
// DECL 0x8694F14 arad::SigAradEventItemLog::SigAradEventItemLog
// DECL 0x8694F28 arad::SigAradEventItemLog::init

#endif  // __IDA91_ARAD_SIGARADEVENTITEMLOG_H__
