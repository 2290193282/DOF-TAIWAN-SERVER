#include "ARAD_SearchEventPeriod.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8195D72
// IDA_NAME: _ZN4ARAD17SearchEventPeriodC2E22ENUM_REPEAT_EVENT_CODE
// DEMANGLED: ARAD::SearchEventPeriod::SearchEventPeriod(ENUM_REPEAT_EVENT_CODE)
int *__cdecl ARAD::SearchEventPeriod::SearchEventPeriod(int *a1, int n142)
{
  int *result; // eax

  result = a1;
  *a1 = n142;
  return result;
}

// IDA_EA: 0x8195D80
// IDA_NAME: _ZNK4ARAD17SearchEventPeriodclERKNS_6SCRIPT16SEventPeriodDataE
// DEMANGLED: ARAD::SearchEventPeriod::operator()(ARAD::SCRIPT::SEventPeriodData const&)const
bool __cdecl ARAD::SearchEventPeriod::operator()(_DWORD *a1, _DWORD *a2)
{
  return *a2 == *a1;
}

// IDA_EA: 0x819A8B4
// IDA_NAME: _ZNK4ARAD17SearchEventPeriodclERKNS_6SCRIPT17SRewardPeriodDataE
// DEMANGLED: ARAD::SearchEventPeriod::operator()(ARAD::SCRIPT::SRewardPeriodData const&)const
bool __cdecl ARAD::SearchEventPeriod::operator()(_DWORD *a1, _DWORD *a2)
{
  return *a2 == *a1;
}
