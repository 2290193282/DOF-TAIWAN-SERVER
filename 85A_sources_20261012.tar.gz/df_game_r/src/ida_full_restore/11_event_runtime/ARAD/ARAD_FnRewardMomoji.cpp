#include "ARAD_FnRewardMomoji.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x819537C
// IDA_NAME: _ZN4ARAD14FnRewardMomoji13GetMailStringEPcS1_
// DEMANGLED: ARAD::FnRewardMomoji::GetMailString(char *,char *)
char *__cdecl ARAD::FnRewardMomoji::GetMailString(ARAD::FnRewardMomoji *this, char *dest_1, char *dest)
{
  const char *src; // eax
  const char *src_1; // eax

  src = (const char *)RDARScriptStringManager::findString(
                        (RDARScriptStringManager *)&g_scriptStringManager_,
                        4,
                        "momiji_event_title",
                        0);
  strncpy(dest, src, 0x14u);
  src_1 = (const char *)RDARScriptStringManager::findString(
                          (RDARScriptStringManager *)&g_scriptStringManager_,
                          4,
                          "momiji_event_mail",
                          0);
  return strncpy(dest_1, src_1, 0xFFu);
}

// IDA_EA: 0x819A900
// IDA_NAME: _ZN4ARAD14FnRewardMomojiC2EP5CUser
// DEMANGLED: ARAD::FnRewardMomoji::FnRewardMomoji(CUser *)
ARAD::FnRewardMomoji *__cdecl ARAD::FnRewardMomoji::FnRewardMomoji(ARAD::FnRewardMomoji *this, CUser *a2)
{
  ARAD::FnRewardMomoji *this_1; // eax

  ARAD::FnRewardInterface::FnRewardInterface(this, a2, 1);
  this_1 = this;
  *(_DWORD *)this = &off_8B9CA58;
  return this_1;
}
