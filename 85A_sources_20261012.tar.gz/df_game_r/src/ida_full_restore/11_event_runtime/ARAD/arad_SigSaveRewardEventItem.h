#ifndef __IDA91_ARAD_SIGSAVEREWARDEVENTITEM_H__
#define __IDA91_ARAD_SIGSAVEREWARDEVENTITEM_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: arad
// Source unit: arad_SigSaveRewardEventItem
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 1408

/* 1408 */
struct arad::SigSaveRewardEventItem;

// Exported member functions:
// 0x8195CD4	arad::SigSaveRewardEventItem::SigSaveRewardEventItem(void)
// 0x8195CE8	arad::SigSaveRewardEventItem::init(void)
// 0x8195D2C	arad::SigSaveRewardEventItem::set(int,unsigned int,unsigned int,unsigned long,short,unsigned int)

// Function declaration index:
// DECL 0x8195CD4 arad::SigSaveRewardEventItem::SigSaveRewardEventItem
// DECL 0x8195CE8 arad::SigSaveRewardEventItem::init
// DECL 0x8195D2C arad::SigSaveRewardEventItem::set

#endif  // __IDA91_ARAD_SIGSAVEREWARDEVENTITEM_H__
