#include "arad_SigSaveRewardEventItem.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8195CD4
// IDA_NAME: _ZN4arad22SigSaveRewardEventItemC2Ev
// DEMANGLED: arad::SigSaveRewardEventItem::SigSaveRewardEventItem(void)
int __cdecl arad::SigSaveRewardEventItem::SigSaveRewardEventItem(arad::SigSaveRewardEventItem *this)
{
  return arad::SigSaveRewardEventItem::init(this);
}

// IDA_EA: 0x8195CE8
// IDA_NAME: _ZN4arad22SigSaveRewardEventItem4initEv
// DEMANGLED: arad::SigSaveRewardEventItem::init(void)
int __cdecl arad::SigSaveRewardEventItem::init(arad::SigSaveRewardEventItem *this)
{
  return arad::SigSaveRewardEventItem::set(this, 0, 0, 0, 0, 0, 0);
}

// IDA_EA: 0x8195D2C
// IDA_NAME: _ZN4arad22SigSaveRewardEventItem3setEijjmsj
// DEMANGLED: arad::SigSaveRewardEventItem::set(int,unsigned int,unsigned int,unsigned long,short,unsigned int)
arad::SigSaveRewardEventItem *__cdecl arad::SigSaveRewardEventItem::set(
        arad::SigSaveRewardEventItem *this,
        int n96,
        unsigned int a3,
        unsigned int a4,
        unsigned int a5,
        __int16 a6,
        unsigned int a7)
{
  arad::SigSaveRewardEventItem *this_1; // eax

  *(_DWORD *)this = n96;
  *((_DWORD *)this + 1) = a3;
  *((_DWORD *)this + 2) = a4;
  *((_DWORD *)this + 4) = a5;
  *((_WORD *)this + 10) = a6;
  this_1 = this;
  *((_DWORD *)this + 3) = a7;
  return this_1;
}
