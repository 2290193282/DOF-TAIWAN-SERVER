#ifndef __IDA91_ARAD_SIGLOADREWARDEVENTITEM_H__
#define __IDA91_ARAD_SIGLOADREWARDEVENTITEM_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: arad
// Source unit: arad_SigLoadRewardEventItem
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 1381

/* 1381 */
struct arad::SigLoadRewardEventItem;

// Exported member functions:
// 0x8186686	arad::SigLoadRewardEventItem::SigLoadRewardEventItem(void)
// 0x818669A	arad::SigLoadRewardEventItem::init(void)
// 0x81866B6	arad::SigLoadRewardEventItem::set(unsigned int)

// Function declaration index:
// DECL 0x8186686 arad::SigLoadRewardEventItem::SigLoadRewardEventItem
// DECL 0x818669A arad::SigLoadRewardEventItem::init
// DECL 0x81866B6 arad::SigLoadRewardEventItem::set

#endif  // __IDA91_ARAD_SIGLOADREWARDEVENTITEM_H__
