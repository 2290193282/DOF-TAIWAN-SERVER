#ifndef __IDA91_ARAD_SINGLETON_LEVELUPSUPPORTEVENTMANGER_H__
#define __IDA91_ARAD_SINGLETON_LEVELUPSUPPORTEVENTMANGER_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: ARAD
// Source unit: ARAD_Singleton<LevelupSupportEventManger>
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
// No matching local type was found; declare types manually during cleanup.

// Exported member functions:
// 0x8147B56	ARAD::Singleton<LevelupSupportEventManger>::Singleton(void)
// 0x8147D68	ARAD::Singleton<LevelupSupportEventManger>::Get(void)

// Function declaration index:
// DECL 0x8147B56 ARAD::Singleton<LevelupSupportEventManger>::Singleton
// DECL 0x8147D68 ARAD::Singleton<LevelupSupportEventManger>::Get

#endif  // __IDA91_ARAD_SINGLETON_LEVELUPSUPPORTEVENTMANGER_H__
