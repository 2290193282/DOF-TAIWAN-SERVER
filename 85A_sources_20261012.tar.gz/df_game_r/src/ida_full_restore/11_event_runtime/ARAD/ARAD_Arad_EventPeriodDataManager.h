#ifndef __IDA91_ARAD_ARAD_EVENTPERIODDATAMANAGER_H__
#define __IDA91_ARAD_ARAD_EVENTPERIODDATAMANAGER_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: ARAD
// Source unit: ARAD_Arad_EventPeriodDataManager
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 1407

/* 1407 */
struct ARAD::Arad_EventPeriodDataManager;

// Exported member functions:
// 0x81953FA	ARAD::Arad_EventPeriodDataManager::Arad_EventPeriodDataManager(void)
// 0x8195536	ARAD::Arad_EventPeriodDataManager::~Arad_EventPeriodDataManager()
// 0x8195632	ARAD::Arad_EventPeriodDataManager::~Arad_EventPeriodDataManager()
// 0x8195650	ARAD::Arad_EventPeriodDataManager::loadScriptData(void)
// 0x8195670	ARAD::Arad_EventPeriodDataManager::clearScriptData(void)
// 0x8195686	ARAD::Arad_EventPeriodDataManager::isRunning(ENUM_REPEAT_EVENT_CODE)
// 0x81956B0	ARAD::Arad_EventPeriodDataManager::isApplied(ENUM_REPEAT_EVENT_CODE,unsigned int)
// 0x8195794	ARAD::Arad_EventPeriodDataManager::checkCreateTime(ENUM_REPEAT_EVENT_CODE,unsigned int,unsigned int)
// 0x819589E	ARAD::Arad_EventPeriodDataManager::setCreatePeriod_GM(int)
// 0x81958B6	ARAD::Arad_EventPeriodDataManager::isRewarded(ARAD::EventRewardItemArad)
// 0x8195994	ARAD::Arad_EventPeriodDataManager::addUserRewardData(CUser *,arad::SigLoadRewardEventItem &)
// 0x8195AA4	ARAD::Arad_EventPeriodDataManager::addUserRewardData(CUser *,ARAD::EventRewardItemArad &)
// 0x8195B06	ARAD::Arad_EventPeriodDataManager::delUserRewardData(CUser *)
// 0x819ABC8	bool ARAD::Arad_EventPeriodDataManager::eventReward<ARAD::FnRewardLethe>(ENUM_REPEAT_EVENT_CODE,unsigned int,CUser *)
// 0x819ADB6	bool ARAD::Arad_EventPeriodDataManager::eventReward<ARAD::FnRewardMomoji>(ENUM_REPEAT_EVENT_CODE,unsigned int,CUser *)

// Function declaration index:
// DECL 0x81953FA ARAD::Arad_EventPeriodDataManager::Arad_EventPeriodDataManager
// DECL 0x8195536 ARAD::Arad_EventPeriodDataManager::~Arad_EventPeriodDataManager
// DECL 0x8195632 ARAD::Arad_EventPeriodDataManager::~Arad_EventPeriodDataManager
// DECL 0x8195650 ARAD::Arad_EventPeriodDataManager::loadScriptData
// DECL 0x8195670 ARAD::Arad_EventPeriodDataManager::clearScriptData
// DECL 0x8195686 ARAD::Arad_EventPeriodDataManager::isRunning
// DECL 0x81956B0 ARAD::Arad_EventPeriodDataManager::isApplied
// DECL 0x8195794 ARAD::Arad_EventPeriodDataManager::checkCreateTime
// DECL 0x819589E ARAD::Arad_EventPeriodDataManager::setCreatePeriod_GM
// DECL 0x81958B6 ARAD::Arad_EventPeriodDataManager::isRewarded
// DECL 0x8195994 ARAD::Arad_EventPeriodDataManager::addUserRewardData
// DECL 0x8195AA4 ARAD::Arad_EventPeriodDataManager::addUserRewardData
// DECL 0x8195B06 ARAD::Arad_EventPeriodDataManager::delUserRewardData
// DECL 0x819ABC8 ARAD::Arad_EventPeriodDataManager::eventReward<ARAD::FnRewardLethe>
// DECL 0x819ADB6 ARAD::Arad_EventPeriodDataManager::eventReward<ARAD::FnRewardMomoji>

#endif  // __IDA91_ARAD_ARAD_EVENTPERIODDATAMANAGER_H__
