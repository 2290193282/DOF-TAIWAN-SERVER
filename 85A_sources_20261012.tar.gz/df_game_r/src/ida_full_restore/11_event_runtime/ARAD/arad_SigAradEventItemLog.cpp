#include "arad_SigAradEventItemLog.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8694F14
// IDA_NAME: _ZN4arad19SigAradEventItemLogC2Ev
// DEMANGLED: arad::SigAradEventItemLog::SigAradEventItemLog(void)
int __cdecl arad::SigAradEventItemLog::SigAradEventItemLog(arad::SigAradEventItemLog *this)
{
  return arad::SigAradEventItemLog::init(this);
}

// IDA_EA: 0x8694F28
// IDA_NAME: _ZN4arad19SigAradEventItemLog4initEv
// DEMANGLED: arad::SigAradEventItemLog::init(void)
arad::SigAradEventItemLog *__cdecl arad::SigAradEventItemLog::init(arad::SigAradEventItemLog *this)
{
  arad::SigAradEventItemLog *this_1; // eax

  *(_DWORD *)this = 0;
  this_1 = this;
  *((_DWORD *)this + 1) = 0;
  return this_1;
}
