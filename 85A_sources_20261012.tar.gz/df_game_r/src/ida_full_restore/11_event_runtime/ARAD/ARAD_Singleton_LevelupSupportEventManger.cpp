#include "ARAD_Singleton_LevelupSupportEventManger.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8147B56
// IDA_NAME: _ZN4ARAD9SingletonI25LevelupSupportEventMangerEC2Ev
// DEMANGLED: ARAD::Singleton<LevelupSupportEventManger>::Singleton(void)
void __cdecl ARAD::Singleton<LevelupSupportEventManger>::Singleton()
{
  ;
}

// IDA_EA: 0x8147D68
// IDA_NAME: _ZN4ARAD9SingletonI25LevelupSupportEventMangerE3GetEv
// DEMANGLED: ARAD::Singleton<LevelupSupportEventManger>::Get(void)
void *ARAD::Singleton<LevelupSupportEventManger>::Get()
{
  if ( !(_BYTE)`guard variable for'ARAD::Singleton<LevelupSupportEventManger>::Get(void)::obj
    && _cxa_guard_acquire(&`guard variable for'ARAD::Singleton<LevelupSupportEventManger>::Get(void)::obj) )
  {
    LevelupSupportEventManger::LevelupSupportEventManger((LevelupSupportEventManger *)&ARAD::Singleton<LevelupSupportEventManger>::Get(void)::obj);
    _cxa_guard_release(&`guard variable for'ARAD::Singleton<LevelupSupportEventManger>::Get(void)::obj);
    __cxa_atexit(
      (void (*)(void *))LevelupSupportEventManger::~LevelupSupportEventManger,
      &ARAD::Singleton<LevelupSupportEventManger>::Get(void)::obj,
      &_dso_handle);
  }
  return &ARAD::Singleton<LevelupSupportEventManger>::Get(void)::obj;
}
