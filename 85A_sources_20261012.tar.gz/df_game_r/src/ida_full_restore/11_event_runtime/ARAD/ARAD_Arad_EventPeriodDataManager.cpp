#include "ARAD_Arad_EventPeriodDataManager.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81953FA
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManagerC2Ev
// DEMANGLED: ARAD::Arad_EventPeriodDataManager::Arad_EventPeriodDataManager(void)
ARAD::Arad_EventPeriodDataManager *__cdecl ARAD::Arad_EventPeriodDataManager::Arad_EventPeriodDataManager(
        ARAD::Arad_EventPeriodDataManager *this)
{
  ARAD::Arad_EventPeriodDataManager *this_1; // eax
  std::string v2; // [esp+18h] [ebp-10h] BYREF
  int v3[2]; // [esp+1Fh] [ebp-9h] BYREF

  std::allocator<char>::allocator(v3);
  std::string::string((int)&v2, "Arad_EventPeriodDataManager", (int)v3);
  ARAD::Arad_InterfaceGameScript::Arad_InterfaceGameScript(this, (std::string)&v2);
  std::string::~string(&v2);
  std::allocator<char>::~allocator(v3);
  *(_DWORD *)this = off_8B9CA40;
  std::vector<ARAD::SCRIPT::SEventPeriodData>::vector((char *)this + 12);
  std::vector<ARAD::SCRIPT::SRewardPeriodData>::vector((char *)this + 24);
  Mutex::Mutex((pthread_mutex_t *)((char *)this + 36));
  std::list<ARAD::EventRewardItemArad>::list((char *)this + 60);
  this_1 = this;
  *((_DWORD *)this + 2) = 0;
  return this_1;
}

// IDA_EA: 0x8195536
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManagerD2Ev
// DEMANGLED: ARAD::Arad_EventPeriodDataManager::~Arad_EventPeriodDataManager()
void __cdecl ARAD::Arad_EventPeriodDataManager::~Arad_EventPeriodDataManager(ARAD::Arad_EventPeriodDataManager *this)
{
  *(_DWORD *)this = off_8B9CA40;
  ARAD::Arad_EventPeriodDataManager::clearScriptData(this);
  std::list<ARAD::EventRewardItemArad>::~list((char *)this + 60);
  Mutex::~Mutex((pthread_mutex_t *)((char *)this + 36));
  std::vector<ARAD::SCRIPT::SRewardPeriodData>::~vector((char *)this + 24);
  std::vector<ARAD::SCRIPT::SEventPeriodData>::~vector((char *)this + 12);
  ARAD::Arad_InterfaceGameScript::~Arad_InterfaceGameScript(this);
}

// IDA_EA: 0x8195632
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManagerD0Ev
// DEMANGLED: ARAD::Arad_EventPeriodDataManager::~Arad_EventPeriodDataManager()
void __cdecl ARAD::Arad_EventPeriodDataManager::~Arad_EventPeriodDataManager(ARAD::Arad_EventPeriodDataManager *this)
{
  ARAD::Arad_EventPeriodDataManager::~Arad_EventPeriodDataManager(this);
  operator delete(this);
}

// IDA_EA: 0x8195650
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManager14loadScriptDataEv
// DEMANGLED: ARAD::Arad_EventPeriodDataManager::loadScriptData(void)
int __cdecl ARAD::Arad_EventPeriodDataManager::loadScriptData(ARAD::Arad_EventPeriodDataManager *this)
{
  return ARAD::SCRIPT::importAradEventScript((char *)this + 12, (char *)this + 24);
}

// IDA_EA: 0x8195670
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManager15clearScriptDataEv
// DEMANGLED: ARAD::Arad_EventPeriodDataManager::clearScriptData(void)
int __cdecl ARAD::Arad_EventPeriodDataManager::clearScriptData(ARAD::Arad_EventPeriodDataManager *this)
{
  return std::vector<ARAD::SCRIPT::SEventPeriodData>::clear((char *)this + 12);
}

// IDA_EA: 0x8195686
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManager9isRunningE22ENUM_REPEAT_EVENT_CODE
// DEMANGLED: ARAD::Arad_EventPeriodDataManager::isRunning(ENUM_REPEAT_EVENT_CODE)
int __cdecl ARAD::Arad_EventPeriodDataManager::isRunning(int a1, int n142)
{
  int CurTickCountEv; // eax

  CurTickCountEv = CSystemTime::getCurTickCount((CSystemTime *)GlobalData::s_systemTime_);
  return ARAD::Arad_EventPeriodDataManager::isApplied(a1, n142, CurTickCountEv);
}

// IDA_EA: 0x81956B0
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManager9isAppliedE22ENUM_REPEAT_EVENT_CODEj
// DEMANGLED: ARAD::Arad_EventPeriodDataManager::isApplied(ENUM_REPEAT_EVENT_CODE,unsigned int)
_BOOL4 __cdecl ARAD::Arad_EventPeriodDataManager::isApplied(int a1, int n142, unsigned int CurSecEv)
{
  int v3; // eax
  int v4; // eax
  _BOOL4 result; // eax
  _BYTE v7[4]; // [esp+18h] [ebp-20h] BYREF
  int v8; // [esp+1Ch] [ebp-1Ch] BYREF
  int v9; // [esp+20h] [ebp-18h] BYREF
  int v10; // [esp+24h] [ebp-14h] BYREF
  _BYTE v11[4]; // [esp+28h] [ebp-10h] BYREF
  unsigned int CurSecEv_1; // [esp+2Ch] [ebp-Ch]

  ARAD::SearchEventPeriod::SearchEventPeriod(&v8, n142);
  std::vector<ARAD::SCRIPT::SEventPeriodData>::end(&v9);
  std::vector<ARAD::SCRIPT::SEventPeriodData>::begin(&v10);
  std::find_if<__gnu_cxx::__normal_iterator<ARAD::SCRIPT::SEventPeriodData *,std::vector<ARAD::SCRIPT::SEventPeriodData>>,ARAD::SearchEventPeriod>(v7);
  std::vector<ARAD::SCRIPT::SEventPeriodData>::end(v11);
  result = 0;
  if ( (unsigned __int8)__gnu_cxx::operator!=<ARAD::SCRIPT::SEventPeriodData *,std::vector<ARAD::SCRIPT::SEventPeriodData>>(
                          v7,
                          v11) )
  {
    CurSecEv_1 = CurSecEv;
    v3 = __gnu_cxx::__normal_iterator<ARAD::SCRIPT::SEventPeriodData *,std::vector<ARAD::SCRIPT::SEventPeriodData>>::operator->(v7);
    if ( *(_DWORD *)(v3 + 4) <= CurSecEv_1 )
    {
      v4 = __gnu_cxx::__normal_iterator<ARAD::SCRIPT::SEventPeriodData *,std::vector<ARAD::SCRIPT::SEventPeriodData>>::operator->(v7);
      if ( *(_DWORD *)(v4 + 8) > CurSecEv_1 )
        return 1;
    }
  }
  return result;
}

// IDA_EA: 0x8195794
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManager15checkCreateTimeE22ENUM_REPEAT_EVENT_CODEjj
// DEMANGLED: ARAD::Arad_EventPeriodDataManager::checkCreateTime(ENUM_REPEAT_EVENT_CODE,unsigned int,unsigned int)
_BOOL4 __cdecl ARAD::Arad_EventPeriodDataManager::checkCreateTime(
        int arg0,
        int n142,
        unsigned int CurCharacCreateTimeEv)
{
  int CurCharacCreateTimeEv_3; // eax
  _BOOL4 result; // eax
  char v5[4]; // [esp+10h] [ebp-28h] BYREF
  int v6; // [esp+14h] [ebp-24h] BYREF
  int v7; // [esp+18h] [ebp-20h] BYREF
  int v8; // [esp+1Ch] [ebp-1Ch] BYREF
  _BYTE v9[7]; // [esp+20h] [ebp-18h] BYREF
  bool isGM; // [esp+27h] [ebp-11h]
  unsigned int CurCharacCreateTimeEv_1; // [esp+28h] [ebp-10h]
  unsigned int CurCharacCreateTimeEv_2; // [esp+2Ch] [ebp-Ch]

  ARAD::SearchEventPeriod::SearchEventPeriod(&v6, n142);
  std::vector<ARAD::SCRIPT::SEventPeriodData>::end((int)&v7, arg0 + 12);
  std::vector<ARAD::SCRIPT::SEventPeriodData>::begin((int)&v8, arg0 + 12);
  std::find_if<__gnu_cxx::__normal_iterator<ARAD::SCRIPT::SEventPeriodData *,std::vector<ARAD::SCRIPT::SEventPeriodData>>,ARAD::SearchEventPeriod>((int)v5);
  std::vector<ARAD::SCRIPT::SEventPeriodData>::end((int)v9, arg0 + 12);
  result = 0;
  if ( __gnu_cxx::operator!=<ARAD::SCRIPT::SEventPeriodData *,std::vector<ARAD::SCRIPT::SEventPeriodData>>(
         (int)v5,
         (int)v9) )
  {
    isGM = WongWork::CGMAccounts::isGM();
    CurCharacCreateTimeEv_3 = isGM ? -86400 * *(_DWORD *)(arg0 + 8) + 1342558800 : 1342558800;
    CurCharacCreateTimeEv_1 = CurCharacCreateTimeEv_3;
    CurCharacCreateTimeEv_2 = *(_DWORD *)(__gnu_cxx::__normal_iterator<ARAD::SCRIPT::SEventPeriodData *,std::vector<ARAD::SCRIPT::SEventPeriodData>>::operator->((int)v5)
                                        + 8);
    if ( CurCharacCreateTimeEv_1 <= CurCharacCreateTimeEv && CurCharacCreateTimeEv < CurCharacCreateTimeEv_2 )
      return 1;
  }
  return result;
}

// IDA_EA: 0x819589E
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManager18setCreatePeriod_GMEi
// DEMANGLED: ARAD::Arad_EventPeriodDataManager::setCreatePeriod_GM(int)
ARAD::Arad_EventPeriodDataManager *__cdecl ARAD::Arad_EventPeriodDataManager::setCreatePeriod_GM(
        ARAD::Arad_EventPeriodDataManager *this,
        int a2)
{
  ARAD::Arad_EventPeriodDataManager *this_1; // eax

  if ( a2 >= 0 )
  {
    this_1 = this;
    *((_DWORD *)this + 2) = a2;
  }
  return this_1;
}

// IDA_EA: 0x81958B6
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManager10isRewardedENS_19EventRewardItemAradE
// DEMANGLED: ARAD::Arad_EventPeriodDataManager::isRewarded(ARAD::EventRewardItemArad)
_BOOL4 __cdecl ARAD::Arad_EventPeriodDataManager::isRewarded(int this)
{
  _BOOL4 v1; // ebx
  int v3; // [esp+1Ch] [ebp-1Ch] BYREF
  int v4; // [esp+20h] [ebp-18h] BYREF
  int v5; // [esp+24h] [ebp-14h] BYREF
  int v6; // [esp+28h] [ebp-10h] BYREF
  _DWORD v7[3]; // [esp+2Ch] [ebp-Ch] BYREF

  Guard<Mutex>::Guard(&v4, (pthread_mutex_t *)(this + 36));
  std::list<ARAD::EventRewardItemArad>::end((int)&v5, this + 60);
  std::list<ARAD::EventRewardItemArad>::begin((int)&v6, (_DWORD *)(this + 60));
  std::find<std::_List_iterator<ARAD::EventRewardItemArad>,ARAD::EventRewardItemArad>((int)&v3);
  std::list<ARAD::EventRewardItemArad>::end((int)v7, this + 60);
  v1 = std::_List_iterator<ARAD::EventRewardItemArad>::operator!=(v7, &v3);
  Guard<Mutex>::~Guard((pthread_mutex_t **)&v4);
  return v1;
}

// IDA_EA: 0x8195994
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManager17addUserRewardDataEP5CUserRN4arad22SigLoadRewardEventItemE
// DEMANGLED: ARAD::Arad_EventPeriodDataManager::addUserRewardData(CUser *,arad::SigLoadRewardEventItem &)
bool __cdecl ARAD::Arad_EventPeriodDataManager::addUserRewardData(
        ARAD::Arad_EventPeriodDataManager *this,
        CUser *a2,
        arad::SigLoadRewardEventItem *a3)
{
  unsigned int charac_noEi; // ebx
  unsigned int acc_idEv; // eax
  int v5; // esi
  int charac_noEi_1; // ebx
  const char *acc_idEv_1; // eax
  bool result; // al
  int v9; // [esp+20h] [ebp-18h] BYREF
  int i; // [esp+2Ch] [ebp-Ch]

  for ( i = 0; ; ++i )
  {
    result = *((__int16 *)a3 + 2) > i;
    if ( *((__int16 *)a3 + 2) <= i )
      break;
    charac_noEi = *(_DWORD *)((char *)a3 + 4 * i + 46);
    acc_idEv = CUser::get_acc_id(a2);
    ARAD::EventRewardItemArad::EventRewardItemArad(
      (ARAD::EventRewardItemArad *)&v9,
      *(_DWORD *)((char *)a3 + 4 * i + 6),
      acc_idEv,
      charac_noEi);
    if ( ARAD::Arad_EventPeriodDataManager::isRewarded((int)this) )
    {
      v5 = *(_DWORD *)((char *)a3 + 4 * i + 6);
      charac_noEi_1 = CUser::get_charac_no(a2, -1);
      acc_idEv_1 = (const char *)CUser::get_acc_id(a2);
      LogManager::logFormat(
        (LogManager *)1,
        (int)"localjapan/Arad_EventPeriodDataManager.cpp",
        "void ARAD::Arad_EventPeriodDataManager::addUserRewardData(CUser*, arad::SigLoadRewardEventItem&)",
        (const char *)0xE3,
        "[FnReward] already reward item. (mid:%u, charac:%u, event:%d)",
        acc_idEv_1,
        charac_noEi_1,
        v5);
    }
    else
    {
      ARAD::Arad_EventPeriodDataManager::addUserRewardData(this, a2, (ARAD::EventRewardItemArad *)&v9);
    }
  }
  return result;
}

// IDA_EA: 0x8195AA4
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManager17addUserRewardDataEP5CUserRNS_19EventRewardItemAradE
// DEMANGLED: ARAD::Arad_EventPeriodDataManager::addUserRewardData(CUser *,ARAD::EventRewardItemArad &)
int __cdecl ARAD::Arad_EventPeriodDataManager::addUserRewardData(
        ARAD::Arad_EventPeriodDataManager *this,
        CUser *a2,
        ARAD::EventRewardItemArad *a3)
{
  int v4[3]; // [esp+1Ch] [ebp-Ch] BYREF

  Guard<Mutex>::Guard(v4, (pthread_mutex_t *)((char *)this + 36));
  std::list<ARAD::EventRewardItemArad>::push_back((char *)this + 60, a3);
  return Guard<Mutex>::~Guard((pthread_mutex_t **)v4);
}

// IDA_EA: 0x8195B06
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManager17delUserRewardDataEP5CUser
// DEMANGLED: ARAD::Arad_EventPeriodDataManager::delUserRewardData(CUser *)
int __cdecl ARAD::Arad_EventPeriodDataManager::delUserRewardData(ARAD::Arad_EventPeriodDataManager *this, CUser *a2)
{
  int acc_idEv; // ebx
  std::_List_node_base *v4; // [esp+1Ch] [ebp-1Ch]
  std::_List_node_base *v5; // [esp+20h] [ebp-18h] BYREF
  int v6; // [esp+24h] [ebp-14h] BYREF
  int v7; // [esp+28h] [ebp-10h] BYREF
  _BYTE v8[12]; // [esp+2Ch] [ebp-Ch] BYREF

  Guard<Mutex>::Guard(&v6, (pthread_mutex_t *)((char *)this + 36));
  std::list<ARAD::EventRewardItemArad>::begin((int)&v5, (_DWORD *)this + 15);
  while ( 1 )
  {
    std::list<ARAD::EventRewardItemArad>::end((int)&v7, (int)this + 60);
    if ( !std::_List_iterator<ARAD::EventRewardItemArad>::operator!=(&v5, &v7) )
      break;
    acc_idEv = *(_DWORD *)(std::_List_iterator<ARAD::EventRewardItemArad>::operator->(&v5) + 4);
    if ( acc_idEv == CUser::get_acc_id(a2) )
    {
      v4 = v5;
      std::_List_iterator<ARAD::EventRewardItemArad>::operator++((_DWORD **)&v5);
      std::list<ARAD::EventRewardItemArad>::erase((int)v8, (int)this + 60, v4);
    }
    else
    {
      std::_List_iterator<ARAD::EventRewardItemArad>::operator++((_DWORD **)&v5);
    }
  }
  return Guard<Mutex>::~Guard((pthread_mutex_t **)&v6);
}

// IDA_EA: 0x819ABC8
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManager11eventRewardINS_13FnRewardLetheEEEb22ENUM_REPEAT_EVENT_CODEjP5CUser
// DEMANGLED: bool ARAD::Arad_EventPeriodDataManager::eventReward<ARAD::FnRewardLethe>(ENUM_REPEAT_EVENT_CODE,unsigned int,CUser *)
int __cdecl ARAD::Arad_EventPeriodDataManager::eventReward<ARAD::FnRewardLethe>(
        ARAD::Arad_EventPeriodDataManager *a1,
        int n143,
        unsigned int CurSecEv,
        CUser *a4)
{
  int v6; // eax
  int v7; // eax
  unsigned int v9; // esi
  __int16 v10; // bx
  int v11; // eax
  _BYTE v12[4]; // [esp+28h] [ebp-30h] BYREF
  int v13; // [esp+2Ch] [ebp-2Ch] BYREF
  int v14; // [esp+38h] [ebp-20h] BYREF
  int v15; // [esp+3Ch] [ebp-1Ch] BYREF
  int v16; // [esp+40h] [ebp-18h] BYREF
  int v17; // [esp+44h] [ebp-14h] BYREF
  _BYTE v18[4]; // [esp+48h] [ebp-10h] BYREF
  unsigned int CurSecEv_1; // [esp+4Ch] [ebp-Ch]

  if ( !a4 || !CUser::get_charac_no(a4, -1) )
    return 0;
  ARAD::FnRewardLethe::FnRewardLethe((ARAD::FnRewardLethe *)&v14, a4);
  ARAD::FnRewardLethe::make_data((ARAD::FnRewardLethe *)&v13, (CUser **)&v14, n143);
  if ( ARAD::Arad_EventPeriodDataManager::isRewarded((int)a1) )
    return 0;
  ARAD::SearchEventPeriod::SearchEventPeriod(&v15, n143);
  std::vector<ARAD::SCRIPT::SRewardPeriodData>::end(&v16);
  std::vector<ARAD::SCRIPT::SRewardPeriodData>::begin(&v17);
  std::find_if<__gnu_cxx::__normal_iterator<ARAD::SCRIPT::SRewardPeriodData *,std::vector<ARAD::SCRIPT::SRewardPeriodData>>,ARAD::SearchEventPeriod>(v12);
  std::vector<ARAD::SCRIPT::SRewardPeriodData>::end(v18);
  if ( !(unsigned __int8)__gnu_cxx::operator!=<ARAD::SCRIPT::SRewardPeriodData *,std::vector<ARAD::SCRIPT::SRewardPeriodData>>(
                           v12,
                           v18) )
    return 0;
  CurSecEv_1 = CurSecEv;
  v6 = __gnu_cxx::__normal_iterator<ARAD::SCRIPT::SRewardPeriodData *,std::vector<ARAD::SCRIPT::SRewardPeriodData>>::operator->(v12);
  if ( *(_DWORD *)(v6 + 12) > CurSecEv_1 )
    return 0;
  v7 = __gnu_cxx::__normal_iterator<ARAD::SCRIPT::SRewardPeriodData *,std::vector<ARAD::SCRIPT::SRewardPeriodData>>::operator->(v12);
  if ( *(_DWORD *)(v7 + 16) <= CurSecEv_1 )
    return 0;
  v9 = *(_DWORD *)(__gnu_cxx::__normal_iterator<ARAD::SCRIPT::SRewardPeriodData *,std::vector<ARAD::SCRIPT::SRewardPeriodData>>::operator->(v12)
                 + 16);
  v10 = *(_WORD *)(__gnu_cxx::__normal_iterator<ARAD::SCRIPT::SRewardPeriodData *,std::vector<ARAD::SCRIPT::SRewardPeriodData>>::operator->(v12)
                 + 8);
  v11 = __gnu_cxx::__normal_iterator<ARAD::SCRIPT::SRewardPeriodData *,std::vector<ARAD::SCRIPT::SRewardPeriodData>>::operator->(v12);
  if ( !(unsigned __int8)ARAD::FnRewardLethe::operator()((CUser **)&v14, n143, *(ARAD::ARAD_ITEM **)(v11 + 4), v10, v9) )
    return 0;
  ARAD::Arad_EventPeriodDataManager::addUserRewardData(a1, a4, (ARAD::EventRewardItemArad *)&v13);
  return 1;
}

// IDA_EA: 0x819ADB6
// IDA_NAME: _ZN4ARAD27Arad_EventPeriodDataManager11eventRewardINS_14FnRewardMomojiEEEb22ENUM_REPEAT_EVENT_CODEjP5CUser
// DEMANGLED: bool ARAD::Arad_EventPeriodDataManager::eventReward<ARAD::FnRewardMomoji>(ENUM_REPEAT_EVENT_CODE,unsigned int,CUser *)
int __cdecl ARAD::Arad_EventPeriodDataManager::eventReward<ARAD::FnRewardMomoji>(
        ARAD::Arad_EventPeriodDataManager *a1,
        char *n155,
        unsigned int CurSecEv,
        CUser *a4)
{
  int v6; // eax
  int v7; // eax
  unsigned int v9; // esi
  __int16 v10; // bx
  int v11; // eax
  _BYTE v12[4]; // [esp+20h] [ebp-38h] BYREF
  int v13; // [esp+24h] [ebp-34h] BYREF
  int v14[3]; // [esp+30h] [ebp-28h] BYREF
  int v15; // [esp+3Ch] [ebp-1Ch] BYREF
  int v16; // [esp+40h] [ebp-18h] BYREF
  int v17; // [esp+44h] [ebp-14h] BYREF
  _BYTE v18[4]; // [esp+48h] [ebp-10h] BYREF
  unsigned int CurSecEv_1; // [esp+4Ch] [ebp-Ch]

  if ( !a4 || !CUser::get_charac_no(a4, -1) )
    return 0;
  ARAD::FnRewardMomoji::FnRewardMomoji((ARAD::FnRewardMomoji *)v14, a4);
  ARAD::FnRewardInterface::make_data((ARAD::FnRewardInterface *)&v13, (int)v14, (int)n155);
  if ( ARAD::Arad_EventPeriodDataManager::isRewarded((int)a1) )
    return 0;
  ARAD::SearchEventPeriod::SearchEventPeriod(&v15, (int)n155);
  std::vector<ARAD::SCRIPT::SRewardPeriodData>::end(&v16);
  std::vector<ARAD::SCRIPT::SRewardPeriodData>::begin(&v17);
  std::find_if<__gnu_cxx::__normal_iterator<ARAD::SCRIPT::SRewardPeriodData *,std::vector<ARAD::SCRIPT::SRewardPeriodData>>,ARAD::SearchEventPeriod>(v12);
  std::vector<ARAD::SCRIPT::SRewardPeriodData>::end(v18);
  if ( !(unsigned __int8)__gnu_cxx::operator!=<ARAD::SCRIPT::SRewardPeriodData *,std::vector<ARAD::SCRIPT::SRewardPeriodData>>(
                           v12,
                           v18) )
    return 0;
  CurSecEv_1 = CurSecEv;
  v6 = __gnu_cxx::__normal_iterator<ARAD::SCRIPT::SRewardPeriodData *,std::vector<ARAD::SCRIPT::SRewardPeriodData>>::operator->(v12);
  if ( *(_DWORD *)(v6 + 12) > CurSecEv_1 )
    return 0;
  v7 = __gnu_cxx::__normal_iterator<ARAD::SCRIPT::SRewardPeriodData *,std::vector<ARAD::SCRIPT::SRewardPeriodData>>::operator->(v12);
  if ( *(_DWORD *)(v7 + 16) <= CurSecEv_1 )
    return 0;
  v9 = *(_DWORD *)(__gnu_cxx::__normal_iterator<ARAD::SCRIPT::SRewardPeriodData *,std::vector<ARAD::SCRIPT::SRewardPeriodData>>::operator->(v12)
                 + 16);
  v10 = *(_WORD *)(__gnu_cxx::__normal_iterator<ARAD::SCRIPT::SRewardPeriodData *,std::vector<ARAD::SCRIPT::SRewardPeriodData>>::operator->(v12)
                 + 8);
  v11 = __gnu_cxx::__normal_iterator<ARAD::SCRIPT::SRewardPeriodData *,std::vector<ARAD::SCRIPT::SRewardPeriodData>>::operator->(v12);
  if ( !(unsigned __int8)ARAD::FnRewardInterface::operator()((int)v14, n155, *(ARAD::ARAD_ITEM **)(v11 + 4), v10, v9) )
    return 0;
  ARAD::Arad_EventPeriodDataManager::addUserRewardData(a1, a4, (ARAD::EventRewardItemArad *)&v13);
  return 1;
}
