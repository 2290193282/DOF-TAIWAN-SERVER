#ifndef __IDA91_ARAD_FNREWARDINTERFACE_H__
#define __IDA91_ARAD_FNREWARDINTERFACE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: ARAD
// Source unit: ARAD_FnRewardInterface
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 1427

/* 1427 */
struct ARAD::FnRewardInterface;

// Exported member functions:
// 0x8194AC8	ARAD::FnRewardInterface::operator()(int,unsigned long,short,unsigned int)
// 0x8194E58	ARAD::FnRewardInterface::make_data(int)
// 0x819A8C8	ARAD::FnRewardInterface::FnRewardInterface(CUser *,bool)

// Function declaration index:
// DECL 0x8194AC8 ARAD::FnRewardInterface::operator
// DECL 0x8194E58 ARAD::FnRewardInterface::make_data
// DECL 0x819A8C8 ARAD::FnRewardInterface::FnRewardInterface

#endif  // __IDA91_ARAD_FNREWARDINTERFACE_H__
