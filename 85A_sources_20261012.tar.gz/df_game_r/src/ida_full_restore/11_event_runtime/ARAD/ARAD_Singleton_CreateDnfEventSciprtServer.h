#ifndef __IDA91_ARAD_SINGLETON_CREATEDNFEVENTSCIPRTSERVER_H__
#define __IDA91_ARAD_SINGLETON_CREATEDNFEVENTSCIPRTSERVER_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: ARAD
// Source unit: ARAD_Singleton<CreateDnfEventSciprtServer>
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
// No matching local type was found; declare types manually during cleanup.

// Exported member functions:
// 0x8164902	ARAD::Singleton<CreateDnfEventSciprtServer>::Singleton(void)
// 0x8164907	ARAD::Singleton<CreateDnfEventSciprtServer>::Get(void)

// Function declaration index:
// DECL 0x8164902 ARAD::Singleton<CreateDnfEventSciprtServer>::Singleton
// DECL 0x8164907 ARAD::Singleton<CreateDnfEventSciprtServer>::Get

#endif  // __IDA91_ARAD_SINGLETON_CREATEDNFEVENTSCIPRTSERVER_H__
