#ifndef __IDA91_DISPATCHER_FATIGUEATTENDANCE_H__
#define __IDA91_DISPATCHER_FATIGUEATTENDANCE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Dispatcher_FatigueAttendance
// Source unit: Dispatcher_FatigueAttendance
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 4264

/* 4264 */
struct Dispatcher_FatigueAttendance;

// Exported member functions:
// 0x81DAFA4	Dispatcher_FatigueAttendance::read(PacketBuf &,MSG_BASE &)
// 0x81DAFFA	Dispatcher_FatigueAttendance::process(CUser *,MSG_BASE &,ParamBase &)
// 0x81DB310	Dispatcher_FatigueAttendance::check_error(CUser *,MSG_BASE &)
// 0x81DB392	Dispatcher_FatigueAttendance::send(CUser *,ParamBase &)
// 0x82449BC	Dispatcher_FatigueAttendance::~Dispatcher_FatigueAttendance()
// 0x82449EC	Dispatcher_FatigueAttendance::~Dispatcher_FatigueAttendance()
// 0x8595970	Dispatcher_FatigueAttendance::Dispatcher_FatigueAttendance(void)

// Function declaration index:
// DECL 0x81DAFA4 Dispatcher_FatigueAttendance::read
// DECL 0x81DAFFA Dispatcher_FatigueAttendance::process
// DECL 0x81DB310 Dispatcher_FatigueAttendance::check_error
// DECL 0x81DB392 Dispatcher_FatigueAttendance::send
// DECL 0x82449BC Dispatcher_FatigueAttendance::~Dispatcher_FatigueAttendance
// DECL 0x82449EC Dispatcher_FatigueAttendance::~Dispatcher_FatigueAttendance
// DECL 0x8595970 Dispatcher_FatigueAttendance::Dispatcher_FatigueAttendance

#endif  // __IDA91_DISPATCHER_FATIGUEATTENDANCE_H__
