#include "Dispatcher_FatigueAttendance.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81DAFA4
// IDA_NAME: _ZN28Dispatcher_FatigueAttendance4readER9PacketBufR8MSG_BASE
// DEMANGLED: Dispatcher_FatigueAttendance::read(PacketBuf &,MSG_BASE &)
int __cdecl Dispatcher_FatigueAttendance::read(Dispatcher_FatigueAttendance *this, PacketBuf *a2, MSG_BASE *a3)
{
  if ( (unsigned __int8)PacketBuf::get_int(a2, (int *)((char *)a3 + 13)) == 1 )
    return 0;
  else
    return LineFunc(18867, "virtual int Dispatcher_FatigueAttendance::read(PacketBuf&, MSG_BASE&)", 0, 0);
}

// IDA_EA: 0x81DAFFA
// IDA_NAME: _ZN28Dispatcher_FatigueAttendance7processEP5CUserR8MSG_BASER9ParamBase
// DEMANGLED: Dispatcher_FatigueAttendance::process(CUser *,MSG_BASE &,ParamBase &)
int __cdecl Dispatcher_FatigueAttendance::process(
        Dispatcher_FatigueAttendance *this,
        CUser *a2,
        MSG_BASE *a3,
        ParamBase *a4)
{
  CDataManager *v5; // eax
  EventClassify::CEventScriptMng *event_script_mngEv; // eax
  CDataManager *v7; // eax
  int server_fatigue_countEh; // ebx
  CDataManager *v9; // eax
  CDataManager *v10; // eax
  EventClassify::CEventScriptMng *event_script_mngEv_1; // eax
  int event_start_timeEv; // eax
  int event_end_timeEv; // eax
  int fatigue_conditionEv; // eax
  CDataManager *v16; // eax
  EventClassify::CEventScriptMng *event_script_mngEv_2; // eax
  int today_timeEv_1; // eax
  int v19; // esi
  int event_start_timeEv_1; // ebx
  CDataManager *v21; // eax
  EventClassify::CEventScriptMng *event_script_mngEv_3; // eax
  CDataManager *v23; // eax
  EventClassify::CEventScriptMng *event_script_mngEv_4; // eax
  unsigned int BingoDataEv_; // [esp+10h] [ebp-38h] BYREF
  unsigned int v26[2]; // [esp+14h] [ebp-34h] BYREF
  int *v27; // [esp+1Ch] [ebp-2Ch]
  MSG_BASE *v28; // [esp+20h] [ebp-28h]
  unsigned __int8 today_time_dayEv; // [esp+27h] [ebp-21h]
  char v30[4]; // [esp+28h] [ebp-20h]
  int fatigue_conditionEv_1; // [esp+2Ch] [ebp-1Ch]
  EventClassify::CEventEntity *event_entityEi; // [esp+30h] [ebp-18h]
  int today_timeEv; // [esp+34h] [ebp-14h]
  int pass_dayEii; // [esp+38h] [ebp-10h]
  int final_day_conditionEv; // [esp+3Ch] [ebp-Ch]

  v27 = (int *)a4;
  v28 = a3;
  *((_DWORD *)a4 + 2) = *(_DWORD *)((char *)a3 + 13);
  v27[1] = Dispatcher_FatigueAttendance::check_error(this, a2, a3);
  if ( v27[1] > 0 )
    return 0;
  if ( v27[1] < 0 )
    return LineFunc(
             18885,
             "virtual int Dispatcher_FatigueAttendance::process(CUser*, MSG_BASE&, ParamBase&)",
             v27[1],
             0);
  v5 = (CDataManager *)G_CDataManager();
  event_script_mngEv = (EventClassify::CEventScriptMng *)CDataManager::get_event_script_mng(v5);
  today_time_dayEv = EventClassify::CEventScriptMng::get_today_time_day(event_script_mngEv);
  v7 = (CDataManager *)G_CDataManager();
  CDataManager::get_event_script_mng(v7);
  *(_DWORD *)v30 = EventClassify::CEventScriptMng::get_record_type();
  std::pair<int,int>::pair(v26);
  CUser::get_ingame_event_history(a2, v30[0], v26);
  BingoDataEv_ = v26[0];
  if ( (unsigned __int8)isSetBit_Uint(v26[0], today_time_dayEv - 1) )
  {
    v27[1] = 18;
    return 0;
  }
  else
  {
    server_fatigue_countEh = (__int16)CUser::get_server_fatigue_count(a2, today_time_dayEv);
    fatigue_conditionEv_1 = server_fatigue_countEh + CUser::get_fatigue_count_db(a2, today_time_dayEv);
    event_entityEi = 0;
    v9 = (CDataManager *)G_CDataManager();
    CDataManager::get_event_script_mng(v9);
    event_entityEi = (EventClassify::CEventEntity *)EventClassify::CEventScriptMng::get_event_entity();
    if ( event_entityEi )
    {
      v10 = (CDataManager *)G_CDataManager();
      event_script_mngEv_1 = (EventClassify::CEventScriptMng *)CDataManager::get_event_script_mng(v10);
      today_timeEv = EventClassify::CEventScriptMng::get_today_time(event_script_mngEv_1);
      event_start_timeEv = EventClassify::CEventEntity::get_event_start_time(event_entityEi);
      if ( event_start_timeEv > today_timeEv
        || (event_end_timeEv = EventClassify::CEventEntity::get_event_end_time(event_entityEi),
            event_end_timeEv < today_timeEv) )
      {
        v27[1] = 7;
        return 0;
      }
      else
      {
        fatigue_conditionEv = EventClassify::CAttendance::get_fatigue_condition(event_entityEi);
        if ( fatigue_conditionEv <= fatigue_conditionEv_1 )
        {
          setBit_Uint(&BingoDataEv_, 1, today_time_dayEv - 1);
          CUser::set_ingame_event_history(a2, v30[0], BingoDataEv_, 0);
          v27[3] = BingoDataEv_;
          v16 = (CDataManager *)G_CDataManager();
          event_script_mngEv_2 = (EventClassify::CEventScriptMng *)CDataManager::get_event_script_mng(v16);
          today_timeEv_1 = EventClassify::CEventScriptMng::get_today_time(event_script_mngEv_2);
          v27[4] = today_timeEv_1;
          v19 = v27[4];
          event_start_timeEv_1 = EventClassify::CEventEntity::get_event_start_time(event_entityEi);
          v21 = (CDataManager *)G_CDataManager();
          event_script_mngEv_3 = (EventClassify::CEventScriptMng *)CDataManager::get_event_script_mng(v21);
          pass_dayEii = EventClassify::CEventScriptMng::get_pass_day(event_script_mngEv_3, event_start_timeEv_1, v19);
          EventClassify::CAttendance::send_attend_reward_item(event_entityEi, a2, pass_dayEii);
          v23 = (CDataManager *)G_CDataManager();
          event_script_mngEv_4 = (EventClassify::CEventScriptMng *)CDataManager::get_event_script_mng(v23);
          EventClassify::CEventScriptMng::process_update_ingame_history(event_script_mngEv_4, a2);
          CUser::reset_ingame_event_history_update(a2);
          final_day_conditionEv = EventClassify::CAttendance::get_final_day_condition(event_entityEi);
          EventClassify::CAttendance::send_attend_final_rward_item(
            event_entityEi,
            a2,
            BingoDataEv_,
            final_day_conditionEv);
        }
        else
        {
          v27[1] = 22;
        }
        return 0;
      }
    }
    else
    {
      return 0;
    }
  }
}

// IDA_EA: 0x81DB310
// IDA_NAME: _ZN28Dispatcher_FatigueAttendance11check_errorEP5CUserR8MSG_BASE
// DEMANGLED: Dispatcher_FatigueAttendance::check_error(CUser *,MSG_BASE &)
int __cdecl Dispatcher_FatigueAttendance::check_error(Dispatcher_FatigueAttendance *this, CUser *a2)
{
  CDataManager *v3; // eax
  EventClassify::CEventScriptMng *event_script_mngEv; // eax

  if ( !a2 )
    return -1;
  if ( !CUserCharacInfo::getCurCharacR(a2) )
    return -1;
  if ( CUser::get_state(a2) != 3 )
    return 99;
  v3 = (CDataManager *)G_CDataManager();
  event_script_mngEv = (EventClassify::CEventScriptMng *)CDataManager::get_event_script_mng(v3);
  if ( (unsigned __int8)EventClassify::CEventScriptMng::is_eventing(event_script_mngEv, 0x56u) == 1 )
    return 0;
  else
    return 7;
}

// IDA_EA: 0x81DB392
// IDA_NAME: _ZN28Dispatcher_FatigueAttendance4sendEP5CUserR9ParamBase
// DEMANGLED: Dispatcher_FatigueAttendance::send(CUser *,ParamBase &)
void __cdecl Dispatcher_FatigueAttendance::send(Dispatcher_FatigueAttendance *this, CUser *a2, ParamBase *a3)
{
  PacketBuf *v3[3]; // [esp+10h] [ebp-18h] BYREF
  ParamBase *v4; // [esp+1Ch] [ebp-Ch]

  v4 = a3;
  PacketGuard::PacketGuard((PacketGuard *)v3);
  InterfacePacketBuf::clear(v3);
  InterfacePacketBuf::put_header(v3, 1, 429);
  if ( *((_DWORD *)v4 + 1) )
  {
    InterfacePacketBuf::put_byte(v3, 0);
    InterfacePacketBuf::put_byte(v3, (char)*((_DWORD *)v4 + 1));
    InterfacePacketBuf::put_short(v3, *((_DWORD *)v4 + 2));
  }
  else
  {
    InterfacePacketBuf::put_byte(v3, 1);
    InterfacePacketBuf::put_short(v3, *((_DWORD *)v4 + 2));
    InterfacePacketBuf::put_int(v3, *((_DWORD *)v4 + 3));
    InterfacePacketBuf::put_int(v3, *((_DWORD *)v4 + 4));
  }
  InterfacePacketBuf::finalize(v3, 1);
  CUser::Send(a2, (PacketGuard *)v3);
  PacketGuard::~PacketGuard(v3);
}

// IDA_EA: 0x82449BC
// IDA_NAME: _ZN28Dispatcher_FatigueAttendanceD2Ev
// DEMANGLED: Dispatcher_FatigueAttendance::~Dispatcher_FatigueAttendance()
void __cdecl Dispatcher_FatigueAttendance::~Dispatcher_FatigueAttendance(Dispatcher_FatigueAttendance *this)
{
  *(_DWORD *)this = &off_8BDA748;
  IPacketDispatcher<MSG_FATIGUE_ATTENDANCE,stFatigueAttendance,(ch_state)0>::~IPacketDispatcher(this);
}

// IDA_EA: 0x82449EC
// IDA_NAME: _ZN28Dispatcher_FatigueAttendanceD0Ev
// DEMANGLED: Dispatcher_FatigueAttendance::~Dispatcher_FatigueAttendance()
void __cdecl Dispatcher_FatigueAttendance::~Dispatcher_FatigueAttendance(Dispatcher_FatigueAttendance *this)
{
  Dispatcher_FatigueAttendance::~Dispatcher_FatigueAttendance(this);
  operator delete(this);
}

// IDA_EA: 0x8595970
// IDA_NAME: _ZN28Dispatcher_FatigueAttendanceC2Ev
// DEMANGLED: Dispatcher_FatigueAttendance::Dispatcher_FatigueAttendance(void)
void __cdecl Dispatcher_FatigueAttendance::Dispatcher_FatigueAttendance(Dispatcher_FatigueAttendance *this)
{
  IPacketDispatcher<MSG_FATIGUE_ATTENDANCE,stFatigueAttendance,(ch_state)0>::IPacketDispatcher(this);
  *(_DWORD *)this = &off_8BDA748;
}
