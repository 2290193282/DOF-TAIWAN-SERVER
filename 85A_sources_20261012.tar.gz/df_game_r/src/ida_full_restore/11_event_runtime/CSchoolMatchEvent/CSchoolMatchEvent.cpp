#include "CSchoolMatchEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8273ECC
// IDA_NAME: _ZN17CSchoolMatchEventC2Ev
// DEMANGLED: CSchoolMatchEvent::CSchoolMatchEvent(void)
void __cdecl CSchoolMatchEvent::CSchoolMatchEvent(CSchoolMatchEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8BFD208;
  std::vector<int>::vector((int)this + 12);
}

// IDA_EA: 0x8273F1A
// IDA_NAME: _ZN17CSchoolMatchEventD2Ev
// DEMANGLED: CSchoolMatchEvent::~CSchoolMatchEvent()
void __cdecl CSchoolMatchEvent::~CSchoolMatchEvent(CSchoolMatchEvent *this)
{
  *(_DWORD *)this = off_8BFD208;
  std::vector<int>::~vector((_DWORD *)this + 3);
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x8273F7C
// IDA_NAME: _ZN17CSchoolMatchEventD0Ev
// DEMANGLED: CSchoolMatchEvent::~CSchoolMatchEvent()
void __cdecl CSchoolMatchEvent::~CSchoolMatchEvent(CSchoolMatchEvent *this)
{
  CSchoolMatchEvent::~CSchoolMatchEvent(this);
  operator delete(this);
}

// IDA_EA: 0x8273F9A
// IDA_NAME: _ZN17CSchoolMatchEvent10StartEventEv
// DEMANGLED: CSchoolMatchEvent::StartEvent(void)
int __cdecl CSchoolMatchEvent::StartEvent(CSchoolMatchEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CSchoolMatchEvent::StartEvent()", 21, 0);
  return cMyTrace::operator()((int)v3, "CSchoolMatchEvent Start!", v2);
}

// IDA_EA: 0x8273FEC
// IDA_NAME: _ZN17CSchoolMatchEvent10StartEventE10Word_Param
// DEMANGLED: CSchoolMatchEvent::StartEvent(Word_Param)
char __cdecl CSchoolMatchEvent::StartEvent(CEventBase *a1, char a2)
{
  char v2; // bl
  GameWorld *v3; // eax
  GameWorld *v4; // eax
  CEnvironment *v6; // eax
  int channel_noEv; // eax
  CEnvironment *v8; // eax
  char result; // al
  bool v10; // [esp+4h] [ebp-84h]
  unsigned int v11; // [esp+4h] [ebp-84h]
  int v12; // [esp+4h] [ebp-84h]
  char v13; // [esp+8h] [ebp-80h]
  int v14; // [esp+30h] [ebp-58h] BYREF
  int v15[4]; // [esp+34h] [ebp-54h] BYREF
  int v16[4]; // [esp+44h] [ebp-44h] BYREF
  _BYTE v17[4]; // [esp+54h] [ebp-34h] BYREF
  int v18; // [esp+58h] [ebp-30h]
  int v19; // [esp+5Ch] [ebp-2Ch] BYREF
  int v20; // [esp+60h] [ebp-28h] BYREF
  _BYTE v21[4]; // [esp+64h] [ebp-24h] BYREF
  int v22; // [esp+68h] [ebp-20h] BYREF
  unsigned __int8 *v23; // [esp+6Ch] [ebp-1Ch]

  CEventBase::SetEventFlag(a1, 1);
  v23 = (unsigned __int8 *)&a2;
  v2 = a2;
  cMyTrace::cMyTrace((cMyTrace *)v15, "virtual void CSchoolMatchEvent::StartEvent(Word_Param)", 30, 0);
  cMyTrace::operator()(
    (int)v15,
    "CSchoolMatchEvent Start! channel_no(%d), player_count(%d), school_rating(%d), player_rating(%d)",
    v2);
  v3 = (GameWorld *)G_GameWorld();
  if ( GameWorld::GetChannelType(v3) == 9 || (v4 = (GameWorld *)G_GameWorld(), GameWorld::GetChannelType(v4) == 10) )
  {
    v6 = (CEnvironment *)G_CEnvironment();
    channel_noEv = CEnvironment::get_channel_no(v6);
    if ( channel_noEv == *v23 )
    {
      CLeagueMatch::SetMatchAble((CLeagueMatch *)1, v10);
      CLeagueMatch::SetPlayCountPerOneTeam((CLeagueMatch *)v23[1], v11);
      PvPGlobalEnvironmentVariable::school_match_elo_k2_ = v23[2];
      PvPGlobalEnvironmentVariable::school_match_elo_k_ = v23[3];
      v8 = (CEnvironment *)G_CEnvironment();
      if ( CEnvironment::get_channel_no(v8) == 71 )
        CLeagueMatch::SetBattleMode((CLeagueMatch *)2, v12);
      cMyTrace::cMyTrace((cMyTrace *)v16, "virtual void CSchoolMatchEvent::StartEvent(Word_Param)", 48, 0);
      cMyTrace::operator()((int)v16, "This is School Matching Server!!", v13);
    }
  }
  v18 = *v23;
  std::vector<int>::end((int)&v19, (int)a1 + 12);
  std::vector<int>::begin((int)&v20, (int)a1 + 12);
  std::find<__gnu_cxx::__normal_iterator<int *,std::vector<int>>,int>((int)v17);
  __gnu_cxx::__normal_iterator<int const*,std::vector<int>>::__normal_iterator<int *>(&v14, (int)v17);
  std::vector<int>::end((int)v21, (int)a1 + 12);
  result = __gnu_cxx::operator==<int const*,int *,std::vector<int>>((int)&v14, (int)v21);
  if ( result )
  {
    v22 = *v23;
    return std::vector<int>::push_back((int)a1 + 12, (int)&v22);
  }
  return result;
}

// IDA_EA: 0x827423C
// IDA_NAME: _ZN17CSchoolMatchEvent8EndEventEv
// DEMANGLED: CSchoolMatchEvent::EndEvent(void)
int __cdecl CSchoolMatchEvent::EndEvent(CSchoolMatchEvent *this)
{
  bool v2; // [esp+4h] [ebp-24h]
  char v3; // [esp+8h] [ebp-20h]
  int v4[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  CLeagueMatch::SetMatchAble(0, v2);
  cMyTrace::cMyTrace((cMyTrace *)v4, "virtual void CSchoolMatchEvent::EndEvent()", 63, 0);
  cMyTrace::operator()((int)v4, "CSchoolMatchEvent End!", v3);
  return std::vector<int>::clear((_DWORD *)this + 3);
}

// IDA_EA: 0x82742A8
// IDA_NAME: _ZN17CSchoolMatchEvent10AppendInfoER11PacketGuard
// DEMANGLED: CSchoolMatchEvent::AppendInfo(PacketGuard &)
bool __cdecl CSchoolMatchEvent::AppendInfo(CSchoolMatchEvent *this, PacketBuf **a2)
{
  int v2; // eax
  bool result; // al
  int v4; // [esp+14h] [ebp-14h] BYREF
  _BYTE v5[4]; // [esp+18h] [ebp-10h] BYREF
  int v6; // [esp+1Ch] [ebp-Ch]

  v2 = std::vector<int>::size((_DWORD *)this + 3);
  InterfacePacketBuf::put_byte(a2, v2);
  std::vector<int>::begin((int)&v4, (int)this + 12);
  while ( 1 )
  {
    std::vector<int>::end((int)v5, (int)this + 12);
    result = __gnu_cxx::operator!=<int *,std::vector<int>>((int)&v4, (int)v5);
    if ( !result )
      break;
    v6 = *(_DWORD *)__gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator*((int)&v4);
    InterfacePacketBuf::put_short(a2, v6);
    __gnu_cxx::__normal_iterator<int *,std::vector<int>>::operator++(&v4);
  }
  return result;
}
