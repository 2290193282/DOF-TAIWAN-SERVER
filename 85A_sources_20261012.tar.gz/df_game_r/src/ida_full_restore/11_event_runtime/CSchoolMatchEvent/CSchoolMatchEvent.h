#ifndef __IDA91_CSCHOOLMATCHEVENT_H__
#define __IDA91_CSCHOOLMATCHEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CSchoolMatchEvent
// Source unit: CSchoolMatchEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "network/PacketGuard.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 4416

/* 4416 */
struct CSchoolMatchEvent;

// Exported member functions:
// 0x8273ECC	CSchoolMatchEvent::CSchoolMatchEvent(void)
// 0x8273F1A	CSchoolMatchEvent::~CSchoolMatchEvent()
// 0x8273F7C	CSchoolMatchEvent::~CSchoolMatchEvent()
// 0x8273F9A	CSchoolMatchEvent::StartEvent(void)
// 0x8273FEC	CSchoolMatchEvent::StartEvent(Word_Param)
// 0x827423C	CSchoolMatchEvent::EndEvent(void)
// 0x82742A8	CSchoolMatchEvent::AppendInfo(PacketGuard &)

// Function declaration index:
// DECL 0x8273ECC CSchoolMatchEvent::CSchoolMatchEvent
// DECL 0x8273F1A CSchoolMatchEvent::~CSchoolMatchEvent
// DECL 0x8273F7C CSchoolMatchEvent::~CSchoolMatchEvent
// DECL 0x8273F9A CSchoolMatchEvent::StartEvent
// DECL 0x8273FEC CSchoolMatchEvent::StartEvent
// DECL 0x827423C CSchoolMatchEvent::EndEvent
// DECL 0x82742A8 CSchoolMatchEvent::AppendInfo

#endif  // __IDA91_CSCHOOLMATCHEVENT_H__
