#ifndef __IDA91_STEVENTMONSTER_T_H__
#define __IDA91_STEVENTMONSTER_T_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stEventMonster_t
// Source unit: stEventMonster_t
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3879

/* 3879 */
struct stEventMonster_t;

// Exported member functions:
// 0x88F90C0	stEventMonster_t::~stEventMonster_t()

// Function declaration index:
// DECL 0x88F90C0 stEventMonster_t::~stEventMonster_t

#endif  // __IDA91_STEVENTMONSTER_T_H__
