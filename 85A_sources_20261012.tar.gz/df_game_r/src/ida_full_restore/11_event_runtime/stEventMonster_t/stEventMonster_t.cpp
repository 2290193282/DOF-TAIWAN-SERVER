#include "stEventMonster_t.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x88F90C0
// IDA_NAME: _ZN16stEventMonster_tD2Ev
// DEMANGLED: stEventMonster_t::~stEventMonster_t()
void stEventMonster_t::~stEventMonster_t()
{
  ;
}
