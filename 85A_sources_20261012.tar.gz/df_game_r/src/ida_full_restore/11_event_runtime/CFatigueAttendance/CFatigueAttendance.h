#ifndef __IDA91_CFATIGUEATTENDANCE_H__
#define __IDA91_CFATIGUEATTENDANCE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CFatigueAttendance
// Source unit: CFatigueAttendance
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1207

/* 1207 */
struct CFatigueAttendance;

// Exported member functions:
// 0x81173EA	CFatigueAttendance::CFatigueAttendance(void)
// 0x8117406	CFatigueAttendance::~CFatigueAttendance()
// 0x8117436	CFatigueAttendance::~CFatigueAttendance()
// 0x8117454	CFatigueAttendance::StartEvent(void)
// 0x8117470	CFatigueAttendance::StartEvent(Word_Param)
// 0x81174FE	CFatigueAttendance::EndEvent(void)

// Function declaration index:
// DECL 0x81173EA CFatigueAttendance::CFatigueAttendance
// DECL 0x8117406 CFatigueAttendance::~CFatigueAttendance
// DECL 0x8117436 CFatigueAttendance::~CFatigueAttendance
// DECL 0x8117454 CFatigueAttendance::StartEvent
// DECL 0x8117470 CFatigueAttendance::StartEvent
// DECL 0x81174FE CFatigueAttendance::EndEvent

#endif  // __IDA91_CFATIGUEATTENDANCE_H__
