#include "CFatigueAttendance.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81173EA
// IDA_NAME: _ZN18CFatigueAttendanceC2Ev
// DEMANGLED: CFatigueAttendance::CFatigueAttendance(void)
void __cdecl CFatigueAttendance::CFatigueAttendance(CFatigueAttendance *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B4F2E8;
}

// IDA_EA: 0x8117406
// IDA_NAME: _ZN18CFatigueAttendanceD2Ev
// DEMANGLED: CFatigueAttendance::~CFatigueAttendance()
void __cdecl CFatigueAttendance::~CFatigueAttendance(CFatigueAttendance *this)
{
  *(_DWORD *)this = off_8B4F2E8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x8117436
// IDA_NAME: _ZN18CFatigueAttendanceD0Ev
// DEMANGLED: CFatigueAttendance::~CFatigueAttendance()
void __cdecl CFatigueAttendance::~CFatigueAttendance(CFatigueAttendance *this)
{
  CFatigueAttendance::~CFatigueAttendance(this);
  operator delete(this);
}

// IDA_EA: 0x8117454
// IDA_NAME: _ZN18CFatigueAttendance10StartEventEv
// DEMANGLED: CFatigueAttendance::StartEvent(void)
CEventBase *__cdecl CFatigueAttendance::StartEvent(CFatigueAttendance *this)
{
  return CEventBase::SetEventFlag(this, 1);
}

// IDA_EA: 0x8117470
// IDA_NAME: _ZN18CFatigueAttendance10StartEventE10Word_Param
// DEMANGLED: CFatigueAttendance::StartEvent(Word_Param)
int __cdecl CFatigueAttendance::StartEvent(_DWORD *a1, int a2)
{
  __int16 v2; // bx
  int v4[6]; // [esp+10h] [ebp-18h] BYREF

  a1[1] = a2;
  (*(void (__cdecl **)(_DWORD *))(*a1 + 8))(a1);
  v2 = *((_WORD *)a1 + 2);
  cMyTrace::cMyTrace((cMyTrace *)v4, "virtual void CFatigueAttendance::StartEvent(Word_Param)", 28, 0);
  return cMyTrace::operator()((int)v4, "CFatigueAttendance(AddInfo:%d,%d) Event Start!", v2);
}

// IDA_EA: 0x81174FE
// IDA_NAME: _ZN18CFatigueAttendance8EndEventEv
// DEMANGLED: CFatigueAttendance::EndEvent(void)
int __cdecl CFatigueAttendance::EndEvent(CFatigueAttendance *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CFatigueAttendance::EndEvent()", 34, 0);
  return cMyTrace::operator()((int)v3, "CFatigueAttendance Event End!", v2);
}
