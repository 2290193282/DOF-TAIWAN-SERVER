#ifndef __IDA91_INTER_COLLECTITEMSREWARD_H__
#define __IDA91_INTER_COLLECTITEMSREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_CollectItemsReward
// Source unit: Inter_CollectItemsReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 3228

/* 3228 */
struct Inter_CollectItemsReward;

// Exported member functions:
// 0x84E71EE	Inter_CollectItemsReward::dispatch_sig(CUser *,char *,int)
// 0x84EEDC0	Inter_CollectItemsReward::Inter_CollectItemsReward(void)
// 0x84F5C70	Inter_CollectItemsReward::~Inter_CollectItemsReward()
// 0x84F5CA0	Inter_CollectItemsReward::~Inter_CollectItemsReward()

// Function declaration index:
// DECL 0x84E71EE Inter_CollectItemsReward::dispatch_sig
// DECL 0x84EEDC0 Inter_CollectItemsReward::Inter_CollectItemsReward
// DECL 0x84F5C70 Inter_CollectItemsReward::~Inter_CollectItemsReward
// DECL 0x84F5CA0 Inter_CollectItemsReward::~Inter_CollectItemsReward

#endif  // __IDA91_INTER_COLLECTITEMSREWARD_H__
