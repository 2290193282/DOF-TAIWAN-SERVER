#include "Inter_CollectItemsReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84E71EE
// IDA_NAME: _ZN24Inter_CollectItemsReward12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_CollectItemsReward::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_CollectItemsReward::dispatch_sig(Inter_CollectItemsReward *this, CUser *a2, char *a3)
{
  char *p_s; // edx
  unsigned int n256; // ebx
  char *v6; // edi
  char *v7; // edx
  __int16 *p_dest; // eax
  char n30; // bl
  unsigned int v10; // ecx
  __int16 *v11; // eax
  int n2; // eax
  const char *CurCharacNameEv_2; // ebx
  char *format_2; // eax
  const char *CurCharacNameEv; // ebx
  char *format; // eax
  const char *CurCharacNameEv_1; // ebx
  char *format_1; // eax
  const char *src; // eax
  unsigned int n8663_1; // ebx
  CItemList **v21; // eax
  int ServerGroup; // ebx
  size_t v23; // esi
  int CurCharacNoEv; // eax
  char s; // [esp+3Dh] [ebp-18Bh] BYREF
  __int16 v26; // [esp+3Eh] [ebp-18Ah] BYREF
  _BYTE v27[2]; // [esp+13Dh] [ebp-8Bh] BYREF
  int n8663; // [esp+13Fh] [ebp-89h]
  int v29; // [esp+144h] [ebp-84h]
  __int16 dest; // [esp+17Ah] [ebp-4Eh] BYREF
  int v31; // [esp+17Ch] [ebp-4Ch] BYREF
  int v32[4]; // [esp+198h] [ebp-30h] BYREF
  char *v33; // [esp+1A8h] [ebp-20h]
  int item; // [esp+1ACh] [ebp-1Ch]

  v33 = a3;
  if ( !CUserCharacInfo::getCurCharacR(a2) )
    return 0;
  Inven_Item::Inven_Item((Inven_Item *)v27);
  item = 0;
  p_s = &s;
  n256 = 256;
  if ( ((unsigned __int8)&s & 1) != 0 )
  {
    s = 0;
    p_s = (char *)&v26;
    n256 = 255;
  }
  if ( ((unsigned __int8)p_s & 2) != 0 )
  {
    *(_WORD *)p_s = 0;
    p_s += 2;
    n256 -= 2;
  }
  memset(p_s, 0, 4 * (n256 >> 2));
  v6 = &p_s[4 * (n256 >> 2)];
  v7 = v6;
  if ( (n256 & 2) != 0 )
  {
    *(_WORD *)v6 = 0;
    v7 = v6 + 2;
  }
  if ( (n256 & 1) != 0 )
    *v7 = 0;
  p_dest = &dest;
  n30 = 30;
  if ( ((unsigned __int8)&dest & 2) != 0 )
  {
    dest = 0;
    p_dest = (__int16 *)&v31;
    n30 = 28;
  }
  v10 = 0;
  do
  {
    *(_DWORD *)&p_dest[v10 / 2] = 0;
    v10 += 4;
  }
  while ( v10 < (n30 & 0x1Cu) );
  v11 = &p_dest[v10 / 2];
  if ( (n30 & 2) != 0 )
    *v11 = 0;
  n2 = (unsigned __int8)v33[18];
  if ( n2 == 1 )
  {
    n8663 = 8663;
    v29 = 1;
    CurCharacNameEv = (const char *)CUserCharacInfo::getCurCharacName(a2);
    format = (char *)RDARScriptStringManager::findString(
                       (RDARScriptStringManager *)&g_scriptStringManager_,
                       4,
                       "game_server_msg_257",
                       0);
    OS_API::snprintf((OS_API *)&s, 0xFFu, format, CurCharacNameEv);
  }
  else if ( n2 == 2 )
  {
    n8663 = 26824;
    v29 = 1;
    CurCharacNameEv_1 = (const char *)CUserCharacInfo::getCurCharacName(a2);
    format_1 = (char *)RDARScriptStringManager::findString(
                         (RDARScriptStringManager *)&g_scriptStringManager_,
                         4,
                         "game_server_msg_259",
                         0);
    OS_API::snprintf((OS_API *)&s, 0xFFu, format_1, CurCharacNameEv_1);
  }
  else if ( !v33[18] )
  {
    n8663 = 8663;
    v29 = 1;
    CurCharacNameEv_2 = (const char *)CUserCharacInfo::getCurCharacName(a2);
    format_2 = (char *)RDARScriptStringManager::findString(
                         (RDARScriptStringManager *)&g_scriptStringManager_,
                         4,
                         "game_server_msg_258",
                         0);
    OS_API::snprintf((OS_API *)&s, 0xFFu, format_2, CurCharacNameEv_2);
  }
  src = (const char *)RDARScriptStringManager::findString(
                        (RDARScriptStringManager *)&g_scriptStringManager_,
                        4,
                        "game_server_msg_256",
                        0);
  strncpy((char *)&dest, src, 0x1Du);
  n8663_1 = n8663;
  v21 = (CItemList **)G_CDataManager();
  item = CDataManager::find_item(v21, n8663_1);
  if ( item )
  {
    (*(void (__cdecl **)(int, _BYTE *))(*(_DWORD *)item + 8))(item, v27);
    ServerGroup = CUser::GetServerGroup(a2);
    v23 = strlen(&s);
    CurCharacNoEv = CUserCharacInfo::getCurCharacNo(a2);
    WongWork::CMailBoxHelper::ReqDBSendNewSystemMail(
      (char *)&dest,
      (Inven_Item *)v27,
      0,
      CurCharacNoEv,
      &s,
      v23,
      0,
      ServerGroup,
      1,
      0);
    CUserCharacInfo::getCurCharacNo(a2);
    LOBYTE(ServerGroup) = CUser::get_acc_id(a2);
    cMyTrace::cMyTrace(
      (cMyTrace *)v32,
      "virtual int Inter_CollectItemsReward::dispatch_sig(CUser*, char*, int)",
      27072,
      0);
    cMyTrace::operator()((int)v32, "[collect items]reward: m_id(), charac_no(), reward()", ServerGroup);
  }
  return 0;
}

// IDA_EA: 0x84EEDC0
// IDA_NAME: _ZN24Inter_CollectItemsRewardC2Ev
// DEMANGLED: Inter_CollectItemsReward::Inter_CollectItemsReward(void)
void __cdecl Inter_CollectItemsReward::Inter_CollectItemsReward(Inter_CollectItemsReward *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8E4E0;
}

// IDA_EA: 0x84F5C70
// IDA_NAME: _ZN24Inter_CollectItemsRewardD2Ev
// DEMANGLED: Inter_CollectItemsReward::~Inter_CollectItemsReward()
void __cdecl Inter_CollectItemsReward::~Inter_CollectItemsReward(Inter_CollectItemsReward *this)
{
  *(_DWORD *)this = &off_8C8E4E0;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84F5CA0
// IDA_NAME: _ZN24Inter_CollectItemsRewardD0Ev
// DEMANGLED: Inter_CollectItemsReward::~Inter_CollectItemsReward()
void __cdecl Inter_CollectItemsReward::~Inter_CollectItemsReward(Inter_CollectItemsReward *this)
{
  Inter_CollectItemsReward::~Inter_CollectItemsReward(this);
  operator delete(this);
}
