#include "TournamentRewardItem.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x88F2DCC
// IDA_NAME: _ZN20TournamentRewardItemC2Ev
// DEMANGLED: TournamentRewardItem::TournamentRewardItem(void)
void __cdecl TournamentRewardItem::TournamentRewardItem(TournamentRewardItem *this)
{
  *(_DWORD *)this = 0;
  *((_DWORD *)this + 1) = 0;
  *((_DWORD *)this + 2) = 0;
}

// IDA_EA: 0x88F9EF6
// IDA_NAME: _ZN20TournamentRewardItemD2Ev
// DEMANGLED: TournamentRewardItem::~TournamentRewardItem()
void TournamentRewardItem::~TournamentRewardItem()
{
  ;
}
