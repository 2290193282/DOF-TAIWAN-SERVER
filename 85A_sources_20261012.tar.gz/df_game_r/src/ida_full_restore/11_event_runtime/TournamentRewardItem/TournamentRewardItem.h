#ifndef __IDA91_TOURNAMENTREWARDITEM_H__
#define __IDA91_TOURNAMENTREWARDITEM_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: TournamentRewardItem
// Source unit: TournamentRewardItem
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 3874

/* 3874 */
struct TournamentRewardItem;

// Exported member functions:
// 0x88F2DCC	TournamentRewardItem::TournamentRewardItem(void)
// 0x88F9EF6	TournamentRewardItem::~TournamentRewardItem()

// Function declaration index:
// DECL 0x88F2DCC TournamentRewardItem::TournamentRewardItem
// DECL 0x88F9EF6 TournamentRewardItem::~TournamentRewardItem

#endif  // __IDA91_TOURNAMENTREWARDITEM_H__
