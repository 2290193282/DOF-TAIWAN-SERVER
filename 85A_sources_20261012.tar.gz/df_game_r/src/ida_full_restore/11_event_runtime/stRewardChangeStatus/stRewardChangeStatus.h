#ifndef __IDA91_STREWARDCHANGESTATUS_H__
#define __IDA91_STREWARDCHANGESTATUS_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stRewardChangeStatus
// Source unit: stRewardChangeStatus
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4050

/* 4050 */
struct stRewardChangeStatus;

// Exported member functions:
// 0x8AA9690	stRewardChangeStatus::stRewardChangeStatus(void)

// Function declaration index:
// DECL 0x8AA9690 stRewardChangeStatus::stRewardChangeStatus

#endif  // __IDA91_STREWARDCHANGESTATUS_H__
