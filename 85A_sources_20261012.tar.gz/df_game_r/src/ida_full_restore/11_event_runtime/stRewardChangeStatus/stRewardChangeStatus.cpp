#include "stRewardChangeStatus.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8AA9690
// IDA_NAME: _ZN20stRewardChangeStatusC2Ev
// DEMANGLED: stRewardChangeStatus::stRewardChangeStatus(void)
void __cdecl stRewardChangeStatus::stRewardChangeStatus(stRewardChangeStatus *this)
{
  stTitleRewardBasis::stTitleRewardBasis(this);
  *(_DWORD *)this = 0;
  *((_DWORD *)this + 3) = 77;
  *((_DWORD *)this + 4) = 2;
  *((_DWORD *)this + 5) = 0;
}
