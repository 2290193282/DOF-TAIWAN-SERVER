#include "MultiBoxLotteryInfo_LotteryDefaultArad.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8513E30
// IDA_NAME: _ZN19MultiBoxLotteryInfo18LotteryDefaultAradC2Ejjj
// DEMANGLED: MultiBoxLotteryInfo::LotteryDefaultArad::LotteryDefaultArad(unsigned int,unsigned int,unsigned int)
MultiBoxLotteryInfo::LotteryDefaultArad *__cdecl MultiBoxLotteryInfo::LotteryDefaultArad::LotteryDefaultArad(
        MultiBoxLotteryInfo::LotteryDefaultArad *this,
        unsigned int n0x28BE16,
        unsigned int n0xA,
        unsigned int n0xC350)
{
  MultiBoxLotteryInfo::LotteryDefaultArad *this_1; // eax

  *(_DWORD *)this = n0x28BE16;
  *((_DWORD *)this + 1) = n0xA;
  this_1 = this;
  *((_DWORD *)this + 2) = n0xC350;
  return this_1;
}

// IDA_EA: 0x8522962
// IDA_NAME: _ZN19MultiBoxLotteryInfo18LotteryDefaultAradD2Ev
// DEMANGLED: MultiBoxLotteryInfo::LotteryDefaultArad::~LotteryDefaultArad()
void MultiBoxLotteryInfo::LotteryDefaultArad::~LotteryDefaultArad()
{
  ;
}
