#include "MultiBoxLotteryInfo_stDefaultItemInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8513E50
// IDA_NAME: _ZN19MultiBoxLotteryInfo17stDefaultItemInfoC2Ev
// DEMANGLED: MultiBoxLotteryInfo::stDefaultItemInfo::stDefaultItemInfo(void)
int __cdecl MultiBoxLotteryInfo::stDefaultItemInfo::stDefaultItemInfo(MultiBoxLotteryInfo::stDefaultItemInfo *this)
{
  std::vector<MultiBoxLotteryInfo::stDefaultItem>::vector((char *)this + 16);
  *(_DWORD *)this = 0;
  *((_DWORD *)this + 1) = 0;
  *((_DWORD *)this + 2) = 0;
  *((_BYTE *)this + 12) = 0;
  return std::vector<MultiBoxLotteryInfo::stDefaultItem>::clear((char *)this + 16);
}

// IDA_EA: 0x8513EC0
// IDA_NAME: _ZN19MultiBoxLotteryInfo17stDefaultItemInfoD2Ev
// DEMANGLED: MultiBoxLotteryInfo::stDefaultItemInfo::~stDefaultItemInfo()
void __cdecl MultiBoxLotteryInfo::stDefaultItemInfo::~stDefaultItemInfo(MultiBoxLotteryInfo::stDefaultItemInfo *this)
{
  std::vector<MultiBoxLotteryInfo::stDefaultItem>::~vector((char *)this + 16);
}
