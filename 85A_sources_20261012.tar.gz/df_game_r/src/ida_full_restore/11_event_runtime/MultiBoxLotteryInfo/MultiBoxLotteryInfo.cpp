#include "MultiBoxLotteryInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8513ED6
// IDA_NAME: _ZN19MultiBoxLotteryInfoC2Ev
// DEMANGLED: MultiBoxLotteryInfo::MultiBoxLotteryInfo(void)
void __cdecl MultiBoxLotteryInfo::MultiBoxLotteryInfo(MultiBoxLotteryInfo *this)
{
  std::vector<MultiBoxLotteryInfo::LotteryUnit>::vector((char *)this + 16);
  MultiBoxLotteryInfo::stDefaultItemInfo::stDefaultItemInfo((MultiBoxLotteryInfo *)((char *)this + 28));
  MultiBoxLotteryInfo::clear(this);
}

// IDA_EA: 0x8513F44
// IDA_NAME: _ZN19MultiBoxLotteryInfo5clearEv
// DEMANGLED: MultiBoxLotteryInfo::clear(void)
MultiBoxLotteryInfo *__cdecl MultiBoxLotteryInfo::clear(MultiBoxLotteryInfo *this)
{
  MultiBoxLotteryInfo *this_1; // eax

  std::vector<MultiBoxLotteryInfo::LotteryUnit>::clear((char *)this + 16);
  *(_DWORD *)this = -1;
  *((_DWORD *)this + 1) = 0;
  *((_DWORD *)this + 2) = -1;
  this_1 = this;
  *((_DWORD *)this + 3) = 0;
  return this_1;
}

// IDA_EA: 0x85145B2
// IDA_NAME: _ZN19MultiBoxLotteryInfoD2Ev
// DEMANGLED: MultiBoxLotteryInfo::~MultiBoxLotteryInfo()
void __cdecl MultiBoxLotteryInfo::~MultiBoxLotteryInfo(MultiBoxLotteryInfo *this)
{
  MultiBoxLotteryInfo::stDefaultItemInfo::~stDefaultItemInfo((MultiBoxLotteryInfo *)((char *)this + 28));
  std::vector<MultiBoxLotteryInfo::LotteryUnit>::~vector((char *)this + 16);
}
