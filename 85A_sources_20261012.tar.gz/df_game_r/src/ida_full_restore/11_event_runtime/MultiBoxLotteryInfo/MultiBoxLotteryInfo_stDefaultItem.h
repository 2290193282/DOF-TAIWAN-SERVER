#ifndef __IDA91_MULTIBOXLOTTERYINFO_STDEFAULTITEM_H__
#define __IDA91_MULTIBOXLOTTERYINFO_STDEFAULTITEM_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: MultiBoxLotteryInfo
// Source unit: MultiBoxLotteryInfo_stDefaultItem
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 3962

/* 3962 */
struct MultiBoxLotteryInfo::stDefaultItem;

// Exported member functions:
// 0x89C35D4	MultiBoxLotteryInfo::stDefaultItem::stDefaultItem(void)
// 0x89D48B2	MultiBoxLotteryInfo::stDefaultItem::~stDefaultItem()

// Function declaration index:
// DECL 0x89C35D4 MultiBoxLotteryInfo::stDefaultItem::stDefaultItem
// DECL 0x89D48B2 MultiBoxLotteryInfo::stDefaultItem::~stDefaultItem

#endif  // __IDA91_MULTIBOXLOTTERYINFO_STDEFAULTITEM_H__
