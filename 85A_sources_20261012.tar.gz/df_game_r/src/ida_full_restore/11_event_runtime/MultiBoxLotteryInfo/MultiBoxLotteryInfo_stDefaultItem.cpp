#include "MultiBoxLotteryInfo_stDefaultItem.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x89C35D4
// IDA_NAME: _ZN19MultiBoxLotteryInfo13stDefaultItemC2Ev
// DEMANGLED: MultiBoxLotteryInfo::stDefaultItem::stDefaultItem(void)
MultiBoxLotteryInfo::stDefaultItem *__cdecl MultiBoxLotteryInfo::stDefaultItem::stDefaultItem(
        MultiBoxLotteryInfo::stDefaultItem *this)
{
  MultiBoxLotteryInfo::stDefaultItem *this_1; // eax

  *(_DWORD *)this = 0;
  *((_DWORD *)this + 1) = 0;
  *((_DWORD *)this + 2) = 0;
  this_1 = this;
  *((_BYTE *)this + 12) = 0;
  return this_1;
}

// IDA_EA: 0x89D48B2
// IDA_NAME: _ZN19MultiBoxLotteryInfo13stDefaultItemD2Ev
// DEMANGLED: MultiBoxLotteryInfo::stDefaultItem::~stDefaultItem()
void MultiBoxLotteryInfo::stDefaultItem::~stDefaultItem()
{
  ;
}
