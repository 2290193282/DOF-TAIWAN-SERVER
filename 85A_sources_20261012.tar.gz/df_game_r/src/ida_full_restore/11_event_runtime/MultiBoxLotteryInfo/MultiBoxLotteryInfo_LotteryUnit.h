#ifndef __IDA91_MULTIBOXLOTTERYINFO_LOTTERYUNIT_H__
#define __IDA91_MULTIBOXLOTTERYINFO_LOTTERYUNIT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: MultiBoxLotteryInfo
// Source unit: MultiBoxLotteryInfo_LotteryUnit
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4452

/* 4452 */
struct MultiBoxLotteryInfo::LotteryUnit;

// Exported member functions:
// 0x85151A8	MultiBoxLotteryInfo::LotteryUnit::LotteryUnit(MultiBoxLotteryInfo::LotteryUnit const&)
// 0x8515236	MultiBoxLotteryInfo::LotteryUnit::~LotteryUnit()
// 0x89C351E	MultiBoxLotteryInfo::LotteryUnit::LotteryUnit(void)
// 0x89C358C	MultiBoxLotteryInfo::LotteryUnit::clear(void)
// 0x89CDF46	MultiBoxLotteryInfo::LotteryUnit::operator=(MultiBoxLotteryInfo::LotteryUnit const&)

// Function declaration index:
// DECL 0x85151A8 MultiBoxLotteryInfo::LotteryUnit::LotteryUnit
// DECL 0x8515236 MultiBoxLotteryInfo::LotteryUnit::~LotteryUnit
// DECL 0x89C351E MultiBoxLotteryInfo::LotteryUnit::LotteryUnit
// DECL 0x89C358C MultiBoxLotteryInfo::LotteryUnit::clear
// DECL 0x89CDF46 MultiBoxLotteryInfo::LotteryUnit::operator=

#endif  // __IDA91_MULTIBOXLOTTERYINFO_LOTTERYUNIT_H__
