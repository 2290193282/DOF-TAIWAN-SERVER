#ifndef __IDA91_MULTIBOXLOTTERYINFO_LOTTERYDEFAULTARAD_H__
#define __IDA91_MULTIBOXLOTTERYINFO_LOTTERYDEFAULTARAD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: MultiBoxLotteryInfo
// Source unit: MultiBoxLotteryInfo_LotteryDefaultArad
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
// Local type ordinals: 3256

/* 3256 */
struct MultiBoxLotteryInfo::LotteryDefaultArad;

// Exported member functions:
// 0x8513E30	MultiBoxLotteryInfo::LotteryDefaultArad::LotteryDefaultArad(unsigned int,unsigned int,unsigned int)
// 0x8522962	MultiBoxLotteryInfo::LotteryDefaultArad::~LotteryDefaultArad()

// Function declaration index:
// DECL 0x8513E30 MultiBoxLotteryInfo::LotteryDefaultArad::LotteryDefaultArad
// DECL 0x8522962 MultiBoxLotteryInfo::LotteryDefaultArad::~LotteryDefaultArad

#endif  // __IDA91_MULTIBOXLOTTERYINFO_LOTTERYDEFAULTARAD_H__
