#ifndef __IDA91_MULTIBOXLOTTERYINFO_STDEFAULTITEMINFO_H__
#define __IDA91_MULTIBOXLOTTERYINFO_STDEFAULTITEMINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: MultiBoxLotteryInfo
// Source unit: MultiBoxLotteryInfo_stDefaultItemInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4627

/* 4627 */
struct MultiBoxLotteryInfo::stDefaultItemInfo;

// Exported member functions:
// 0x8513E50	MultiBoxLotteryInfo::stDefaultItemInfo::stDefaultItemInfo(void)
// 0x8513EC0	MultiBoxLotteryInfo::stDefaultItemInfo::~stDefaultItemInfo()

// Function declaration index:
// DECL 0x8513E50 MultiBoxLotteryInfo::stDefaultItemInfo::stDefaultItemInfo
// DECL 0x8513EC0 MultiBoxLotteryInfo::stDefaultItemInfo::~stDefaultItemInfo

#endif  // __IDA91_MULTIBOXLOTTERYINFO_STDEFAULTITEMINFO_H__
