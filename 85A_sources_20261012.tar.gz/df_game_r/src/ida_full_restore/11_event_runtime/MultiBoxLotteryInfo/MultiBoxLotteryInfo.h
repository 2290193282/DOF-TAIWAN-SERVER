#ifndef __IDA91_MULTIBOXLOTTERYINFO_H__
#define __IDA91_MULTIBOXLOTTERYINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: MultiBoxLotteryInfo
// Source unit: MultiBoxLotteryInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4735

/* 4735 */
struct MultiBoxLotteryInfo;

// Exported member functions:
// 0x8513ED6	MultiBoxLotteryInfo::MultiBoxLotteryInfo(void)
// 0x8513F44	MultiBoxLotteryInfo::clear(void)
// 0x85145B2	MultiBoxLotteryInfo::~MultiBoxLotteryInfo()

// Function declaration index:
// DECL 0x8513ED6 MultiBoxLotteryInfo::MultiBoxLotteryInfo
// DECL 0x8513F44 MultiBoxLotteryInfo::clear
// DECL 0x85145B2 MultiBoxLotteryInfo::~MultiBoxLotteryInfo

#endif  // __IDA91_MULTIBOXLOTTERYINFO_H__
