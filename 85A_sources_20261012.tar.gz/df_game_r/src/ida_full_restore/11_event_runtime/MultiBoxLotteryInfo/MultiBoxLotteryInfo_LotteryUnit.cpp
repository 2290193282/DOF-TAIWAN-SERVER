#include "MultiBoxLotteryInfo_LotteryUnit.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x85151A8
// IDA_NAME: _ZN19MultiBoxLotteryInfo11LotteryUnitC2ERKS0_
// DEMANGLED: MultiBoxLotteryInfo::LotteryUnit::LotteryUnit(MultiBoxLotteryInfo::LotteryUnit const&)
int __cdecl MultiBoxLotteryInfo::LotteryUnit::LotteryUnit(
        MultiBoxLotteryInfo::LotteryUnit *this,
        const MultiBoxLotteryInfo::LotteryUnit *a2)
{
  *(_DWORD *)this = *(_DWORD *)a2;
  *((_DWORD *)this + 1) = *((_DWORD *)a2 + 1);
  *((_DWORD *)this + 2) = *((_DWORD *)a2 + 2);
  *((_BYTE *)this + 12) = *((_BYTE *)a2 + 12);
  std::vector<std::pair<int,int>>::vector((int *)this + 4, (_DWORD *)a2 + 4);
  return std::vector<std::pair<int,int>>::vector((int *)this + 7, (_DWORD *)a2 + 7);
}

// IDA_EA: 0x8515236
// IDA_NAME: _ZN19MultiBoxLotteryInfo11LotteryUnitD2Ev
// DEMANGLED: MultiBoxLotteryInfo::LotteryUnit::~LotteryUnit()
void __cdecl MultiBoxLotteryInfo::LotteryUnit::~LotteryUnit(MultiBoxLotteryInfo::LotteryUnit *this)
{
  std::vector<std::pair<int,int>>::~vector((int *)this + 7);
  std::vector<std::pair<int,int>>::~vector((int *)this + 4);
}

// IDA_EA: 0x89C351E
// IDA_NAME: _ZN19MultiBoxLotteryInfo11LotteryUnitC2Ev
// DEMANGLED: MultiBoxLotteryInfo::LotteryUnit::LotteryUnit(void)
int __cdecl MultiBoxLotteryInfo::LotteryUnit::LotteryUnit(MultiBoxLotteryInfo::LotteryUnit *this)
{
  std::vector<std::pair<int,int>>::vector((int)this + 16);
  std::vector<std::pair<int,int>>::vector((int)this + 28);
  return MultiBoxLotteryInfo::LotteryUnit::clear(this);
}

// IDA_EA: 0x89C358C
// IDA_NAME: _ZN19MultiBoxLotteryInfo11LotteryUnit5clearEv
// DEMANGLED: MultiBoxLotteryInfo::LotteryUnit::clear(void)
MultiBoxLotteryInfo::LotteryUnit *__cdecl MultiBoxLotteryInfo::LotteryUnit::clear(
        MultiBoxLotteryInfo::LotteryUnit *this)
{
  MultiBoxLotteryInfo::LotteryUnit *this_1; // eax

  *((_DWORD *)this + 1) = 0;
  *((_DWORD *)this + 2) = 0;
  *((_BYTE *)this + 12) = 0;
  std::vector<std::pair<int,int>>::clear((_DWORD *)this + 4);
  std::vector<std::pair<int,int>>::clear((_DWORD *)this + 7);
  this_1 = this;
  *(_DWORD *)this = 0;
  return this_1;
}

// IDA_EA: 0x89CDF46
// IDA_NAME: _ZN19MultiBoxLotteryInfo11LotteryUnitaSERKS0_
// DEMANGLED: MultiBoxLotteryInfo::LotteryUnit::operator=(MultiBoxLotteryInfo::LotteryUnit const&)
int __cdecl MultiBoxLotteryInfo::LotteryUnit::operator=(int a1, int a2)
{
  *(_DWORD *)a1 = *(_DWORD *)a2;
  *(_DWORD *)(a1 + 4) = *(_DWORD *)(a2 + 4);
  *(_DWORD *)(a1 + 8) = *(_DWORD *)(a2 + 8);
  *(_BYTE *)(a1 + 12) = *(_BYTE *)(a2 + 12);
  std::vector<std::pair<int,int>>::operator=((int *)(a1 + 16), (int *)(a2 + 16));
  std::vector<std::pair<int,int>>::operator=((int *)(a1 + 28), (int *)(a2 + 28));
  return a1;
}
