#ifndef __IDA91_DISPATCHER_MULTIBOXLOTTERY_H__
#define __IDA91_DISPATCHER_MULTIBOXLOTTERY_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DisPatcher_MultiBoxLottery
// Source unit: DisPatcher_MultiBoxLottery
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 1941

/* 1941 */
struct DisPatcher_MultiBoxLottery;

// Exported member functions:
// 0x820B802	DisPatcher_MultiBoxLottery::dispatch_sig(CUser *,PacketBuf &)
// 0x8233BD2	DisPatcher_MultiBoxLottery::read(PacketBuf &,MSG_BASE &)
// 0x8233BDC	DisPatcher_MultiBoxLottery::process(CUser *,MSG_BASE &,ParamBase &)
// 0x8241F14	DisPatcher_MultiBoxLottery::~DisPatcher_MultiBoxLottery()
// 0x8241F44	DisPatcher_MultiBoxLottery::~DisPatcher_MultiBoxLottery()
// 0x859694C	DisPatcher_MultiBoxLottery::DisPatcher_MultiBoxLottery(void)

// Function declaration index:
// DECL 0x820B802 DisPatcher_MultiBoxLottery::dispatch_sig
// DECL 0x8233BD2 DisPatcher_MultiBoxLottery::read
// DECL 0x8233BDC DisPatcher_MultiBoxLottery::process
// DECL 0x8241F14 DisPatcher_MultiBoxLottery::~DisPatcher_MultiBoxLottery
// DECL 0x8241F44 DisPatcher_MultiBoxLottery::~DisPatcher_MultiBoxLottery
// DECL 0x859694C DisPatcher_MultiBoxLottery::DisPatcher_MultiBoxLottery

#endif  // __IDA91_DISPATCHER_MULTIBOXLOTTERY_H__
