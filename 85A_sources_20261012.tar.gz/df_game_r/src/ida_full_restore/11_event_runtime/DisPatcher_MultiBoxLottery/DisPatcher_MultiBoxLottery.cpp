#include "DisPatcher_MultiBoxLottery.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x820B802
// IDA_NAME: _ZN26DisPatcher_MultiBoxLottery12dispatch_sigEP5CUserR9PacketBuf
// DEMANGLED: DisPatcher_MultiBoxLottery::dispatch_sig(CUser *,PacketBuf &)
int __cdecl DisPatcher_MultiBoxLottery::dispatch_sig(DisPatcher_MultiBoxLottery *this, CUser *a2, PacketBuf *a3)
{
  void *v4; // eax
  PacketBuf *v5[3]; // [esp+18h] [ebp-30h] BYREF
  unsigned __int16 v6; // [esp+34h] [ebp-14h] BYREF
  unsigned __int16 v7; // [esp+36h] [ebp-12h] BYREF
  int v8; // [esp+38h] [ebp-10h]
  int v9; // [esp+3Ch] [ebp-Ch]

  if ( CUser::get_state(a2) <= 2 )
    return 0;
  if ( (unsigned __int8)CUser::CheckInTrade(a2) )
    return 0;
  v4 = ARAD::Singleton<ServiceRestrictManager>::Get();
  if ( (unsigned __int8)ServiceRestrictManager::isRestricted((int)v4, a2, 1, 18) )
  {
    CUser::SendCmdErrorPacket(a2, 211, 209);
    return 0;
  }
  else
  {
    v8 = CSecu_ProtectionField::Check(GlobalData::s_pSecuProtectionField, a2, 24);
    if ( v8 )
    {
      CUser::SendCmdErrorPacket(a2, 211, (unsigned __int8)v8);
      return 0;
    }
    else if ( (unsigned __int8)PacketBuf::get_short(a3, &v6) == 1 )
    {
      if ( (unsigned __int8)PacketBuf::get_short(a3, &v7) == 1 )
      {
        v9 = CUser::multibox_lottery_item(a2, v6, v7);
        if ( v9 > 0 )
        {
          PacketGuard::PacketGuard((PacketGuard *)v5);
          InterfacePacketBuf::put_header(v5, 1, 211);
          InterfacePacketBuf::put_byte(v5, 0);
          InterfacePacketBuf::put_byte(v5, v9);
          InterfacePacketBuf::finalize(v5, 1);
          CUser::Send(a2, (PacketGuard *)v5);
          PacketGuard::~PacketGuard(v5);
        }
        return 0;
      }
      else
      {
        return LineFunc(43065, "virtual int DisPatcher_MultiBoxLottery::dispatch_sig(CUser*, PacketBuf&)", 0, 0);
      }
    }
    else
    {
      return LineFunc(43064, "virtual int DisPatcher_MultiBoxLottery::dispatch_sig(CUser*, PacketBuf&)", 0, 0);
    }
  }
}

// IDA_EA: 0x8233BD2
// IDA_NAME: _ZN26DisPatcher_MultiBoxLottery4readER9PacketBufR8MSG_BASE
// DEMANGLED: DisPatcher_MultiBoxLottery::read(PacketBuf &,MSG_BASE &)
int DisPatcher_MultiBoxLottery::read()
{
  return 0;
}

// IDA_EA: 0x8233BDC
// IDA_NAME: _ZN26DisPatcher_MultiBoxLottery7processEP5CUserR8MSG_BASER9ParamBase
// DEMANGLED: DisPatcher_MultiBoxLottery::process(CUser *,MSG_BASE &,ParamBase &)
int DisPatcher_MultiBoxLottery::process()
{
  return 0;
}

// IDA_EA: 0x8241F14
// IDA_NAME: _ZN26DisPatcher_MultiBoxLotteryD2Ev
// DEMANGLED: DisPatcher_MultiBoxLottery::~DisPatcher_MultiBoxLottery()
void __cdecl DisPatcher_MultiBoxLottery::~DisPatcher_MultiBoxLottery(DisPatcher_MultiBoxLottery *this)
{
  *(_DWORD *)this = &off_8BD7D88;
  IPacketDispatcher<MSG_BASE,ParamBase,(ch_state)0>::~IPacketDispatcher(this);
}

// IDA_EA: 0x8241F44
// IDA_NAME: _ZN26DisPatcher_MultiBoxLotteryD0Ev
// DEMANGLED: DisPatcher_MultiBoxLottery::~DisPatcher_MultiBoxLottery()
void __cdecl DisPatcher_MultiBoxLottery::~DisPatcher_MultiBoxLottery(DisPatcher_MultiBoxLottery *this)
{
  DisPatcher_MultiBoxLottery::~DisPatcher_MultiBoxLottery(this);
  operator delete(this);
}

// IDA_EA: 0x859694C
// IDA_NAME: _ZN26DisPatcher_MultiBoxLotteryC2Ev
// DEMANGLED: DisPatcher_MultiBoxLottery::DisPatcher_MultiBoxLottery(void)
void __cdecl DisPatcher_MultiBoxLottery::DisPatcher_MultiBoxLottery(DisPatcher_MultiBoxLottery *this)
{
  IPacketDispatcher<MSG_BASE,ParamBase,(ch_state)0>::IPacketDispatcher(this);
  *(_DWORD *)this = &off_8BD7D88;
}
