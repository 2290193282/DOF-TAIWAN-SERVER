#include "BlueMarbleRewardInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x88D9360
// IDA_NAME: _ZN20BlueMarbleRewardInfoD2Ev
// DEMANGLED: BlueMarbleRewardInfo::~BlueMarbleRewardInfo()
void BlueMarbleRewardInfo::~BlueMarbleRewardInfo()
{
  ;
}
