#ifndef __IDA91_BLUEMARBLEREWARDINFO_H__
#define __IDA91_BLUEMARBLEREWARDINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: BlueMarbleRewardInfo
// Source unit: BlueMarbleRewardInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3864

/* 3864 */
struct BlueMarbleRewardInfo;

// Exported member functions:
// 0x88D9360	BlueMarbleRewardInfo::~BlueMarbleRewardInfo()

// Function declaration index:
// DECL 0x88D9360 BlueMarbleRewardInfo::~BlueMarbleRewardInfo

#endif  // __IDA91_BLUEMARBLEREWARDINFO_H__
