#ifndef __IDA91_ATTENDANCEEVENT_H__
#define __IDA91_ATTENDANCEEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: AttendanceEvent
// Source unit: AttendanceEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4080

/* 4080 */
struct AttendanceEvent;

// Exported member functions:
// 0x80C828C	AttendanceEvent::AttendanceEvent(void)
// 0x80C82A8	AttendanceEvent::~AttendanceEvent()
// 0x80C82D8	AttendanceEvent::~AttendanceEvent()
// 0x80C82F6	AttendanceEvent::StartEvent(void)
// 0x80C8312	AttendanceEvent::StartEvent(Word_Param)
// 0x80C83F4	AttendanceEvent::EndEvent(void)
// 0x80C8446	AttendanceEvent::getRewordItem(void)

// Function declaration index:
// DECL 0x80C828C AttendanceEvent::AttendanceEvent
// DECL 0x80C82A8 AttendanceEvent::~AttendanceEvent
// DECL 0x80C82D8 AttendanceEvent::~AttendanceEvent
// DECL 0x80C82F6 AttendanceEvent::StartEvent
// DECL 0x80C8312 AttendanceEvent::StartEvent
// DECL 0x80C83F4 AttendanceEvent::EndEvent
// DECL 0x80C8446 AttendanceEvent::getRewordItem

#endif  // __IDA91_ATTENDANCEEVENT_H__
