#include "AttendanceEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x80C828C
// IDA_NAME: _ZN15AttendanceEventC2Ev
// DEMANGLED: AttendanceEvent::AttendanceEvent(void)
void __cdecl AttendanceEvent::AttendanceEvent(AttendanceEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B25BA8;
}

// IDA_EA: 0x80C82A8
// IDA_NAME: _ZN15AttendanceEventD2Ev
// DEMANGLED: AttendanceEvent::~AttendanceEvent()
void __cdecl AttendanceEvent::~AttendanceEvent(AttendanceEvent *this)
{
  *(_DWORD *)this = off_8B25BA8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x80C82D8
// IDA_NAME: _ZN15AttendanceEventD0Ev
// DEMANGLED: AttendanceEvent::~AttendanceEvent()
void __cdecl AttendanceEvent::~AttendanceEvent(AttendanceEvent *this)
{
  AttendanceEvent::~AttendanceEvent(this);
  operator delete(this);
}

// IDA_EA: 0x80C82F6
// IDA_NAME: _ZN15AttendanceEvent10StartEventEv
// DEMANGLED: AttendanceEvent::StartEvent(void)
int __cdecl AttendanceEvent::StartEvent(AttendanceEvent *this)
{
  return CEventBase::SetEventFlag(this, 1);
}

// IDA_EA: 0x80C8312
// IDA_NAME: _ZN15AttendanceEvent10StartEventE10Word_Param
// DEMANGLED: AttendanceEvent::StartEvent(Word_Param)
int __cdecl AttendanceEvent::StartEvent(int a1, int a2)
{
  __int16 v3; // bx
  int v4[6]; // [esp+20h] [ebp-18h] BYREF

  *(_DWORD *)(a1 + 4) = a2;
  if ( *(__int16 *)(a1 + 4) <= 0 )
    return LogManager::logFormat(
             (LogManager *)1,
             (int)"AttendanceEvent.cpp",
             "virtual void AttendanceEvent::StartEvent(Word_Param)",
             (const char *)0x19,
             "Attendance(AddInfo:%d,%d) Event Start Error!",
             (const char *)*(__int16 *)(a1 + 4),
             *(__int16 *)(a1 + 6));
  (*(void (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
  v3 = *(_WORD *)(a1 + 4);
  cMyTrace::cMyTrace((cMyTrace *)v4, "virtual void AttendanceEvent::StartEvent(Word_Param)", 29, 0);
  return cMyTrace::operator()((int)v4, "Attendance(AddInfo:%d,%d) Event Start!", v3);
}

// IDA_EA: 0x80C83F4
// IDA_NAME: _ZN15AttendanceEvent8EndEventEv
// DEMANGLED: AttendanceEvent::EndEvent(void)
int __cdecl AttendanceEvent::EndEvent(AttendanceEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void AttendanceEvent::EndEvent()", 35, 0);
  return cMyTrace::operator()((int)v3, "Attendacne Event End!", v2);
}

// IDA_EA: 0x80C8446
// IDA_NAME: _ZN15AttendanceEvent13getRewordItemEv
// DEMANGLED: AttendanceEvent::getRewordItem(void)
int __cdecl AttendanceEvent::getRewordItem()
{
  _WORD v1[6]; // [esp+1Ch] [ebp-Ch] BYREF

  CEventBase::GetAddInfo((CEventBase *)v1);
  return v1[0];
}
