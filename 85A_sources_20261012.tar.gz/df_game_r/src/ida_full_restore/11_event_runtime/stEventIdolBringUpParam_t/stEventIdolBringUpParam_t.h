#ifndef __IDA91_STEVENTIDOLBRINGUPPARAM_T_H__
#define __IDA91_STEVENTIDOLBRINGUPPARAM_T_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stEventIdolBringUpParam_t
// Source unit: stEventIdolBringUpParam_t
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2375

/* 2375 */
struct stEventIdolBringUpParam_t;

// Exported member functions:
// 0x836F2A2	stEventIdolBringUpParam_t::stEventIdolBringUpParam_t(void)
// 0x836FA54	stEventIdolBringUpParam_t::~stEventIdolBringUpParam_t()

// Function declaration index:
// DECL 0x836F2A2 stEventIdolBringUpParam_t::stEventIdolBringUpParam_t
// DECL 0x836FA54 stEventIdolBringUpParam_t::~stEventIdolBringUpParam_t

#endif  // __IDA91_STEVENTIDOLBRINGUPPARAM_T_H__
