#include "stEventIdolBringUpParam_t.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x836F2A2
// IDA_NAME: _ZN25stEventIdolBringUpParam_tC2Ev
// DEMANGLED: stEventIdolBringUpParam_t::stEventIdolBringUpParam_t(void)
void __cdecl stEventIdolBringUpParam_t::stEventIdolBringUpParam_t(stEventIdolBringUpParam_t *this)
{
  *(_DWORD *)this = 0;
  *((_DWORD *)this + 1) = 0;
  std::vector<int>::vector((int)this + 8);
}

// IDA_EA: 0x836FA54
// IDA_NAME: _ZN25stEventIdolBringUpParam_tD2Ev
// DEMANGLED: stEventIdolBringUpParam_t::~stEventIdolBringUpParam_t()
void __cdecl stEventIdolBringUpParam_t::~stEventIdolBringUpParam_t(stEventIdolBringUpParam_t *this)
{
  std::vector<int>::~vector((_DWORD *)this + 2);
}
