#ifndef __IDA91_DISPATCHER_BINGOQUIZ_H__
#define __IDA91_DISPATCHER_BINGOQUIZ_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Dispatcher_BingoQuiz
// Source unit: Dispatcher_BingoQuiz
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 4159

/* 4159 */
struct Dispatcher_BingoQuiz;

// Exported member functions:
// 0x825E962	Dispatcher_BingoQuiz::read(PacketBuf &,MSG_BASE &)
// 0x825E9B8	Dispatcher_BingoQuiz::process(CUser *,MSG_BASE &,ParamBase &)
// 0x825EACA	Dispatcher_BingoQuiz::check_error(CUser *,MSG_BASE &)
// 0x825EB92	Dispatcher_BingoQuiz::send(CUser *,ParamBase &)
// 0x8260ADC	Dispatcher_BingoQuiz::~Dispatcher_BingoQuiz()
// 0x8260B0C	Dispatcher_BingoQuiz::~Dispatcher_BingoQuiz()
// 0x8595874	Dispatcher_BingoQuiz::Dispatcher_BingoQuiz(void)

// Function declaration index:
// DECL 0x825E962 Dispatcher_BingoQuiz::read
// DECL 0x825E9B8 Dispatcher_BingoQuiz::process
// DECL 0x825EACA Dispatcher_BingoQuiz::check_error
// DECL 0x825EB92 Dispatcher_BingoQuiz::send
// DECL 0x8260ADC Dispatcher_BingoQuiz::~Dispatcher_BingoQuiz
// DECL 0x8260B0C Dispatcher_BingoQuiz::~Dispatcher_BingoQuiz
// DECL 0x8595874 Dispatcher_BingoQuiz::Dispatcher_BingoQuiz

#endif  // __IDA91_DISPATCHER_BINGOQUIZ_H__
