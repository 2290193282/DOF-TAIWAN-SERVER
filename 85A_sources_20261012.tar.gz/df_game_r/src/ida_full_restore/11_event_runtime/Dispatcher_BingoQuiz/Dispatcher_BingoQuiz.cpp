#include "Dispatcher_BingoQuiz.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x825E962
// IDA_NAME: _ZN20Dispatcher_BingoQuiz4readER9PacketBufR8MSG_BASE
// DEMANGLED: Dispatcher_BingoQuiz::read(PacketBuf &,MSG_BASE &)
int __cdecl Dispatcher_BingoQuiz::read(Dispatcher_BingoQuiz *this, PacketBuf *a2, MSG_BASE *a3)
{
  if ( (unsigned __int8)PacketBuf::get_int(a2, (int *)((char *)a3 + 13)) == 1 )
    return 0;
  else
    return LineFunc(478, "virtual int Dispatcher_BingoQuiz::read(PacketBuf&, MSG_BASE&)", 0, 0);
}

// IDA_EA: 0x825E9B8
// IDA_NAME: _ZN20Dispatcher_BingoQuiz7processEP5CUserR8MSG_BASER9ParamBase
// DEMANGLED: Dispatcher_BingoQuiz::process(CUser *,MSG_BASE &,ParamBase &)
int __cdecl Dispatcher_BingoQuiz::process(Dispatcher_BingoQuiz *this, CUser *a2, MSG_BASE *a3, ParamBase *a4)
{
  BingoEvent *RepeatEvent; // [esp+2Ch] [ebp-Ch]

  *((_DWORD *)a4 + 1) = Dispatcher_BingoQuiz::check_error(this, a2, a3);
  if ( *((int *)a4 + 1) > 0 )
    return 0;
  if ( *((int *)a4 + 1) >= 0 )
  {
    RepeatEvent = (BingoEvent *)CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 106);
    if ( RepeatEvent )
      *((_DWORD *)a4 + 1) = BingoEvent::reqBingoQuizMark(RepeatEvent, a2, *(_DWORD *)((char *)a3 + 13));
    else
      *((_DWORD *)a4 + 1) = 19;
    *((_DWORD *)a4 + 2) = *(_DWORD *)CUser::getBingoData(a2);
    return 0;
  }
  else
  {
    LogManager::logFormat(
      (LogManager *)1,
      (int)"PacketDispatcher_Impl_2.cpp",
      "virtual int Dispatcher_BingoQuiz::process(CUser*, MSG_BASE&, ParamBase&)",
      (const char *)0x1F0,
      "Dispatcher Check_Error No(%d)",
      *((const char **)a4 + 1));
    return LineFunc(497, "virtual int Dispatcher_BingoQuiz::process(CUser*, MSG_BASE&, ParamBase&)", 0, 0);
  }
}

// IDA_EA: 0x825EACA
// IDA_NAME: _ZN20Dispatcher_BingoQuiz11check_errorEP5CUserR8MSG_BASE
// DEMANGLED: Dispatcher_BingoQuiz::check_error(CUser *,MSG_BASE &)
int __cdecl Dispatcher_BingoQuiz::check_error(Dispatcher_BingoQuiz *this, CUser *a2)
{
  int RepeatEvent; // eax

  if ( !a2 || !CUserCharacInfo::getCurCharacR(a2) )
    return -1;
  if ( CUser::get_state(a2) != 3 )
    return 30;
  RepeatEvent = CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 106);
  if ( (*(unsigned __int8 (__cdecl **)(int, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) != 1 )
    return 19;
  if ( *(_BYTE *)(CUser::getBingoData(a2) + 5) )
    return 18;
  if ( *(char *)(CUser::getBingoData(a2) + 4) <= 2 )
    return 0;
  return 22;
}

// IDA_EA: 0x825EB92
// IDA_NAME: _ZN20Dispatcher_BingoQuiz4sendEP5CUserR9ParamBase
// DEMANGLED: Dispatcher_BingoQuiz::send(CUser *,ParamBase &)
void __cdecl Dispatcher_BingoQuiz::send(Dispatcher_BingoQuiz *this, CUser *a2, ParamBase *a3)
{
  PacketBuf *v3[3]; // [esp+14h] [ebp-24h] BYREF
  PacketBuf *v4[3]; // [esp+20h] [ebp-18h] BYREF
  ParamBase *v5; // [esp+2Ch] [ebp-Ch]

  v5 = a3;
  if ( *((_DWORD *)a3 + 1) )
  {
    PacketGuard::PacketGuard((PacketGuard *)v3);
    InterfacePacketBuf::put_header(v3, 1, 515);
    InterfacePacketBuf::put_byte(v3, 0);
    InterfacePacketBuf::put_byte(v3, *((_DWORD *)v5 + 1));
    InterfacePacketBuf::put_int(v3, *((_DWORD *)v5 + 2));
    InterfacePacketBuf::finalize(v3, 1);
    CUser::Send(a2, (PacketGuard *)v3);
    PacketGuard::~PacketGuard(v3);
  }
  else
  {
    PacketGuard::PacketGuard((PacketGuard *)v4);
    InterfacePacketBuf::put_header(v4, 1, 515);
    InterfacePacketBuf::put_byte(v4, 1);
    InterfacePacketBuf::put_int(v4, *((_DWORD *)v5 + 2));
    InterfacePacketBuf::finalize(v4, 1);
    CUser::Send(a2, (PacketGuard *)v4);
    PacketGuard::~PacketGuard(v4);
  }
}

// IDA_EA: 0x8260ADC
// IDA_NAME: _ZN20Dispatcher_BingoQuizD2Ev
// DEMANGLED: Dispatcher_BingoQuiz::~Dispatcher_BingoQuiz()
void __cdecl Dispatcher_BingoQuiz::~Dispatcher_BingoQuiz(Dispatcher_BingoQuiz *this)
{
  *(_DWORD *)this = &off_8BEA4A8;
  IPacketDispatcher<MSG_BINGO_QUIZ,stBingoQuiz,(ch_state)3>::~IPacketDispatcher(this);
}

// IDA_EA: 0x8260B0C
// IDA_NAME: _ZN20Dispatcher_BingoQuizD0Ev
// DEMANGLED: Dispatcher_BingoQuiz::~Dispatcher_BingoQuiz()
void __cdecl Dispatcher_BingoQuiz::~Dispatcher_BingoQuiz(Dispatcher_BingoQuiz *this)
{
  Dispatcher_BingoQuiz::~Dispatcher_BingoQuiz(this);
  operator delete(this);
}

// IDA_EA: 0x8595874
// IDA_NAME: _ZN20Dispatcher_BingoQuizC2Ev
// DEMANGLED: Dispatcher_BingoQuiz::Dispatcher_BingoQuiz(void)
void __cdecl Dispatcher_BingoQuiz::Dispatcher_BingoQuiz(Dispatcher_BingoQuiz *this)
{
  IPacketDispatcher<MSG_BINGO_QUIZ,stBingoQuiz,(ch_state)3>::IPacketDispatcher(this);
  *(_DWORD *)this = &off_8BEA4A8;
}
