#include "stBlueMarbleConfirmInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8231DBE
// IDA_NAME: _ZN23stBlueMarbleConfirmInfoC2Ev
// DEMANGLED: stBlueMarbleConfirmInfo::stBlueMarbleConfirmInfo(void)
void __cdecl stBlueMarbleConfirmInfo::stBlueMarbleConfirmInfo(stBlueMarbleConfirmInfo *this)
{
  ParamBase::ParamBase(this);
  *(_DWORD *)this = off_8BDE880;
  *((_DWORD *)this + 1) = 0;
}

// IDA_EA: 0x82465C4
// IDA_NAME: _ZN23stBlueMarbleConfirmInfoD2Ev
// DEMANGLED: stBlueMarbleConfirmInfo::~stBlueMarbleConfirmInfo()
void __cdecl stBlueMarbleConfirmInfo::~stBlueMarbleConfirmInfo(stBlueMarbleConfirmInfo *this)
{
  *(_DWORD *)this = off_8BDE880;
  ParamBase::~ParamBase(this);
}

// IDA_EA: 0x82465F4
// IDA_NAME: _ZN23stBlueMarbleConfirmInfoD0Ev
// DEMANGLED: stBlueMarbleConfirmInfo::~stBlueMarbleConfirmInfo()
void __cdecl stBlueMarbleConfirmInfo::~stBlueMarbleConfirmInfo(stBlueMarbleConfirmInfo *this)
{
  stBlueMarbleConfirmInfo::~stBlueMarbleConfirmInfo(this);
  operator delete(this);
}
