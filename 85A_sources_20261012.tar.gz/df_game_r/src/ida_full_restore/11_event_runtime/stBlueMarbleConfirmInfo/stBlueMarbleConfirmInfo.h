#ifndef __IDA91_STBLUEMARBLECONFIRMINFO_H__
#define __IDA91_STBLUEMARBLECONFIRMINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stBlueMarbleConfirmInfo
// Source unit: stBlueMarbleConfirmInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1816

/* 1816 */
struct stBlueMarbleConfirmInfo;

// Exported member functions:
// 0x8231DBE	stBlueMarbleConfirmInfo::stBlueMarbleConfirmInfo(void)
// 0x82465C4	stBlueMarbleConfirmInfo::~stBlueMarbleConfirmInfo()
// 0x82465F4	stBlueMarbleConfirmInfo::~stBlueMarbleConfirmInfo()

// Function declaration index:
// DECL 0x8231DBE stBlueMarbleConfirmInfo::stBlueMarbleConfirmInfo
// DECL 0x82465C4 stBlueMarbleConfirmInfo::~stBlueMarbleConfirmInfo
// DECL 0x82465F4 stBlueMarbleConfirmInfo::~stBlueMarbleConfirmInfo

#endif  // __IDA91_STBLUEMARBLECONFIRMINFO_H__
