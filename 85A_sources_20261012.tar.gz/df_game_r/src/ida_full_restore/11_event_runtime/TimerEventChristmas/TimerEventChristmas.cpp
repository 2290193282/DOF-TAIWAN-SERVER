#include "TimerEventChristmas.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x863570A
// IDA_NAME: _ZN19TimerEventChristmas12dispatch_sigEiij
// DEMANGLED: TimerEventChristmas::dispatch_sig(int,int,unsigned int)
int __cdecl TimerEventChristmas::dispatch_sig(TimerEventChristmas *this, int a2, CServerEvent *a3, CServerEvent *a4)
{
  __int16 EventInterval; // ax
  int v6; // [esp+4h] [ebp-14h]
  int v7; // [esp+4h] [ebp-14h]

  CServerEvent::SubExpRate(a3, v6);
  CServerEvent::TurnOffEvent(a4, v7);
  EventInterval = CServerEvent::GetEventInterval(a4);
  Inter_MonitorServerEventStart::SendEventNotiPacket(0, (__int16)a4, EventInterval, 0);
  return 1;
}

// IDA_EA: 0x863C602
// IDA_NAME: _ZN19TimerEventChristmasC2Ev
// DEMANGLED: TimerEventChristmas::TimerEventChristmas(void)
void __cdecl TimerEventChristmas::TimerEventChristmas(TimerEventChristmas *this)
{
  TimerSig::TimerSig(this);
  *(_DWORD *)this = &off_8CE8F10;
}

// IDA_EA: 0x8640272
// IDA_NAME: _ZN19TimerEventChristmasD2Ev
// DEMANGLED: TimerEventChristmas::~TimerEventChristmas()
void __cdecl TimerEventChristmas::~TimerEventChristmas(TimerEventChristmas *this)
{
  *(_DWORD *)this = &off_8CE8F10;
  TimerSig::~TimerSig(this);
}

// IDA_EA: 0x86402A2
// IDA_NAME: _ZN19TimerEventChristmasD0Ev
// DEMANGLED: TimerEventChristmas::~TimerEventChristmas()
void __cdecl TimerEventChristmas::~TimerEventChristmas(TimerEventChristmas *this)
{
  TimerEventChristmas::~TimerEventChristmas(this);
  operator delete(this);
}
