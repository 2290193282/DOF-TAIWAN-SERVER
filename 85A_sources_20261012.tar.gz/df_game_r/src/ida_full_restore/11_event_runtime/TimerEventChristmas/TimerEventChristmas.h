#ifndef __IDA91_TIMEREVENTCHRISTMAS_H__
#define __IDA91_TIMEREVENTCHRISTMAS_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: TimerEventChristmas
// Source unit: TimerEventChristmas
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3493

/* 3493 */
struct TimerEventChristmas;

// Exported member functions:
// 0x863570A	TimerEventChristmas::dispatch_sig(int,int,unsigned int)
// 0x863C602	TimerEventChristmas::TimerEventChristmas(void)
// 0x8640272	TimerEventChristmas::~TimerEventChristmas()
// 0x86402A2	TimerEventChristmas::~TimerEventChristmas()

// Function declaration index:
// DECL 0x863570A TimerEventChristmas::dispatch_sig
// DECL 0x863C602 TimerEventChristmas::TimerEventChristmas
// DECL 0x8640272 TimerEventChristmas::~TimerEventChristmas
// DECL 0x86402A2 TimerEventChristmas::~TimerEventChristmas

#endif  // __IDA91_TIMEREVENTCHRISTMAS_H__
