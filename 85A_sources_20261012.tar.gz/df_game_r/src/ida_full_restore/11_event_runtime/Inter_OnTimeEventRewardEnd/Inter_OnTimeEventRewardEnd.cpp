#include "Inter_OnTimeEventRewardEnd.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84E1062
// IDA_NAME: _ZN26Inter_OnTimeEventRewardEnd12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_OnTimeEventRewardEnd::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_OnTimeEventRewardEnd::dispatch_sig(Inter_OnTimeEventRewardEnd *this, CUser *a2, char *a3)
{
  GameWorld *v4; // eax
  Timer_Send_Ontime_Reward *v6; // [esp+0h] [ebp-58h]
  char v7; // [esp+8h] [ebp-50h]
  char v8; // [esp+8h] [ebp-50h]
  PacketBuf *v9[3]; // [esp+1Ch] [ebp-3Ch] BYREF
  int v10[4]; // [esp+28h] [ebp-30h] BYREF
  int v11[5]; // [esp+38h] [ebp-20h] BYREF
  COnTimeEvent *RepeatEvent; // [esp+4Ch] [ebp-Ch]

  v11[4] = (int)a3;
  cMyTrace::cMyTrace(
    (cMyTrace *)v10,
    "virtual int Inter_OnTimeEventRewardEnd::dispatch_sig(CUser*, char*, int)",
    20492,
    0);
  cMyTrace::operator()((int)v10, "[ON_TIME_EVENT] Reward End", v7);
  RepeatEvent = (COnTimeEvent *)CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 51);
  if ( RepeatEvent
    && (*(unsigned __int8 (__cdecl **)(COnTimeEvent *, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) )
  {
    COnTimeEvent::set_reward_state(RepeatEvent, 1);
    if ( COnTimeEvent::get_ontime_reward_user_count(RepeatEvent) )
      Timer_Send_Ontime_Reward::RegistNextTimer(v6);
    PacketGuard::PacketGuard((PacketGuard *)v9);
    InterfacePacketBuf::put_header(v9, 0, 262);
    InterfacePacketBuf::finalize(v9, 1);
    v4 = (GameWorld *)G_GameWorld();
    GameWorld::send_all_with_state(v4, (PacketGuard *)v9, 3);
    PacketGuard::~PacketGuard(v9);
  }
  else
  {
    cMyTrace::cMyTrace(
      (cMyTrace *)v11,
      "virtual int Inter_OnTimeEventRewardEnd::dispatch_sig(CUser*, char*, int)",
      20507,
      5);
    cMyTrace::operator()((int)v11, "[ON_TIME_EVENT] Inter_OnTimeEventRewardEnd() error", v8);
  }
  return 0;
}

// IDA_EA: 0x84EE66C
// IDA_NAME: _ZN26Inter_OnTimeEventRewardEndC2Ev
// DEMANGLED: Inter_OnTimeEventRewardEnd::Inter_OnTimeEventRewardEnd(void)
void __cdecl Inter_OnTimeEventRewardEnd::Inter_OnTimeEventRewardEnd(Inter_OnTimeEventRewardEnd *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8EB20;
}

// IDA_EA: 0x84F703E
// IDA_NAME: _ZN26Inter_OnTimeEventRewardEndD2Ev
// DEMANGLED: Inter_OnTimeEventRewardEnd::~Inter_OnTimeEventRewardEnd()
void __cdecl Inter_OnTimeEventRewardEnd::~Inter_OnTimeEventRewardEnd(Inter_OnTimeEventRewardEnd *this)
{
  *(_DWORD *)this = &off_8C8EB20;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84F706E
// IDA_NAME: _ZN26Inter_OnTimeEventRewardEndD0Ev
// DEMANGLED: Inter_OnTimeEventRewardEnd::~Inter_OnTimeEventRewardEnd()
void __cdecl Inter_OnTimeEventRewardEnd::~Inter_OnTimeEventRewardEnd(Inter_OnTimeEventRewardEnd *this)
{
  Inter_OnTimeEventRewardEnd::~Inter_OnTimeEventRewardEnd(this);
  operator delete(this);
}
