#ifndef __IDA91_INTER_ONTIMEEVENTREWARDEND_H__
#define __IDA91_INTER_ONTIMEEVENTREWARDEND_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_OnTimeEventRewardEnd
// Source unit: Inter_OnTimeEventRewardEnd
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 3164

/* 3164 */
struct Inter_OnTimeEventRewardEnd;

// Exported member functions:
// 0x84E1062	Inter_OnTimeEventRewardEnd::dispatch_sig(CUser *,char *,int)
// 0x84EE66C	Inter_OnTimeEventRewardEnd::Inter_OnTimeEventRewardEnd(void)
// 0x84F703E	Inter_OnTimeEventRewardEnd::~Inter_OnTimeEventRewardEnd()
// 0x84F706E	Inter_OnTimeEventRewardEnd::~Inter_OnTimeEventRewardEnd()

// Function declaration index:
// DECL 0x84E1062 Inter_OnTimeEventRewardEnd::dispatch_sig
// DECL 0x84EE66C Inter_OnTimeEventRewardEnd::Inter_OnTimeEventRewardEnd
// DECL 0x84F703E Inter_OnTimeEventRewardEnd::~Inter_OnTimeEventRewardEnd
// DECL 0x84F706E Inter_OnTimeEventRewardEnd::~Inter_OnTimeEventRewardEnd

#endif  // __IDA91_INTER_ONTIMEEVENTREWARDEND_H__
