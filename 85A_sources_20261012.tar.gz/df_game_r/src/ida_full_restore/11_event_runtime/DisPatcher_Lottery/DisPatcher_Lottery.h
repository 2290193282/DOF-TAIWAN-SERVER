#ifndef __IDA91_DISPATCHER_LOTTERY_H__
#define __IDA91_DISPATCHER_LOTTERY_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DisPatcher_Lottery
// Source unit: DisPatcher_Lottery
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 1846

/* 1846 */
struct DisPatcher_Lottery;

// Exported member functions:
// 0x81F8380	DisPatcher_Lottery::dispatch_sig(CUser *,PacketBuf &)
// 0x8233276	DisPatcher_Lottery::read(PacketBuf &,MSG_BASE &)
// 0x8233280	DisPatcher_Lottery::process(CUser *,MSG_BASE &,ParamBase &)
// 0x823328A	DisPatcher_Lottery::~DisPatcher_Lottery()
// 0x82332BA	DisPatcher_Lottery::~DisPatcher_Lottery()
// 0x8595628	DisPatcher_Lottery::DisPatcher_Lottery(void)

// Function declaration index:
// DECL 0x81F8380 DisPatcher_Lottery::dispatch_sig
// DECL 0x8233276 DisPatcher_Lottery::read
// DECL 0x8233280 DisPatcher_Lottery::process
// DECL 0x823328A DisPatcher_Lottery::~DisPatcher_Lottery
// DECL 0x82332BA DisPatcher_Lottery::~DisPatcher_Lottery
// DECL 0x8595628 DisPatcher_Lottery::DisPatcher_Lottery

#endif  // __IDA91_DISPATCHER_LOTTERY_H__
