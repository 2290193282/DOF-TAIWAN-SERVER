#include "DisPatcher_Lottery.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81F8380
// IDA_NAME: _ZN18DisPatcher_Lottery12dispatch_sigEP5CUserR9PacketBuf
// DEMANGLED: DisPatcher_Lottery::dispatch_sig(CUser *,PacketBuf &)
int __cdecl DisPatcher_Lottery::dispatch_sig(DisPatcher_Lottery *this, CUser *a2, PacketBuf *a3)
{
  int v3; // ebx
  int CurSecEv; // ebx
  char *HackAnalyzerEv; // eax
  unsigned int CurSecEv_1; // eax
  PacketBuf *v8[3]; // [esp+20h] [ebp-38h] BYREF
  PacketBuf *v9[3]; // [esp+2Ch] [ebp-2Ch] BYREF
  __int16 v10; // [esp+46h] [ebp-12h] BYREF
  int v11; // [esp+48h] [ebp-10h]
  unsigned int n2; // [esp+4Ch] [ebp-Ch]

  if ( CUser::get_state(a2) <= 2 )
    return 0;
  if ( (unsigned __int8)CUser::CheckInTrade(a2) )
  {
    PacketGuard::PacketGuard((PacketGuard *)v9);
    InterfacePacketBuf::put_header(v9, 1, 29);
    InterfacePacketBuf::put_byte(v9, 0);
    InterfacePacketBuf::put_byte(v9, 218);
    InterfacePacketBuf::finalize(v9, 1);
    CUser::Send(a2, (PacketGuard *)v9);
    v3 = 0;
    PacketGuard::~PacketGuard(v9);
  }
  else if ( (unsigned __int8)PacketBuf::get_short(a3, &v10) == 1 )
  {
    v11 = CUser::lottery_item(a2, v10);
    if ( v11 <= 0 )
    {
      if ( CUser::getLastLotteryTime(a2) )
      {
        CurSecEv = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
        n2 = CurSecEv - CUser::getLastLotteryTime(a2);
        if ( n2 <= 2 )
        {
          HackAnalyzerEv = CUser::getHackAnalyzer(a2);
          WongWork::CHackAnalyzer::addServerHackCnt((WongWork::CHackAnalyzer *)HackAnalyzerEv, a2, 0x334u, 1, 0, 0);
        }
      }
      CurSecEv_1 = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
      CUser::setLastLotteryTime(a2, CurSecEv_1);
      return 0;
    }
    else
    {
      PacketGuard::PacketGuard((PacketGuard *)v8);
      InterfacePacketBuf::put_header(v8, 1, 29);
      InterfacePacketBuf::put_byte(v8, 0);
      InterfacePacketBuf::put_byte(v8, v11);
      InterfacePacketBuf::finalize(v8, 1);
      CUser::Send(a2, (PacketGuard *)v8);
      v3 = 0;
      PacketGuard::~PacketGuard(v8);
    }
  }
  else
  {
    return LineFunc(34332, "virtual int DisPatcher_Lottery::dispatch_sig(CUser*, PacketBuf&)", 0, 0);
  }
  return v3;
}

// IDA_EA: 0x8233276
// IDA_NAME: _ZN18DisPatcher_Lottery4readER9PacketBufR8MSG_BASE
// DEMANGLED: DisPatcher_Lottery::read(PacketBuf &,MSG_BASE &)
int DisPatcher_Lottery::read()
{
  return 0;
}

// IDA_EA: 0x8233280
// IDA_NAME: _ZN18DisPatcher_Lottery7processEP5CUserR8MSG_BASER9ParamBase
// DEMANGLED: DisPatcher_Lottery::process(CUser *,MSG_BASE &,ParamBase &)
int DisPatcher_Lottery::process()
{
  return 0;
}

// IDA_EA: 0x823328A
// IDA_NAME: _ZN18DisPatcher_LotteryD2Ev
// DEMANGLED: DisPatcher_Lottery::~DisPatcher_Lottery()
void __cdecl DisPatcher_Lottery::~DisPatcher_Lottery(DisPatcher_Lottery *this)
{
  *(_DWORD *)this = &off_8BD9308;
  IPacketDispatcher<MSG_BASE,ParamBase,(ch_state)0>::~IPacketDispatcher(this);
}

// IDA_EA: 0x82332BA
// IDA_NAME: _ZN18DisPatcher_LotteryD0Ev
// DEMANGLED: DisPatcher_Lottery::~DisPatcher_Lottery()
void __cdecl DisPatcher_Lottery::~DisPatcher_Lottery(DisPatcher_Lottery *this)
{
  DisPatcher_Lottery::~DisPatcher_Lottery(this);
  operator delete(this);
}

// IDA_EA: 0x8595628
// IDA_NAME: _ZN18DisPatcher_LotteryC2Ev
// DEMANGLED: DisPatcher_Lottery::DisPatcher_Lottery(void)
void __cdecl DisPatcher_Lottery::DisPatcher_Lottery(DisPatcher_Lottery *this)
{
  IPacketDispatcher<MSG_BASE,ParamBase,(ch_state)0>::IPacketDispatcher(this);
  *(_DWORD *)this = &off_8BD9308;
}
