#ifndef __IDA91_BINGODATA_H__
#define __IDA91_BINGODATA_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: BingoData
// Source unit: BingoData
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1111

/* 1111 */
struct BingoData;

// Exported member functions:
// 0x80CBC6C	BingoData::clear(void)
// 0x8697128	BingoData::BingoData(void)

// Function declaration index:
// DECL 0x80CBC6C BingoData::clear
// DECL 0x8697128 BingoData::BingoData

#endif  // __IDA91_BINGODATA_H__
