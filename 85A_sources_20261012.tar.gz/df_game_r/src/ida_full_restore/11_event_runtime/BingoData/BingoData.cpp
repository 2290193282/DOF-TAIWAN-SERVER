#include "BingoData.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x80CBC6C
// IDA_NAME: _ZN9BingoData5clearEv
// DEMANGLED: BingoData::clear(void)
BingoData *__cdecl BingoData::clear(BingoData *this)
{
  BingoData *this_1; // eax

  *(_DWORD *)this = 0;
  *((_BYTE *)this + 4) = 0;
  *((_BYTE *)this + 5) = 0;
  this_1 = this;
  *((_BYTE *)this + 6) = 0;
  return this_1;
}

// IDA_EA: 0x8697128
// IDA_NAME: _ZN9BingoDataC2Ev
// DEMANGLED: BingoData::BingoData(void)
void __cdecl BingoData::BingoData(BingoData *this)
{
  *(_DWORD *)this = 0;
  *((_BYTE *)this + 4) = 0;
  *((_BYTE *)this + 5) = 0;
  *((_BYTE *)this + 6) = 0;
}
