#include "Dispatcher_BlueMarble.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81E5F86
// IDA_NAME: _ZN21Dispatcher_BlueMarble4readER9PacketBufR8MSG_BASE
// DEMANGLED: Dispatcher_BlueMarble::read(PacketBuf &,MSG_BASE &)
int __cdecl Dispatcher_BlueMarble::read(Dispatcher_BlueMarble *this, PacketBuf *a2, MSG_BASE *a3)
{
  if ( (unsigned __int8)PacketBuf::get_byte(a2, (char *)a3 + 13) == 1 )
    return 0;
  else
    return LineFunc(24730, "virtual int Dispatcher_BlueMarble::read(PacketBuf&, MSG_BASE&)", 0, 0);
}

// IDA_EA: 0x81E5FDC
// IDA_NAME: _ZN21Dispatcher_BlueMarble7processEP5CUserR8MSG_BASER9ParamBase
// DEMANGLED: Dispatcher_BlueMarble::process(CUser *,MSG_BASE &,ParamBase &)
int __cdecl Dispatcher_BlueMarble::process(Dispatcher_BlueMarble *this, CUser *UserEv, MSG_BASE *a3, ParamBase *a4)
{
  BlueMarble *BlueMarbleEv; // [esp+1Ch] [ebp-Ch]

  *((_DWORD *)a4 + 1) = Dispatcher_BlueMarble::check_error(this, UserEv, a3);
  if ( *((int *)a4 + 1) > 0 )
    return 0;
  if ( *((int *)a4 + 1) < 0 )
    return LineFunc(
             24745,
             "virtual int Dispatcher_BlueMarble::process(CUser*, MSG_BASE&, ParamBase&)",
             *((_DWORD *)a4 + 1),
             0);
  BlueMarbleEv = (BlueMarble *)CUser::getBlueMarble(UserEv);
  if ( BlueMarbleEv )
  {
    switch ( *((_BYTE *)a3 + 13) )
    {
      case 0:
        BlueMarble::startBlueMarble(BlueMarbleEv);
        break;
      case 1:
        BlueMarble::userThrowDice(BlueMarbleEv, UserEv);
        break;
      case 2:
        BlueMarble::enterDungeon(BlueMarbleEv, UserEv);
        break;
      case 3:
        BlueMarble::giveupDungeon((BlueMarbleScriptManager **)BlueMarbleEv, UserEv);
        break;
      case 4:
        BlueMarble::clearDungeon(BlueMarbleEv, UserEv);
        break;
      case 5:
        BlueMarble::exitDungeon(BlueMarbleEv, UserEv);
        break;
      case 6:
        BlueMarble::leaveUser(BlueMarbleEv, UserEv);
        break;
      case 7:
        BlueMarble::giveBonusItem(BlueMarbleEv, UserEv);
        break;
      default:
        return 0;
    }
  }
  return 0;
}

// IDA_EA: 0x81E612C
// IDA_NAME: _ZN21Dispatcher_BlueMarble11check_errorEP5CUserR8MSG_BASE
// DEMANGLED: Dispatcher_BlueMarble::check_error(CUser *,MSG_BASE &)
int __cdecl Dispatcher_BlueMarble::check_error(Dispatcher_BlueMarble *this, CUser *UserEv, MSG_BASE *a3)
{
  BlueMarble *BlueMarbleEv; // [esp+18h] [ebp-10h]

  if ( !UserEv )
    return -1;
  if ( *((_BYTE *)a3 + 13) == 6 )
    return 0;
  if ( CUser::getMoveSpace(UserEv) != 1 )
    return -2;
  BlueMarbleEv = (BlueMarble *)CUser::getBlueMarble(UserEv);
  if ( !BlueMarbleEv )
    return -3;
  if ( BlueMarble::getUserSlot(BlueMarbleEv, UserEv) == -1 )
    return -4;
  if ( CUser::get_state(UserEv) != 11 && CUser::get_state(UserEv) != 5 )
    return -5;
  else
    return 0;
}

// IDA_EA: 0x81E61F4
// IDA_NAME: _ZN21Dispatcher_BlueMarble4sendEP5CUserR9ParamBase
// DEMANGLED: Dispatcher_BlueMarble::send(CUser *,ParamBase &)
int __cdecl Dispatcher_BlueMarble::send(Dispatcher_BlueMarble *this, CUser *a2, ParamBase *a3)
{
  if ( *((_DWORD *)a3 + 1) )
    return CUser::SendCmdErrorPacket(a2, 496, (unsigned __int8)*((_DWORD *)a3 + 1));
  else
    return CUser::SendCmdOkPacket(a2, 496);
}

// IDA_EA: 0x8243CA2
// IDA_NAME: _ZN21Dispatcher_BlueMarbleD2Ev
// DEMANGLED: Dispatcher_BlueMarble::~Dispatcher_BlueMarble()
void __cdecl Dispatcher_BlueMarble::~Dispatcher_BlueMarble(Dispatcher_BlueMarble *this)
{
  *(_DWORD *)this = &off_8BD9C88;
  IPacketDispatcher<MSG_BLUE_MARBLE,stBlueMarble,(ch_state)3>::~IPacketDispatcher(this);
}

// IDA_EA: 0x8243CD2
// IDA_NAME: _ZN21Dispatcher_BlueMarbleD0Ev
// DEMANGLED: Dispatcher_BlueMarble::~Dispatcher_BlueMarble()
void __cdecl Dispatcher_BlueMarble::~Dispatcher_BlueMarble(Dispatcher_BlueMarble *this)
{
  Dispatcher_BlueMarble::~Dispatcher_BlueMarble(this);
  operator delete(this);
}

// IDA_EA: 0x8597DC6
// IDA_NAME: _ZN21Dispatcher_BlueMarbleC2Ev
// DEMANGLED: Dispatcher_BlueMarble::Dispatcher_BlueMarble(void)
void __cdecl Dispatcher_BlueMarble::Dispatcher_BlueMarble(Dispatcher_BlueMarble *this)
{
  IPacketDispatcher<MSG_BLUE_MARBLE,stBlueMarble,(ch_state)3>::IPacketDispatcher(this);
  *(_DWORD *)this = &off_8BD9C88;
}
