#ifndef __IDA91_DISPATCHER_BLUEMARBLE_H__
#define __IDA91_DISPATCHER_BLUEMARBLE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Dispatcher_BlueMarble
// Source unit: Dispatcher_BlueMarble
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 4330,1120

/* 4330 */
struct Dispatcher_BlueMarble;

/* 1120 */
struct BlueMarble;

// Exported member functions:
// 0x81E5F86	Dispatcher_BlueMarble::read(PacketBuf &,MSG_BASE &)
// 0x81E5FDC	Dispatcher_BlueMarble::process(CUser *,MSG_BASE &,ParamBase &)
// 0x81E612C	Dispatcher_BlueMarble::check_error(CUser *,MSG_BASE &)
// 0x81E61F4	Dispatcher_BlueMarble::send(CUser *,ParamBase &)
// 0x8243CA2	Dispatcher_BlueMarble::~Dispatcher_BlueMarble()
// 0x8243CD2	Dispatcher_BlueMarble::~Dispatcher_BlueMarble()
// 0x8597DC6	Dispatcher_BlueMarble::Dispatcher_BlueMarble(void)

// Function declaration index:
// DECL 0x81E5F86 Dispatcher_BlueMarble::read
// DECL 0x81E5FDC Dispatcher_BlueMarble::process
// DECL 0x81E612C Dispatcher_BlueMarble::check_error
// DECL 0x81E61F4 Dispatcher_BlueMarble::send
// DECL 0x8243CA2 Dispatcher_BlueMarble::~Dispatcher_BlueMarble
// DECL 0x8243CD2 Dispatcher_BlueMarble::~Dispatcher_BlueMarble
// DECL 0x8597DC6 Dispatcher_BlueMarble::Dispatcher_BlueMarble

#endif  // __IDA91_DISPATCHER_BLUEMARBLE_H__
