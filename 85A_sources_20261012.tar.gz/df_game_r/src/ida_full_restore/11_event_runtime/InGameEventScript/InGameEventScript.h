#ifndef __IDA91_INGAMEEVENTSCRIPT_H__
#define __IDA91_INGAMEEVENTSCRIPT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: InGameEventScript
// Source unit: InGameEventScript
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4398

/* 4398 */
struct InGameEventScript;

// Exported member functions:
// 0x8110E96	InGameEventScript::~InGameEventScript()
// 0x8985864	InGameEventScript::InGameEventScript(void)

// Function declaration index:
// DECL 0x8110E96 InGameEventScript::~InGameEventScript
// DECL 0x8985864 InGameEventScript::InGameEventScript

#endif  // __IDA91_INGAMEEVENTSCRIPT_H__
