#include "InGameEventScript.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8110E96
// IDA_NAME: _ZN17InGameEventScriptD2Ev
// DEMANGLED: InGameEventScript::~InGameEventScript()
void __cdecl InGameEventScript::~InGameEventScript(InGameEventScript *this)
{
  std::string::~string((char *)this + 4);
  std::string::~string(this);
}

// IDA_EA: 0x8985864
// IDA_NAME: _ZN17InGameEventScriptC2Ev
// DEMANGLED: InGameEventScript::InGameEventScript(void)
void __cdecl InGameEventScript::InGameEventScript(std::string *this)
{
  std::string::string(this);
  std::string::string(this + 1);
  std::string::clear(this);
  std::string::clear(this + 1);
}
