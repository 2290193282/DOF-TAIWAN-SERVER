#ifndef __IDA91_PRESENTRESPONCESCRIPTEVENT_H__
#define __IDA91_PRESENTRESPONCESCRIPTEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: PresentResponceScriptEvent
// Source unit: PresentResponceScriptEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 3318

/* 3318 */
struct PresentResponceScriptEvent;

// Exported member functions:
// 0x8585564	PresentResponceScriptEvent::~PresentResponceScriptEvent()
// 0x8A00B6A	PresentResponceScriptEvent::clear(void)
// 0x8A00B8A	PresentResponceScriptEvent::PresentResponceScriptEvent(void)
// 0x8A036F0	PresentResponceScriptEvent::PresentResponceScriptEvent(PresentResponceScriptEvent const&)
// 0x8A0379E	PresentResponceScriptEvent::operator=(PresentResponceScriptEvent const&)

// Function declaration index:
// DECL 0x8585564 PresentResponceScriptEvent::~PresentResponceScriptEvent
// DECL 0x8A00B6A PresentResponceScriptEvent::clear
// DECL 0x8A00B8A PresentResponceScriptEvent::PresentResponceScriptEvent
// DECL 0x8A036F0 PresentResponceScriptEvent::PresentResponceScriptEvent
// DECL 0x8A0379E PresentResponceScriptEvent::operator=

#endif  // __IDA91_PRESENTRESPONCESCRIPTEVENT_H__
