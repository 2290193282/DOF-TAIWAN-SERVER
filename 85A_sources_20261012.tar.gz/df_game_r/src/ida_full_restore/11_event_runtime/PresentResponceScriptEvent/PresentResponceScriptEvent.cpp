#include "PresentResponceScriptEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8585564
// IDA_NAME: _ZN26PresentResponceScriptEventD2Ev
// DEMANGLED: PresentResponceScriptEvent::~PresentResponceScriptEvent()
void __cdecl PresentResponceScriptEvent::~PresentResponceScriptEvent(PresentResponceScriptEvent *this)
{
  std::string::~string((char *)this + 4);
}

// IDA_EA: 0x8A00B6A
// IDA_NAME: _ZN26PresentResponceScriptEvent5clearEv
// DEMANGLED: PresentResponceScriptEvent::clear(void)
unsigned int *__cdecl PresentResponceScriptEvent::clear(std::string *this)
{
  this->_M_dataplus.__vftable = 0;
  return std::string::clear(this + 1);
}

// IDA_EA: 0x8A00B8A
// IDA_NAME: _ZN26PresentResponceScriptEventC2Ev
// DEMANGLED: PresentResponceScriptEvent::PresentResponceScriptEvent(void)
void __cdecl PresentResponceScriptEvent::PresentResponceScriptEvent(PresentResponceScriptEvent *this)
{
  std::string::string((std::string *)this + 1);
  PresentResponceScriptEvent::clear((std::string *)this);
}

// IDA_EA: 0x8A036F0
// IDA_NAME: _ZN26PresentResponceScriptEventC2ERKS_
// DEMANGLED: PresentResponceScriptEvent::PresentResponceScriptEvent(PresentResponceScriptEvent const&)
void __cdecl PresentResponceScriptEvent::PresentResponceScriptEvent(
        PresentResponceScriptEvent *this,
        const std::string *a2)
{
  *(std::string *)this = (std::string)a2->_M_dataplus.__vftable;
  std::string::string((std::string *)this + 1, a2 + 1);
}

// IDA_EA: 0x8A0379E
// IDA_NAME: _ZN26PresentResponceScriptEventaSERKS_
// DEMANGLED: PresentResponceScriptEvent::operator=(PresentResponceScriptEvent const&)
std::string *__cdecl PresentResponceScriptEvent::operator=(std::string *a1, const std::string *a2)
{
  a1->_M_dataplus.__vftable = a2->_M_dataplus.__vftable;
  std::string::operator=(a1 + 1, a2 + 1);
  return a1;
}
