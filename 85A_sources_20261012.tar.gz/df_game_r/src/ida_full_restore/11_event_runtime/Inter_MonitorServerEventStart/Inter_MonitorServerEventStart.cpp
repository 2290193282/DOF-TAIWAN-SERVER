#include "Inter_MonitorServerEventStart.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84CF2DE
// IDA_NAME: _ZN29Inter_MonitorServerEventStart19SendEventNotiPacketEbssP5CUser
// DEMANGLED: Inter_MonitorServerEventStart::SendEventNotiPacket(bool,short,short,CUser *)
void __cdecl Inter_MonitorServerEventStart::SendEventNotiPacket(
        Inter_MonitorServerEventStart *this,
        __int16 a2,
        __int16 a3,
        CUser *a4)
{
  GameWorld *v4; // eax
  PacketBuf *v5[5]; // [esp+24h] [ebp-14h] BYREF

  PacketGuard::PacketGuard((PacketGuard *)v5);
  InterfacePacketBuf::put_header(v5, 0, 69);
  InterfacePacketBuf::put_byte(v5, (unsigned __int8)this);
  InterfacePacketBuf::put_short(v5, a2);
  InterfacePacketBuf::put_short(v5, a3);
  InterfacePacketBuf::finalize(v5, 1);
  if ( a4 )
  {
    CUser::Send(a4, (PacketGuard *)v5);
  }
  else
  {
    v4 = (GameWorld *)G_GameWorld();
    GameWorld::send_all(v4, (PacketGuard *)v5);
  }
  PacketGuard::~PacketGuard(v5);
}

// IDA_EA: 0x84CF3CA
// IDA_NAME: _ZN29Inter_MonitorServerEventStart12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_MonitorServerEventStart::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_MonitorServerEventStart::dispatch_sig(Inter_MonitorServerEventStart *this, CUser *a2, char *a3)
{
  int v3; // edi
  int v4; // esi
  int v5; // ebx
  TimerQueue *v6; // eax
  int v7; // ebx
  int v9; // [esp+4h] [ebp-64h]
  int v10; // [esp+8h] [ebp-60h]
  char v11; // [esp+8h] [ebp-60h]
  PacketPool *v12[3]; // [esp+20h] [ebp-48h] BYREF
  int v13[4]; // [esp+2Ch] [ebp-3Ch] BYREF
  int v14[4]; // [esp+3Ch] [ebp-2Ch] BYREF
  char *v15; // [esp+4Ch] [ebp-1Ch]

  v15 = a3;
  PacketGuard::PacketGuard((PacketGuard *)v12);
  if ( *(_DWORD *)(v15 + 10) == 1 )
  {
    Inter_MonitorServerEventStart::SendEventNotiPacket(
      (Inter_MonitorServerEventStart *)1,
      *(_DWORD *)(v15 + 10),
      *((_WORD *)v15 + 8),
      0);
    CServerEvent::AddExpRate((CServerEvent *)*((unsigned __int16 *)v15 + 7), v9);
    CServerEvent::TurnOnEvent(*(CServerEvent **)(v15 + 10), *((unsigned __int16 *)v15 + 8), v10);
    v3 = *(_DWORD *)(v15 + 10);
    v4 = *((unsigned __int16 *)v15 + 7);
    v5 = *((unsigned __int16 *)v15 + 8);
    v6 = (TimerQueue *)G_TimerQueue();
    TimerQueue::InsertTimer(v6, 2, 0, 83, v5, v4, v3);
    cMyTrace::cMyTrace(
      (cMyTrace *)v13,
      "virtual int Inter_MonitorServerEventStart::dispatch_sig(CUser*, char*, int)",
      11336,
      0);
    cMyTrace::operator()((int)v13, "X-Mas Event Start", v11);
  }
  else
  {
    v7 = *(_DWORD *)(v15 + 10);
    cMyTrace::cMyTrace(
      (cMyTrace *)v14,
      "virtual int Inter_MonitorServerEventStart::dispatch_sig(CUser*, char*, int)",
      11339,
      5);
    cMyTrace::operator()((int)v14, "Unknown ServerEvent (%d)", v7);
  }
  PacketGuard::~PacketGuard(v12);
  return 0;
}

// IDA_EA: 0x84ED4EC
// IDA_NAME: _ZN29Inter_MonitorServerEventStartC2Ev
// DEMANGLED: Inter_MonitorServerEventStart::Inter_MonitorServerEventStart(void)
void __cdecl Inter_MonitorServerEventStart::Inter_MonitorServerEventStart(Inter_MonitorServerEventStart *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8F978;
}

// IDA_EA: 0x84F9E8E
// IDA_NAME: _ZN29Inter_MonitorServerEventStartD2Ev
// DEMANGLED: Inter_MonitorServerEventStart::~Inter_MonitorServerEventStart()
void __cdecl Inter_MonitorServerEventStart::~Inter_MonitorServerEventStart(Inter_MonitorServerEventStart *this)
{
  *(_DWORD *)this = &off_8C8F978;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84F9EBE
// IDA_NAME: _ZN29Inter_MonitorServerEventStartD0Ev
// DEMANGLED: Inter_MonitorServerEventStart::~Inter_MonitorServerEventStart()
void __cdecl Inter_MonitorServerEventStart::~Inter_MonitorServerEventStart(Inter_MonitorServerEventStart *this)
{
  Inter_MonitorServerEventStart::~Inter_MonitorServerEventStart(this);
  operator delete(this);
}
