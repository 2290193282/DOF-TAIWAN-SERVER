#ifndef __IDA91_INTER_MONITORSERVEREVENTSTART_H__
#define __IDA91_INTER_MONITORSERVEREVENTSTART_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_MonitorServerEventStart
// Source unit: Inter_MonitorServerEventStart
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 3008

/* 3008 */
struct Inter_MonitorServerEventStart;

// Exported member functions:
// 0x84CF2DE	Inter_MonitorServerEventStart::SendEventNotiPacket(bool,short,short,CUser *)
// 0x84CF3CA	Inter_MonitorServerEventStart::dispatch_sig(CUser *,char *,int)
// 0x84ED4EC	Inter_MonitorServerEventStart::Inter_MonitorServerEventStart(void)
// 0x84F9E8E	Inter_MonitorServerEventStart::~Inter_MonitorServerEventStart()
// 0x84F9EBE	Inter_MonitorServerEventStart::~Inter_MonitorServerEventStart()

// Function declaration index:
// DECL 0x84CF2DE Inter_MonitorServerEventStart::SendEventNotiPacket
// DECL 0x84CF3CA Inter_MonitorServerEventStart::dispatch_sig
// DECL 0x84ED4EC Inter_MonitorServerEventStart::Inter_MonitorServerEventStart
// DECL 0x84F9E8E Inter_MonitorServerEventStart::~Inter_MonitorServerEventStart
// DECL 0x84F9EBE Inter_MonitorServerEventStart::~Inter_MonitorServerEventStart

#endif  // __IDA91_INTER_MONITORSERVEREVENTSTART_H__
