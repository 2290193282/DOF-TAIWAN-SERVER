#include "STBreakAwayRewards.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x831D454
// IDA_NAME: _ZN18STBreakAwayRewards5clearEv
// DEMANGLED: STBreakAwayRewards::clear(void)
STBreakAwayRewards *__cdecl STBreakAwayRewards::clear(STBreakAwayRewards *this)
{
  STBreakAwayRewards *this_1; // eax

  *(_DWORD *)this = 0;
  *((_DWORD *)this + 1) = 0;
  *((_DWORD *)this + 2) = 0;
  *((_DWORD *)this + 3) = 0;
  this_1 = this;
  *((_DWORD *)this + 4) = 0;
  return this_1;
}

// IDA_EA: 0x831D48A
// IDA_NAME: _ZN18STBreakAwayRewardsaSERKS_
// DEMANGLED: STBreakAwayRewards::operator=(STBreakAwayRewards const&)
_DWORD *__cdecl STBreakAwayRewards::operator=(_DWORD *a1, _DWORD *a2)
{
  _DWORD *result; // eax

  *a1 = *a2;
  a1[1] = a2[1];
  a1[2] = a2[2];
  a1[3] = a2[3];
  result = a1;
  a1[4] = a2[4];
  return result;
}

// IDA_EA: 0x831D4CA
// IDA_NAME: _ZN18STBreakAwayRewardsC2Ev
// DEMANGLED: STBreakAwayRewards::STBreakAwayRewards(void)
void __cdecl STBreakAwayRewards::STBreakAwayRewards(STBreakAwayRewards *this)
{
  STBreakAwayRewards::clear(this);
}
