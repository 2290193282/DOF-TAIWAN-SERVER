#ifndef __IDA91_STBREAKAWAYREWARDS_H__
#define __IDA91_STBREAKAWAYREWARDS_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: STBreakAwayRewards
// Source unit: STBreakAwayRewards
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2327

/* 2327 */
struct STBreakAwayRewards;

// Exported member functions:
// 0x831D454	STBreakAwayRewards::clear(void)
// 0x831D48A	STBreakAwayRewards::operator=(STBreakAwayRewards const&)
// 0x831D4CA	STBreakAwayRewards::STBreakAwayRewards(void)

// Function declaration index:
// DECL 0x831D454 STBreakAwayRewards::clear
// DECL 0x831D48A STBreakAwayRewards::operator=
// DECL 0x831D4CA STBreakAwayRewards::STBreakAwayRewards

#endif  // __IDA91_STBREAKAWAYREWARDS_H__
