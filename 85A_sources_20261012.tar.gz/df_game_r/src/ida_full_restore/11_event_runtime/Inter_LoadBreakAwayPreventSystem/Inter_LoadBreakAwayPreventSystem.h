#ifndef __IDA91_INTER_LOADBREAKAWAYPREVENTSYSTEM_H__
#define __IDA91_INTER_LOADBREAKAWAYPREVENTSYSTEM_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_LoadBreakAwayPreventSystem
// Source unit: Inter_LoadBreakAwayPreventSystem
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 3098

/* 3098 */
struct Inter_LoadBreakAwayPreventSystem;

// Exported member functions:
// 0x84D928C	Inter_LoadBreakAwayPreventSystem::dispatch_sig(CUser *,char *,int)
// 0x84EDF18	Inter_LoadBreakAwayPreventSystem::Inter_LoadBreakAwayPreventSystem(void)
// 0x84F8286	Inter_LoadBreakAwayPreventSystem::~Inter_LoadBreakAwayPreventSystem()
// 0x84F82B6	Inter_LoadBreakAwayPreventSystem::~Inter_LoadBreakAwayPreventSystem()

// Function declaration index:
// DECL 0x84D928C Inter_LoadBreakAwayPreventSystem::dispatch_sig
// DECL 0x84EDF18 Inter_LoadBreakAwayPreventSystem::Inter_LoadBreakAwayPreventSystem
// DECL 0x84F8286 Inter_LoadBreakAwayPreventSystem::~Inter_LoadBreakAwayPreventSystem
// DECL 0x84F82B6 Inter_LoadBreakAwayPreventSystem::~Inter_LoadBreakAwayPreventSystem

#endif  // __IDA91_INTER_LOADBREAKAWAYPREVENTSYSTEM_H__
