#include "Inter_LoadBreakAwayPreventSystem.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84D928C
// IDA_NAME: _ZN32Inter_LoadBreakAwayPreventSystem12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_LoadBreakAwayPreventSystem::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_LoadBreakAwayPreventSystem::dispatch_sig(
        Inter_LoadBreakAwayPreventSystem *this,
        CUser *a2,
        char *src)
{
  break_away_prevent::CBreakAwayPreventSystem::loadDbData(
    GlobalData::s_BreakAwaySys,
    (SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER *)src);
  return 0;
}

// IDA_EA: 0x84EDF18
// IDA_NAME: _ZN32Inter_LoadBreakAwayPreventSystemC2Ev
// DEMANGLED: Inter_LoadBreakAwayPreventSystem::Inter_LoadBreakAwayPreventSystem(void)
void __cdecl Inter_LoadBreakAwayPreventSystem::Inter_LoadBreakAwayPreventSystem(Inter_LoadBreakAwayPreventSystem *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8F0C0;
}

// IDA_EA: 0x84F8286
// IDA_NAME: _ZN32Inter_LoadBreakAwayPreventSystemD2Ev
// DEMANGLED: Inter_LoadBreakAwayPreventSystem::~Inter_LoadBreakAwayPreventSystem()
void __cdecl Inter_LoadBreakAwayPreventSystem::~Inter_LoadBreakAwayPreventSystem(
        Inter_LoadBreakAwayPreventSystem *this)
{
  *(_DWORD *)this = &off_8C8F0C0;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84F82B6
// IDA_NAME: _ZN32Inter_LoadBreakAwayPreventSystemD0Ev
// DEMANGLED: Inter_LoadBreakAwayPreventSystem::~Inter_LoadBreakAwayPreventSystem()
void __cdecl Inter_LoadBreakAwayPreventSystem::~Inter_LoadBreakAwayPreventSystem(
        Inter_LoadBreakAwayPreventSystem *this)
{
  Inter_LoadBreakAwayPreventSystem::~Inter_LoadBreakAwayPreventSystem(this);
  operator delete(this);
}
