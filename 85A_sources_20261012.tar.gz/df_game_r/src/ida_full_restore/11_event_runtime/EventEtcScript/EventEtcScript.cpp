#include "EventEtcScript.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8372E66
// IDA_NAME: _ZN14EventEtcScriptC2Ev
// DEMANGLED: EventEtcScript::EventEtcScript(void)
void __cdecl EventEtcScript::EventEtcScript(EventEtcScript *this)
{
  std::vector<int>::vector((int)this);
  std::map<unsigned int,unsigned int>::map((int)this + 12);
  EventEtcScript::clear(this);
}

// IDA_EA: 0x8372ECE
// IDA_NAME: _ZN14EventEtcScript5clearEv
// DEMANGLED: EventEtcScript::clear(void)
bool __cdecl EventEtcScript::clear(EventEtcScript *this)
{
  std::vector<int>::clear(this);
  return std::vector<int>::reserve((int *)this, 7u);
}

// IDA_EA: 0x837DDA0
// IDA_NAME: _ZN14EventEtcScriptD2Ev
// DEMANGLED: EventEtcScript::~EventEtcScript()
void __cdecl EventEtcScript::~EventEtcScript(EventEtcScript *this)
{
  std::map<unsigned int,unsigned int>::~map((int)this + 12);
  std::vector<int>::~vector(this);
}
