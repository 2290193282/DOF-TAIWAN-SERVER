#ifndef __IDA91_EVENTETCSCRIPT_H__
#define __IDA91_EVENTETCSCRIPT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: EventEtcScript
// Source unit: EventEtcScript
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4613

/* 4613 */
struct EventEtcScript;

// Exported member functions:
// 0x8372E66	EventEtcScript::EventEtcScript(void)
// 0x8372ECE	EventEtcScript::clear(void)
// 0x837DDA0	EventEtcScript::~EventEtcScript()

// Function declaration index:
// DECL 0x8372E66 EventEtcScript::EventEtcScript
// DECL 0x8372ECE EventEtcScript::clear
// DECL 0x837DDA0 EventEtcScript::~EventEtcScript

#endif  // __IDA91_EVENTETCSCRIPT_H__
