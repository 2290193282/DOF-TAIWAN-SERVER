#include "DB_InsertArchieveEventLog.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x842E7BE
// IDA_NAME: _ZN25DB_InsertArchieveEventLog8dispatchEiiP6Stream
// DEMANGLED: DB_InsertArchieveEventLog::dispatch(int,int,Stream *)
int __cdecl DB_InsertArchieveEventLog::dispatch(DB_InsertArchieveEventLog *this, int a2, int a3, Stream *a4)
{
  unsigned int v4; // esi
  unsigned int v5; // ebx
  const char *v6; // eax
  MySQL *DBHandle; // [esp+28h] [ebp-10h]
  unsigned int *Out; // [esp+2Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 4, 0);
  Out = (unsigned int *)Stream::GetOutBuffer<SIG_INSERT_ACHIEVE_EVENT>(a4);
  v4 = Out[2];
  v5 = Out[1];
  v6 = (const char *)NumberToString(*Out, 0);
  MySQL::set_query(
    DBHandle,
    "inSert into log_charac_lev_log(occ_time,m_id,charac_no,achieve_type) values(now(),%s,%d,%d)",
    v6,
    v5,
    v4);
  MySQL::exec(DBHandle, 1);
  return 1;
}

// IDA_EA: 0x842E856
// IDA_NAME: _ZN25DB_InsertArchieveEventLog11makeRequestEjjN24SIG_INSERT_ACHIEVE_EVENT17ENUM_ACHIEVE_TYPEE
// DEMANGLED: DB_InsertArchieveEventLog::makeRequest(unsigned int,unsigned int,SIG_INSERT_ACHIEVE_EVENT::ENUM_ACHIEVE_TYPE)
void __cdecl DB_InsertArchieveEventLog::makeRequest(int a1, int a2, int a3)
{
  Stream *v3; // eax
  Stream **v4; // eax
  Stream **v5; // eax
  int v6; // eax
  _BYTE v7[8]; // [esp+14h] [ebp-14h] BYREF
  _DWORD *v8; // [esp+1Ch] [ebp-Ch]

  v3 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 29513);
  CStreamGuard::CStreamGuard((CStreamGuard *)v7, v3, 1);
  v4 = (Stream **)CStreamGuard::operator*((int)v7);
  CStreamGuard::operator<<(v4, 23);
  v5 = (Stream **)CStreamGuard::operator*((int)v7);
  CStreamGuard::operator<<(v5, -1);
  v6 = CStreamGuard::operator->((int)v7);
  v8 = (_DWORD *)CStreamGuard::GetInBuffer<SIG_INSERT_ACHIEVE_EVENT>(v6);
  *v8 = a1;
  v8[1] = a2;
  v8[2] = a3;
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 4, (CStreamGuard *)v7);
  CStreamGuard::~CStreamGuard((CStreamGuard *)v7);
}

// IDA_EA: 0x844EAF2
// IDA_NAME: _ZN25DB_InsertArchieveEventLogC2Ev
// DEMANGLED: DB_InsertArchieveEventLog::DB_InsertArchieveEventLog(void)
void __cdecl DB_InsertArchieveEventLog::DB_InsertArchieveEventLog(DB_InsertArchieveEventLog *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5F030;
}

// IDA_EA: 0x845DF7E
// IDA_NAME: _ZN25DB_InsertArchieveEventLogD2Ev
// DEMANGLED: DB_InsertArchieveEventLog::~DB_InsertArchieveEventLog()
void __cdecl DB_InsertArchieveEventLog::~DB_InsertArchieveEventLog(DB_InsertArchieveEventLog *this)
{
  *(_DWORD *)this = &off_8C5F030;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845DFAE
// IDA_NAME: _ZN25DB_InsertArchieveEventLogD0Ev
// DEMANGLED: DB_InsertArchieveEventLog::~DB_InsertArchieveEventLog()
void __cdecl DB_InsertArchieveEventLog::~DB_InsertArchieveEventLog(DB_InsertArchieveEventLog *this)
{
  DB_InsertArchieveEventLog::~DB_InsertArchieveEventLog(this);
  operator delete(this);
}
