#ifndef __IDA91_DB_INSERTARCHIEVEEVENTLOG_H__
#define __IDA91_DB_INSERTARCHIEVEEVENTLOG_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_InsertArchieveEventLog
// Source unit: DB_InsertArchieveEventLog
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2551

/* 2551 */
struct DB_InsertArchieveEventLog;

// Exported member functions:
// 0x842E7BE	DB_InsertArchieveEventLog::dispatch(int,int,Stream *)
// 0x842E856	DB_InsertArchieveEventLog::makeRequest(unsigned int,unsigned int,SIG_INSERT_ACHIEVE_EVENT::ENUM_ACHIEVE_TYPE)
// 0x844EAF2	DB_InsertArchieveEventLog::DB_InsertArchieveEventLog(void)
// 0x845DF7E	DB_InsertArchieveEventLog::~DB_InsertArchieveEventLog()
// 0x845DFAE	DB_InsertArchieveEventLog::~DB_InsertArchieveEventLog()

// Function declaration index:
// DECL 0x842E7BE DB_InsertArchieveEventLog::dispatch
// DECL 0x842E856 DB_InsertArchieveEventLog::makeRequest
// DECL 0x844EAF2 DB_InsertArchieveEventLog::DB_InsertArchieveEventLog
// DECL 0x845DF7E DB_InsertArchieveEventLog::~DB_InsertArchieveEventLog
// DECL 0x845DFAE DB_InsertArchieveEventLog::~DB_InsertArchieveEventLog

#endif  // __IDA91_DB_INSERTARCHIEVEEVENTLOG_H__
