#include "CVendingMachineBonusEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8116DBE
// IDA_NAME: _ZN25CVendingMachineBonusEventC2Ev
// DEMANGLED: CVendingMachineBonusEvent::CVendingMachineBonusEvent(void)
void __cdecl CVendingMachineBonusEvent::CVendingMachineBonusEvent(CVendingMachineBonusEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B4F428;
}

// IDA_EA: 0x8116DDA
// IDA_NAME: _ZN25CVendingMachineBonusEventD2Ev
// DEMANGLED: CVendingMachineBonusEvent::~CVendingMachineBonusEvent()
void __cdecl CVendingMachineBonusEvent::~CVendingMachineBonusEvent(CVendingMachineBonusEvent *this)
{
  *(_DWORD *)this = off_8B4F428;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x8116E0A
// IDA_NAME: _ZN25CVendingMachineBonusEventD0Ev
// DEMANGLED: CVendingMachineBonusEvent::~CVendingMachineBonusEvent()
void __cdecl CVendingMachineBonusEvent::~CVendingMachineBonusEvent(CVendingMachineBonusEvent *this)
{
  CVendingMachineBonusEvent::~CVendingMachineBonusEvent(this);
  operator delete(this);
}

// IDA_EA: 0x8116E28
// IDA_NAME: _ZN25CVendingMachineBonusEvent10StartEventEv
// DEMANGLED: CVendingMachineBonusEvent::StartEvent(void)
int __cdecl CVendingMachineBonusEvent::StartEvent(CVendingMachineBonusEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CVendingMachineBonusEvent::StartEvent()", 18, 0);
  return cMyTrace::operator()((int)v3, "CVendingMachineBonus Event Start!", v2);
}

// IDA_EA: 0x8116E7A
// IDA_NAME: _ZN25CVendingMachineBonusEvent10StartEventE10Word_Param
// DEMANGLED: CVendingMachineBonusEvent::StartEvent(Word_Param)
int __cdecl CVendingMachineBonusEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x8116E94
// IDA_NAME: _ZN25CVendingMachineBonusEvent8EndEventEv
// DEMANGLED: CVendingMachineBonusEvent::EndEvent(void)
int __cdecl CVendingMachineBonusEvent::EndEvent(CVendingMachineBonusEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CVendingMachineBonusEvent::EndEvent()", 28, 0);
  return cMyTrace::operator()((int)v3, "CVendingMachineBonus Event End!", v2);
}
