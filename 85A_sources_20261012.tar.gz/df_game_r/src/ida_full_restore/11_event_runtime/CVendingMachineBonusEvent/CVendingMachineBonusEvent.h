#ifndef __IDA91_CVENDINGMACHINEBONUSEVENT_H__
#define __IDA91_CVENDINGMACHINEBONUSEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CVendingMachineBonusEvent
// Source unit: CVendingMachineBonusEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4098

/* 4098 */
struct CVendingMachineBonusEvent;

// Exported member functions:
// 0x8116DBE	CVendingMachineBonusEvent::CVendingMachineBonusEvent(void)
// 0x8116DDA	CVendingMachineBonusEvent::~CVendingMachineBonusEvent()
// 0x8116E0A	CVendingMachineBonusEvent::~CVendingMachineBonusEvent()
// 0x8116E28	CVendingMachineBonusEvent::StartEvent(void)
// 0x8116E7A	CVendingMachineBonusEvent::StartEvent(Word_Param)
// 0x8116E94	CVendingMachineBonusEvent::EndEvent(void)

// Function declaration index:
// DECL 0x8116DBE CVendingMachineBonusEvent::CVendingMachineBonusEvent
// DECL 0x8116DDA CVendingMachineBonusEvent::~CVendingMachineBonusEvent
// DECL 0x8116E0A CVendingMachineBonusEvent::~CVendingMachineBonusEvent
// DECL 0x8116E28 CVendingMachineBonusEvent::StartEvent
// DECL 0x8116E7A CVendingMachineBonusEvent::StartEvent
// DECL 0x8116E94 CVendingMachineBonusEvent::EndEvent

#endif  // __IDA91_CVENDINGMACHINEBONUSEVENT_H__
