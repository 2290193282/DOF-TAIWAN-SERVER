#ifndef __IDA91_EXCHANGERANDOMITEMREWARDSCRIPT_H__
#define __IDA91_EXCHANGERANDOMITEMREWARDSCRIPT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: ExchangeRandomItemRewardScript
// Source unit: ExchangeRandomItemRewardScript
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4828

/* 4828 */
struct ExchangeRandomItemRewardScript;

// Exported member functions:
// 0x8985AE0	ExchangeRandomItemRewardScript::reset(void)
// 0x8985B1A	ExchangeRandomItemRewardScript::ExchangeRandomItemRewardScript(void)

// Function declaration index:
// DECL 0x8985AE0 ExchangeRandomItemRewardScript::reset
// DECL 0x8985B1A ExchangeRandomItemRewardScript::ExchangeRandomItemRewardScript

#endif  // __IDA91_EXCHANGERANDOMITEMREWARDSCRIPT_H__
