#include "ExchangeRandomItemRewardScript.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8985AE0
// IDA_NAME: _ZN30ExchangeRandomItemRewardScript5resetEv
// DEMANGLED: ExchangeRandomItemRewardScript::reset(void)
int __cdecl ExchangeRandomItemRewardScript::reset(ExchangeRandomItemRewardScript *this)
{
  *((_BYTE *)this + 8) = 0;
  std::vector<std::pair<int,int>>::clear((_DWORD *)this + 3);
  std::vector<int>::clear((_DWORD *)this + 6);
  return Action_SendMail::reset((std::string *)this + 9);
}

// IDA_EA: 0x8985B1A
// IDA_NAME: _ZN30ExchangeRandomItemRewardScriptC2Ev
// DEMANGLED: ExchangeRandomItemRewardScript::ExchangeRandomItemRewardScript(void)
void __cdecl ExchangeRandomItemRewardScript::ExchangeRandomItemRewardScript(std::string *this)
{
  InGameEventScript::InGameEventScript(this);
  std::vector<std::pair<int,int>>::vector((int)&this[3]);
  std::vector<int>::vector((int)&this[6]);
  Action_SendMail::Action_SendMail((Action_SendMail *)&this[9]);
  ExchangeRandomItemRewardScript::reset((ExchangeRandomItemRewardScript *)this);
}
