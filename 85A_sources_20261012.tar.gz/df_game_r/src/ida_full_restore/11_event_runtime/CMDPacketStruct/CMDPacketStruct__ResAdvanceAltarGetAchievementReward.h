#ifndef __IDA91_CMDPACKETSTRUCT_RESADVANCEALTARGETACHIEVEMENTREWARD_H__
#define __IDA91_CMDPACKETSTRUCT_RESADVANCEALTARGETACHIEVEMENTREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CMDPacketStruct
// Source unit: CMDPacketStruct__ResAdvanceAltarGetAchievementReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "network/PacketGuard.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 1277

/* 1277 */
struct CMDPacketStruct::_ResAdvanceAltarGetAchievementReward;

// Exported member functions:
// 0x8141F5A	CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::_ResAdvanceAltarGetAchievementReward(void)
// 0x81426F0	CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::~_ResAdvanceAltarGetAchievementReward()
// 0x8142720	CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::~_ResAdvanceAltarGetAchievementReward()

// Function declaration index:
// DECL 0x8141F5A CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::_ResAdvanceAltarGetAchievementReward
// DECL 0x81426F0 CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::~_ResAdvanceAltarGetAchievementReward
// DECL 0x8142720 CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::~_ResAdvanceAltarGetAchievementReward

#endif  // __IDA91_CMDPACKETSTRUCT_RESADVANCEALTARGETACHIEVEMENTREWARD_H__
