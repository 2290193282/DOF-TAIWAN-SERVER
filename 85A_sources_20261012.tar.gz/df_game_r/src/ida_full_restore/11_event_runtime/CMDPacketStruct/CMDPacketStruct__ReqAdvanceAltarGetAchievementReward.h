#ifndef __IDA91_CMDPACKETSTRUCT_REQADVANCEALTARGETACHIEVEMENTREWARD_H__
#define __IDA91_CMDPACKETSTRUCT_REQADVANCEALTARGETACHIEVEMENTREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CMDPacketStruct
// Source unit: CMDPacketStruct__ReqAdvanceAltarGetAchievementReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "network/PacketGuard.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 1276

/* 1276 */
struct CMDPacketStruct::_ReqAdvanceAltarGetAchievementReward;

// Exported member functions:
// 0x8141F2C	CMDPacketStruct::_ReqAdvanceAltarGetAchievementReward::_ReqAdvanceAltarGetAchievementReward(void)

// Function declaration index:
// DECL 0x8141F2C CMDPacketStruct::_ReqAdvanceAltarGetAchievementReward::_ReqAdvanceAltarGetAchievementReward

#endif  // __IDA91_CMDPACKETSTRUCT_REQADVANCEALTARGETACHIEVEMENTREWARD_H__
