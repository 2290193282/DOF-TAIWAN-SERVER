#include "CMDPacketStruct__ResAdvanceAltarGetAchievementReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8141F5A
// IDA_NAME: _ZN15CMDPacketStruct36_ResAdvanceAltarGetAchievementRewardC2Ev
// DEMANGLED: CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::_ResAdvanceAltarGetAchievementReward(void)
void *__cdecl CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::_ResAdvanceAltarGetAchievementReward(
        CMDPacketStruct::_ResAdvanceAltarGetAchievementReward *this)
{
  CMDPacketStruct::STBaseResponse::STBaseResponse(this);
  *(_DWORD *)this = off_8B6EF28;
  return memset(this, 0, 0xCu);
}

// IDA_EA: 0x81426F0
// IDA_NAME: _ZN15CMDPacketStruct36_ResAdvanceAltarGetAchievementRewardD2Ev
// DEMANGLED: CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::~_ResAdvanceAltarGetAchievementReward()
void __cdecl CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::~_ResAdvanceAltarGetAchievementReward(
        CMDPacketStruct::_ResAdvanceAltarGetAchievementReward *this)
{
  *(_DWORD *)this = off_8B6EF28;
  CMDPacketStruct::STBaseResponse::~STBaseResponse(this);
}

// IDA_EA: 0x8142720
// IDA_NAME: _ZN15CMDPacketStruct36_ResAdvanceAltarGetAchievementRewardD0Ev
// DEMANGLED: CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::~_ResAdvanceAltarGetAchievementReward()
void __cdecl CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::~_ResAdvanceAltarGetAchievementReward(
        CMDPacketStruct::_ResAdvanceAltarGetAchievementReward *this)
{
  CMDPacketStruct::_ResAdvanceAltarGetAchievementReward::~_ResAdvanceAltarGetAchievementReward(this);
  operator delete(this);
}
