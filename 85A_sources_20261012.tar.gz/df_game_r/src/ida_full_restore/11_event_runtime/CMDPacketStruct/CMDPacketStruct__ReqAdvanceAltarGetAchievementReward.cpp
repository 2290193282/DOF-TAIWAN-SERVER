#include "CMDPacketStruct__ReqAdvanceAltarGetAchievementReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8141F2C
// IDA_NAME: _ZN15CMDPacketStruct36_ReqAdvanceAltarGetAchievementRewardC2Ev
// DEMANGLED: CMDPacketStruct::_ReqAdvanceAltarGetAchievementReward::_ReqAdvanceAltarGetAchievementReward(void)
void *__cdecl CMDPacketStruct::_ReqAdvanceAltarGetAchievementReward::_ReqAdvanceAltarGetAchievementReward(
        CMDPacketStruct::_ReqAdvanceAltarGetAchievementReward *this)
{
  CMDPacketStruct::STBaseRequest::STBaseRequest(this);
  return memset(this, 0, 0x14u);
}
