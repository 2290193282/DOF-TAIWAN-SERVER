#include "LevelupSupport2ndEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x811B988
// IDA_NAME: _ZN22LevelupSupport2ndEventC2Ev
// DEMANGLED: LevelupSupport2ndEvent::LevelupSupport2ndEvent(void)
void __cdecl LevelupSupport2ndEvent::LevelupSupport2ndEvent(LevelupSupport2ndEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B522C8;
}

// IDA_EA: 0x811B9A4
// IDA_NAME: _ZN22LevelupSupport2ndEventD2Ev
// DEMANGLED: LevelupSupport2ndEvent::~LevelupSupport2ndEvent()
void __cdecl LevelupSupport2ndEvent::~LevelupSupport2ndEvent(LevelupSupport2ndEvent *this)
{
  *(_DWORD *)this = off_8B522C8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x811B9D4
// IDA_NAME: _ZN22LevelupSupport2ndEventD0Ev
// DEMANGLED: LevelupSupport2ndEvent::~LevelupSupport2ndEvent()
void __cdecl LevelupSupport2ndEvent::~LevelupSupport2ndEvent(LevelupSupport2ndEvent *this)
{
  LevelupSupport2ndEvent::~LevelupSupport2ndEvent(this);
  operator delete(this);
}

// IDA_EA: 0x811B9F2
// IDA_NAME: _ZN22LevelupSupport2ndEvent10StartEventEv
// DEMANGLED: LevelupSupport2ndEvent::StartEvent(void)
int __cdecl LevelupSupport2ndEvent::StartEvent(LevelupSupport2ndEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 107, 0);
  return cMyTrace::operator()((int)v3, "LevelupSupport2ndEvent Event Start!", v2);
}

// IDA_EA: 0x811BA44
// IDA_NAME: _ZN22LevelupSupport2ndEvent10StartEventE10Word_Param
// DEMANGLED: LevelupSupport2ndEvent::StartEvent(Word_Param)
int __cdecl LevelupSupport2ndEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x811BA5E
// IDA_NAME: _ZN22LevelupSupport2ndEvent8EndEventEv
// DEMANGLED: LevelupSupport2ndEvent::EndEvent(void)
int __cdecl LevelupSupport2ndEvent::EndEvent(LevelupSupport2ndEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "EndEvent", 117, 0);
  return cMyTrace::operator()((int)v3, "LevelupSupport2ndEvent Event End!", v2);
}
