#ifndef __IDA91_LEVELUPSUPPORT2NDEVENT_H__
#define __IDA91_LEVELUPSUPPORT2NDEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: LevelupSupport2ndEvent
// Source unit: LevelupSupport2ndEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4104

/* 4104 */
struct LevelupSupport2ndEvent;

// Exported member functions:
// 0x811B988	LevelupSupport2ndEvent::LevelupSupport2ndEvent(void)
// 0x811B9A4	LevelupSupport2ndEvent::~LevelupSupport2ndEvent()
// 0x811B9D4	LevelupSupport2ndEvent::~LevelupSupport2ndEvent()
// 0x811B9F2	LevelupSupport2ndEvent::StartEvent(void)
// 0x811BA44	LevelupSupport2ndEvent::StartEvent(Word_Param)
// 0x811BA5E	LevelupSupport2ndEvent::EndEvent(void)

// Function declaration index:
// DECL 0x811B988 LevelupSupport2ndEvent::LevelupSupport2ndEvent
// DECL 0x811B9A4 LevelupSupport2ndEvent::~LevelupSupport2ndEvent
// DECL 0x811B9D4 LevelupSupport2ndEvent::~LevelupSupport2ndEvent
// DECL 0x811B9F2 LevelupSupport2ndEvent::StartEvent
// DECL 0x811BA44 LevelupSupport2ndEvent::StartEvent
// DECL 0x811BA5E LevelupSupport2ndEvent::EndEvent

#endif  // __IDA91_LEVELUPSUPPORT2NDEVENT_H__
