#ifndef __IDA91_GAME_MASTER_CENDEVENT_H__
#define __IDA91_GAME_MASTER_CENDEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: game_master
// Source unit: game_master_CEndEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2239

/* 2239 */
struct game_master::CEndEvent;

// Exported member functions:
// 0x82A845E	game_master::CEndEvent::CEndEvent(void)
// 0x84AB914	game_master::CEndEvent::parse(void)
// 0x84AB94C	game_master::CEndEvent::execute(void)

// Function declaration index:
// DECL 0x82A845E game_master::CEndEvent::CEndEvent
// DECL 0x84AB914 game_master::CEndEvent::parse
// DECL 0x84AB94C game_master::CEndEvent::execute

#endif  // __IDA91_GAME_MASTER_CENDEVENT_H__
