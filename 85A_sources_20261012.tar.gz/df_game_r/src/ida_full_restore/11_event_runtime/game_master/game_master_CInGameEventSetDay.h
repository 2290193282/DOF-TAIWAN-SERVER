#ifndef __IDA91_GAME_MASTER_CINGAMEEVENTSETDAY_H__
#define __IDA91_GAME_MASTER_CINGAMEEVENTSETDAY_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: game_master
// Source unit: game_master_CInGameEventSetDay
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2269

/* 2269 */
struct game_master::CInGameEventSetDay;

// Exported member functions:
// 0x82A87A6	game_master::CInGameEventSetDay::CInGameEventSetDay(void)
// 0x84B09D0	game_master::CInGameEventSetDay::parse(void)
// 0x84B0A08	game_master::CInGameEventSetDay::execute(void)

// Function declaration index:
// DECL 0x82A87A6 game_master::CInGameEventSetDay::CInGameEventSetDay
// DECL 0x84B09D0 game_master::CInGameEventSetDay::parse
// DECL 0x84B0A08 game_master::CInGameEventSetDay::execute

#endif  // __IDA91_GAME_MASTER_CINGAMEEVENTSETDAY_H__
