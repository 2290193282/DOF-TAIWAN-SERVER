#ifndef __IDA91_GAME_MASTER_CSTARTEVENT_H__
#define __IDA91_GAME_MASTER_CSTARTEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: game_master
// Source unit: game_master_CStartEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2238

/* 2238 */
struct game_master::CStartEvent;

// Exported member functions:
// 0x82A8442	game_master::CStartEvent::CStartEvent(void)
// 0x84AB5B6	game_master::CStartEvent::parse(void)
// 0x84AB64E	game_master::CStartEvent::getParam(std::string)
// 0x84AB886	game_master::CStartEvent::execute(void)

// Function declaration index:
// DECL 0x82A8442 game_master::CStartEvent::CStartEvent
// DECL 0x84AB5B6 game_master::CStartEvent::parse
// DECL 0x84AB64E game_master::CStartEvent::getParam
// DECL 0x84AB886 game_master::CStartEvent::execute

#endif  // __IDA91_GAME_MASTER_CSTARTEVENT_H__
