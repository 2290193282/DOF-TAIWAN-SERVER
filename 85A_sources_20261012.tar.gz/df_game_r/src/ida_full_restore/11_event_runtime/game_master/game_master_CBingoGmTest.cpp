#include "game_master_CBingoGmTest.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x82A893A
// IDA_NAME: _ZN11game_master12CBingoGmTestC2Ev
// DEMANGLED: game_master::CBingoGmTest::CBingoGmTest(void)
game_master::CBingoGmTest *__cdecl game_master::CBingoGmTest::CBingoGmTest(game_master::CBingoGmTest *this)
{
  game_master::CBingoGmTest *this_1; // eax

  game_master::CCommand::CCommand(this);
  this_1 = this;
  *(_DWORD *)this = off_8C81510;
  return this_1;
}

// IDA_EA: 0x84B35C4
// IDA_NAME: _ZN11game_master12CBingoGmTest5parseEv
// DEMANGLED: game_master::CBingoGmTest::parse(void)
int __cdecl game_master::CBingoGmTest::parse(game_master::CBingoGmTest *this)
{
  const char *nptr; // eax
  int result; // eax

  trim((std::string *)(*((_DWORD *)this + 1) + 12));
  nptr = (const char *)std::string::c_str((std::string *)(*((_DWORD *)this + 1) + 12));
  result = atoi(nptr);
  *((_DWORD *)this + 2) = result;
  return result;
}

// IDA_EA: 0x84B35FC
// IDA_NAME: _ZN11game_master12CBingoGmTest7executeEv
// DEMANGLED: game_master::CBingoGmTest::execute(void)
int __cdecl game_master::CBingoGmTest::execute(game_master::CBingoGmTest *this)
{
  int result; // eax

  result = game_master::CCommand::GetUser(this);
  if ( result )
  {
    if ( *((_DWORD *)this + 2) )
      return game_master::CBingoGmTest::reqValue(this);
    else
      return game_master::CBingoGmTest::resetData(this);
  }
  return result;
}

// IDA_EA: 0x84B363E
// IDA_NAME: _ZN11game_master12CBingoGmTest9resetDataEv
// DEMANGLED: game_master::CBingoGmTest::resetData(void)
CUser *__cdecl game_master::CBingoGmTest::resetData(game_master::CBingoGmTest *this)
{
  CUser *result; // eax
  BingoData *BingoDataEv; // eax
  CUser *v3; // [esp+1Ch] [ebp-Ch]

  result = (CUser *)game_master::CCommand::GetUser(this);
  v3 = result;
  if ( result )
  {
    BingoDataEv = (BingoData *)CUser::getBingoData(result);
    BingoData::clear(BingoDataEv);
    *(_BYTE *)(CUser::getBingoData(v3) + 6) = 1;
    return (CUser *)CUser::sendBingoData(v3);
  }
  return result;
}

// IDA_EA: 0x84B368A
// IDA_NAME: _ZN11game_master12CBingoGmTest8reqValueEv
// DEMANGLED: game_master::CBingoGmTest::reqValue(void)
void __cdecl game_master::CBingoGmTest::reqValue(game_master::CBingoGmTest *this)
{
  int BingoRandomVauleEi; // esi
  unsigned int *BingoDataEv; // ebx
  char *BingoSystemEv; // eax
  CBingo *v4; // eax
  int n3; // eax
  int *BingoDataEv_1; // eax
  PacketBuf *v7[3]; // [esp+1Ch] [ebp-2Ch] BYREF
  CUser *User; // [esp+28h] [ebp-20h]
  BingoEvent *RepeatEvent; // [esp+2Ch] [ebp-1Ch]
  int v10; // [esp+30h] [ebp-18h]
  int v11; // [esp+34h] [ebp-14h]
  int n3_1; // [esp+38h] [ebp-10h]
  int n3_2; // [esp+3Ch] [ebp-Ch]

  User = (CUser *)game_master::CCommand::GetUser(this);
  if ( User )
  {
    RepeatEvent = (BingoEvent *)CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 106);
    if ( RepeatEvent )
    {
      if ( *(char *)(CUser::getBingoData(User) + 4) <= 2 )
      {
        v10 = *(_DWORD *)CUser::getBingoData(User);
        BingoRandomVauleEi = *((_DWORD *)this + 2);
        BingoDataEv = (unsigned int *)CUser::getBingoData(User);
        BingoSystemEv = BingoEvent::getBingoSystem(RepeatEvent);
        v4 = (CBingo *)boost::shared_ptr<CBingo>::operator->((int)BingoSystemEv);
        v11 = CBingo::calNewValue(v4, BingoDataEv, BingoRandomVauleEi);
        if ( *(_DWORD *)CUser::getBingoData(User) != v10 )
        {
          *(_BYTE *)(CUser::getBingoData(User) + 6) = 1;
          n3_1 = v11 - *(char *)(CUser::getBingoData(User) + 4);
          if ( n3_1 > 0 )
          {
            n3 = n3_1;
            if ( n3_1 > 3 )
              n3 = 3;
            n3_1 = n3;
            *(_BYTE *)(CUser::getBingoData(User) + 4) = v11;
            for ( n3_2 = 0; n3_2 < n3_1; ++n3_2 )
              BingoEvent::sendOneMatchLineReward(RepeatEvent, User);
          }
        }
        PacketGuard::PacketGuard((PacketGuard *)v7);
        InterfacePacketBuf::clear(v7);
        InterfacePacketBuf::put_header(v7, 0, 451);
        InterfacePacketBuf::put_byte(v7, *((_DWORD *)this + 2));
        BingoDataEv_1 = (int *)CUser::getBingoData(User);
        InterfacePacketBuf::put_int(v7, *BingoDataEv_1);
        InterfacePacketBuf::finalize(v7, 1);
        CUser::Send(User, (PacketGuard *)v7);
        PacketGuard::~PacketGuard(v7);
      }
    }
  }
}
