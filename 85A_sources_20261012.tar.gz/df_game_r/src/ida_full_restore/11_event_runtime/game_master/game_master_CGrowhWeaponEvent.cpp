#include "game_master_CGrowhWeaponEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x82A88E6
// IDA_NAME: _ZN11game_master17CGrowhWeaponEventC2Ev
// DEMANGLED: game_master::CGrowhWeaponEvent::CGrowhWeaponEvent(void)
game_master::CGrowhWeaponEvent *__cdecl game_master::CGrowhWeaponEvent::CGrowhWeaponEvent(
        game_master::CGrowhWeaponEvent *this)
{
  game_master::CGrowhWeaponEvent *this_1; // eax

  game_master::CCommand::CCommand(this);
  this_1 = this;
  *(_DWORD *)this = off_8C81558;
  return this_1;
}

// IDA_EA: 0x84B28D6
// IDA_NAME: _ZN11game_master17CGrowhWeaponEvent5parseEv
// DEMANGLED: game_master::CGrowhWeaponEvent::parse(void)
game_master::CGrowhWeaponEvent *__cdecl game_master::CGrowhWeaponEvent::parse(game_master::CGrowhWeaponEvent *this)
{
  game_master::CGrowhWeaponEvent *this_1; // eax
  const char *nptr; // eax

  trim((std::string *)(*((_DWORD *)this + 1) + 12));
  if ( std::operator==<char>((std::string *)(*((_DWORD *)this + 1) + 12), "gw") )
  {
    this_1 = this;
    *((_BYTE *)this + 8) = 1;
  }
  else
  {
    *((_BYTE *)this + 8) = 0;
    nptr = (const char *)std::string::c_str((std::string *)(*((_DWORD *)this + 1) + 12));
    this_1 = (game_master::CGrowhWeaponEvent *)atoi(nptr);
    *((_DWORD *)this + 3) = this_1;
  }
  return this_1;
}

// IDA_EA: 0x84B293C
// IDA_NAME: _ZN11game_master17CGrowhWeaponEvent7executeEv
// DEMANGLED: game_master::CGrowhWeaponEvent::execute(void)
void __cdecl game_master::CGrowhWeaponEvent::execute(game_master::CGrowhWeaponEvent *this)
{
  DB_EventGrowthWeaponReset *acc_idEv; // eax
  __int16 v2; // bx
  DB_EventUpdateGrowthWeaponTimepiece *acc_idEv_1; // eax
  CUser *User; // [esp+18h] [ebp-10h]
  int GrowthWeaponEventdataEv; // [esp+1Ch] [ebp-Ch]

  User = (CUser *)game_master::CCommand::GetUser(this);
  if ( User )
  {
    GrowthWeaponEventdataEv = CUser::getGrowthWeaponEventdata(User);
    if ( *((_BYTE *)this + 8) )
    {
      *(_DWORD *)(GrowthWeaponEventdataEv + 8) = 0;
      *(_DWORD *)(GrowthWeaponEventdataEv + 4) = 0;
      *(_BYTE *)GrowthWeaponEventdataEv = 0;
      *(_WORD *)(GrowthWeaponEventdataEv + 16) = 0;
      *(_DWORD *)(GrowthWeaponEventdataEv + 12) = 0;
      acc_idEv = (DB_EventGrowthWeaponReset *)CUser::get_acc_id(User);
      DB_EventGrowthWeaponReset::makeRequest(acc_idEv);
    }
    else
    {
      *(_WORD *)(GrowthWeaponEventdataEv + 16) = *((_DWORD *)this + 3);
      *(_DWORD *)(GrowthWeaponEventdataEv + 12) = 0;
      v2 = *(_WORD *)(GrowthWeaponEventdataEv + 16);
      acc_idEv_1 = (DB_EventUpdateGrowthWeaponTimepiece *)CUser::get_acc_id(User);
      DB_EventUpdateGrowthWeaponTimepiece::makeRequest(acc_idEv_1, v2, 0);
    }
  }
}
