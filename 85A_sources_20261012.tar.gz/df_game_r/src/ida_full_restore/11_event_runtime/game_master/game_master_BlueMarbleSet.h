#ifndef __IDA91_GAME_MASTER_BLUEMARBLESET_H__
#define __IDA91_GAME_MASTER_BLUEMARBLESET_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: game_master
// Source unit: game_master_BlueMarbleSet
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2275

/* 2275 */
struct game_master::BlueMarbleSet;

// Exported member functions:
// 0x82A88AE	game_master::BlueMarbleSet::BlueMarbleSet(void)
// 0x84B22CA	game_master::BlueMarbleSet::parse(void)
// 0x84B235C	game_master::BlueMarbleSet::getParam(std::string)
// 0x84B25A4	game_master::BlueMarbleSet::execute(void)

// Function declaration index:
// DECL 0x82A88AE game_master::BlueMarbleSet::BlueMarbleSet
// DECL 0x84B22CA game_master::BlueMarbleSet::parse
// DECL 0x84B235C game_master::BlueMarbleSet::getParam
// DECL 0x84B25A4 game_master::BlueMarbleSet::execute

#endif  // __IDA91_GAME_MASTER_BLUEMARBLESET_H__
