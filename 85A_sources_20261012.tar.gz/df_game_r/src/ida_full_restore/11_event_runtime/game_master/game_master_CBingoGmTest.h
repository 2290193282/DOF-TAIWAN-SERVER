#ifndef __IDA91_GAME_MASTER_CBINGOGMTEST_H__
#define __IDA91_GAME_MASTER_CBINGOGMTEST_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: game_master
// Source unit: game_master_CBingoGmTest
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2280

/* 2280 */
struct game_master::CBingoGmTest;

// Exported member functions:
// 0x82A893A	game_master::CBingoGmTest::CBingoGmTest(void)
// 0x84B35C4	game_master::CBingoGmTest::parse(void)
// 0x84B35FC	game_master::CBingoGmTest::execute(void)
// 0x84B363E	game_master::CBingoGmTest::resetData(void)
// 0x84B368A	game_master::CBingoGmTest::reqValue(void)

// Function declaration index:
// DECL 0x82A893A game_master::CBingoGmTest::CBingoGmTest
// DECL 0x84B35C4 game_master::CBingoGmTest::parse
// DECL 0x84B35FC game_master::CBingoGmTest::execute
// DECL 0x84B363E game_master::CBingoGmTest::resetData
// DECL 0x84B368A game_master::CBingoGmTest::reqValue

#endif  // __IDA91_GAME_MASTER_CBINGOGMTEST_H__
