#ifndef __IDA91_GAME_MASTER_CCLEARREWARDTEST_H__
#define __IDA91_GAME_MASTER_CCLEARREWARDTEST_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: game_master
// Source unit: game_master_CClearRewardTest
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 2278

/* 2278 */
struct game_master::CClearRewardTest;

// Exported member functions:
// 0x82A8902	game_master::CClearRewardTest::CClearRewardTest(void)
// 0x84B2A02	game_master::CClearRewardTest::parse(void)
// 0x84B2A08	game_master::CClearRewardTest::execute(void)
// 0x84B3398	game_master::CClearRewardTest::printClient(CUser *,char const*,char const*)

// Function declaration index:
// DECL 0x82A8902 game_master::CClearRewardTest::CClearRewardTest
// DECL 0x84B2A02 game_master::CClearRewardTest::parse
// DECL 0x84B2A08 game_master::CClearRewardTest::execute
// DECL 0x84B3398 game_master::CClearRewardTest::printClient

#endif  // __IDA91_GAME_MASTER_CCLEARREWARDTEST_H__
