#include "game_master_CEndEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x82A845E
// IDA_NAME: _ZN11game_master9CEndEventC2Ev
// DEMANGLED: game_master::CEndEvent::CEndEvent(void)
game_master::CEndEvent *__cdecl game_master::CEndEvent::CEndEvent(game_master::CEndEvent *this)
{
  game_master::CEndEvent *this_1; // eax

  game_master::CCommand::CCommand(this);
  this_1 = this;
  *(_DWORD *)this = off_8C81900;
  return this_1;
}

// IDA_EA: 0x84AB914
// IDA_NAME: _ZN11game_master9CEndEvent5parseEv
// DEMANGLED: game_master::CEndEvent::parse(void)
int __cdecl game_master::CEndEvent::parse(game_master::CEndEvent *this)
{
  const char *nptr; // eax
  int result; // eax

  trim((std::string *)(*((_DWORD *)this + 1) + 12));
  nptr = (const char *)std::string::c_str((std::string *)(*((_DWORD *)this + 1) + 12));
  result = atoi(nptr);
  *((_DWORD *)this + 2) = result;
  return result;
}

// IDA_EA: 0x84AB94C
// IDA_NAME: _ZN11game_master9CEndEvent7executeEv
// DEMANGLED: game_master::CEndEvent::execute(void)
char __cdecl game_master::CEndEvent::execute(game_master::CEndEvent *this)
{
  int v1; // eax
  int ServerGroup; // eax
  CMonitorServerProxy *ServerProxy; // eax
  char src[10]; // [esp+1Eh] [ebp-1Ah] BYREF
  int v6; // [esp+28h] [ebp-10h]
  CUser *User; // [esp+2Ch] [ebp-Ch]

  User = (CUser *)game_master::CCommand::GetUser(this);
  v1 = CUser::isGMUser(User) ^ 1;
  if ( !(_BYTE)v1 )
  {
    Packet_Monitor_Event_End::Packet_Monitor_Event_End((Packet_Monitor_Event_End *)src);
    v6 = *((_DWORD *)this + 2);
    ServerGroup = CUser::GetServerGroup(User);
    ServerProxy = (CMonitorServerProxy *)CServerProxyMgr<CMonitorServerProxy>::GetServerProxy(
                                           GlobalData::s_monitor_proxy_mgr,
                                           ServerGroup);
    LOBYTE(v1) = CMonitorServerProxy::SendTcpPacket(ServerProxy, src, 0xEu);
  }
  return v1;
}
