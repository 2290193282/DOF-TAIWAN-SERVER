#include "game_master_CInGameEventSetDay.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x82A87A6
// IDA_NAME: _ZN11game_master18CInGameEventSetDayC2Ev
// DEMANGLED: game_master::CInGameEventSetDay::CInGameEventSetDay(void)
game_master::CInGameEventSetDay *__cdecl game_master::CInGameEventSetDay::CInGameEventSetDay(
        game_master::CInGameEventSetDay *this)
{
  game_master::CInGameEventSetDay *this_1; // eax

  game_master::CCommand::CCommand(this);
  this_1 = this;
  *(_DWORD *)this = off_8C81630;
  return this_1;
}

// IDA_EA: 0x84B09D0
// IDA_NAME: _ZN11game_master18CInGameEventSetDay5parseEv
// DEMANGLED: game_master::CInGameEventSetDay::parse(void)
int __cdecl game_master::CInGameEventSetDay::parse(game_master::CInGameEventSetDay *this)
{
  const char *nptr; // eax
  int result; // eax

  trim((std::string *)(*((_DWORD *)this + 1) + 12));
  nptr = (const char *)std::string::c_str((std::string *)(*((_DWORD *)this + 1) + 12));
  result = atoi(nptr);
  *((_DWORD *)this + 2) = result;
  return result;
}

// IDA_EA: 0x84B0A08
// IDA_NAME: _ZN11game_master18CInGameEventSetDay7executeEv
// DEMANGLED: game_master::CInGameEventSetDay::execute(void)
void __cdecl game_master::CInGameEventSetDay::execute(game_master::CInGameEventSetDay *this)
{
  int n20109999; // ebx
  CDataManager *v2; // eax
  EventClassify::CEventScriptMng *event_script_mngEv; // eax

  n20109999 = *((_DWORD *)this + 2);
  v2 = (CDataManager *)G_CDataManager();
  event_script_mngEv = (EventClassify::CEventScriptMng *)CDataManager::get_event_script_mng(v2);
  EventClassify::CEventScriptMng::test_process_change_day(event_script_mngEv, n20109999);
}
