#include "game_master_BlueMarbleSet.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x82A88AE
// IDA_NAME: _ZN11game_master13BlueMarbleSetC2Ev
// DEMANGLED: game_master::BlueMarbleSet::BlueMarbleSet(void)
game_master::BlueMarbleSet *__cdecl game_master::BlueMarbleSet::BlueMarbleSet(game_master::BlueMarbleSet *this)
{
  game_master::BlueMarbleSet *this_1; // eax

  game_master::CCommand::CCommand(this);
  this_1 = this;
  *(_DWORD *)this = off_8C81588;
  return this_1;
}

// IDA_EA: 0x84B22CA
// IDA_NAME: _ZN11game_master13BlueMarbleSet5parseEv
// DEMANGLED: game_master::BlueMarbleSet::parse(void)
void __cdecl game_master::BlueMarbleSet::parse(game_master::BlueMarbleSet *this)
{
  std::string v1; // [esp+1Ch] [ebp-Ch] BYREF

  *((_BYTE *)this + 9) = 0;
  *((_BYTE *)this + 10) = 0;
  *((_BYTE *)this + 8) = 0;
  *((_DWORD *)this + 3) = 0;
  trim((std::string *)(*((_DWORD *)this + 1) + 12));
  std::string::string(&v1, (const std::string *)(*((_DWORD *)this + 1) + 12));
  game_master::BlueMarbleSet::getParam(this, (std::string)&v1);
  std::string::~string(&v1);
}

// IDA_EA: 0x84B235C
// IDA_NAME: _ZN11game_master13BlueMarbleSet8getParamESs
// DEMANGLED: game_master::BlueMarbleSet::getParam(std::string)
std::string *__cdecl game_master::BlueMarbleSet::getParam(game_master::BlueMarbleSet *this, std::string a2)
{
  std::string *v2; // edi
  int n15; // esi
  const char *nptr; // eax
  std::string *i; // ebx
  std::string *result; // eax
  std::string v7; // [esp+24h] [ebp-64h] BYREF
  std::string v8; // [esp+28h] [ebp-60h] BYREF
  std::string v9; // [esp+64h] [ebp-24h] BYREF
  std::string v10; // [esp+68h] [ebp-20h] BYREF
  int v11; // [esp+6Ch] [ebp-1Ch]

  v11 = 0;
  v2 = &v7;
  for ( n15 = 15; n15 != -1; --n15 )
    std::string::string(v2++);
  while ( 1 )
  {
    v11 = std::string::find((std::string *)a2._M_dataplus.__vftable, 32, 0);
    if ( v11 == -1 )
      break;
    std::string::substr(&v9, (unsigned int)a2._M_dataplus.__vftable, 0);
    std::string::operator=(&v7 + *((_DWORD *)this + 3), &v9);
    std::string::~string(&v9);
    std::string::substr(&v10, (unsigned int)a2._M_dataplus.__vftable, v11 + 1);
    std::string::operator=(a2._M_dataplus.__vftable, &v10);
    std::string::~string(&v10);
    ++*((_DWORD *)this + 3);
  }
  std::string::operator=(&v7 + *((_DWORD *)this + 3), a2._M_dataplus.__vftable);
  if ( !std::string::compare(&v7, "move") )
  {
    *((_BYTE *)this + 9) = 1;
  }
  else if ( !std::string::compare(&v7, "enter") )
  {
    *((_BYTE *)this + 10) = 1;
  }
  nptr = (const char *)std::string::c_str(&v8);
  *((_BYTE *)this + 8) = atoi(nptr);
  for ( i = &v9; ; std::string::~string(i) )
  {
    result = &v7;
    if ( i == &v7 )
      break;
    --i;
  }
  return result;
}

// IDA_EA: 0x84B25A4
// IDA_NAME: _ZN11game_master13BlueMarbleSet7executeEv
// DEMANGLED: game_master::BlueMarbleSet::execute(void)
void __cdecl game_master::BlueMarbleSet::execute(game_master::BlueMarbleSet *this)
{
  CUserCharacInfo *UserEv; // [esp+18h] [ebp-10h]
  BlueMarble *BlueMarbleEv; // [esp+1Ch] [ebp-Ch]

  UserEv = (CUserCharacInfo *)game_master::CCommand::GetUser(this);
  if ( UserEv )
  {
    if ( *((_BYTE *)this + 10) )
    {
      CUserCharacInfo::resetBlueMarbleEnterCount(UserEv);
      CUser::sendBlueMarbleEnterCount(UserEv);
    }
    else
    {
      BlueMarbleEv = (BlueMarble *)CUser::getBlueMarble(UserEv);
      if ( BlueMarbleEv && *((_BYTE *)this + 9) )
      {
        if ( *((_BYTE *)this + 8) )
          BlueMarble::movePosition(BlueMarbleEv, UserEv, *((unsigned __int8 *)this + 8));
      }
    }
  }
}
