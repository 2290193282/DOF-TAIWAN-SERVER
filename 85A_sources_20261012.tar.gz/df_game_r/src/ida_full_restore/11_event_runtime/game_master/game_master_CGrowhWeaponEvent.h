#ifndef __IDA91_GAME_MASTER_CGROWHWEAPONEVENT_H__
#define __IDA91_GAME_MASTER_CGROWHWEAPONEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: game_master
// Source unit: game_master_CGrowhWeaponEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2277

/* 2277 */
struct game_master::CGrowhWeaponEvent;

// Exported member functions:
// 0x82A88E6	game_master::CGrowhWeaponEvent::CGrowhWeaponEvent(void)
// 0x84B28D6	game_master::CGrowhWeaponEvent::parse(void)
// 0x84B293C	game_master::CGrowhWeaponEvent::execute(void)

// Function declaration index:
// DECL 0x82A88E6 game_master::CGrowhWeaponEvent::CGrowhWeaponEvent
// DECL 0x84B28D6 game_master::CGrowhWeaponEvent::parse
// DECL 0x84B293C game_master::CGrowhWeaponEvent::execute

#endif  // __IDA91_GAME_MASTER_CGROWHWEAPONEVENT_H__
