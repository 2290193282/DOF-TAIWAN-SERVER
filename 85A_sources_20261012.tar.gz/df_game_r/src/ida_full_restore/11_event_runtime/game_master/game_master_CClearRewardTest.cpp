#include "game_master_CClearRewardTest.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x82A8902
// IDA_NAME: _ZN11game_master16CClearRewardTestC2Ev
// DEMANGLED: game_master::CClearRewardTest::CClearRewardTest(void)
game_master::CClearRewardTest *__cdecl game_master::CClearRewardTest::CClearRewardTest(
        game_master::CClearRewardTest *this)
{
  game_master::CClearRewardTest *this_1; // eax

  game_master::CCommand::CCommand(this);
  this_1 = this;
  *(_DWORD *)this = off_8C81540;
  return this_1;
}

// IDA_EA: 0x84B2A02
// IDA_NAME: _ZN11game_master16CClearRewardTest5parseEv
// DEMANGLED: game_master::CClearRewardTest::parse(void)
void game_master::CClearRewardTest::parse()
{
  ;
}

// IDA_EA: 0x84B2A08
// IDA_NAME: _ZN11game_master16CClearRewardTest7executeEv
// DEMANGLED: game_master::CClearRewardTest::execute(void)
void __cdecl game_master::CClearRewardTest::execute(game_master::CClearRewardTest *this)
{
  CDataManager *v1; // eax
  int ItemGeneratorEv; // eax
  int v3; // eax
  unsigned int n2; // ebx
  CItemList **v5; // eax
  int v6; // edi
  int rarityEv; // esi
  const char *ItemName; // ebx
  int indexEv; // eax
  const char *v10; // ebx
  CUser *v11; // eax
  int v12; // eax
  unsigned int n2_1; // ebx
  CItemList **v14; // eax
  int v15; // edi
  int rarityEv_1; // esi
  const char *v17; // ebx
  int indexEv_1; // eax
  const char *v19; // ebx
  CUser *v20; // eax
  char dest[1024]; // [esp+2Ch] [ebp-55Ch] BYREF
  _BYTE v22[56]; // [esp+42Ch] [ebp-15Ch] BYREF
  int n1065353216; // [esp+464h] [ebp-124h]
  int v24; // [esp+468h] [ebp-120h]
  CDungeon *v25; // [esp+46Ch] [ebp-11Ch]
  _DWORD v26[12]; // [esp+474h] [ebp-114h] BYREF
  std::_Rb_tree_node_base *src__1; // [esp+4A4h] [ebp-E4h] BYREF
  int v28; // [esp+4A8h] [ebp-E0h] BYREF
  int v29; // [esp+4ACh] [ebp-DCh] BYREF
  std::_Rb_tree_node_base *src_; // [esp+4B0h] [ebp-D8h] BYREF
  int v31; // [esp+4B4h] [ebp-D4h] BYREF
  int v32; // [esp+4B8h] [ebp-D0h] BYREF
  std::string v33; // [esp+4BCh] [ebp-CCh] BYREF
  _BYTE v34[24]; // [esp+4C0h] [ebp-C8h] BYREF
  _DWORD v35[2]; // [esp+4D8h] [ebp-B0h] BYREF
  int v36; // [esp+4E0h] [ebp-A8h] BYREF
  _BYTE v37[8]; // [esp+4E4h] [ebp-A4h] BYREF
  int v38; // [esp+4ECh] [ebp-9Ch] BYREF
  unsigned int __t[3]; // [esp+4F4h] [ebp-94h] BYREF
  int v40; // [esp+500h] [ebp-88h] BYREF
  int v41; // [esp+504h] [ebp-84h] BYREF
  int v42; // [esp+508h] [ebp-80h] BYREF
  _BYTE dest_[4]; // [esp+50Ch] [ebp-7Ch] BYREF
  _DWORD v44[2]; // [esp+510h] [ebp-78h] BYREF
  int v45; // [esp+518h] [ebp-70h] BYREF
  _BYTE v46[8]; // [esp+51Ch] [ebp-6Ch] BYREF
  int v47; // [esp+524h] [ebp-64h] BYREF
  unsigned int __t_1[3]; // [esp+52Ch] [ebp-5Ch] BYREF
  int v49; // [esp+538h] [ebp-50h] BYREF
  int v50; // [esp+53Ch] [ebp-4Ch] BYREF
  int v51; // [esp+540h] [ebp-48h] BYREF
  _BYTE dest__1[4]; // [esp+544h] [ebp-44h] BYREF
  CUser *User; // [esp+548h] [ebp-40h]
  CParty *Party; // [esp+54Ch] [ebp-3Ch]
  CDungeon *v55; // [esp+550h] [ebp-38h]
  char dungeon_diffEv; // [esp+557h] [ebp-31h]
  int standard_levelEv; // [esp+558h] [ebp-30h]
  int GeneratorENS0_15eGenerateType_tE; // [esp+55Ch] [ebp-2Ch]
  int n99999; // [esp+560h] [ebp-28h]
  CItem *item; // [esp+564h] [ebp-24h]
  int n99999_1; // [esp+568h] [ebp-20h]
  CItem *v62; // [esp+56Ch] [ebp-1Ch]

  User = (CUser *)game_master::CCommand::GetUser(this);
  if ( User )
  {
    if ( CUserCharacInfo::getCurCharacR(User) )
    {
      if ( CUser::get_state(User) == 5 )
      {
        Party = (CParty *)CUser::GetParty(User);
        if ( Party )
        {
          if ( *((_DWORD *)Party + 811) )
          {
            v55 = (CDungeon *)*((_DWORD *)Party + 811);
            dungeon_diffEv = CBattle_Field::get_dungeon_diff((CParty *)((char *)Party + 2852));
            standard_levelEv = 0;
            if ( (char)CDungeon::get_dimension_possible(v55) <= 0 )
              standard_levelEv = CDungeon::get_standard_level(v55);
            else
              standard_levelEv = CParty::getStandardDimensionLevel(Party);
            WongWork::stGenerateRefData_t::stGenerateRefData_t((WongWork::stGenerateRefData_t *)v22);
            v22[53] = dungeon_diffEv;
            v22[52] = standard_levelEv;
            v25 = v55;
            n1065353216 = 1065353216;
            v24 = 0;
            v1 = (CDataManager *)G_CDataManager();
            ItemGeneratorEv = CDataManager::getItemGenerator(v1);
            GeneratorENS0_15eGenerateType_tE = WongWork::CItemGeneratorMgr::getGenerator(ItemGeneratorEv, 2);
            WongWork::stGenerateResult_t::stGenerateResult_t((WongWork::stGenerateResult_t *)v26);
            for ( n99999 = 0; n99999 <= 99999; ++n99999 )
              (*(void (__cdecl **)(int, _BYTE *, _DWORD *))(*(_DWORD *)GeneratorENS0_15eGenerateType_tE + 8))(
                GeneratorENS0_15eGenerateType_tE,
                v22,
                v26);
            std::map<int,int>::map((int)v34);
            std::map<int,int>::clear((int)v34);
            std::vector<Inven_Item>::begin((int)&v32, (int)v26);
            while ( 1 )
            {
              std::vector<Inven_Item>::end(v35, (int)v26);
              if ( !__gnu_cxx::operator!=<Inven_Item *,std::vector<Inven_Item>>((int)&v32, (int)v35) )
                break;
              v35[1] = *(_DWORD *)(__gnu_cxx::__normal_iterator<Inven_Item *,std::vector<Inven_Item>>::operator->((int)&v32)
                                 + 2);
              std::map<int,int>::find((int)&v31);
              std::map<int,int>::end((int)&v36);
              if ( std::_Rb_tree_iterator<std::pair<int const,int>>::operator==(&v31, &v36) )
              {
                __t[2] = 1;
                __gnu_cxx::__normal_iterator<Inven_Item *,std::vector<Inven_Item>>::operator->((int)&v32);
                std::make_pair<unsigned long &,int>(__t);
                std::pair<int const,int>::pair<unsigned long,int>((int)&v38, __t);
                std::map<int,int>::insert((int)v37);
              }
              else
              {
                v3 = std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v31);
                ++*(_DWORD *)(v3 + 4);
              }
              __gnu_cxx::__normal_iterator<Inven_Item *,std::vector<Inven_Item>>::operator++(&v40, &v32);
            }
            std::string::string(&v33);
            std::map<int,int>::begin(&src_, (int)v34);
            while ( 1 )
            {
              std::map<int,int>::end((int)&v41);
              if ( !std::_Rb_tree_iterator<std::pair<int const,int>>::operator!=(&src_, &v41) )
                break;
              memset(dest, 0, sizeof(dest));
              std::map<int,int>::begin(&v42, (int)v34);
              if ( std::_Rb_tree_iterator<std::pair<int const,int>>::operator==(&src_, &v42) )
              {
                memcpy(dest, "    Item Index\t\t                     Item Name\t\tRarity\t\tCount\n", 0x3Fu);
                std::string::operator+=(&v33, dest);
                memset(dest, 0, sizeof(dest));
              }
              n2 = *(_DWORD *)std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&src_);
              v5 = (CItemList **)G_CDataManager();
              item = (CItem *)CDataManager::find_item(v5, n2);
              if ( item )
              {
                v6 = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&src_) + 4);
                rarityEv = CItem::get_rarity(item);
                ItemName = (const char *)CItem::GetItemName((std::string *)item);
                indexEv = CItem::get_index(item);
                sprintf(dest, "%14d\t\t%30s\t\t%6d\t\t%5d\n", indexEv, ItemName, rarityEv, v6);
                std::string::operator+=(&v33, dest);
              }
              std::_Rb_tree_iterator<std::pair<int const,int>>::operator++(dest_, &src_);
            }
            v10 = (const char *)std::string::c_str(&v33);
            v11 = (CUser *)game_master::CCommand::GetUser(this);
            game_master::CClearRewardTest::printClient(this, v11, "cltr_normal.txt", v10);
            v24 = 1;
            std::vector<Inven_Item>::clear(v26);
            std::string::clear(&v33);
            std::map<int,int>::clear((int)v34);
            for ( n99999_1 = 0; n99999_1 <= 99999; ++n99999_1 )
              (*(void (__cdecl **)(int, _BYTE *, _DWORD *))(*(_DWORD *)GeneratorENS0_15eGenerateType_tE + 8))(
                GeneratorENS0_15eGenerateType_tE,
                v22,
                v26);
            std::vector<Inven_Item>::begin((int)&v29, (int)v26);
            while ( 1 )
            {
              std::vector<Inven_Item>::end(v44, (int)v26);
              if ( !__gnu_cxx::operator!=<Inven_Item *,std::vector<Inven_Item>>((int)&v29, (int)v44) )
                break;
              v44[1] = *(_DWORD *)(__gnu_cxx::__normal_iterator<Inven_Item *,std::vector<Inven_Item>>::operator->((int)&v29)
                                 + 2);
              std::map<int,int>::find((int)&v28);
              std::map<int,int>::end((int)&v45);
              if ( std::_Rb_tree_iterator<std::pair<int const,int>>::operator==(&v28, &v45) )
              {
                __t_1[2] = 1;
                __gnu_cxx::__normal_iterator<Inven_Item *,std::vector<Inven_Item>>::operator->((int)&v29);
                std::make_pair<unsigned long &,int>(__t_1);
                std::pair<int const,int>::pair<unsigned long,int>((int)&v47, __t_1);
                std::map<int,int>::insert((int)v46);
              }
              else
              {
                v12 = std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&v28);
                ++*(_DWORD *)(v12 + 4);
              }
              __gnu_cxx::__normal_iterator<Inven_Item *,std::vector<Inven_Item>>::operator++(&v49, &v29);
            }
            std::map<int,int>::begin(&src__1, (int)v34);
            while ( 1 )
            {
              std::map<int,int>::end((int)&v50);
              if ( !std::_Rb_tree_iterator<std::pair<int const,int>>::operator!=(&src__1, &v50) )
                break;
              memset(dest, 0, sizeof(dest));
              std::map<int,int>::begin(&v51, (int)v34);
              if ( std::_Rb_tree_iterator<std::pair<int const,int>>::operator==(&src__1, &v51) )
              {
                memcpy(dest, "    Item Index\t\t                     Item Name\t\tRarity\t\tCount\n", 0x3Fu);
                std::string::operator+=(&v33, dest);
                memset(dest, 0, sizeof(dest));
              }
              n2_1 = *(_DWORD *)std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&src__1);
              v14 = (CItemList **)G_CDataManager();
              v62 = (CItem *)CDataManager::find_item(v14, n2_1);
              if ( v62 )
              {
                v15 = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,int>>::operator->(&src__1) + 4);
                rarityEv_1 = CItem::get_rarity(v62);
                v17 = (const char *)CItem::GetItemName((std::string *)v62);
                indexEv_1 = CItem::get_index(v62);
                sprintf(dest, "%14d\t\t%30s\t\t%6d\t\t%5d\n", indexEv_1, v17, rarityEv_1, v15);
                std::string::operator+=(&v33, dest);
              }
              std::_Rb_tree_iterator<std::pair<int const,int>>::operator++(dest__1, &src__1);
            }
            v19 = (const char *)std::string::c_str(&v33);
            v20 = (CUser *)game_master::CCommand::GetUser(this);
            game_master::CClearRewardTest::printClient(this, v20, "cltr_gold.txt", v19);
            std::string::~string(&v33);
            std::map<int,int>::~map((int)v34);
            WongWork::stGenerateResult_t::~stGenerateResult_t((WongWork::stGenerateResult_t *)v26);
            WongWork::stGenerateRefData_t::~stGenerateRefData_t((WongWork::stGenerateRefData_t *)v22);
          }
        }
      }
    }
  }
}

// IDA_EA: 0x84B3398
// IDA_NAME: _ZN11game_master16CClearRewardTest11printClientEP5CUserPKcS4_
// DEMANGLED: game_master::CClearRewardTest::printClient(CUser *,char const*,char const*)
void __cdecl game_master::CClearRewardTest::printClient(
        game_master::CClearRewardTest *this,
        CUser *a2,
        char *s,
        char *s_1)
{
  size_t v4; // eax
  size_t v5; // eax
  size_t v6; // eax
  size_t v7; // eax
  PacketBuf *v8[5]; // [esp+14h] [ebp-14h] BYREF

  PacketGuard::PacketGuard((PacketGuard *)v8);
  InterfacePacketBuf::put_header(v8, 0, 318);
  InterfacePacketBuf::put_byte(v8, 1);
  v4 = strlen(s);
  InterfacePacketBuf::put_int(v8, v4);
  v5 = strlen(s);
  InterfacePacketBuf::put_str(v8, s, v5);
  v6 = strlen(s_1);
  InterfacePacketBuf::put_int(v8, v6);
  v7 = strlen(s_1);
  InterfacePacketBuf::put_str(v8, s_1, v7);
  InterfacePacketBuf::finalize(v8, 1);
  CUser::Send(a2, (PacketGuard *)v8);
  PacketGuard::~PacketGuard(v8);
}
