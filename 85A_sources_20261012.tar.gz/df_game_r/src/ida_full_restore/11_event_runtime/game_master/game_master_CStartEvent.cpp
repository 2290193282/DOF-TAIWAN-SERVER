#include "game_master_CStartEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x82A8442
// IDA_NAME: _ZN11game_master11CStartEventC2Ev
// DEMANGLED: game_master::CStartEvent::CStartEvent(void)
game_master::CStartEvent *__cdecl game_master::CStartEvent::CStartEvent(game_master::CStartEvent *this)
{
  game_master::CStartEvent *this_1; // eax

  game_master::CCommand::CCommand(this);
  this_1 = this;
  *(_DWORD *)this = off_8C81918;
  return this_1;
}

// IDA_EA: 0x84AB5B6
// IDA_NAME: _ZN11game_master11CStartEvent5parseEv
// DEMANGLED: game_master::CStartEvent::parse(void)
void __cdecl game_master::CStartEvent::parse(game_master::CStartEvent *this)
{
  std::string v1; // [esp+1Ch] [ebp-Ch] BYREF

  *((_DWORD *)this + 3) = 0;
  *((_WORD *)this + 8) = 0;
  *((_WORD *)this + 9) = 0;
  *((_DWORD *)this + 2) = 0;
  trim((std::string *)(*((_DWORD *)this + 1) + 12));
  std::string::string(&v1, (const std::string *)(*((_DWORD *)this + 1) + 12));
  game_master::CStartEvent::getParam(this, (std::string)&v1);
  std::string::~string(&v1);
}

// IDA_EA: 0x84AB64E
// IDA_NAME: _ZN11game_master11CStartEvent8getParamESs
// DEMANGLED: game_master::CStartEvent::getParam(std::string)
std::string *__cdecl game_master::CStartEvent::getParam(game_master::CStartEvent *this, std::string a2)
{
  std::string *v2; // edi
  int n15; // esi
  const char *nptr; // eax
  const char *nptr_1; // eax
  const char *nptr_2; // eax
  std::string *i; // ebx
  std::string *result; // eax
  std::string v9; // [esp+24h] [ebp-64h] BYREF
  std::string v10; // [esp+28h] [ebp-60h] BYREF
  std::string v11; // [esp+2Ch] [ebp-5Ch] BYREF
  std::string v12; // [esp+64h] [ebp-24h] BYREF
  std::string v13; // [esp+68h] [ebp-20h] BYREF
  int v14; // [esp+6Ch] [ebp-1Ch]

  v14 = 0;
  v2 = &v9;
  for ( n15 = 15; n15 != -1; --n15 )
    std::string::string(v2++);
  while ( 1 )
  {
    v14 = std::string::find((std::string *)a2._M_dataplus.__vftable, 32, 0);
    if ( v14 == -1 )
      break;
    std::string::substr(&v12, (unsigned int)a2._M_dataplus.__vftable, 0);
    std::string::operator=(&v9 + *((_DWORD *)this + 2), &v12);
    std::string::~string(&v12);
    std::string::substr(&v13, (unsigned int)a2._M_dataplus.__vftable, v14 + 1);
    std::string::operator=(a2._M_dataplus.__vftable, &v13);
    std::string::~string(&v13);
    ++*((_DWORD *)this + 2);
  }
  std::string::operator=(&v9 + *((_DWORD *)this + 2), a2._M_dataplus.__vftable);
  nptr = (const char *)std::string::c_str(&v9);
  *((_DWORD *)this + 3) = atoi(nptr);
  nptr_1 = (const char *)std::string::c_str(&v10);
  *((_WORD *)this + 8) = atoi(nptr_1);
  nptr_2 = (const char *)std::string::c_str(&v11);
  *((_WORD *)this + 9) = atoi(nptr_2);
  for ( i = &v12; ; std::string::~string(i) )
  {
    result = &v9;
    if ( i == &v9 )
      break;
    --i;
  }
  return result;
}

// IDA_EA: 0x84AB886
// IDA_NAME: _ZN11game_master11CStartEvent7executeEv
// DEMANGLED: game_master::CStartEvent::execute(void)
char __cdecl game_master::CStartEvent::execute(game_master::CStartEvent *this)
{
  int v1; // eax
  int ServerGroup; // eax
  CMonitorServerProxy *ServerProxy; // eax
  char src[10]; // [esp+1Ah] [ebp-1Eh] BYREF
  int v6; // [esp+24h] [ebp-14h]
  __int16 v7; // [esp+28h] [ebp-10h]
  __int16 v8; // [esp+2Ah] [ebp-Eh]
  CUser *User; // [esp+2Ch] [ebp-Ch]

  User = (CUser *)game_master::CCommand::GetUser(this);
  v1 = CUser::isGMUser(User) ^ 1;
  if ( !(_BYTE)v1 )
  {
    Packet_Monitor_Event_Start::Packet_Monitor_Event_Start((Packet_Monitor_Event_Start *)src);
    v6 = *((_DWORD *)this + 3);
    v7 = *((_WORD *)this + 8);
    v8 = *((_WORD *)this + 9);
    ServerGroup = CUser::GetServerGroup(User);
    ServerProxy = (CMonitorServerProxy *)CServerProxyMgr<CMonitorServerProxy>::GetServerProxy(
                                           GlobalData::s_monitor_proxy_mgr,
                                           ServerGroup);
    LOBYTE(v1) = CMonitorServerProxy::SendTcpPacket(ServerProxy, src, 0x12u);
  }
  return v1;
}
