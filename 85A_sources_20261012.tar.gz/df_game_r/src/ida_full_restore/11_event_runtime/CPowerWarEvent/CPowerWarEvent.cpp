#include "CPowerWarEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8267990
// IDA_NAME: _ZN14CPowerWarEventC2Ev
// DEMANGLED: CPowerWarEvent::CPowerWarEvent(void)
void __cdecl CPowerWarEvent::CPowerWarEvent(CPowerWarEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8BF12E8;
}

// IDA_EA: 0x82679AC
// IDA_NAME: _ZN14CPowerWarEventD2Ev
// DEMANGLED: CPowerWarEvent::~CPowerWarEvent()
void __cdecl CPowerWarEvent::~CPowerWarEvent(CPowerWarEvent *this)
{
  *(_DWORD *)this = off_8BF12E8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x82679DC
// IDA_NAME: _ZN14CPowerWarEventD0Ev
// DEMANGLED: CPowerWarEvent::~CPowerWarEvent()
void __cdecl CPowerWarEvent::~CPowerWarEvent(CPowerWarEvent *this)
{
  CPowerWarEvent::~CPowerWarEvent(this);
  operator delete(this);
}

// IDA_EA: 0x82679FA
// IDA_NAME: _ZN14CPowerWarEvent10StartEventEv
// DEMANGLED: CPowerWarEvent::StartEvent(void)
void __cdecl CPowerWarEvent::StartEvent(CPowerWarEvent *this)
{
  CEnvironment *v2; // eax
  CMonitorServerProxy *ServerProxy; // eax
  int v4; // eax
  int v5; // eax
  GameWorld *v6; // eax
  GameWorld *v7; // eax
  int v8; // edi
  int v9; // esi
  unsigned __int16 v10; // bx
  CGuildServerProxy *v11; // eax
  GameWorld *v12; // eax
  int v13; // ebx
  TimerQueue *v14; // eax
  int v15; // ebx
  TimerQueue *v16; // eax
  int v17; // eax
  TimerQueue *v18; // eax
  int v19; // ebx
  char v20; // [esp+8h] [ebp-90h]
  char v21; // [esp+8h] [ebp-90h]
  int v22; // [esp+28h] [ebp-70h]
  int v23; // [esp+2Ch] [ebp-6Ch]
  PacketBuf *v24[3]; // [esp+30h] [ebp-68h] BYREF
  char src[10]; // [esp+3Eh] [ebp-5Ah] BYREF
  int n30; // [esp+48h] [ebp-50h]
  int v27[4]; // [esp+4Ch] [ebp-4Ch] BYREF
  int v28[4]; // [esp+5Ch] [ebp-3Ch] BYREF
  int v29[4]; // [esp+6Ch] [ebp-2Ch] BYREF
  int server_groupEv; // [esp+7Ch] [ebp-1Ch]

  if ( *(_DWORD *)(G_CEnvironment() + 424) == 1 || *(_DWORD *)(G_CEnvironment() + 424) == 2 )
  {
    Packet_Monitor_Event_End::Packet_Monitor_Event_End((Packet_Monitor_Event_End *)src);
    n30 = 30;
    v2 = (CEnvironment *)G_CEnvironment();
    server_groupEv = CEnvironment::get_server_group(v2);
    ServerProxy = (CMonitorServerProxy *)CServerProxyMgr<CMonitorServerProxy>::GetServerProxy(
                                           GlobalData::s_monitor_proxy_mgr,
                                           server_groupEv);
    CMonitorServerProxy::SendTcpPacket(ServerProxy, src, 0xEu);
  }
  else if ( (*(unsigned __int8 (__cdecl **)(CPowerWarEvent *, _DWORD))(*(_DWORD *)this + 52))(this, 0) != 1 )
  {
    CEventBase::SetEventFlag(this, 1);
    v4 = G_CDataManager();
    if ( (unsigned __int8)ServerParameterScript::isDungeonOpen((ServerParameterScript *)(v4 + 104), 255) )
    {
      v5 = G_CDataManager();
      ServerParameterScript::setDungeonOpen((ServerParameterScript *)(v5 + 104), 255, 0);
      v6 = (GameWorld *)G_GameWorld();
      GameWorld::send_all_dungeon_inout_message(v6, 11007, 0);
      cMyTrace::cMyTrace((cMyTrace *)v27, "virtual void CPowerWarEvent::StartEvent()", 58, 0);
      cMyTrace::operator()((int)v27, "ULTIMATE_LOG : POWER WAR START!! ULTIMATE DUNGEON CLOSE!!", v20);
    }
    else
    {
      cMyTrace::cMyTrace((cMyTrace *)v28, "virtual void CPowerWarEvent::StartEvent()", 61, 0);
      cMyTrace::operator()((int)v28, "ULTIMATE_LOG : ALLEADY ULTIMATE DUNGEON CLOSE!!", v21);
    }
    CPowerManager::Init(GlobalData::s_power_manager);
    v7 = (GameWorld *)G_GameWorld();
    GameWorld::CleanupPowerWarVillToStart(v7);
    v22 = *(_DWORD *)(G_CDataManager() + 42668);
    v23 = *(_DWORD *)(G_CDataManager() + 42672);
    v8 = *(_DWORD *)(G_CDataManager() + 42664);
    v9 = *(_DWORD *)(G_CDataManager() + 42660);
    v10 = *(_DWORD *)(G_CDataManager() + 42548);
    v11 = (CGuildServerProxy *)CServerProxyMgr<CGuildServerProxy>::GetServerProxy(GlobalData::s_guild_proxy_mgr, 0);
    CGuildServerProxy::SendPowerWarCfg(v11, v10, v9, v8, v23, v22);
    PacketGuard::PacketGuard((PacketGuard *)v24);
    InterfacePacketBuf::put_header(v24, 0, 159);
    InterfacePacketBuf::finalize(v24, 1);
    v12 = (GameWorld *)G_GameWorld();
    GameWorld::send_all(v12, (PacketGuard *)v24);
    v13 = *(_DWORD *)(G_CDataManager() + 42584);
    v14 = (TimerQueue *)G_TimerQueue();
    TimerQueue::InsertTimer(v14, 0, 0, 123, v13, 0, 0);
    v15 = 60 * *(_DWORD *)(G_CDataManager() + 42608);
    v16 = (TimerQueue *)G_TimerQueue();
    TimerQueue::InsertTimer(v16, 2, 0, 124, v15, 0, 0);
    v17 = G_CDataManager();
    CPowerManager::SetPowerUpRemainTime(GlobalData::s_power_manager, 60 * *(_DWORD *)(v17 + 42608));
    CPowerManager::SetPowerUpTimerPeriod(GlobalData::s_power_manager, 0);
    v18 = (TimerQueue *)G_TimerQueue();
    TimerQueue::InsertTimer(v18, 2, 0, 125, 5, 0, 0);
    v19 = *(_DWORD *)(G_CEnvironment() + 432);
    cMyTrace::cMyTrace((cMyTrace *)v29, "virtual void CPowerWarEvent::StartEvent()", 112, 0);
    cMyTrace::operator()((int)v29, "Power War Event Start! server(%d)", v19);
    PacketGuard::~PacketGuard(v24);
  }
}

// IDA_EA: 0x8267DEA
// IDA_NAME: _ZN14CPowerWarEvent10StartEventE10Word_Param
// DEMANGLED: CPowerWarEvent::StartEvent(Word_Param)
void __cdecl CPowerWarEvent::StartEvent(CEventBase *a1, int a2)
{
  CEnvironment *v3; // eax
  CMonitorServerProxy *ServerProxy; // eax
  int v5; // eax
  int v6; // eax
  GameWorld *v7; // eax
  GameWorld *v8; // eax
  int v9; // edi
  int v10; // esi
  unsigned __int16 v11; // bx
  CGuildServerProxy *v12; // eax
  GameWorld *v13; // eax
  int v14; // ebx
  TimerQueue *v15; // eax
  int v16; // ebx
  TimerQueue *v17; // eax
  int v18; // eax
  TimerQueue *v19; // eax
  int v20; // ebx
  char v21; // [esp+8h] [ebp-90h]
  char v22; // [esp+8h] [ebp-90h]
  int v23; // [esp+28h] [ebp-70h]
  int v24; // [esp+2Ch] [ebp-6Ch]
  PacketBuf *v25[3]; // [esp+30h] [ebp-68h] BYREF
  char src[10]; // [esp+3Eh] [ebp-5Ah] BYREF
  int n30; // [esp+48h] [ebp-50h]
  int v28[4]; // [esp+4Ch] [ebp-4Ch] BYREF
  int v29[4]; // [esp+5Ch] [ebp-3Ch] BYREF
  int v30[4]; // [esp+6Ch] [ebp-2Ch] BYREF
  int server_groupEv; // [esp+7Ch] [ebp-1Ch]

  if ( *(_DWORD *)(G_CEnvironment() + 424) == 1 || *(_DWORD *)(G_CEnvironment() + 424) == 2 )
  {
    Packet_Monitor_Event_End::Packet_Monitor_Event_End((Packet_Monitor_Event_End *)src);
    n30 = 30;
    v3 = (CEnvironment *)G_CEnvironment();
    server_groupEv = CEnvironment::get_server_group(v3);
    ServerProxy = (CMonitorServerProxy *)CServerProxyMgr<CMonitorServerProxy>::GetServerProxy(
                                           GlobalData::s_monitor_proxy_mgr,
                                           server_groupEv);
    CMonitorServerProxy::SendTcpPacket(ServerProxy, src, 0xEu);
  }
  else if ( (*(unsigned __int8 (__cdecl **)(CEventBase *, _DWORD))(*(_DWORD *)a1 + 52))(a1, 0) != 1 )
  {
    CEventBase::SetEventFlag(a1, 1);
    *(_DWORD *)((char *)a1 + 10) = a2;
    v5 = G_CDataManager();
    if ( (unsigned __int8)ServerParameterScript::isDungeonOpen((ServerParameterScript *)(v5 + 104), 255) )
    {
      v6 = G_CDataManager();
      ServerParameterScript::setDungeonOpen((ServerParameterScript *)(v6 + 104), 255, 0);
      v7 = (GameWorld *)G_GameWorld();
      GameWorld::send_all_dungeon_inout_message(v7, 11007, 0);
      cMyTrace::cMyTrace((cMyTrace *)v28, "virtual void CPowerWarEvent::StartEvent(Word_Param)", 143, 0);
      cMyTrace::operator()((int)v28, "ULTIMATE_LOG : POWER WAR START!! ULTIMATE DUNGEON CLOSE!!", v21);
    }
    else
    {
      cMyTrace::cMyTrace((cMyTrace *)v29, "virtual void CPowerWarEvent::StartEvent(Word_Param)", 146, 0);
      cMyTrace::operator()((int)v29, "ULTIMATE_LOG : ALLEADY ULTIMATE DUNGEON CLOSE!!", v22);
    }
    CPowerManager::Init(GlobalData::s_power_manager);
    v8 = (GameWorld *)G_GameWorld();
    GameWorld::CleanupPowerWarVillToStart(v8);
    v23 = *(_DWORD *)(G_CDataManager() + 42668);
    v24 = *(_DWORD *)(G_CDataManager() + 42672);
    v9 = *(_DWORD *)(G_CDataManager() + 42664);
    v10 = *(_DWORD *)(G_CDataManager() + 42660);
    v11 = *(_DWORD *)(G_CDataManager() + 42548);
    v12 = (CGuildServerProxy *)CServerProxyMgr<CGuildServerProxy>::GetServerProxy(GlobalData::s_guild_proxy_mgr, 0);
    CGuildServerProxy::SendPowerWarCfg(v12, v11, v10, v9, v24, v23);
    PacketGuard::PacketGuard((PacketGuard *)v25);
    InterfacePacketBuf::put_header(v25, 0, 159);
    InterfacePacketBuf::finalize(v25, 1);
    v13 = (GameWorld *)G_GameWorld();
    GameWorld::send_all(v13, (PacketGuard *)v25);
    v14 = *(_DWORD *)(G_CDataManager() + 42584);
    v15 = (TimerQueue *)G_TimerQueue();
    TimerQueue::InsertTimer(v15, 0, 0, 123, v14, 0, 0);
    v16 = 60 * *(_DWORD *)(G_CDataManager() + 42608);
    v17 = (TimerQueue *)G_TimerQueue();
    TimerQueue::InsertTimer(v17, 2, 0, 124, v16, 0, 0);
    v18 = G_CDataManager();
    CPowerManager::SetPowerUpRemainTime(GlobalData::s_power_manager, 60 * *(_DWORD *)(v18 + 42608));
    CPowerManager::SetPowerUpTimerPeriod(GlobalData::s_power_manager, 0);
    v19 = (TimerQueue *)G_TimerQueue();
    TimerQueue::InsertTimer(v19, 2, 0, 125, 5, 0, 0);
    v20 = *(_DWORD *)(G_CEnvironment() + 432);
    cMyTrace::cMyTrace((cMyTrace *)v30, "virtual void CPowerWarEvent::StartEvent(Word_Param)", 198, 0);
    cMyTrace::operator()((int)v30, "Power War Event Start! server(%d)", v20);
    PacketGuard::~PacketGuard(v25);
  }
}

// IDA_EA: 0x82681E2
// IDA_NAME: _ZN14CPowerWarEvent8EndEventEv
// DEMANGLED: CPowerWarEvent::EndEvent(void)
void __cdecl CPowerWarEvent::EndEvent(CPowerWarEvent *this)
{
  bool v1; // al
  int v2; // eax
  int v3; // eax
  GameWorld *v4; // eax
  GameWorld *v5; // eax
  GameWorld *v6; // eax
  GameWorld *v7; // eax
  pvp_assault::CAssaultMgr *InstanceAssaultMgr; // eax
  int v9; // [esp+4h] [ebp-64h]
  char v10; // [esp+8h] [ebp-60h]
  char v11; // [esp+8h] [ebp-60h]
  char v12; // [esp+8h] [ebp-60h]
  char v13; // [esp+8h] [ebp-60h]
  PacketBuf *v14[3]; // [esp+14h] [ebp-54h] BYREF
  int v15[4]; // [esp+20h] [ebp-48h] BYREF
  int v16[4]; // [esp+30h] [ebp-38h] BYREF
  int v17[4]; // [esp+40h] [ebp-28h] BYREF
  int v18[6]; // [esp+50h] [ebp-18h] BYREF

  v1 = *(_DWORD *)(G_CEnvironment() + 424) == 1 || *(_DWORD *)(G_CEnvironment() + 424) == 2;
  if ( !v1 && (*(unsigned __int8 (__cdecl **)(CPowerWarEvent *, _DWORD))(*(_DWORD *)this + 52))(this, 0) )
  {
    CEventBase::SetEventFlag(this, 0);
    *((_WORD *)this + 5) = 0;
    *((_WORD *)this + 6) = 0;
    v2 = G_CDataManager();
    if ( (unsigned __int8)ServerParameterScript::isDungeonOpen((ServerParameterScript *)(v2 + 104), 255) == 1 )
    {
      cMyTrace::cMyTrace((cMyTrace *)v17, "virtual void CPowerWarEvent::EndEvent()", 228, 0);
      cMyTrace::operator()((int)v17, "ULTIMATE_LOG : ALLEADY ULTIMATE DUNGEON OPEN!!", v12);
    }
    else if ( (unsigned __int8)Timer_DungeonInoutOpenTime::checkDungeonInoutTime(
                                 (Timer_DungeonInoutOpenTime *)0x2AFF,
                                 v9) )
    {
      v3 = G_CDataManager();
      ServerParameterScript::setDungeonOpen((ServerParameterScript *)(v3 + 104), 255, 1);
      v4 = (GameWorld *)G_GameWorld();
      GameWorld::send_all_dungeon_inout_message(v4, 11007, 1);
      cMyTrace::cMyTrace((cMyTrace *)v15, "virtual void CPowerWarEvent::EndEvent()", 222, 0);
      cMyTrace::operator()((int)v15, "ULTIMATE_LOG : POWER WAR EVENT END!! ULTIMATE DUNGEON OPEN!!", v10);
    }
    else
    {
      cMyTrace::cMyTrace((cMyTrace *)v16, "virtual void CPowerWarEvent::EndEvent()", 225, 0);
      cMyTrace::operator()((int)v16, "ULTIMATE_LOG : NOT UTIMATE DUNGEON OPEN TIME!!", v11);
    }
    PacketGuard::PacketGuard((PacketGuard *)v14);
    InterfacePacketBuf::put_header(v14, 0, 160);
    v5 = (GameWorld *)G_GameWorld();
    GameWorld::OnEndPowerWar(v5, (PacketGuard *)v14);
    v6 = (GameWorld *)G_GameWorld();
    GameWorld::CancelPowerUp(v6);
    InterfacePacketBuf::finalize(v14, 1);
    v7 = (GameWorld *)G_GameWorld();
    GameWorld::send_all(v7, (PacketGuard *)v14);
    CPowerWarEvent::CleanupPowerWarServerMessage(this);
    InstanceAssaultMgr = (pvp_assault::CAssaultMgr *)pvp_assault::GetInstanceAssaultMgr();
    pvp_assault::CAssaultMgr::FrocedCloseAssaults(InstanceAssaultMgr);
    CEventManager::TriggerEventStart(GlobalData::s_event_manager, 53, 0);
    cMyTrace::cMyTrace((cMyTrace *)v18, "virtual void CPowerWarEvent::EndEvent()", 272, 0);
    cMyTrace::operator()((int)v18, "Power War Event End", v13);
    PacketGuard::~PacketGuard(v14);
  }
}

// IDA_EA: 0x8268492
// IDA_NAME: _ZN14CPowerWarEvent28CleanupPowerWarServerMessageEv
// DEMANGLED: CPowerWarEvent::CleanupPowerWarServerMessage(void)
void CPowerWarEvent::CleanupPowerWarServerMessage()
{
  CGameManager *v0; // eax
  GameWorld *v1; // eax
  PacketBuf *v2[3]; // [esp+14h] [ebp-24h] BYREF
  CSharedServerMessageManager *SharedServerMessageManager; // [esp+20h] [ebp-18h]
  char *s; // [esp+24h] [ebp-14h]
  int v5; // [esp+28h] [ebp-10h]
  int n2; // [esp+2Ch] [ebp-Ch]

  v0 = (CGameManager *)G_CGameManager();
  SharedServerMessageManager = (CSharedServerMessageManager *)CGameManager::GetSharedServerMessageManager(v0);
  if ( SharedServerMessageManager )
  {
    CSharedServerMessageManager::DeleteSpecificMessage(SharedServerMessageManager, 1);
    CSharedServerMessageManager::DeleteSpecificMessage(SharedServerMessageManager, 2);
    CSharedServerMessageManager::DeleteSpecificMessage(SharedServerMessageManager, 3);
    PacketGuard::PacketGuard((PacketGuard *)v2);
    InterfacePacketBuf::put_header(v2, 0, 192);
    InterfacePacketBuf::put_byte(v2, 2);
    InterfacePacketBuf::put_byte(v2, 3);
    s = "null string";
    v5 = strlen("null string");
    for ( n2 = 0; n2 <= 2; ++n2 )
    {
      InterfacePacketBuf::put_byte(v2, n2 + 1);
      InterfacePacketBuf::put_int(v2, v5);
      InterfacePacketBuf::put_str(v2, s, v5);
      InterfacePacketBuf::put_int(v2, v5);
      InterfacePacketBuf::put_str(v2, s, v5);
    }
    InterfacePacketBuf::finalize(v2, 1);
    v1 = (GameWorld *)G_GameWorld();
    GameWorld::send_all_with_state(v1, (PacketGuard *)v2, 3);
    PacketGuard::~PacketGuard(v2);
  }
}
