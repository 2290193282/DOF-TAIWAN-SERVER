#ifndef __IDA91_CPOWERWAREVENT_H__
#define __IDA91_CPOWERWAREVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CPowerWarEvent
// Source unit: CPowerWarEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4161

/* 4161 */
struct CPowerWarEvent;

// Exported member functions:
// 0x8267990	CPowerWarEvent::CPowerWarEvent(void)
// 0x82679AC	CPowerWarEvent::~CPowerWarEvent()
// 0x82679DC	CPowerWarEvent::~CPowerWarEvent()
// 0x82679FA	CPowerWarEvent::StartEvent(void)
// 0x8267DEA	CPowerWarEvent::StartEvent(Word_Param)
// 0x82681E2	CPowerWarEvent::EndEvent(void)
// 0x8268492	CPowerWarEvent::CleanupPowerWarServerMessage(void)

// Function declaration index:
// DECL 0x8267990 CPowerWarEvent::CPowerWarEvent
// DECL 0x82679AC CPowerWarEvent::~CPowerWarEvent
// DECL 0x82679DC CPowerWarEvent::~CPowerWarEvent
// DECL 0x82679FA CPowerWarEvent::StartEvent
// DECL 0x8267DEA CPowerWarEvent::StartEvent
// DECL 0x82681E2 CPowerWarEvent::EndEvent
// DECL 0x8268492 CPowerWarEvent::CleanupPowerWarServerMessage

#endif  // __IDA91_CPOWERWAREVENT_H__
