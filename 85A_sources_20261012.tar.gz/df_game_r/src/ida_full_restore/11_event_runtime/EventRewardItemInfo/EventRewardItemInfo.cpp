#include "EventRewardItemInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x826FAA0
// IDA_NAME: _ZN19EventRewardItemInfoD2Ev
// DEMANGLED: EventRewardItemInfo::~EventRewardItemInfo()
void __cdecl EventRewardItemInfo::~EventRewardItemInfo(EventRewardItemInfo *this)
{
  std::vector<int>::~vector((_DWORD *)this + 3);
}

// IDA_EA: 0x826FAB6
// IDA_NAME: _ZN19EventRewardItemInfoaSERKS_
// DEMANGLED: EventRewardItemInfo::operator=(EventRewardItemInfo const&)
int __cdecl EventRewardItemInfo::operator=(int a1, int a2)
{
  *(_DWORD *)a1 = *(_DWORD *)a2;
  *(_DWORD *)(a1 + 4) = *(_DWORD *)(a2 + 4);
  *(_WORD *)(a1 + 8) = *(_WORD *)(a2 + 8);
  std::vector<int>::operator=((int *)(a1 + 12), (int *)(a2 + 12));
  return a1;
}

// IDA_EA: 0x891548A
// IDA_NAME: _ZN19EventRewardItemInfoC2Ev
// DEMANGLED: EventRewardItemInfo::EventRewardItemInfo(void)
void __cdecl EventRewardItemInfo::EventRewardItemInfo(EventRewardItemInfo *this)
{
  std::vector<int>::vector((int)this + 12);
  *(_DWORD *)this = 0;
  *((_DWORD *)this + 1) = 0;
  *((_WORD *)this + 4) = 0;
}

// IDA_EA: 0x89154BC
// IDA_NAME: _ZN19EventRewardItemInfo5clearEv
// DEMANGLED: EventRewardItemInfo::clear(void)
int __cdecl EventRewardItemInfo::clear(EventRewardItemInfo *this)
{
  *(_DWORD *)this = 0;
  *((_DWORD *)this + 1) = 0;
  *((_WORD *)this + 4) = 0;
  return std::vector<int>::clear((_DWORD *)this + 3);
}

// IDA_EA: 0x89333B0
// IDA_NAME: _ZN19EventRewardItemInfoC2ERKS_
// DEMANGLED: EventRewardItemInfo::EventRewardItemInfo(EventRewardItemInfo const&)
void __cdecl EventRewardItemInfo::EventRewardItemInfo(EventRewardItemInfo *this, const EventRewardItemInfo *a2)
{
  *(_DWORD *)this = *(_DWORD *)a2;
  *((_DWORD *)this + 1) = *((_DWORD *)a2 + 1);
  *((_WORD *)this + 4) = *((_WORD *)a2 + 4);
  std::vector<int>::vector((int *)this + 3, (_DWORD *)a2 + 3);
}
