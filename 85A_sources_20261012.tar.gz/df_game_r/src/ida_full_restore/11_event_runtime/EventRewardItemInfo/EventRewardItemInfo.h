#ifndef __IDA91_EVENTREWARDITEMINFO_H__
#define __IDA91_EVENTREWARDITEMINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: EventRewardItemInfo
// Source unit: EventRewardItemInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 2140

/* 2140 */
struct EventRewardItemInfo;

// Exported member functions:
// 0x826FAA0	EventRewardItemInfo::~EventRewardItemInfo()
// 0x826FAB6	EventRewardItemInfo::operator=(EventRewardItemInfo const&)
// 0x891548A	EventRewardItemInfo::EventRewardItemInfo(void)
// 0x89154BC	EventRewardItemInfo::clear(void)
// 0x89333B0	EventRewardItemInfo::EventRewardItemInfo(EventRewardItemInfo const&)

// Function declaration index:
// DECL 0x826FAA0 EventRewardItemInfo::~EventRewardItemInfo
// DECL 0x826FAB6 EventRewardItemInfo::operator=
// DECL 0x891548A EventRewardItemInfo::EventRewardItemInfo
// DECL 0x89154BC EventRewardItemInfo::clear
// DECL 0x89333B0 EventRewardItemInfo::EventRewardItemInfo

#endif  // __IDA91_EVENTREWARDITEMINFO_H__
