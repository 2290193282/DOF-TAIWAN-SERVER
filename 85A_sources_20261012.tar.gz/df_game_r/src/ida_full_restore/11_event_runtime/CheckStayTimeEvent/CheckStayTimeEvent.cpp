#include "CheckStayTimeEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x815B362
// IDA_NAME: _ZN18CheckStayTimeEvent8dispatchEiiP6Stream
// DEMANGLED: CheckStayTimeEvent::dispatch(int,int,Stream *)
int __cdecl CheckStayTimeEvent::dispatch(CheckStayTimeEvent *this, int a2, char src, Stream *a4)
{
  _DWORD *exception; // eax
  _DWORD *v5; // eax
  const char *v6; // eax
  _DWORD *v7; // eax
  const char *v8; // eax
  _DWORD *v9; // eax
  _DWORD *v10; // eax
  _DWORD *v11; // eax
  const char *v12; // eax
  _DWORD *v13; // eax
  int v15; // [esp+20h] [ebp-18h] BYREF
  unsigned int *v16; // [esp+24h] [ebp-14h]
  MySQL *DBHandle; // [esp+28h] [ebp-10h]

  v16 = (unsigned int *)Stream::GetOutBuffer<Taiwan::SigStayTimeEvent>(a4);
  if ( !v16 )
  {
    exception = _cxa_allocate_exception(4u);
    *exception = "context null";
    _cxa_throw(exception, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  DBHandle = (MySQL *)DBMgr::GetDBHandle(GlobalData::s_db_mgr, 9, 0);
  if ( !DBHandle )
  {
    v5 = _cxa_allocate_exception(4u);
    *v5 = "handle null";
    _cxa_throw(v5, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  v6 = (const char *)NumberToString(*v16, 0);
  MySQL::set_query(DBHandle, "seLect reward_flag from event_stay_time_charac where m_id=%s", v6);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
  {
    v7 = _cxa_allocate_exception(4u);
    *v7 = "select_exec";
    _cxa_throw(v7, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  if ( MySQL::get_n_rows(DBHandle) )
  {
    if ( (unsigned __int8)MySQL::fetch(DBHandle) != 1 )
    {
      v10 = _cxa_allocate_exception(4u);
      *v10 = "fetch";
      _cxa_throw(v10, (struct type_info *)&`typeinfo for'char const*, 0);
    }
    v15 = 0;
    if ( (unsigned __int8)MySQL::get_int(DBHandle, 0, &v15) != 1 )
    {
      v11 = _cxa_allocate_exception(4u);
      *v11 = "get_int";
      _cxa_throw(v11, (struct type_info *)&`typeinfo for'char const*, 0);
    }
    if ( !v15 )
    {
      v12 = (const char *)NumberToString(*v16, 0);
      MySQL::set_query(
        DBHandle,
        "upDate event_stay_time_charac set reward_flag=1, reward_count=reward_count+1, mod_date=now() where m_id = %s",
        v12);
      if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
      {
        v13 = _cxa_allocate_exception(4u);
        *v13 = "update_exec";
        _cxa_throw(v13, (struct type_info *)&`typeinfo for'char const*, 0);
      }
      CheckStayTimeEvent::sendStayTimeData(this, src);
    }
  }
  else
  {
    v8 = (const char *)NumberToString(*v16, 0);
    MySQL::set_query(DBHandle, "inSert into event_stay_time_charac values('%s', 1, 1, now())", v8);
    if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
    {
      v9 = _cxa_allocate_exception(4u);
      *v9 = "insert_exec";
      _cxa_throw(v9, (struct type_info *)&`typeinfo for'char const*, 0);
    }
    CheckStayTimeEvent::sendStayTimeData(this, src);
  }
  return 1;
}

// IDA_EA: 0x815B6AC
// IDA_NAME: _ZN18CheckStayTimeEvent16sendStayTimeDataEi
// DEMANGLED: CheckStayTimeEvent::sendStayTimeData(int)
void __cdecl CheckStayTimeEvent::sendStayTimeData(CheckStayTimeEvent *this, char src)
{
  Stream *v2; // eax
  int v3; // eax
  int v4[2]; // [esp+14h] [ebp-14h] BYREF

  v2 = (Stream *)StreamPool::Acquire(GlobalData::s_stream_pool, "localtaiwan/Dispatcher/Taiwan_DbThread.cpp", 402);
  CStreamGuard::CStreamGuard((CStreamGuard *)v4, v2, 1);
  Taiwan::internal_stream((int)v4, 5, src);
  v3 = CStreamGuard::operator->((int)v4);
  if ( CStreamGuard::GetInBuffer<Taiwan::SigStayTimeEvent>(v3) )
    MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 1, (CStreamGuard *)v4);
  CStreamGuard::~CStreamGuard((CStreamGuard *)v4);
}

// IDA_EA: 0x815E14E
// IDA_NAME: _ZN18CheckStayTimeEventC2Ev
// DEMANGLED: CheckStayTimeEvent::CheckStayTimeEvent(void)
void __cdecl CheckStayTimeEvent::CheckStayTimeEvent(CheckStayTimeEvent *this)
{
  TaiwanInterfaceDBDispatcher::TaiwanInterfaceDBDispatcher(this, 5);
  *(_DWORD *)this = off_8B79418;
}

// IDA_EA: 0x815E172
// IDA_NAME: _ZN18CheckStayTimeEventD2Ev
// DEMANGLED: CheckStayTimeEvent::~CheckStayTimeEvent()
void __cdecl CheckStayTimeEvent::~CheckStayTimeEvent(CheckStayTimeEvent *this)
{
  *(_DWORD *)this = off_8B79418;
  TaiwanInterfaceDBDispatcher::~TaiwanInterfaceDBDispatcher(this);
}

// IDA_EA: 0x815E1A2
// IDA_NAME: _ZN18CheckStayTimeEventD0Ev
// DEMANGLED: CheckStayTimeEvent::~CheckStayTimeEvent()
void __cdecl CheckStayTimeEvent::~CheckStayTimeEvent(CheckStayTimeEvent *this)
{
  CheckStayTimeEvent::~CheckStayTimeEvent(this);
  operator delete(this);
}
