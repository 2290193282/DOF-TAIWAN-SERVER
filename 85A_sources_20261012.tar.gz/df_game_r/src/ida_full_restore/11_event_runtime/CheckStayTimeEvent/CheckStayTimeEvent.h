#ifndef __IDA91_CHECKSTAYTIMEEVENT_H__
#define __IDA91_CHECKSTAYTIMEEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CheckStayTimeEvent
// Source unit: CheckStayTimeEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "network/Stream.h"
// Local type ordinals: 1319

/* 1319 */
struct CheckStayTimeEvent;

// Exported member functions:
// 0x815B362	CheckStayTimeEvent::dispatch(int,int,Stream *)
// 0x815B6AC	CheckStayTimeEvent::sendStayTimeData(int)
// 0x815E14E	CheckStayTimeEvent::CheckStayTimeEvent(void)
// 0x815E172	CheckStayTimeEvent::~CheckStayTimeEvent()
// 0x815E1A2	CheckStayTimeEvent::~CheckStayTimeEvent()

// Function declaration index:
// DECL 0x815B362 CheckStayTimeEvent::dispatch
// DECL 0x815B6AC CheckStayTimeEvent::sendStayTimeData
// DECL 0x815E14E CheckStayTimeEvent::CheckStayTimeEvent
// DECL 0x815E172 CheckStayTimeEvent::~CheckStayTimeEvent
// DECL 0x815E1A2 CheckStayTimeEvent::~CheckStayTimeEvent

#endif  // __IDA91_CHECKSTAYTIMEEVENT_H__
