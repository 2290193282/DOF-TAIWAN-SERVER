#ifndef __IDA91_DB_CHECKSECUREWARD_H__
#define __IDA91_DB_CHECKSECUREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_CheckSecuReward
// Source unit: DB_CheckSecuReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2685

/* 2685 */
struct DB_CheckSecuReward;

// Exported member functions:
// 0x84441E6	DB_CheckSecuReward::dispatch(int,int,Stream *)
// 0x8444408	DB_CheckSecuReward::makeRequest(int,unsigned int,int)
// 0x844F9B6	DB_CheckSecuReward::DB_CheckSecuReward(void)
// 0x845B6F8	DB_CheckSecuReward::~DB_CheckSecuReward()
// 0x845B728	DB_CheckSecuReward::~DB_CheckSecuReward()

// Function declaration index:
// DECL 0x84441E6 DB_CheckSecuReward::dispatch
// DECL 0x8444408 DB_CheckSecuReward::makeRequest
// DECL 0x844F9B6 DB_CheckSecuReward::DB_CheckSecuReward
// DECL 0x845B6F8 DB_CheckSecuReward::~DB_CheckSecuReward
// DECL 0x845B728 DB_CheckSecuReward::~DB_CheckSecuReward

#endif  // __IDA91_DB_CHECKSECUREWARD_H__
