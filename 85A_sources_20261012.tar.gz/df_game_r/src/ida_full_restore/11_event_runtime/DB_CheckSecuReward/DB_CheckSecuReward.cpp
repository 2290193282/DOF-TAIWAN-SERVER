#include "DB_CheckSecuReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84441E6
// IDA_NAME: _ZN18DB_CheckSecuReward8dispatchEiiP6Stream
// DEMANGLED: DB_CheckSecuReward::dispatch(int,int,Stream *)
int __cdecl DB_CheckSecuReward::dispatch(DB_CheckSecuReward *this, char src, char src_1, Stream *a4)
{
  const char *v4; // eax
  Stream *v7; // eax
  Stream **v8; // eax
  Stream **v9; // eax
  int v10; // eax
  _BYTE v11[8]; // [esp+10h] [ebp-28h] BYREF
  time_t timer; // [esp+18h] [ebp-20h] BYREF
  unsigned int timer_1; // [esp+1Ch] [ebp-1Ch] BYREF
  unsigned int *Out; // [esp+20h] [ebp-18h]
  MySQL *DBHandle; // [esp+24h] [ebp-14h]
  int n75599; // [esp+28h] [ebp-10h]
  _DWORD *v17; // [esp+2Ch] [ebp-Ch]

  Out = (unsigned int *)Stream::GetOutBuffer<SIG_CHECK_USER_SECU_REWARD>(a4);
  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  timer_1 = 0;
  v4 = (const char *)NumberToString(*Out, 0);
  MySQL::set_query(DBHandle, "seLect unix_timestamp(last_check_time) from member_security_grade where m_id=%s", v4);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1
    || !MySQL::get_n_rows(DBHandle)
    || (unsigned __int8)MySQL::fetch(DBHandle) != 1 )
  {
    return 1;
  }
  MySQL::get_uint(DBHandle, 0, &timer_1);
  time(&timer);
  n75599 = timer % 86400;
  timer = timer - timer % 86400 - 10800;
  if ( n75599 > 75599 )
    timer += 86400;
  if ( (int)timer_1 < timer )
  {
    v7 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 43813);
    CStreamGuard::CStreamGuard((CStreamGuard *)v11, v7, 1);
    v8 = (Stream **)CStreamGuard::operator*((int)v11);
    CStreamGuard::operator<<(v8, src);
    v9 = (Stream **)CStreamGuard::operator*((int)v11);
    CStreamGuard::operator<<(v9, src_1);
    v10 = CStreamGuard::operator->((int)v11);
    v17 = (_DWORD *)CStreamGuard::GetInBuffer<SIG_SEND_USER_REWARD>(v10);
    *v17 = Out[1];
    MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 1, (CStreamGuard *)v11);
    CStreamGuard::~CStreamGuard((CStreamGuard *)v11);
  }
  return 1;
}

// IDA_EA: 0x8444408
// IDA_NAME: _ZN18DB_CheckSecuReward11makeRequestEiji
// DEMANGLED: DB_CheckSecuReward::makeRequest(int,unsigned int,int)
void __cdecl DB_CheckSecuReward::makeRequest(DB_CheckSecuReward *this, int a2, unsigned int a3)
{
  Stream *v3; // eax
  Stream **v4; // eax
  Stream **v5; // eax
  int v6; // eax
  _BYTE v7[8]; // [esp+14h] [ebp-14h] BYREF
  _DWORD *v8; // [esp+1Ch] [ebp-Ch]

  v3 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 43828);
  CStreamGuard::CStreamGuard((CStreamGuard *)v7, v3, 1);
  v4 = (Stream **)CStreamGuard::operator*((int)v7);
  CStreamGuard::operator<<(v4, 171);
  v5 = (Stream **)CStreamGuard::operator*((int)v7);
  CStreamGuard::operator<<(v5, (char)this);
  v6 = CStreamGuard::operator->((int)v7);
  v8 = (_DWORD *)CStreamGuard::GetInBuffer<SIG_CHECK_USER_SECU_REWARD>(v6);
  *v8 = a2;
  v8[1] = a3;
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v7);
  CStreamGuard::~CStreamGuard((CStreamGuard *)v7);
}

// IDA_EA: 0x844F9B6
// IDA_NAME: _ZN18DB_CheckSecuRewardC2Ev
// DEMANGLED: DB_CheckSecuReward::DB_CheckSecuReward(void)
void __cdecl DB_CheckSecuReward::DB_CheckSecuReward(DB_CheckSecuReward *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5E3B8;
}

// IDA_EA: 0x845B6F8
// IDA_NAME: _ZN18DB_CheckSecuRewardD2Ev
// DEMANGLED: DB_CheckSecuReward::~DB_CheckSecuReward()
void __cdecl DB_CheckSecuReward::~DB_CheckSecuReward(DB_CheckSecuReward *this)
{
  *(_DWORD *)this = &off_8C5E3B8;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845B728
// IDA_NAME: _ZN18DB_CheckSecuRewardD0Ev
// DEMANGLED: DB_CheckSecuReward::~DB_CheckSecuReward()
void __cdecl DB_CheckSecuReward::~DB_CheckSecuReward(DB_CheckSecuReward *this)
{
  DB_CheckSecuReward::~DB_CheckSecuReward(this);
  operator delete(this);
}
