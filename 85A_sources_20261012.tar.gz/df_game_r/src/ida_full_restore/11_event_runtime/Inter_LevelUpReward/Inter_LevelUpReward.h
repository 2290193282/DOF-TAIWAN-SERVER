#ifndef __IDA91_INTER_LEVELUPREWARD_H__
#define __IDA91_INTER_LEVELUPREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_LevelUpReward
// Source unit: Inter_LevelUpReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 2924

/* 2924 */
struct Inter_LevelUpReward;

// Exported member functions:
// 0x84E4F56	Inter_LevelUpReward::dispatch_sig(CUser *,char *,int)
// 0x84EEBC8	Inter_LevelUpReward::Inter_LevelUpReward(void)
// 0x84F6102	Inter_LevelUpReward::~Inter_LevelUpReward()
// 0x84F6132	Inter_LevelUpReward::~Inter_LevelUpReward()

// Function declaration index:
// DECL 0x84E4F56 Inter_LevelUpReward::dispatch_sig
// DECL 0x84EEBC8 Inter_LevelUpReward::Inter_LevelUpReward
// DECL 0x84F6102 Inter_LevelUpReward::~Inter_LevelUpReward
// DECL 0x84F6132 Inter_LevelUpReward::~Inter_LevelUpReward

#endif  // __IDA91_INTER_LEVELUPREWARD_H__
