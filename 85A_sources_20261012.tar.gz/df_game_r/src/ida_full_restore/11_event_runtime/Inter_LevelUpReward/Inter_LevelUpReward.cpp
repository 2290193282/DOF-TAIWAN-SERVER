#include "Inter_LevelUpReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84E4F56
// IDA_NAME: _ZN19Inter_LevelUpReward12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_LevelUpReward::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_LevelUpReward::dispatch_sig(Inter_LevelUpReward *this, CUser *a2, char *src)
{
  _BYTE dest_[4]; // [esp+18h] [ebp-10h] BYREF
  _BYTE dest[12]; // [esp+1Ch] [ebp-Ch] BYREF

  if ( !CUser::get_state(a2) )
    return 25254;
  memcpy(dest, src, 4u);
  memcpy(dest_, src + 4, sizeof(dest_));
  return 0;
}

// IDA_EA: 0x84EEBC8
// IDA_NAME: _ZN19Inter_LevelUpRewardC2Ev
// DEMANGLED: Inter_LevelUpReward::Inter_LevelUpReward(void)
void __cdecl Inter_LevelUpReward::Inter_LevelUpReward(Inter_LevelUpReward *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8E660;
}

// IDA_EA: 0x84F6102
// IDA_NAME: _ZN19Inter_LevelUpRewardD2Ev
// DEMANGLED: Inter_LevelUpReward::~Inter_LevelUpReward()
void __cdecl Inter_LevelUpReward::~Inter_LevelUpReward(Inter_LevelUpReward *this)
{
  *(_DWORD *)this = &off_8C8E660;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84F6132
// IDA_NAME: _ZN19Inter_LevelUpRewardD0Ev
// DEMANGLED: Inter_LevelUpReward::~Inter_LevelUpReward()
void __cdecl Inter_LevelUpReward::~Inter_LevelUpReward(Inter_LevelUpReward *this)
{
  Inter_LevelUpReward::~Inter_LevelUpReward(this);
  operator delete(this);
}
