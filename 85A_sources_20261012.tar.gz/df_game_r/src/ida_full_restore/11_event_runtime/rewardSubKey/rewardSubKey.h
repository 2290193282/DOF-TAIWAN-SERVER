#ifndef __IDA91_REWARDSUBKEY_H__
#define __IDA91_REWARDSUBKEY_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: rewardSubKey
// Source unit: rewardSubKey
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1149

/* 1149 */
struct rewardSubKey;

// Exported member functions:
// 0x80F1190	rewardSubKey::rewardSubKey(void)
// 0x80F11A2	rewardSubKey::operator<(rewardSubKey const&)const
// 0x80F11DE	rewardSubKey::clear(void)

// Function declaration index:
// DECL 0x80F1190 rewardSubKey::rewardSubKey
// DECL 0x80F11A2 rewardSubKey::operator<
// DECL 0x80F11DE rewardSubKey::clear

#endif  // __IDA91_REWARDSUBKEY_H__
