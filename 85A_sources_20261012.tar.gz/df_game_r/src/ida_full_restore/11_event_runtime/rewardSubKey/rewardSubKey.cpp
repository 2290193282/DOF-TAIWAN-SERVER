#include "rewardSubKey.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x80F1190
// IDA_NAME: _ZN12rewardSubKeyC2Ev
// DEMANGLED: rewardSubKey::rewardSubKey(void)
void __cdecl rewardSubKey::rewardSubKey(rewardSubKey *this)
{
  *(_BYTE *)this = 0;
  *((_BYTE *)this + 1) = 0;
}

// IDA_EA: 0x80F11A2
// IDA_NAME: _ZNK12rewardSubKeyltERKS_
// DEMANGLED: rewardSubKey::operator<(rewardSubKey const&)const
bool __cdecl rewardSubKey::operator<(char *a1, char *a2)
{
  char v2; // dl
  char v3; // al

  if ( *a1 == *a2 )
  {
    v2 = a1[1];
    v3 = a2[1];
  }
  else
  {
    v2 = *a1;
    v3 = *a2;
  }
  return v2 < v3;
}

// IDA_EA: 0x80F11DE
// IDA_NAME: _ZN12rewardSubKey5clearEv
// DEMANGLED: rewardSubKey::clear(void)
rewardSubKey *__cdecl rewardSubKey::clear(rewardSubKey *this)
{
  rewardSubKey *this_1; // eax

  *(_BYTE *)this = 0;
  this_1 = this;
  *((_BYTE *)this + 1) = 0;
  return this_1;
}
