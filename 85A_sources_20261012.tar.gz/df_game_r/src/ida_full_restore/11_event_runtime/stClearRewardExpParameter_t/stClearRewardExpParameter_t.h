#ifndef __IDA91_STCLEARREWARDEXPPARAMETER_T_H__
#define __IDA91_STCLEARREWARDEXPPARAMETER_T_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stClearRewardExpParameter_t
// Source unit: stClearRewardExpParameter_t
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1296

/* 1296 */
struct stClearRewardExpParameter_t;

// Exported member functions:
// 0x814A8B8	stClearRewardExpParameter_t::stClearRewardExpParameter_t(void)

// Function declaration index:
// DECL 0x814A8B8 stClearRewardExpParameter_t::stClearRewardExpParameter_t

#endif  // __IDA91_STCLEARREWARDEXPPARAMETER_T_H__
