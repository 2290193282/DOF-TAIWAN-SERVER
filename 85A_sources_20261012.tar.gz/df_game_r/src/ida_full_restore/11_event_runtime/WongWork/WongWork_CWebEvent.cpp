#include "WongWork_CWebEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x86C11D0
// IDA_NAME: _ZN8WongWork9CWebEvent15RecvInfoFromWebEjjjjjj
// DEMANGLED: WongWork::CWebEvent::RecvInfoFromWeb(unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int)
int __cdecl WongWork::CWebEvent::RecvInfoFromWeb(
        WongWork::CWebEvent *this,
        unsigned int CurCharacNoEv,
        unsigned int n0x65AE,
        unsigned int a4,
        unsigned int n0x30D47,
        unsigned int a6)
{
  bool v7; // [esp+1Ch] [ebp-Ch]

  if ( n0x65AE == 999 )
    return 0;
  else
    return WongWork::CWebEvent::ReqSaveEventItem(this, CurCharacNoEv, n0x65AE, a4, n0x30D47, a6, 0, v7);
}

// IDA_EA: 0x86C121E
// IDA_NAME: _ZN8WongWork9CWebEvent14RecvInfoFromDBEP5CUserjjjj
// DEMANGLED: WongWork::CWebEvent::RecvInfoFromDB(CUser *,unsigned int,unsigned int,unsigned int,unsigned int)
int __usercall WongWork::CWebEvent::RecvInfoFromDB@<eax>(
        int a1@<ebx>,
        CUser **this,
        CUser *n2,
        char *a4,
        WongWork::CWebEvent *n200006,
        char src)
{
  CInventory *CurCharacInvenREv; // eax
  char *v7; // ebx
  CInventory *CurCharacInvenWEv; // eax
  CInventory *CurCharacInvenREv_1; // eax
  int EventCoin; // eax
  Stream *v11; // eax
  Stream **v12; // eax
  Stream **v13; // eax
  int v14; // edi
  const char *CurCharacNameEv; // esi
  int v16; // ebx
  WongWork::CGenUniqueNo *v17; // eax
  CItemList **v18; // eax
  const char *EventString; // eax
  char v20; // si
  unsigned int n2_1; // ebx
  CInventory *CurCharacInvenWEv_1; // eax
  int v23; // esi
  int v24; // eax
  int v25; // esi
  CUserCharacInfo **CurCharacInvenWEv_2; // eax
  int v29; // [esp+4h] [ebp-144h]
  int v30; // [esp+4h] [ebp-144h]
  int v31; // [esp+4h] [ebp-144h]
  void (__cdecl *v32)(int, CUser **, int, _BYTE *, WongWork::CGenUniqueNo *, int, const char *, int); // [esp+5Ch] [ebp-ECh]
  int v33[15]; // [esp+63h] [ebp-E5h] BYREF
  char v34; // [esp+9Fh] [ebp-A9h]
  int v35[6]; // [esp+A0h] [ebp-A8h] BYREF
  int v36[3]; // [esp+B8h] [ebp-90h] BYREF
  int v37; // [esp+C4h] [ebp-84h] BYREF
  bool v38; // [esp+CBh] [ebp-7Dh] BYREF
  int v39; // [esp+CCh] [ebp-7Ch] BYREF
  int v40; // [esp+D0h] [ebp-78h] BYREF
  char src_[4]; // [esp+D4h] [ebp-74h] BYREF
  int v42; // [esp+D8h] [ebp-70h]
  int v43; // [esp+DCh] [ebp-6Ch]
  int v44; // [esp+E0h] [ebp-68h]
  int v45; // [esp+E4h] [ebp-64h]
  Stream *v46[2]; // [esp+E8h] [ebp-60h] BYREF
  _BYTE v47[12]; // [esp+F0h] [ebp-58h] BYREF
  _BYTE v48[20]; // [esp+FCh] [ebp-4Ch] BYREF
  int item; // [esp+110h] [ebp-38h]
  int n13; // [esp+114h] [ebp-34h]
  int EventIPGCode; // [esp+118h] [ebp-30h]
  int ATIAvatarAbility; // [esp+11Ch] [ebp-2Ch]
  int n3; // [esp+120h] [ebp-28h]
  CUser *n50000; // [esp+124h] [ebp-24h]
  int CurSecEv; // [esp+128h] [ebp-20h]
  int n3_1; // [esp+12Ch] [ebp-1Ch]

  if ( n2 == (CUser *)1 )
  {
    CurCharacInvenREv = (CInventory *)CUserCharacInfo::getCurCharacInvenR((CUserCharacInfo *)this);
    v7 = &a4[CInventory::GetEventCoin(CurCharacInvenREv)];
    CurCharacInvenWEv = (CInventory *)CUserCharacInfo::getCurCharacInvenW((CUserCharacInfo *)this);
    CInventory::SetEventCoin(CurCharacInvenWEv, (unsigned int)v7);
    CurCharacInvenREv_1 = (CInventory *)CUserCharacInfo::getCurCharacInvenR((CUserCharacInfo *)this);
    EventCoin = CInventory::GetEventCoin(CurCharacInvenREv_1);
    cUserHistoryLog::EventCoinAdd(this + 124352, EventCoin, (int)a4, 2);
    CUser::SaveMoneyCoin((CUser *)this);
    CUser::SendCoin((CUser *)this);
    return 1;
  }
  if ( n2 != (CUser *)999 )
  {
    v18 = (CItemList **)G_CDataManager();
    item = CDataManager::find_item(v18, (unsigned int)n2);
    if ( !item )
      return 0;
    Inven_Item::Inven_Item((Inven_Item *)v33);
    (*(void (__cdecl **)(int))(*(_DWORD *)item + 8))(item);
    if ( BYTE1(v33[0]) == 1 )
    {
      if ( (unsigned int)a4 > 1 )
        *(int *)((char *)&v33[1] + 3) = (int)a4;
    }
    else
    {
      *(int *)((char *)&v33[1] + 3) = (int)a4;
    }
    *(int *)((char *)v33 + 2) = (int)n2;
    n13 = 13;
    if ( n200006 == (WongWork::CWebEvent *)100001 )
    {
      n13 = 14;
    }
    else if ( n200006 == (WongWork::CWebEvent *)200006 )
    {
      n13 = 20;
    }
    if ( (*(unsigned __int8 (__cdecl **)(int))(*(_DWORD *)item + 16))(item) )
    {
      ATIAvatarAbility = WongWork::CWebEvent::_GetATIAvatarAbility(n2, (int)v33);
      *(_DWORD *)src_ = 0;
      v42 = 0;
      v43 = 0;
      v44 = 0;
      v45 = 0;
      EventString = (const char *)WongWork::CWebEvent::_GetEventString(n200006, v31);
      OS_API::snprintf((OS_API *)src_, 0x14u, "E_%s", EventString);
      n3 = -1;
      v20 = ATIAvatarAbility;
      n2_1 = *(int *)((char *)v33 + 2);
      CurCharacInvenWEv_1 = (CInventory *)CUserCharacInfo::getCurCharacInvenW((CUserCharacInfo *)this);
      n3 = CInventory::AddAvatarItem(CurCharacInvenWEv_1, n2_1, 0, 0, v20, -1, src_, 2, 0, 0);
      if ( n3 == -1 )
        return 0;
      CUser::SendUpdateItemList((CUserCharacInfo *)this, 1, 1, n3);
      return 1;
    }
    v40 = 0;
    v39 = 0;
    v38 = 0;
    if ( !(unsigned __int8)WongWork::CCeraShop::IsSpecialItem(
                             GlobalData::s_pCeraShop,
                             *(int *)((char *)v33 + 2),
                             &v40,
                             &v39,
                             &v38) )
    {
      n3_1 = -1;
      CurCharacInvenWEv_2 = (CUserCharacInfo **)CUserCharacInfo::getCurCharacInvenW((CUserCharacInfo *)this);
      n3_1 = CInventory::insertItemIntoInventory(
               CurCharacInvenWEv_2,
               *(__int64 *)v33,
               v33[2],
               v33[3],
               v33[4],
               v33[5],
               v33[6],
               v33[7],
               v33[8],
               v33[9],
               v33[10],
               v33[11],
               v33[12],
               v33[13],
               v33[14],
               v34,
               n13,
               1u,
               0);
      if ( n3_1 == -1 )
        return 0;
      CUser::SendUpdateItemList((CUserCharacInfo *)this, 1, 0, n3_1);
      return 1;
    }
    v37 = 0;
    v23 = *(int *)((char *)v33 + 2);
    v24 = G_CDataManager();
    n50000 = (CUser *)CItemList::GetRestrictCode(*(CItemList **)(v24 + 12), v23);
    CurSecEv = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
    std::vector<Inven_Item>::vector((int)v36);
    WongWork::CCeraShop::stCeraShopItemParam_t::stCeraShopItemParam_t((WongWork::CCeraShop::stCeraShopItemParam_t *)v35);
    if ( (unsigned __int8)WongWork::CCeraShop::ProcessSpecialItem(
                            GlobalData::s_pCeraShop,
                            (CUserCharacInfo *)this,
                            *(int *)((char *)v33 + 2),
                            (int)n50000,
                            &v37,
                            CurSecEv,
                            1,
                            (int)v36,
                            (int)v35,
                            0,
                            0,
                            0,
                            1) )
    {
      if ( v37 )
      {
        a1 = 0;
        v25 = 0;
        goto LABEL_33;
      }
      if ( n50000 && (unsigned __int8)CUser::IsRestrictedGoods((CUser *)this, (int)n50000) != 1 )
      {
        CUser::SetRestrictedGoods((CUser *)this, (int)n50000);
        WongWork::CCeraShop::SaveFeaturedIdx((WongWork::CCeraShop *)this, n50000, CurSecEv, 0);
      }
    }
    v25 = 1;
LABEL_33:
    WongWork::CCeraShop::stCeraShopItemParam_t::~stCeraShopItemParam_t((WongWork::CCeraShop::stCeraShopItemParam_t *)v35);
    std::vector<Inven_Item>::~vector(v36);
    if ( !v25 )
      return a1;
    return 1;
  }
  OS_API::snprintf((OS_API *)v47, 0xCu, "%d", a4);
  v11 = StreamPool::Acquire(GlobalData::s_stream_pool, "WebEvent.cpp", 71);
  CStreamGuard::CStreamGuard((CStreamGuard *)v46, v11, 0);
  v12 = (Stream **)CStreamGuard::operator*((int)v46);
  CStreamGuard::operator<<(v12, (char)n200006);
  v13 = (Stream **)CStreamGuard::operator*((int)v46);
  CStreamGuard::operator<<(v13, src);
  EventIPGCode = WongWork::CWebEvent::_GetEventIPGCode(n200006, v29);
  if ( EventIPGCode )
  {
    v32 = **(void (__cdecl ***)(int, CUser **, int, _BYTE *, WongWork::CGenUniqueNo *, int, const char *, int))GlobalData::s_pIPGHelper;
    v14 = CStreamGuard::Get((CStreamGuard *)v46);
    CurCharacNameEv = CUserCharacInfo::getCurCharacName((CUserCharacInfo *)this);
    v16 = WongWork::CWebEvent::_GetEventString(n200006, v30);
    v17 = WongWork::CGenUniqueNo::GenUniqueNo((WongWork::CGenUniqueNo *)v48);
    v32(GlobalData::s_pIPGHelper, this, EventIPGCode, v47, v17, v16, CurCharacNameEv, v14);
    a1 = 0;
  }
  else
  {
    StreamPool::Free(GlobalData::s_stream_pool, (CStreamGuard *)v46);
    a1 = 1;
  }
  CStreamGuard::~CStreamGuard(v46);
  return a1;
}

// IDA_EA: 0x86C1910
// IDA_NAME: _ZN8WongWork9CWebEvent16ReqSaveEventItemEjjjjjjb
// DEMANGLED: WongWork::CWebEvent::ReqSaveEventItem(unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,bool)
int __cdecl WongWork::CWebEvent::ReqSaveEventItem(
        WongWork::CWebEvent *this,
        unsigned int CurCharacNoEv,
        unsigned int n0x65AE,
        unsigned int a4,
        unsigned int n0x30D47,
        unsigned int a6,
        char a7)
{
  Stream *v7; // eax
  Stream **v8; // eax
  Stream **v9; // eax
  int v10; // eax
  Stream *v12[2]; // [esp+24h] [ebp-14h] BYREF
  int v13; // [esp+2Ch] [ebp-Ch]

  v7 = StreamPool::Acquire(GlobalData::s_stream_pool, "WebEvent.cpp", 160);
  CStreamGuard::CStreamGuard((CStreamGuard *)v12, v7, 1);
  v8 = (Stream **)CStreamGuard::operator*((int)v12);
  CStreamGuard::operator<<(v8, 76);
  v9 = (Stream **)CStreamGuard::operator*((int)v12);
  CStreamGuard::operator<<(v9, -1);
  v10 = CStreamGuard::operator->((int)v12);
  v13 = CStreamGuard::GetInBuffer<SIG_SAVE_EVENTITEM>(v10);
  *(_DWORD *)v13 = this;
  *(_DWORD *)(v13 + 4) = CurCharacNoEv;
  *(_DWORD *)(v13 + 12) = n0x65AE;
  *(_DWORD *)(v13 + 16) = a4;
  *(_DWORD *)(v13 + 8) = n0x30D47;
  *(_DWORD *)(v13 + 20) = a6;
  *(_BYTE *)(v13 + 24) = a7;
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v12);
  CStreamGuard::~CStreamGuard(v12);
  return 1;
}

// IDA_EA: 0x86C1A2E
// IDA_NAME: _ZN8WongWork9CWebEvent20_GetATIAvatarAbilityEi
// DEMANGLED: WongWork::CWebEvent::_GetATIAvatarAbility(int)
int __cdecl WongWork::CWebEvent::_GetATIAvatarAbility(WongWork::CWebEvent *this)
{
  int v2; // [esp+Ch] [ebp-4h]

  v2 = 0;
  if ( this == (WongWork::CWebEvent *)45048 )
    return 0;
  if ( (int)this <= 45048 )
  {
    if ( this != (WongWork::CWebEvent *)41056 )
    {
      if ( this == (WongWork::CWebEvent *)44648 )
        return 6;
      if ( this == (WongWork::CWebEvent *)40656 )
        return 1;
      return v2;
    }
    return 0;
  }
  if ( this == (WongWork::CWebEvent *)49052 )
    return 0;
  if ( (int)this > 49052 )
  {
    if ( this == (WongWork::CWebEvent *)52609 )
      return 0;
    if ( this != (WongWork::CWebEvent *)53009 )
      return v2;
    return 0;
  }
  if ( this == (WongWork::CWebEvent *)48652 )
    return 4;
  return v2;
}

// IDA_EA: 0x86C1ABA
// IDA_NAME: _ZN8WongWork9CWebEvent11GetItemTypeEii
// DEMANGLED: WongWork::CWebEvent::GetItemType(int,int)
int __cdecl WongWork::CWebEvent::GetItemType(WongWork::CWebEvent *this, int n52609)
{
  int v3; // [esp+Ch] [ebp-4h]

  v3 = 0;
  if ( this == (WongWork::CWebEvent *)2 )
  {
    if ( n52609 != 44648 )
    {
      if ( n52609 > 44648 )
      {
        if ( n52609 != 49052 )
        {
          if ( n52609 > 49052 )
          {
            if ( n52609 == 52609 )
              return 1;
            if ( n52609 != 53009 )
              return v3;
          }
          else if ( n52609 != 45048 )
          {
            if ( n52609 != 48652 )
              return v3;
            return 1;
          }
        }
        return 2;
      }
      if ( n52609 == 26013 )
        return 3;
      if ( n52609 <= 26013 )
      {
        if ( n52609 == 999 )
          return 4;
        return v3;
      }
      if ( n52609 != 40656 )
      {
        if ( n52609 != 41056 )
          return v3;
        return 2;
      }
    }
    return 1;
  }
  if ( this == (WongWork::CWebEvent *)3 )
  {
    if ( n52609 == 8 )
      return 2;
    else
      return n52609 == 26014;
  }
  return v3;
}

// IDA_EA: 0x86C1BA8
// IDA_NAME: _ZN8WongWork9CWebEvent15_GetEventStringEi
// DEMANGLED: WongWork::CWebEvent::_GetEventString(int)
int __cdecl WongWork::CWebEvent::_GetEventString(WongWork::CWebEvent *this)
{
  if ( (int)this <= 10 )
    return 18 * (_DWORD)this + 154848864;
  else
    return 0;
}

// IDA_EA: 0x86C1BD4
// IDA_NAME: _ZN8WongWork9CWebEvent16_GetEventIPGCodeEi
// DEMANGLED: WongWork::CWebEvent::_GetEventIPGCode(int)
int __cdecl WongWork::CWebEvent::_GetEventIPGCode(WongWork::CWebEvent *this)
{
  if ( (int)this > 9 )
    return 0;
  if ( WongWork::CWebEvent::m_strEventIPGCode[11 * (_DWORD)this] )
    return 11 * (_DWORD)this + 154849056;
  return 0;
}
