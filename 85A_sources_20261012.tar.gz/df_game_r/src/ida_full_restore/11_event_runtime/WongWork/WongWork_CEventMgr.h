#ifndef __IDA91_WONGWORK_CEVENTMGR_H__
#define __IDA91_WONGWORK_CEVENTMGR_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: WongWork
// Source unit: WongWork_CEventMgr
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2837

/* 2837 */
struct WongWork::CEventMgr;

// Exported member functions:
// 0x848EF0C	WongWork::CEventMgr::_IsEventing(int,int,int,int,int,int,int,int,WongWork::CEventMgr::EVENT_TYPE)
// 0x848EFF8	WongWork::CEventMgr::GetCoinPerDay(void)
// 0x848F002	WongWork::CEventMgr::GetCoinCharacCreate(void)
// 0x848F06E	WongWork::CEventMgr::GetMoneyCharacCreate(void)
// 0x848F078	WongWork::CEventMgr::GetPremiumServiceBonus(void)
// 0x848F0DC	WongWork::CEventMgr::IsPCRoomEventing(void)
// 0x848F140	WongWork::CEventMgr::IsChildrensDayEventing(void)

// Function declaration index:
// DECL 0x848EF0C WongWork::CEventMgr::_IsEventing
// DECL 0x848EFF8 WongWork::CEventMgr::GetCoinPerDay
// DECL 0x848F002 WongWork::CEventMgr::GetCoinCharacCreate
// DECL 0x848F06E WongWork::CEventMgr::GetMoneyCharacCreate
// DECL 0x848F078 WongWork::CEventMgr::GetPremiumServiceBonus
// DECL 0x848F0DC WongWork::CEventMgr::IsPCRoomEventing
// DECL 0x848F140 WongWork::CEventMgr::IsChildrensDayEventing

#endif  // __IDA91_WONGWORK_CEVENTMGR_H__
