#include "WongWork_EventCommon.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x83F9B54
// IDA_NAME: _ZN8WongWork11EventCommon26InsertEventItem2EventTableEjjjj
// DEMANGLED: WongWork::EventCommon::InsertEventItem2EventTable(unsigned int,unsigned int,unsigned int,unsigned int)
unsigned int __cdecl WongWork::EventCommon::InsertEventItem2EventTable(
        WongWork::EventCommon *this,
        unsigned int a2,
        unsigned int a3,
        unsigned int a4)
{
  int v5[4]; // [esp+2Ch] [ebp-2Ch] BYREF
  int v6[4]; // [esp+3Ch] [ebp-1Ch] BYREF
  MySQL *DBHandle; // [esp+4Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 3, 0);
  MySQL::set_query(
    DBHandle,
    "inSert into charac_event_items(charac_no,it_id,stack_count,event_code,reg_time) values(%d,%d,%d,%d,now())",
    this,
    a2,
    a3,
    a4);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) == 1 )
  {
    cMyTrace::cMyTrace(
      (cMyTrace *)v6,
      "unsigned int WongWork::EventCommon::InsertEventItem2EventTable(unsigned int, unsigned int, unsigned int, unsigned int)",
      40,
      0);
    cMyTrace::operator()(
      (int)v6,
      "SUCCESS : insert into charac_event_items(charac_no,it_id,stack_count,event_code,reg_time) values(%d,%d,%d,%d,now())",
      (char)this);
    return WongWork::DBCommon::GetIdentity(DBHandle);
  }
  else
  {
    cMyTrace::cMyTrace(
      (cMyTrace *)v5,
      "unsigned int WongWork::EventCommon::InsertEventItem2EventTable(unsigned int, unsigned int, unsigned int, unsigned int)",
      37,
      0);
    cMyTrace::operator()(
      (int)v5,
      "FAIL : insert into charac_event_items(charac_no,it_id,stack_count,event_code,reg_time) values(%d,%d,%d,%d,now())",
      (char)this);
    return 0;
  }
}

// IDA_EA: 0x83F9C7B
// IDA_NAME: _ZN8WongWork11EventCommon19LoadCharacEventItemEjjj
// DEMANGLED: WongWork::EventCommon::LoadCharacEventItem(unsigned int,unsigned int,unsigned int)
void __cdecl WongWork::EventCommon::LoadCharacEventItem(WongWork::EventCommon *this, int a2, unsigned int a3)
{
  const char *v3; // eax
  Stream *v4; // eax
  Stream **v5; // eax
  Stream **v6; // eax
  int v7; // eax
  _BYTE v8[8]; // [esp+18h] [ebp-30h] BYREF
  int v9[4]; // [esp+20h] [ebp-28h] BYREF
  MySQL *DBHandle; // [esp+30h] [ebp-18h]
  _DWORD *v11; // [esp+34h] [ebp-14h]
  int n_rowsEv; // [esp+38h] [ebp-10h]
  int n_rowsEv_1; // [esp+3Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 3, 0);
  if ( a3 )
  {
    v3 = (const char *)NumberToString(a3, 0);
    MySQL::set_query(
      DBHandle,
      "seLect id,it_id,stack_count,event_code from charac_event_items where id=%s and charac_no=%d",
      v3,
      a2);
  }
  else
  {
    MySQL::set_query(
      DBHandle,
      "seLect id,it_id,stack_count,event_code from charac_event_items where charac_no=%d and delete_flag=0 limit %d",
      a2,
      5);
  }
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) == 1 )
  {
    if ( MySQL::get_n_rows(DBHandle) )
    {
      v4 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBEventWork.inl", 62);
      CStreamGuard::CStreamGuard((CStreamGuard *)v8, v4, 1);
      v5 = (Stream **)CStreamGuard::operator*((int)v8);
      CStreamGuard::operator<<(v5, 75);
      v6 = (Stream **)CStreamGuard::operator*((int)v8);
      CStreamGuard::operator<<(v6, -1);
      v7 = CStreamGuard::operator->((int)v8);
      v11 = (_DWORD *)CStreamGuard::GetInBuffer<SIG_LOAD_EVENTITEM>(v7);
      *v11 = this;
      v11[1] = a2;
      n_rowsEv = MySQL::get_n_rows(DBHandle);
      for ( n_rowsEv_1 = 0; n_rowsEv_1 < n_rowsEv && (unsigned __int8)MySQL::fetch(DBHandle) == 1; ++n_rowsEv_1 )
      {
        MySQL::get_uint(DBHandle, 0, &v11[4 * n_rowsEv_1 + 3]);
        MySQL::get_uint(DBHandle, 1, &v11[4 * n_rowsEv_1 + 4]);
        MySQL::get_uint(DBHandle, 2, &v11[4 * n_rowsEv_1 + 5]);
        MySQL::get_uint(DBHandle, 3, &v11[4 * n_rowsEv_1 + 6]);
      }
      v11[2] = n_rowsEv;
      MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 1, (CStreamGuard *)v8);
      CStreamGuard::~CStreamGuard((CStreamGuard *)v8);
    }
  }
  else
  {
    cMyTrace::cMyTrace(
      (cMyTrace *)v9,
      "void WongWork::EventCommon::LoadCharacEventItem(memberIdentificationNumber_t, unsigned int, memberIdentificationNumber_t)",
      55,
      5);
    cMyTrace::operator()((int)v9, "DB_LoadInventory::GetUserInven, exec ERROR charac_no=%u", a2);
  }
}
