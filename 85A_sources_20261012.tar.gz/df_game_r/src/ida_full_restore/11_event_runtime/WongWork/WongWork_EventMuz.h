#ifndef __IDA91_WONGWORK_EVENTMUZ_H__
#define __IDA91_WONGWORK_EVENTMUZ_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: WongWork
// Source unit: WongWork_EventMuz
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4804

/* 4804 */
struct WongWork::EventMuz;

// Exported member functions:
// 0x83FB047	WongWork::EventMuz::CheckAlreadyGetMuzItem(unsigned int,int)
// 0x83FB105	WongWork::EventMuz::UpdateEventMuzInfo(unsigned int,int)
// 0x83FB16A	WongWork::EventMuz::ArrangeMuzEventItem(unsigned int,unsigned int)

// Function declaration index:
// DECL 0x83FB047 WongWork::EventMuz::CheckAlreadyGetMuzItem
// DECL 0x83FB105 WongWork::EventMuz::UpdateEventMuzInfo
// DECL 0x83FB16A WongWork::EventMuz::ArrangeMuzEventItem

#endif  // __IDA91_WONGWORK_EVENTMUZ_H__
