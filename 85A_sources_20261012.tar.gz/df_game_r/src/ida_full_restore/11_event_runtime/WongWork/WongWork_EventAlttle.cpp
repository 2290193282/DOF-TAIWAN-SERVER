#include "WongWork_EventAlttle.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x83FB472
// IDA_NAME: _ZN8WongWork11EventAlttle25CheckAlreadyGetAlttleItemEji
// DEMANGLED: WongWork::EventAlttle::CheckAlreadyGetAlttleItem(unsigned int,int)
_BOOL4 __cdecl WongWork::EventAlttle::CheckAlreadyGetAlttleItem(WongWork::EventAlttle *this)
{
  const char *v1; // eax
  bool v3; // al
  int v4; // [esp+18h] [ebp-10h] BYREF
  MySQL *DBHandle; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  v1 = (const char *)NumberToString((unsigned int)this, 0);
  MySQL::set_query(DBHandle, "seLect item_check from event_alttle_info where m_id=%s", v1);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
    return 0;
  v4 = 0;
  v3 = (unsigned __int8)MySQL::get_int(DBHandle, 0, &v4) != 1 || !v4;
  return !v3;
}

// IDA_EA: 0x83FB530
// IDA_NAME: _ZN8WongWork11EventAlttle21UpdateEventAlttleInfoEji
// DEMANGLED: WongWork::EventAlttle::UpdateEventAlttleInfo(unsigned int,int)
int __cdecl WongWork::EventAlttle::UpdateEventAlttleInfo(WongWork::EventAlttle *this)
{
  const char *v1; // eax
  MySQL *DBHandle; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  v1 = (const char *)NumberToString((unsigned int)this, 0);
  MySQL::set_query(DBHandle, "upDate event_alttle_info set item_check=unix_timestamp(now()) where m_id=%s", v1);
  return MySQL::exec(DBHandle, 1);
}

// IDA_EA: 0x83FB595
// IDA_NAME: _ZN8WongWork11EventAlttle22ArrangeAlttleEventItemEjj
// DEMANGLED: WongWork::EventAlttle::ArrangeAlttleEventItem(unsigned int,unsigned int)
char __cdecl WongWork::EventAlttle::ArrangeAlttleEventItem(WongWork::EventAlttle *this, unsigned int a2)
{
  const char *v2; // eax
  char result; // al
  unsigned int n_rowsEv; // eax
  int v5; // [esp+B4h] [ebp-44h] BYREF
  int v6; // [esp+B8h] [ebp-40h] BYREF
  int v7; // [esp+BCh] [ebp-3Ch] BYREF
  int v8; // [esp+C0h] [ebp-38h] BYREF
  int v9; // [esp+C4h] [ebp-34h] BYREF
  int v10[5]; // [esp+C8h] [ebp-30h] BYREF
  MySQL *DBHandle; // [esp+DCh] [ebp-1Ch]
  int v12; // [esp+E0h] [ebp-18h]
  unsigned int n_rowsEv_1; // [esp+E4h] [ebp-14h]
  int v14; // [esp+E8h] [ebp-10h]
  int i; // [esp+ECh] [ebp-Ch]
  _BYTE v16[8]; // [esp+F0h] [ebp-8h] BYREF

  v10[4] = 10;
  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  v2 = (const char *)NumberToString((unsigned int)this, 0);
  MySQL::set_query(
    DBHandle,
    "seLect item_server_id,item_charac_no,item_no,item_check,item_cnt from event_alttle_info where m_id=%s and occ_check!=0 limit %d",
    v2,
    10);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) == 1 )
  {
    v12 = 0;
    for ( n_rowsEv_1 = 0; ; ++n_rowsEv_1 )
    {
      n_rowsEv = MySQL::get_n_rows(DBHandle);
      if ( n_rowsEv <= n_rowsEv_1 || (unsigned __int8)MySQL::fetch(DBHandle) != 1 )
        break;
      v14 = 0;
      v9 = 0;
      v8 = 0;
      v7 = 0;
      v6 = 0;
      v5 = 0;
      MySQL::get_int(DBHandle, 0, &v9);
      MySQL::get_int(DBHandle, 1, &v8);
      MySQL::get_int(DBHandle, 2, &v7);
      MySQL::get_int(DBHandle, 3, &v6);
      MySQL::get_int(DBHandle, 4, &v5);
      if ( !v6 && v9 == a2 )
      {
        *(_DWORD *)&v16[16 * v12 - 220] = this;
        *(_DWORD *)&v16[16 * v12 - 212] = v7;
        *(_DWORD *)&v16[16 * v12 - 208] = v5;
        *(_DWORD *)&v16[16 * v12++ - 216] = v8;
      }
    }
    for ( i = 0; ; ++i )
    {
      result = i < v12;
      if ( i >= v12 )
        break;
      WongWork::EventAlttle::UpdateEventAlttleInfo(*(WongWork::EventAlttle **)&v16[16 * i - 220]);
      WongWork::EventCommon::InsertEventItem2EventTable(
        *(WongWork::EventCommon **)&v16[16 * i - 216],
        *(_DWORD *)&v16[16 * i - 212],
        *(_DWORD *)&v16[16 * i - 208],
        6u);
    }
  }
  else
  {
    NumberToString((unsigned int)this, 0);
    cMyTrace::cMyTrace(
      (cMyTrace *)v10,
      "void WongWork::EventAlttle::ArrangeAlttleEventItem(memberIdentificationNumber_t, unsigned int)",
      539,
      5);
    return cMyTrace::operator()(
             (int)v10,
             "%s, exec ERROR m_id=%s",
             (char)"void WongWork::EventAlttle::ArrangeAlttleEventItem(memberIdentificationNumber_t, unsigned int)");
  }
  return result;
}
