#ifndef __IDA91_WONGWORK_EVENTFCCOMBO_H__
#define __IDA91_WONGWORK_EVENTFCCOMBO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: WongWork
// Source unit: WongWork_EventFCCombo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4768

/* 4768 */
struct WongWork::EventFCCombo;

// Exported member functions:
// 0x83FB883	WongWork::EventFCCombo::CheckAlreadyFCComboEventItem(unsigned int,int)
// 0x83FB929	WongWork::EventFCCombo::UpdateFCComboEventInfo(unsigned int,int)
// 0x83FB976	WongWork::EventFCCombo::ArrangeFCComboEventItem(unsigned int,unsigned int)
// 0x844DC7C	WongWork::EventFCCombo::GetDBHandle(void)

// Function declaration index:
// DECL 0x83FB883 WongWork::EventFCCombo::CheckAlreadyFCComboEventItem
// DECL 0x83FB929 WongWork::EventFCCombo::UpdateFCComboEventInfo
// DECL 0x83FB976 WongWork::EventFCCombo::ArrangeFCComboEventItem
// DECL 0x844DC7C WongWork::EventFCCombo::GetDBHandle

#endif  // __IDA91_WONGWORK_EVENTFCCOMBO_H__
