#include "WongWork_EventATI.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x83F9F2E
// IDA_NAME: _ZN8WongWork8EventATI22CheckAlreadyGetATIItemEji
// DEMANGLED: WongWork::EventATI::CheckAlreadyGetATIItem(unsigned int,int)
_BOOL4 __cdecl WongWork::EventATI::CheckAlreadyGetATIItem(WongWork::EventATI *this, unsigned int a2)
{
  int n4; // eax
  const char *v3; // eax
  const char *v4; // eax
  const char *v5; // eax
  const char *v6; // eax
  bool v8; // al
  int v9; // [esp+8h] [ebp-20h]
  int v10; // [esp+18h] [ebp-10h] BYREF
  MySQL *DBHandle; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  n4 = WongWork::CWebEvent::GetItemType((WongWork::CWebEvent *)2, a2, v9);
  if ( n4 == 2 )
  {
    v4 = (const char *)NumberToString((unsigned int)this, 0);
    MySQL::set_query(DBHandle, "seLect avata_check2 from event_ati_info where id=%s", v4);
  }
  else if ( n4 > 2 )
  {
    if ( n4 == 3 )
    {
      v5 = (const char *)NumberToString((unsigned int)this, 0);
      MySQL::set_query(DBHandle, "seLect item_check from event_ati_info where id=%s", v5);
    }
    else if ( n4 == 4 )
    {
      v6 = (const char *)NumberToString((unsigned int)this, 0);
      MySQL::set_query(DBHandle, "seLect cera_check from event_ati_info where id=%s", v6);
    }
  }
  else if ( n4 == 1 )
  {
    v3 = (const char *)NumberToString((unsigned int)this, 0);
    MySQL::set_query(DBHandle, "seLect avata_check1 from event_ati_info where id=%s", v3);
  }
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
    return 0;
  v10 = 0;
  v8 = (unsigned __int8)MySQL::get_int(DBHandle, 0, &v10) != 1 || !v10;
  return !v8;
}

// IDA_EA: 0x83FA0AD
// IDA_NAME: _ZN8WongWork8EventATI18UpdateEventATIInfoEji
// DEMANGLED: WongWork::EventATI::UpdateEventATIInfo(unsigned int,int)
int __cdecl WongWork::EventATI::UpdateEventATIInfo(WongWork::EventATI *this, unsigned int a2)
{
  int n4; // eax
  const char *v3; // eax
  const char *v4; // eax
  const char *v5; // eax
  const char *v6; // eax
  int v8; // [esp+8h] [ebp-20h]
  MySQL *DBHandle; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  n4 = WongWork::CWebEvent::GetItemType((WongWork::CWebEvent *)2, a2, v8);
  if ( n4 == 2 )
  {
    v4 = (const char *)NumberToString((unsigned int)this, 0);
    MySQL::set_query(DBHandle, "upDate event_ati_info set avata_check2=unix_timestamp(now()) where id=%s", v4);
  }
  else if ( n4 > 2 )
  {
    if ( n4 == 3 )
    {
      v5 = (const char *)NumberToString((unsigned int)this, 0);
      MySQL::set_query(DBHandle, "upDate event_ati_info set item_check=unix_timestamp(now()) where id=%s", v5);
    }
    else if ( n4 == 4 )
    {
      v6 = (const char *)NumberToString((unsigned int)this, 0);
      MySQL::set_query(DBHandle, "upDate event_ati_info set cera_check=unix_timestamp(now()) where id=%s", v6);
    }
  }
  else if ( n4 == 1 )
  {
    v3 = (const char *)NumberToString((unsigned int)this, 0);
    MySQL::set_query(DBHandle, "upDate event_ati_info set avata_check1=unix_timestamp(now()) where id=%s", v3);
  }
  return MySQL::exec(DBHandle, 1);
}

// IDA_EA: 0x83FA1D3
// IDA_NAME: _ZN8WongWork8EventATI19ArrangeATIEventItemEjj
// DEMANGLED: WongWork::EventATI::ArrangeATIEventItem(unsigned int,unsigned int)
char __cdecl WongWork::EventATI::ArrangeATIEventItem(WongWork::EventATI *this, unsigned int a2)
{
  const char *v2; // eax
  char result; // al
  unsigned int n_rowsEv; // eax
  int v5; // [esp+B8h] [ebp-60h] BYREF
  int v6; // [esp+BCh] [ebp-5Ch] BYREF
  int v7; // [esp+C0h] [ebp-58h] BYREF
  int v8; // [esp+C4h] [ebp-54h] BYREF
  int v9; // [esp+C8h] [ebp-50h] BYREF
  int v10; // [esp+CCh] [ebp-4Ch] BYREF
  int v11; // [esp+D0h] [ebp-48h] BYREF
  int v12; // [esp+D4h] [ebp-44h] BYREF
  int v13; // [esp+D8h] [ebp-40h] BYREF
  int v14; // [esp+DCh] [ebp-3Ch] BYREF
  int v15; // [esp+E0h] [ebp-38h] BYREF
  int v16; // [esp+E4h] [ebp-34h] BYREF
  unsigned int v17; // [esp+E8h] [ebp-30h] BYREF
  int v18[5]; // [esp+ECh] [ebp-2Ch] BYREF
  MySQL *DBHandle; // [esp+100h] [ebp-18h]
  int v20; // [esp+104h] [ebp-14h]
  unsigned int n_rowsEv_1; // [esp+108h] [ebp-10h]
  int i; // [esp+10Ch] [ebp-Ch]
  _BYTE v23[8]; // [esp+110h] [ebp-8h] BYREF

  v18[4] = 10;
  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  v2 = (const char *)NumberToString((unsigned int)this, 0);
  MySQL::set_query(
    DBHandle,
    "seLect id,cera,cera_check,item_no,item_server_id,item_charac_no,item_check,avata_no1,avata_no2,avata_server_id,avata"
    "_charac_no,avata_check1,avata_check2 from event_ati_info where m_id=%s and occ_check!=0 limit %d",
    v2,
    10);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) == 1 )
  {
    v20 = 0;
    for ( n_rowsEv_1 = 0; ; ++n_rowsEv_1 )
    {
      n_rowsEv = MySQL::get_n_rows(DBHandle);
      if ( n_rowsEv <= n_rowsEv_1 || (unsigned __int8)MySQL::fetch(DBHandle) != 1 )
        break;
      v17 = 0;
      v16 = 0;
      v15 = 0;
      v14 = 0;
      v13 = 0;
      v12 = 0;
      v11 = 0;
      v10 = 0;
      v9 = 0;
      v8 = 0;
      v7 = 0;
      v6 = 0;
      v5 = 0;
      MySQL::get_int(DBHandle, 0, &v17);
      MySQL::get_int(DBHandle, 1, &v16);
      MySQL::get_int(DBHandle, 2, &v15);
      MySQL::get_int(DBHandle, 3, &v14);
      MySQL::get_int(DBHandle, 4, &v13);
      MySQL::get_int(DBHandle, 5, &v12);
      MySQL::get_int(DBHandle, 6, &v11);
      MySQL::get_int(DBHandle, 7, &v10);
      MySQL::get_int(DBHandle, 8, &v9);
      MySQL::get_int(DBHandle, 9, &v8);
      MySQL::get_int(DBHandle, 10, &v7);
      MySQL::get_int(DBHandle, 11, &v6);
      MySQL::get_int(DBHandle, 12, &v5);
      if ( !v11 && v13 == a2 )
      {
        *(_DWORD *)&v23[16 * v20 - 248] = v17;
        *(_DWORD *)&v23[16 * v20 - 240] = v14;
        *(_DWORD *)&v23[16 * v20 - 236] = 1;
        *(_DWORD *)&v23[16 * v20++ - 244] = v12;
      }
      if ( v8 == a2 )
      {
        if ( !v6 )
        {
          *(_DWORD *)&v23[16 * v20 - 248] = v17;
          *(_DWORD *)&v23[16 * v20 - 240] = v10;
          *(_DWORD *)&v23[16 * v20 - 236] = 1;
          *(_DWORD *)&v23[16 * v20++ - 244] = v7;
        }
        if ( !v5 )
        {
          *(_DWORD *)&v23[16 * v20 - 248] = v17;
          *(_DWORD *)&v23[16 * v20 - 240] = v9;
          *(_DWORD *)&v23[16 * v20 - 236] = 1;
          *(_DWORD *)&v23[16 * v20++ - 244] = v7;
        }
      }
    }
    for ( i = 0; ; ++i )
    {
      result = i < v20;
      if ( i >= v20 )
        break;
      WongWork::EventATI::UpdateEventATIInfo(*(WongWork::EventATI **)&v23[16 * i - 248], *(_DWORD *)&v23[16 * i - 240]);
      WongWork::EventCommon::InsertEventItem2EventTable(
        *(WongWork::EventCommon **)&v23[16 * i - 244],
        *(_DWORD *)&v23[16 * i - 240],
        *(_DWORD *)&v23[16 * i - 236],
        2u);
    }
  }
  else
  {
    NumberToString((unsigned int)this, 0);
    cMyTrace::cMyTrace(
      (cMyTrace *)v18,
      "void WongWork::EventATI::ArrangeATIEventItem(memberIdentificationNumber_t, unsigned int)",
      161,
      5);
    return cMyTrace::operator()(
             (int)v18,
             "%s, exec ERROR m_id=%s",
             (char)"void WongWork::EventATI::ArrangeATIEventItem(memberIdentificationNumber_t, unsigned int)");
  }
  return result;
}
