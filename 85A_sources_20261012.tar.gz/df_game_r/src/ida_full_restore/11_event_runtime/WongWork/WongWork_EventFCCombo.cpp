#include "WongWork_EventFCCombo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x83FB883
// IDA_NAME: _ZN8WongWork12EventFCCombo28CheckAlreadyFCComboEventItemEji
// DEMANGLED: WongWork::EventFCCombo::CheckAlreadyFCComboEventItem(unsigned int,int)
_BOOL4 __cdecl WongWork::EventFCCombo::CheckAlreadyFCComboEventItem(WongWork::EventFCCombo *this)
{
  const char *v1; // eax
  bool v3; // al
  WongWork::EventFCCombo *v4; // [esp+0h] [ebp-28h]
  int v5; // [esp+18h] [ebp-10h] BYREF
  MySQL *DBHandle; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)WongWork::EventFCCombo::GetDBHandle(v4);
  v1 = (const char *)NumberToString((unsigned int)this, 0);
  MySQL::set_query(DBHandle, "seLect item_check from event_combo_entry where id=%s", v1);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
    return 0;
  v5 = 0;
  v3 = (unsigned __int8)MySQL::get_int(DBHandle, 0, &v5) != 1 || !v5;
  return !v3;
}

// IDA_EA: 0x83FB929
// IDA_NAME: _ZN8WongWork12EventFCCombo22UpdateFCComboEventInfoEji
// DEMANGLED: WongWork::EventFCCombo::UpdateFCComboEventInfo(unsigned int,int)
int __cdecl WongWork::EventFCCombo::UpdateFCComboEventInfo(WongWork::EventFCCombo *this)
{
  const char *v1; // eax
  WongWork::EventFCCombo *v3; // [esp+0h] [ebp-28h]
  MySQL *DBHandle; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)WongWork::EventFCCombo::GetDBHandle(v3);
  v1 = (const char *)NumberToString((unsigned int)this, 0);
  MySQL::set_query(DBHandle, "upDate event_combo_entry set item_check=unix_timestamp(now()) where id=%s", v1);
  return MySQL::exec(DBHandle, 1);
}

// IDA_EA: 0x83FB976
// IDA_NAME: _ZN8WongWork12EventFCCombo23ArrangeFCComboEventItemEjj
// DEMANGLED: WongWork::EventFCCombo::ArrangeFCComboEventItem(unsigned int,unsigned int)
char __cdecl WongWork::EventFCCombo::ArrangeFCComboEventItem(WongWork::EventFCCombo *this, unsigned int a2)
{
  const char *v2; // eax
  char result; // al
  unsigned int n_rowsEv; // eax
  WongWork::EventFCCombo *v5; // [esp+0h] [ebp-F8h]
  _BYTE v6[160]; // [esp+14h] [ebp-E4h]
  int v7; // [esp+B4h] [ebp-44h] BYREF
  int v8; // [esp+B8h] [ebp-40h] BYREF
  int v9; // [esp+BCh] [ebp-3Ch] BYREF
  int v10; // [esp+C0h] [ebp-38h] BYREF
  int v11; // [esp+C4h] [ebp-34h] BYREF
  unsigned int v12; // [esp+C8h] [ebp-30h] BYREF
  int v13[5]; // [esp+CCh] [ebp-2Ch] BYREF
  MySQL *DBHandle; // [esp+E0h] [ebp-18h]
  int v15; // [esp+E4h] [ebp-14h]
  unsigned int n_rowsEv_1; // [esp+E8h] [ebp-10h]
  int i; // [esp+ECh] [ebp-Ch]

  v13[4] = 10;
  DBHandle = (MySQL *)WongWork::EventFCCombo::GetDBHandle(v5);
  v2 = (const char *)NumberToString((unsigned int)this, 0);
  MySQL::set_query(
    DBHandle,
    "seLect id,item_server_id,item_charac_no,item_no,item_check,item_cnt from event_combo_entry where m_id=%s and occ_check!=0 limit %d",
    v2,
    10);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) == 1 )
  {
    v15 = 0;
    for ( n_rowsEv_1 = 0; ; ++n_rowsEv_1 )
    {
      n_rowsEv = MySQL::get_n_rows(DBHandle);
      if ( n_rowsEv <= n_rowsEv_1 || (unsigned __int8)MySQL::fetch(DBHandle) != 1 )
        break;
      v12 = 0;
      v11 = 0;
      v10 = 0;
      v9 = 0;
      v8 = 0;
      v7 = 0;
      MySQL::get_int(DBHandle, 0, &v12);
      MySQL::get_int(DBHandle, 1, &v11);
      MySQL::get_int(DBHandle, 2, &v10);
      MySQL::get_int(DBHandle, 3, &v9);
      MySQL::get_int(DBHandle, 4, &v8);
      MySQL::get_int(DBHandle, 5, &v7);
      if ( !v8 && v11 == a2 )
      {
        *(_DWORD *)&v6[16 * v15] = v12;
        *(_DWORD *)&v6[16 * v15 + 8] = v9;
        *(_DWORD *)&v6[16 * v15 + 12] = v7;
        *(_DWORD *)&v6[16 * v15++ + 4] = v10;
      }
    }
    for ( i = 0; ; ++i )
    {
      result = i < v15;
      if ( i >= v15 )
        break;
      WongWork::EventFCCombo::UpdateFCComboEventInfo(*(WongWork::EventFCCombo **)&v6[16 * i]);
      WongWork::EventCommon::InsertEventItem2EventTable(
        *(WongWork::EventCommon **)&v6[16 * i + 4],
        *(_DWORD *)&v6[16 * i + 8],
        *(_DWORD *)&v6[16 * i + 12],
        7u);
    }
  }
  else
  {
    NumberToString((unsigned int)this, 0);
    cMyTrace::cMyTrace(
      (cMyTrace *)v13,
      "void WongWork::EventFCCombo::ArrangeFCComboEventItem(memberIdentificationNumber_t, unsigned int)",
      634,
      5);
    return cMyTrace::operator()(
             (int)v13,
             "%s, exec ERROR m_id=%s",
             (char)"void WongWork::EventFCCombo::ArrangeFCComboEventItem(memberIdentificationNumber_t, unsigned int)");
  }
  return result;
}

// IDA_EA: 0x844DC7C
// IDA_NAME: _ZN8WongWork12EventFCCombo11GetDBHandleEv
// DEMANGLED: WongWork::EventFCCombo::GetDBHandle(void)
int WongWork::EventFCCombo::GetDBHandle()
{
  return DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
}
