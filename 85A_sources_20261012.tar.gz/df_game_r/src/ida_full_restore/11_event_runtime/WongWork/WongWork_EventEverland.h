#ifndef __IDA91_WONGWORK_EVENTEVERLAND_H__
#define __IDA91_WONGWORK_EVENTEVERLAND_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: WongWork
// Source unit: WongWork_EventEverland
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4803

/* 4803 */
struct WongWork::EventEverland;

// Exported member functions:
// 0x83FAC0D	WongWork::EventEverland::CheckAlreadyGetEverlandItem(unsigned int,int)
// 0x83FACE3	WongWork::EventEverland::UpdateEventEverlandInfo(unsigned int,int)
// 0x83FAD60	WongWork::EventEverland::ArrangeEverlandEventItem(unsigned int,unsigned int)

// Function declaration index:
// DECL 0x83FAC0D WongWork::EventEverland::CheckAlreadyGetEverlandItem
// DECL 0x83FACE3 WongWork::EventEverland::UpdateEventEverlandInfo
// DECL 0x83FAD60 WongWork::EventEverland::ArrangeEverlandEventItem

#endif  // __IDA91_WONGWORK_EVENTEVERLAND_H__
