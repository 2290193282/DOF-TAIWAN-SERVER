#ifndef __IDA91_WONGWORK_CWEBEVENT_H__
#define __IDA91_WONGWORK_CWEBEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: WongWork
// Source unit: WongWork_CWebEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
//   #include "items/AvatarTypes.h"
// Local type ordinals: 3645

/* 3645 */
struct WongWork::CWebEvent;

// Exported member functions:
// 0x86C11D0	WongWork::CWebEvent::RecvInfoFromWeb(unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int)
// 0x86C121E	WongWork::CWebEvent::RecvInfoFromDB(CUser *,unsigned int,unsigned int,unsigned int,unsigned int)
// 0x86C1910	WongWork::CWebEvent::ReqSaveEventItem(unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,unsigned int,bool)
// 0x86C1A2E	WongWork::CWebEvent::_GetATIAvatarAbility(int)
// 0x86C1ABA	WongWork::CWebEvent::GetItemType(int,int)
// 0x86C1BA8	WongWork::CWebEvent::_GetEventString(int)
// 0x86C1BD4	WongWork::CWebEvent::_GetEventIPGCode(int)

// Function declaration index:
// DECL 0x86C11D0 WongWork::CWebEvent::RecvInfoFromWeb
// DECL 0x86C121E WongWork::CWebEvent::RecvInfoFromDB
// DECL 0x86C1910 WongWork::CWebEvent::ReqSaveEventItem
// DECL 0x86C1A2E WongWork::CWebEvent::_GetATIAvatarAbility
// DECL 0x86C1ABA WongWork::CWebEvent::GetItemType
// DECL 0x86C1BA8 WongWork::CWebEvent::_GetEventString
// DECL 0x86C1BD4 WongWork::CWebEvent::_GetEventIPGCode

#endif  // __IDA91_WONGWORK_CWEBEVENT_H__
