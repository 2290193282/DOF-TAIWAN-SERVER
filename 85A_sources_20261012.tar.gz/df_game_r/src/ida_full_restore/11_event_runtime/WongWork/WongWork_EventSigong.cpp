#include "WongWork_EventSigong.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x83FA69C
// IDA_NAME: _ZN8WongWork11EventSigong25CheckAlreadyGetSigongItemEji
// DEMANGLED: WongWork::EventSigong::CheckAlreadyGetSigongItem(unsigned int,int)
_BOOL4 __cdecl WongWork::EventSigong::CheckAlreadyGetSigongItem(WongWork::EventSigong *this, unsigned int a2)
{
  int n2; // eax
  const char *v3; // eax
  const char *v4; // eax
  bool v6; // al
  int v7; // [esp+8h] [ebp-20h]
  int v8; // [esp+18h] [ebp-10h] BYREF
  MySQL *DBHandle; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  n2 = WongWork::CWebEvent::GetItemType((WongWork::CWebEvent *)3, a2, v7);
  if ( n2 == 1 )
  {
    v3 = (const char *)NumberToString((unsigned int)this, 0);
    MySQL::set_query(DBHandle, "seLect item1_check from event_sigong_info where id=%s", v3);
  }
  else if ( n2 == 2 )
  {
    v4 = (const char *)NumberToString((unsigned int)this, 0);
    MySQL::set_query(DBHandle, "seLect item2_check from event_sigong_info where id=%s", v4);
  }
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
    return 0;
  v8 = 0;
  v6 = (unsigned __int8)MySQL::get_int(DBHandle, 0, &v8) != 1 || !v8;
  return !v6;
}

// IDA_EA: 0x83FA7A5
// IDA_NAME: _ZN8WongWork11EventSigong21UpdateEventSigongInfoEji
// DEMANGLED: WongWork::EventSigong::UpdateEventSigongInfo(unsigned int,int)
int __cdecl WongWork::EventSigong::UpdateEventSigongInfo(WongWork::EventSigong *this, unsigned int a2)
{
  int n2; // eax
  const char *v3; // eax
  const char *v4; // eax
  int v6; // [esp+8h] [ebp-20h]
  MySQL *DBHandle; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  n2 = WongWork::CWebEvent::GetItemType((WongWork::CWebEvent *)3, a2, v6);
  if ( n2 == 1 )
  {
    v3 = (const char *)NumberToString((unsigned int)this, 0);
    MySQL::set_query(DBHandle, "upDate event_sigong_info set item1_check=unix_timestamp(now()) where id=%s", v3);
  }
  else if ( n2 == 2 )
  {
    v4 = (const char *)NumberToString((unsigned int)this, 0);
    MySQL::set_query(DBHandle, "upDate event_sigong_info set item2_check=unix_timestamp(now()) where id=%s", v4);
  }
  return MySQL::exec(DBHandle, 1);
}

// IDA_EA: 0x83FA855
// IDA_NAME: _ZN8WongWork11EventSigong22ArrangeSigongEventItemEjj
// DEMANGLED: WongWork::EventSigong::ArrangeSigongEventItem(unsigned int,unsigned int)
char __cdecl WongWork::EventSigong::ArrangeSigongEventItem(WongWork::EventSigong *this, unsigned int a2)
{
  const char *v2; // eax
  char result; // al
  unsigned int n_rowsEv; // eax
  _DWORD v5[2]; // [esp+BCh] [ebp-5Ch]
  int v6; // [esp+C4h] [ebp-54h] BYREF
  int v7; // [esp+C8h] [ebp-50h] BYREF
  int v8; // [esp+CCh] [ebp-4Ch] BYREF
  int v9; // [esp+D0h] [ebp-48h] BYREF
  int v10; // [esp+D4h] [ebp-44h] BYREF
  int v11; // [esp+D8h] [ebp-40h] BYREF
  int v12; // [esp+DCh] [ebp-3Ch] BYREF
  int v13; // [esp+E0h] [ebp-38h] BYREF
  unsigned int v14; // [esp+E4h] [ebp-34h] BYREF
  int v15[5]; // [esp+E8h] [ebp-30h] BYREF
  MySQL *DBHandle; // [esp+FCh] [ebp-1Ch]
  int v17; // [esp+100h] [ebp-18h]
  unsigned int n_rowsEv_1; // [esp+104h] [ebp-14h]
  int i; // [esp+108h] [ebp-10h]
  int j; // [esp+10Ch] [ebp-Ch]
  _BYTE v21[8]; // [esp+110h] [ebp-8h] BYREF

  v15[4] = 10;
  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  v2 = (const char *)NumberToString((unsigned int)this, 0);
  MySQL::set_query(
    DBHandle,
    "seLect id,item1_no,item1_server_id,item1_charac_no,item1_check,item2_no,item2_server_id,item2_charac_no,item2_check "
    "from event_sigong_info where m_id=%s and occ_check!=0 limit %d",
    v2,
    10);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) == 1 )
  {
    v17 = 0;
    for ( n_rowsEv_1 = 0; ; ++n_rowsEv_1 )
    {
      n_rowsEv = MySQL::get_n_rows(DBHandle);
      if ( n_rowsEv <= n_rowsEv_1 || (unsigned __int8)MySQL::fetch(DBHandle) != 1 )
        break;
      v14 = 0;
      v12 = 0;
      v13 = 0;
      v10 = 0;
      v11 = 0;
      v8 = 0;
      v9 = 0;
      v6 = 0;
      v7 = 0;
      v5[0] = 1;
      v5[1] = 200;
      MySQL::get_int(DBHandle, 0, &v14);
      MySQL::get_int(DBHandle, 1, &v12);
      MySQL::get_int(DBHandle, 2, &v10);
      MySQL::get_int(DBHandle, 3, &v8);
      MySQL::get_int(DBHandle, 4, &v6);
      MySQL::get_int(DBHandle, 5, &v13);
      MySQL::get_int(DBHandle, 6, &v11);
      MySQL::get_int(DBHandle, 7, &v9);
      MySQL::get_int(DBHandle, 8, &v7);
      for ( i = 0; i <= 1; ++i )
      {
        if ( !*(&v6 + i) && *(&v10 + i) == a2 )
        {
          *(_DWORD *)&v21[16 * v17 - 244] = v14;
          *(_DWORD *)&v21[16 * v17 - 236] = *(&v12 + i);
          *(_DWORD *)&v21[16 * v17 - 232] = v5[i];
          *(_DWORD *)&v21[16 * v17++ - 240] = *(&v8 + i);
        }
      }
    }
    for ( j = 0; ; ++j )
    {
      result = j < v17;
      if ( j >= v17 )
        break;
      WongWork::EventSigong::UpdateEventSigongInfo(
        *(WongWork::EventSigong **)&v21[16 * j - 244],
        *(_DWORD *)&v21[16 * j - 236]);
      WongWork::EventCommon::InsertEventItem2EventTable(
        *(WongWork::EventCommon **)&v21[16 * j - 240],
        *(_DWORD *)&v21[16 * j - 236],
        *(_DWORD *)&v21[16 * j - 232],
        3u);
    }
  }
  else
  {
    NumberToString((unsigned int)this, 0);
    cMyTrace::cMyTrace(
      (cMyTrace *)v15,
      "void WongWork::EventSigong::ArrangeSigongEventItem(memberIdentificationNumber_t, unsigned int)",
      291,
      5);
    return cMyTrace::operator()(
             (int)v15,
             "%s, exec ERROR m_id=%s",
             (char)"void WongWork::EventSigong::ArrangeSigongEventItem(memberIdentificationNumber_t, unsigned int)");
  }
  return result;
}
