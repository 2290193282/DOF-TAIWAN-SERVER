#include "WongWork_EventEverland.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x83FAC0D
// IDA_NAME: _ZN8WongWork13EventEverland27CheckAlreadyGetEverlandItemEji
// DEMANGLED: WongWork::EventEverland::CheckAlreadyGetEverlandItem(unsigned int,int)
_BOOL4 __cdecl WongWork::EventEverland::CheckAlreadyGetEverlandItem(WongWork::EventEverland *this, unsigned int a2)
{
  const char *v2; // eax
  bool v4; // al
  int v5; // [esp+8h] [ebp-20h]
  int v6; // [esp+18h] [ebp-10h] BYREF
  MySQL *DBHandle; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  if ( WongWork::CWebEvent::GetItemType((WongWork::CWebEvent *)4, a2, v5) == 1 )
  {
    v2 = (const char *)NumberToString((unsigned int)this, 0);
    MySQL::set_query(DBHandle, "seLect coin_check from event_everland_info where id=%s", v2);
  }
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
    return 0;
  v6 = 0;
  v4 = (unsigned __int8)MySQL::get_int(DBHandle, 0, &v6) != 1 || !v6;
  return !v4;
}

// IDA_EA: 0x83FACE3
// IDA_NAME: _ZN8WongWork13EventEverland23UpdateEventEverlandInfoEji
// DEMANGLED: WongWork::EventEverland::UpdateEventEverlandInfo(unsigned int,int)
int __cdecl WongWork::EventEverland::UpdateEventEverlandInfo(WongWork::EventEverland *this, unsigned int a2)
{
  const char *v2; // eax
  int v4; // [esp+8h] [ebp-20h]
  MySQL *DBHandle; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  if ( WongWork::CWebEvent::GetItemType((WongWork::CWebEvent *)4, a2, v4) == 1 )
  {
    v2 = (const char *)NumberToString((unsigned int)this, 0);
    MySQL::set_query(DBHandle, "upDate event_everland_info set coin_check=unix_timestamp(now()) where id=%s", v2);
  }
  return MySQL::exec(DBHandle, 1);
}

// IDA_EA: 0x83FAD60
// IDA_NAME: _ZN8WongWork13EventEverland24ArrangeEverlandEventItemEjj
// DEMANGLED: WongWork::EventEverland::ArrangeEverlandEventItem(unsigned int,unsigned int)
char __cdecl WongWork::EventEverland::ArrangeEverlandEventItem(WongWork::EventEverland *this, unsigned int a2)
{
  const char *v2; // eax
  char result; // al
  unsigned int n_rowsEv; // eax
  int v5; // [esp+B8h] [ebp-40h] BYREF
  int v6; // [esp+BCh] [ebp-3Ch] BYREF
  int v7; // [esp+C0h] [ebp-38h] BYREF
  int v8; // [esp+C4h] [ebp-34h] BYREF
  unsigned int v9; // [esp+C8h] [ebp-30h] BYREF
  int v10[5]; // [esp+CCh] [ebp-2Ch] BYREF
  MySQL *DBHandle; // [esp+E0h] [ebp-18h]
  int v12; // [esp+E4h] [ebp-14h]
  unsigned int n_rowsEv_1; // [esp+E8h] [ebp-10h]
  int i; // [esp+ECh] [ebp-Ch]
  _BYTE v15[8]; // [esp+F0h] [ebp-8h] BYREF

  v10[4] = 10;
  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  v2 = (const char *)NumberToString((unsigned int)this, 0);
  MySQL::set_query(
    DBHandle,
    "seLect id,server_id,charac_no,coin,coin_check from event_everland_info where m_id=%s and occ_check!=0 limit %d",
    v2,
    10);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) == 1 )
  {
    v12 = 0;
    for ( n_rowsEv_1 = 0; ; ++n_rowsEv_1 )
    {
      n_rowsEv = MySQL::get_n_rows(DBHandle);
      if ( n_rowsEv <= n_rowsEv_1 || (unsigned __int8)MySQL::fetch(DBHandle) != 1 )
        break;
      v9 = 0;
      v8 = 0;
      v7 = 0;
      v6 = 0;
      v5 = 0;
      MySQL::get_int(DBHandle, 0, &v9);
      MySQL::get_int(DBHandle, 1, &v8);
      MySQL::get_int(DBHandle, 2, &v7);
      MySQL::get_int(DBHandle, 3, &v6);
      MySQL::get_int(DBHandle, 4, &v5);
      if ( !v5 && v8 == a2 )
      {
        *(_DWORD *)&v15[16 * v12 - 216] = v9;
        *(_DWORD *)&v15[16 * v12 - 208] = 1;
        *(_DWORD *)&v15[16 * v12 - 204] = v6;
        *(_DWORD *)&v15[16 * v12++ - 212] = v7;
      }
    }
    for ( i = 0; ; ++i )
    {
      result = i < v12;
      if ( i >= v12 )
        break;
      WongWork::EventEverland::UpdateEventEverlandInfo(
        *(WongWork::EventEverland **)&v15[16 * i - 216],
        *(_DWORD *)&v15[16 * i - 208]);
      WongWork::EventCommon::InsertEventItem2EventTable(
        *(WongWork::EventCommon **)&v15[16 * i - 212],
        *(_DWORD *)&v15[16 * i - 208],
        *(_DWORD *)&v15[16 * i - 204],
        3u);
    }
  }
  else
  {
    NumberToString((unsigned int)this, 0);
    cMyTrace::cMyTrace(
      (cMyTrace *)v10,
      "void WongWork::EventEverland::ArrangeEverlandEventItem(memberIdentificationNumber_t, unsigned int)",
      386,
      5);
    return cMyTrace::operator()(
             (int)v10,
             "%s, exec ERROR m_id=%s",
             (char)"void WongWork::EventEverland::ArrangeEverlandEventItem(memberIdentificationNumber_t, unsigned int)");
  }
  return result;
}
