#include "WongWork_CEventMgr.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x848EF0C
// IDA_NAME: _ZN8WongWork9CEventMgr11_IsEventingEiiiiiiiiNS0_10EVENT_TYPEE
// DEMANGLED: WongWork::CEventMgr::_IsEventing(int,int,int,int,int,int,int,int,WongWork::CEventMgr::EVENT_TYPE)
int __cdecl WongWork::CEventMgr::_IsEventing(
        int n2006,
        int n5,
        int tm_mday,
        int tm_hour,
        int arg10,
        int n2,
        int tm_mday_1,
        int tm_hour_1,
        int arg20)
{
  struct tm tp; // [esp+14h] [ebp-94h] BYREF
  tm s_; // [esp+40h] [ebp-68h] BYREF
  tm s; // [esp+6Ch] [ebp-3Ch] BYREF
  time_t timer; // [esp+98h] [ebp-10h] BYREF
  struct tm *v14; // [esp+9Ch] [ebp-Ch]

  memset(&s, 0, sizeof(s));
  memset(&s_, 0, sizeof(s_));
  s_.tm_year = n2006 - 1900;
  s_.tm_mon = n5 - 1;
  s_.tm_mday = tm_mday;
  s_.tm_hour = tm_hour;
  s.tm_year = arg10 - 1900;
  s.tm_mon = n2 - 1;
  s.tm_mday = tm_mday_1;
  s.tm_hour = tm_hour_1;
  if ( in_time(&s_, &s) )
  {
    if ( arg20 != 1 )
      return 1;
    timer = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
    v14 = localtime_r(&timer, &tp);
    if ( !v14->tm_wday || v14->tm_wday == 6 )
      return 1;
  }
  return 0;
}

// IDA_EA: 0x848EFF8
// IDA_NAME: _ZN8WongWork9CEventMgr13GetCoinPerDayEv
// DEMANGLED: WongWork::CEventMgr::GetCoinPerDay(void)
int WongWork::CEventMgr::GetCoinPerDay()
{
  return 1;
}

// IDA_EA: 0x848F002
// IDA_NAME: _ZN8WongWork9CEventMgr19GetCoinCharacCreateEv
// DEMANGLED: WongWork::CEventMgr::GetCoinCharacCreate(void)
int WongWork::CEventMgr::GetCoinCharacCreate()
{
  int n5; // [esp+18h] [ebp-10h]
  CCoinEventOnCharCreate *RepeatEvent; // [esp+1Ch] [ebp-Ch]

  n5 = 5;
  RepeatEvent = (CCoinEventOnCharCreate *)CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 5);
  if ( RepeatEvent
    && (*(unsigned __int8 (__cdecl **)(CCoinEventOnCharCreate *, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0) )
  {
    return CCoinEventOnCharCreate::GetCoinNoOnCreateCharac(RepeatEvent);
  }
  return n5;
}

// IDA_EA: 0x848F06E
// IDA_NAME: _ZN8WongWork9CEventMgr20GetMoneyCharacCreateEv
// DEMANGLED: WongWork::CEventMgr::GetMoneyCharacCreate(void)
int WongWork::CEventMgr::GetMoneyCharacCreate()
{
  return 0;
}

// IDA_EA: 0x848F078
// IDA_NAME: _ZN8WongWork9CEventMgr22GetPremiumServiceBonusEv
// DEMANGLED: WongWork::CEventMgr::GetPremiumServiceBonus(void)
int WongWork::CEventMgr::GetPremiumServiceBonus()
{
  if ( (unsigned __int8)WongWork::CEventMgr::_IsEventing(2006, 1, 2, 0, 2006, 1, 11, 0, 0) )
    return 7;
  else
    return 0;
}

// IDA_EA: 0x848F0DC
// IDA_NAME: _ZN8WongWork9CEventMgr16IsPCRoomEventingEv
// DEMANGLED: WongWork::CEventMgr::IsPCRoomEventing(void)
_BOOL4 WongWork::CEventMgr::IsPCRoomEventing()
{
  return (unsigned __int8)WongWork::CEventMgr::_IsEventing(2006, 1, 24, 0, 2006, 2, 7, 6, 0) != 0;
}

// IDA_EA: 0x848F140
// IDA_NAME: _ZN8WongWork9CEventMgr22IsChildrensDayEventingEv
// DEMANGLED: WongWork::CEventMgr::IsChildrensDayEventing(void)
_BOOL4 WongWork::CEventMgr::IsChildrensDayEventing()
{
  return (unsigned __int8)WongWork::CEventMgr::_IsEventing(2006, 5, 5, 6, 2006, 5, 8, 6, 0) != 0;
}
