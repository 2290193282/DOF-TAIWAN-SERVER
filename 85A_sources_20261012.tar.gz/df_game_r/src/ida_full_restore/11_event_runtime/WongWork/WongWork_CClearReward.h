#ifndef __IDA91_WONGWORK_CCLEARREWARD_H__
#define __IDA91_WONGWORK_CCLEARREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: WongWork
// Source unit: WongWork_CClearReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
//   #include "world/CDungeon.h"
// Local type ordinals: 3265,3271

/* 3265 */
struct WongWork::CClearReward;

/* 3271 */
struct WongWork::CClearReward::stGoldCardBlankItemInfo_t;

// Exported member functions:
// 0x85385B2	WongWork::CClearReward::getGoldCardCommission(int)
// 0x85385C8	WongWork::CClearReward::setDropRatio(float)
// 0x8538694	WongWork::CClearReward::_getGenItemProbIdx(int,WongWork::eClearRewardDropProb_t)
// 0x853873A	WongWork::CClearReward::generateRandomItem(WongWork::stGenerateRefData_t const&,WongWork::stGenerateResult_t &)
// 0x85387C0	WongWork::CClearReward::_generateRandomItem(WongWork::stGenerateRefClearReward_t const&,int,WongWork::stGenerateResult_t &,float)
// 0x8538A92	WongWork::CClearReward::generatePremiumGoldCardItem(WongWork::stGenerateRefData_t const&,WongWork::stGenerateResult_t &,ENUM_RARITY,unsigned int)
// 0x8538BF8	WongWork::CClearReward::_generateSpecificItem(WongWork::stGenerateRefClearReward_t const&,WongWork::stGenerateResult_t &)
// 0x8538C84	WongWork::CClearReward::generateSpecificItem(WongWork::stGenerateRefData_t const&,WongWork::stGenerateResult_t &)
// 0x8538E64	WongWork::CClearReward::power_war_dungeon_gold_clear_reward(WongWork::stGenerateRefData_t const&,WongWork::stGenerateResult_t &,int)
// 0x853900C	WongWork::CClearReward::generatePcRoomCardBlankItem(Inven_Item &)
// 0x8539166	WongWork::CClearReward::generateGoldCardBlankItem(Inven_Item &)
// 0x85392C0	WongWork::CClearReward::loadScript(char const*)
// 0x853A968	WongWork::CClearReward::CClearReward(int)
// 0x853F17E	WongWork::CClearReward::stGoldCardBlankItemInfo_t::~stGoldCardBlankItemInfo_t()
// 0x85BF000	WongWork::CClearReward::getGoldCardCreateRate(void)
// 0x85BF018	WongWork::CClearReward::getRewardItemRatePerMapMaxCount(int)const

// Function declaration index:
// DECL 0x85385B2 WongWork::CClearReward::getGoldCardCommission
// DECL 0x85385C8 WongWork::CClearReward::setDropRatio
// DECL 0x8538694 WongWork::CClearReward::_getGenItemProbIdx
// DECL 0x853873A WongWork::CClearReward::generateRandomItem
// DECL 0x85387C0 WongWork::CClearReward::_generateRandomItem
// DECL 0x8538A92 WongWork::CClearReward::generatePremiumGoldCardItem
// DECL 0x8538BF8 WongWork::CClearReward::_generateSpecificItem
// DECL 0x8538C84 WongWork::CClearReward::generateSpecificItem
// DECL 0x8538E64 WongWork::CClearReward::power_war_dungeon_gold_clear_reward
// DECL 0x853900C WongWork::CClearReward::generatePcRoomCardBlankItem
// DECL 0x8539166 WongWork::CClearReward::generateGoldCardBlankItem
// DECL 0x85392C0 WongWork::CClearReward::loadScript
// DECL 0x853A968 WongWork::CClearReward::CClearReward
// DECL 0x853F17E WongWork::CClearReward::stGoldCardBlankItemInfo_t::~stGoldCardBlankItemInfo_t
// DECL 0x85BF000 WongWork::CClearReward::getGoldCardCreateRate
// DECL 0x85BF018 WongWork::CClearReward::getRewardItemRatePerMapMaxCount

#endif  // __IDA91_WONGWORK_CCLEARREWARD_H__
