#include "WongWork_EventMuz.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x83FB047
// IDA_NAME: _ZN8WongWork8EventMuz22CheckAlreadyGetMuzItemEji
// DEMANGLED: WongWork::EventMuz::CheckAlreadyGetMuzItem(unsigned int,int)
_BOOL4 __cdecl WongWork::EventMuz::CheckAlreadyGetMuzItem(WongWork::EventMuz *this)
{
  const char *v1; // eax
  bool v3; // al
  int v4; // [esp+18h] [ebp-10h] BYREF
  MySQL *DBHandle; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  v1 = (const char *)NumberToString((unsigned int)this, 0);
  MySQL::set_query(DBHandle, "seLect item_check from event_muz_entry where id=%s", v1);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
    return 0;
  v4 = 0;
  v3 = (unsigned __int8)MySQL::get_int(DBHandle, 0, &v4) != 1 || !v4;
  return !v3;
}

// IDA_EA: 0x83FB105
// IDA_NAME: _ZN8WongWork8EventMuz18UpdateEventMuzInfoEji
// DEMANGLED: WongWork::EventMuz::UpdateEventMuzInfo(unsigned int,int)
int __cdecl WongWork::EventMuz::UpdateEventMuzInfo(WongWork::EventMuz *this)
{
  const char *v1; // eax
  MySQL *DBHandle; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  v1 = (const char *)NumberToString((unsigned int)this, 0);
  MySQL::set_query(DBHandle, "upDate event_muz_entry set item_check=unix_timestamp(now()) where id=%s", v1);
  return MySQL::exec(DBHandle, 1);
}

// IDA_EA: 0x83FB16A
// IDA_NAME: _ZN8WongWork8EventMuz19ArrangeMuzEventItemEjj
// DEMANGLED: WongWork::EventMuz::ArrangeMuzEventItem(unsigned int,unsigned int)
char __cdecl WongWork::EventMuz::ArrangeMuzEventItem(WongWork::EventMuz *this, unsigned int a2)
{
  const char *v2; // eax
  char result; // al
  unsigned int n_rowsEv; // eax
  int v5; // [esp+B4h] [ebp-44h] BYREF
  int v6; // [esp+B8h] [ebp-40h] BYREF
  int v7; // [esp+BCh] [ebp-3Ch] BYREF
  int v8; // [esp+C0h] [ebp-38h] BYREF
  int v9; // [esp+C4h] [ebp-34h] BYREF
  unsigned int v10; // [esp+C8h] [ebp-30h] BYREF
  int v11[5]; // [esp+CCh] [ebp-2Ch] BYREF
  MySQL *DBHandle; // [esp+E0h] [ebp-18h]
  int v13; // [esp+E4h] [ebp-14h]
  unsigned int n_rowsEv_1; // [esp+E8h] [ebp-10h]
  int i; // [esp+ECh] [ebp-Ch]
  _BYTE v16[8]; // [esp+F0h] [ebp-8h] BYREF

  v11[4] = 10;
  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 1, 0);
  v2 = (const char *)NumberToString((unsigned int)this, 0);
  MySQL::set_query(
    DBHandle,
    "seLect id,item_server_id,item_charac_no,item_no,item_check,item_cnt from event_muz_entry where m_id=%s and occ_check!=0 limit %d",
    v2,
    10);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) == 1 )
  {
    v13 = 0;
    for ( n_rowsEv_1 = 0; ; ++n_rowsEv_1 )
    {
      n_rowsEv = MySQL::get_n_rows(DBHandle);
      if ( n_rowsEv <= n_rowsEv_1 || (unsigned __int8)MySQL::fetch(DBHandle) != 1 )
        break;
      v10 = 0;
      v9 = 0;
      v8 = 0;
      v7 = 0;
      v6 = 0;
      v5 = 0;
      MySQL::get_int(DBHandle, 0, &v10);
      MySQL::get_int(DBHandle, 1, &v9);
      MySQL::get_int(DBHandle, 2, &v8);
      MySQL::get_int(DBHandle, 3, &v7);
      MySQL::get_int(DBHandle, 4, &v6);
      MySQL::get_int(DBHandle, 5, &v5);
      if ( !v6 && v9 == a2 )
      {
        *(_DWORD *)&v16[16 * v13 - 220] = v10;
        *(_DWORD *)&v16[16 * v13 - 212] = v7;
        *(_DWORD *)&v16[16 * v13 - 208] = v5;
        *(_DWORD *)&v16[16 * v13++ - 216] = v8;
      }
    }
    for ( i = 0; ; ++i )
    {
      result = i < v13;
      if ( i >= v13 )
        break;
      WongWork::EventMuz::UpdateEventMuzInfo(*(WongWork::EventMuz **)&v16[16 * i - 220]);
      WongWork::EventCommon::InsertEventItem2EventTable(
        *(WongWork::EventCommon **)&v16[16 * i - 216],
        *(_DWORD *)&v16[16 * i - 212],
        *(_DWORD *)&v16[16 * i - 208],
        5u);
    }
  }
  else
  {
    NumberToString((unsigned int)this, 0);
    cMyTrace::cMyTrace(
      (cMyTrace *)v11,
      "void WongWork::EventMuz::ArrangeMuzEventItem(memberIdentificationNumber_t, unsigned int)",
      462,
      5);
    return cMyTrace::operator()(
             (int)v11,
             "%s, exec ERROR m_id=%s",
             (char)"void WongWork::EventMuz::ArrangeMuzEventItem(memberIdentificationNumber_t, unsigned int)");
  }
  return result;
}
