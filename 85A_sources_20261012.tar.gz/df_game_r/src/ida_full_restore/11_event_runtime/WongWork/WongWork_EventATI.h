#ifndef __IDA91_WONGWORK_EVENTATI_H__
#define __IDA91_WONGWORK_EVENTATI_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: WongWork
// Source unit: WongWork_EventATI
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4801

/* 4801 */
struct WongWork::EventATI;

// Exported member functions:
// 0x83F9F2E	WongWork::EventATI::CheckAlreadyGetATIItem(unsigned int,int)
// 0x83FA0AD	WongWork::EventATI::UpdateEventATIInfo(unsigned int,int)
// 0x83FA1D3	WongWork::EventATI::ArrangeATIEventItem(unsigned int,unsigned int)

// Function declaration index:
// DECL 0x83F9F2E WongWork::EventATI::CheckAlreadyGetATIItem
// DECL 0x83FA0AD WongWork::EventATI::UpdateEventATIInfo
// DECL 0x83FA1D3 WongWork::EventATI::ArrangeATIEventItem

#endif  // __IDA91_WONGWORK_EVENTATI_H__
