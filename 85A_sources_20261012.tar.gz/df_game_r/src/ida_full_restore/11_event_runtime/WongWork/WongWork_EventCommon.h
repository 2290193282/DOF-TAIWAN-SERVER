#ifndef __IDA91_WONGWORK_EVENTCOMMON_H__
#define __IDA91_WONGWORK_EVENTCOMMON_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: WongWork
// Source unit: WongWork_EventCommon
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4800

/* 4800 */
struct WongWork::EventCommon;

// Exported member functions:
// 0x83F9B54	WongWork::EventCommon::InsertEventItem2EventTable(unsigned int,unsigned int,unsigned int,unsigned int)
// 0x83F9C7B	WongWork::EventCommon::LoadCharacEventItem(unsigned int,unsigned int,unsigned int)

// Function declaration index:
// DECL 0x83F9B54 WongWork::EventCommon::InsertEventItem2EventTable
// DECL 0x83F9C7B WongWork::EventCommon::LoadCharacEventItem

#endif  // __IDA91_WONGWORK_EVENTCOMMON_H__
