#ifndef __IDA91_WONGWORK_EVENTSIGONG_H__
#define __IDA91_WONGWORK_EVENTSIGONG_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: WongWork
// Source unit: WongWork_EventSigong
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4802

/* 4802 */
struct WongWork::EventSigong;

// Exported member functions:
// 0x83FA69C	WongWork::EventSigong::CheckAlreadyGetSigongItem(unsigned int,int)
// 0x83FA7A5	WongWork::EventSigong::UpdateEventSigongInfo(unsigned int,int)
// 0x83FA855	WongWork::EventSigong::ArrangeSigongEventItem(unsigned int,unsigned int)

// Function declaration index:
// DECL 0x83FA69C WongWork::EventSigong::CheckAlreadyGetSigongItem
// DECL 0x83FA7A5 WongWork::EventSigong::UpdateEventSigongInfo
// DECL 0x83FA855 WongWork::EventSigong::ArrangeSigongEventItem

#endif  // __IDA91_WONGWORK_EVENTSIGONG_H__
