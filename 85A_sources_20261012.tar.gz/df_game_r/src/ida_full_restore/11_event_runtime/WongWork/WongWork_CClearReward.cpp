#include "WongWork_CClearReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x85385B2
// IDA_NAME: _ZN8WongWork12CClearReward21getGoldCardCommissionEi
// DEMANGLED: WongWork::CClearReward::getGoldCardCommission(int)
int __cdecl WongWork::CClearReward::getGoldCardCommission(WongWork::CClearReward *this, int standard_levelEv)
{
  return *((_DWORD *)this + standard_levelEv + 36357);
}

// IDA_EA: 0x85385C8
// IDA_NAME: _ZN8WongWork12CClearReward12setDropRatioEf
// DEMANGLED: WongWork::CClearReward::setDropRatio(float)
bool __cdecl WongWork::CClearReward::setDropRatio(WongWork::CClearReward *this, float a2)
{
  bool result; // al
  float v3; // [esp+0h] [ebp-38h]
  int n5; // [esp+24h] [ebp-14h]
  unsigned int i; // [esp+28h] [ebp-10h]
  int v6; // [esp+2Ch] [ebp-Ch]

  for ( n5 = 0; ; ++n5 )
  {
    result = n5 <= 5;
    if ( n5 > 5 )
      break;
    std::vector<WongWork::CClearReward::stGenItemProb_t>::operator=(
      (char *)this + 12 * n5 + 96,
      (char *)this + 12 * n5 + 24);
    for ( i = 0; std::vector<WongWork::CClearReward::stGenItemProb_t>::size((char *)this + 12 * n5 + 96) > i; ++i )
    {
      v6 = std::vector<WongWork::CClearReward::stGenItemProb_t>::operator[]((char *)this + 12 * n5 + 96, i);
      v3 = (long double)*(int *)(v6 + 8) * a2;
      *(_DWORD *)(v6 + 8) = roundFloat(v3);
    }
  }
  return result;
}

// IDA_EA: 0x8538694
// IDA_NAME: _ZN8WongWork12CClearReward18_getGenItemProbIdxEiNS_22eClearRewardDropProb_tE
// DEMANGLED: WongWork::CClearReward::_getGenItemProbIdx(int,WongWork::eClearRewardDropProb_t)
unsigned int __cdecl WongWork::CClearReward::_getGenItemProbIdx(int this, int a2, int a3)
{
  unsigned int GenItemProbIdxEiNS_22eClearRewardDropProb_tE; // [esp+18h] [ebp-10h]
  _DWORD *v5; // [esp+1Ch] [ebp-Ch]

  for ( GenItemProbIdxEiNS_22eClearRewardDropProb_tE = 0;
        std::vector<WongWork::CClearReward::stGenItemProb_t>::size((_DWORD *)(this + 12 * a3 + 96)) > GenItemProbIdxEiNS_22eClearRewardDropProb_tE;
        ++GenItemProbIdxEiNS_22eClearRewardDropProb_tE )
  {
    v5 = (_DWORD *)std::vector<WongWork::CClearReward::stGenItemProb_t>::operator[](
                     (char *)(this + 96 + 12 * a3),
                     GenItemProbIdxEiNS_22eClearRewardDropProb_tE);
    if ( *v5 <= a2 && v5[1] >= a2 )
      break;
  }
  if ( std::vector<WongWork::CClearReward::stGenItemProb_t>::size((_DWORD *)(this + 12 * a3 + 96)) > GenItemProbIdxEiNS_22eClearRewardDropProb_tE )
    return GenItemProbIdxEiNS_22eClearRewardDropProb_tE;
  else
    return -1;
}

// IDA_EA: 0x853873A
// IDA_NAME: _ZN8WongWork12CClearReward18generateRandomItemERKNS_19stGenerateRefData_tERNS_18stGenerateResult_tE
// DEMANGLED: WongWork::CClearReward::generateRandomItem(WongWork::stGenerateRefData_t const&,WongWork::stGenerateResult_t &)
int __cdecl WongWork::CClearReward::generateRandomItem(
        WongWork::CClearReward *this,
        const WongWork::stGenerateRefData_t *a2,
        WongWork::stGenerateResult_t *a3)
{
  if ( (signed int)WongWork::CGenerateRandomNumber::generateNumber(
                     (WongWork::CClearReward *)((char *)this + 8),
                     1,
                     0x2710u) >= *((_DWORD *)this + 42) )
    return WongWork::CClearReward::_generateSpecificItem(this, (char *)a2 + 52, a3);
  else
    return WongWork::CClearReward::_generateRandomItem(this, (int)a2 + 52, *(_DWORD *)a2, (int)a3, *((float *)a2 + 1));
}

// IDA_EA: 0x85387C0
// IDA_NAME: _ZN8WongWork12CClearReward19_generateRandomItemERKNS_26stGenerateRefClearReward_tEiRNS_18stGenerateResult_tEf
// DEMANGLED: WongWork::CClearReward::_generateRandomItem(WongWork::stGenerateRefClearReward_t const&,int,WongWork::stGenerateResult_t &,float)
char __cdecl WongWork::CClearReward::_generateRandomItem(
        WongWork::CItemGenerator *this,
        unsigned __int8 *a2,
        int a3,
        int a4,
        float a5)
{
  int GenItemProbIdxEiNS_22eClearRewardDropProb_tE; // eax
  int *v6; // eax
  int GeneratorTypeEv; // ebx
  CDataManager *v8; // eax
  int ItemGeneratorEv; // eax
  int v10; // eax
  int v11; // eax
  _BYTE v13[2]; // [esp+2Fh] [ebp-79h] BYREF
  int GenItemProbIdxEiNS_22eClearRewardDropProb_tE_4; // [esp+31h] [ebp-77h]
  int v15; // [esp+6Ch] [ebp-3Ch]
  int v16; // [esp+70h] [ebp-38h]
  int v17; // [esp+74h] [ebp-34h]
  int GenItemProbIdxEiNS_22eClearRewardDropProb_tE_1; // [esp+78h] [ebp-30h]
  int v19; // [esp+7Ch] [ebp-2Ch]
  signed int v20; // [esp+80h] [ebp-28h]
  int n2; // [esp+84h] [ebp-24h]
  signed int Number; // [esp+88h] [ebp-20h]
  int v23; // [esp+8Ch] [ebp-1Ch]
  int ItemRarity; // [esp+90h] [ebp-18h]
  int GenItemProbIdxEiNS_22eClearRewardDropProb_tE_2; // [esp+94h] [ebp-14h]
  int GenItemProbIdxEiNS_22eClearRewardDropProb_tE_3; // [esp+98h] [ebp-10h]
  int n4; // [esp+9Ch] [ebp-Ch]

  GenItemProbIdxEiNS_22eClearRewardDropProb_tE = WongWork::CClearReward::_getGenItemProbIdx(
                                                   (int)this,
                                                   *a2,
                                                   *((_DWORD *)a2 + 2));
  GenItemProbIdxEiNS_22eClearRewardDropProb_tE_1 = GenItemProbIdxEiNS_22eClearRewardDropProb_tE;
  if ( GenItemProbIdxEiNS_22eClearRewardDropProb_tE >= 0 )
  {
    v6 = (int *)std::vector<WongWork::CClearReward::stGenItemProb_t>::operator[](
                  (char *)this + 12 * *((_DWORD *)a2 + 2) + 96,
                  GenItemProbIdxEiNS_22eClearRewardDropProb_tE_1);
    v15 = *v6;
    v16 = v6[1];
    v17 = v6[2];
    v19 = (int)((long double)(a3 / 100 * ((int)((long double)v17 * *((float *)a2 + 1)) + *((_DWORD *)this + a2[1] + 49)))
              * (1.0 - a5));
    LOBYTE(GenItemProbIdxEiNS_22eClearRewardDropProb_tE) = (int)WongWork::CGenerateRandomNumber::generateNumber(
                                                                  (WongWork::CItemGenerator *)((char *)this + 8),
                                                                  0,
                                                                  0x2710u) >= v19;
    if ( !(_BYTE)GenItemProbIdxEiNS_22eClearRewardDropProb_tE )
    {
      v20 = 0;
      n2 = 1;
      Number = WongWork::CGenerateRandomNumber::generateNumber(
                 (WongWork::CItemGenerator *)((char *)this + 8),
                 2,
                 0x2710u);
      for ( n4 = 1; n4 <= 4; ++n4 )
      {
        v20 += *((_DWORD *)this + n4 + 44);
        if ( Number < v20 )
        {
          n2 = n4;
          break;
        }
      }
      v23 = WongWork::CGenerateRandomNumber::generateNumber((WongWork::CItemGenerator *)((char *)this + 8), 3, 0xF4240u);
      ItemRarity = CLuckPoint::GetItemRarity((CLuckPoint *)(a4 + 12), (int *)this + 63, v23, n2);
      GeneratorTypeEv = WongWork::CItemGenerator::getGeneratorType(this);
      v8 = (CDataManager *)G_CDataManager();
      ItemGeneratorEv = CDataManager::getItemGenerator(v8);
      WongWork::CItemGeneratorMgr::onTryGenerateRandomItem(ItemGeneratorEv, GeneratorTypeEv, n2, ItemRarity);
      GenItemProbIdxEiNS_22eClearRewardDropProb_tE = WongWork::CItemGenRateTable::chooseItem(
                                                       (int)this + 680,
                                                       n2,
                                                       ItemRarity,
                                                       *a2);
      GenItemProbIdxEiNS_22eClearRewardDropProb_tE_2 = GenItemProbIdxEiNS_22eClearRewardDropProb_tE;
      if ( GenItemProbIdxEiNS_22eClearRewardDropProb_tE != -1 )
      {
        v10 = G_CDataManager();
        GenItemProbIdxEiNS_22eClearRewardDropProb_tE = CItemList::find_item(
                                                         *(CItemList **)(v10 + 12),
                                                         GenItemProbIdxEiNS_22eClearRewardDropProb_tE_2);
        GenItemProbIdxEiNS_22eClearRewardDropProb_tE_3 = GenItemProbIdxEiNS_22eClearRewardDropProb_tE;
        if ( GenItemProbIdxEiNS_22eClearRewardDropProb_tE )
        {
          Inven_Item::Inven_Item((Inven_Item *)v13);
          GenItemProbIdxEiNS_22eClearRewardDropProb_tE_4 = GenItemProbIdxEiNS_22eClearRewardDropProb_tE_2;
          v11 = G_CDataManager();
          CItemList::create_item(*(CItemList **)(v11 + 12), 1, (Inven_Item *)v13, 1);
          LOBYTE(GenItemProbIdxEiNS_22eClearRewardDropProb_tE) = std::vector<Inven_Item>::push_back(a4, (int)v13);
        }
      }
    }
  }
  return GenItemProbIdxEiNS_22eClearRewardDropProb_tE;
}

// IDA_EA: 0x8538A92
// IDA_NAME: _ZN8WongWork12CClearReward27generatePremiumGoldCardItemERKNS_19stGenerateRefData_tERNS_18stGenerateResult_tE11ENUM_RARITYj
// DEMANGLED: WongWork::CClearReward::generatePremiumGoldCardItem(WongWork::stGenerateRefData_t const&,WongWork::stGenerateResult_t &,ENUM_RARITY,unsigned int)
int __cdecl WongWork::CClearReward::generatePremiumGoldCardItem(
        WongWork::CItemGenerator *GeneratorENS0_15eGenerateType_tE,
        int p_StdDropRateEv,
        int a3,
        int n5_2,
        int n10000)
{
  int GeneratorTypeEv; // ebx
  CDataManager *v6; // eax
  int ItemGeneratorEv; // eax
  int v8; // eax
  int result; // eax
  int v10; // eax
  _BYTE v11[2]; // [esp+1Bh] [ebp-5Dh] BYREF
  int n10000_2; // [esp+1Dh] [ebp-5Bh]
  int n2; // [esp+58h] [ebp-20h]
  int n5_1; // [esp+5Ch] [ebp-1Ch]
  int n10000_1; // [esp+60h] [ebp-18h]
  int v16; // [esp+64h] [ebp-14h]
  signed int Number; // [esp+68h] [ebp-10h]
  int n5; // [esp+6Ch] [ebp-Ch]

  n2 = 2;
  n5_1 = 0;
  if ( n5_2 >= 0 )
  {
    n5_1 = n5_2;
  }
  else
  {
    Number = WongWork::CGenerateRandomNumber::generateNumber(
               (WongWork::CItemGenerator *)((char *)GeneratorENS0_15eGenerateType_tE + 8),
               3,
               0x2710u);
    for ( n5 = 0; n5 <= 5; ++n5 )
    {
      if ( *(_DWORD *)(G_CDataManager() + 4 * (n5 + 4708) + 20) >= Number )
      {
        n5_1 = n5;
        break;
      }
    }
  }
  GeneratorTypeEv = WongWork::CItemGenerator::getGeneratorType(GeneratorENS0_15eGenerateType_tE);
  v6 = (CDataManager *)G_CDataManager();
  ItemGeneratorEv = CDataManager::getItemGenerator(v6);
  WongWork::CItemGeneratorMgr::onTryGenerateRandomItem(ItemGeneratorEv, GeneratorTypeEv, n2, n5_1);
  n10000_1 = WongWork::CItemGenRateTable::chooseItem(
               (int)GeneratorENS0_15eGenerateType_tE + 680,
               n2,
               n5_1,
               *(unsigned __int8 *)(p_StdDropRateEv + 52));
  if ( n10000_1 == -1 )
    n10000_1 = n10000;
  v8 = G_CDataManager();
  result = CItemList::find_item(*(CItemList **)(v8 + 12), n10000_1);
  v16 = result;
  if ( result )
  {
    Inven_Item::Inven_Item((Inven_Item *)v11);
    n10000_2 = n10000_1;
    v10 = G_CDataManager();
    CItemList::create_item(*(CItemList **)(v10 + 12), 1, (Inven_Item *)v11, 1);
    return std::vector<Inven_Item>::push_back(a3, (int)v11);
  }
  return result;
}

// IDA_EA: 0x8538BF8
// IDA_NAME: _ZN8WongWork12CClearReward21_generateSpecificItemERKNS_26stGenerateRefClearReward_tERNS_18stGenerateResult_tE
// DEMANGLED: WongWork::CClearReward::_generateSpecificItem(WongWork::stGenerateRefClearReward_t const&,WongWork::stGenerateResult_t &)
int __cdecl WongWork::CClearReward::_generateSpecificItem(
        WongWork::CClearReward *this,
        CDungeon **a2,
        WongWork::stGenerateResult_t *a3)
{
  unsigned int Number; // eax
  int clear_itemEi; // eax
  int v5; // eax
  _BYTE v6[2]; // [esp+1Fh] [ebp-49h] BYREF
  int clear_itemEi_2; // [esp+21h] [ebp-47h]
  int clear_itemEi_1; // [esp+5Ch] [ebp-Ch]

  Number = WongWork::CGenerateRandomNumber::generateNumber((WongWork::CClearReward *)((char *)this + 8), 4, 0x64u);
  clear_itemEi = CDungeon::get_clear_item(a2[3], Number);
  clear_itemEi_1 = clear_itemEi;
  if ( clear_itemEi != -2 )
  {
    Inven_Item::Inven_Item((Inven_Item *)v6);
    clear_itemEi_2 = clear_itemEi_1;
    v5 = G_CDataManager();
    CItemList::create_item(*(CItemList **)(v5 + 12), 1, (Inven_Item *)v6, 1);
    return std::vector<Inven_Item>::push_back((int)a3, (int)v6);
  }
  return clear_itemEi;
}

// IDA_EA: 0x8538C84
// IDA_NAME: _ZN8WongWork12CClearReward20generateSpecificItemERKNS_19stGenerateRefData_tERNS_18stGenerateResult_tE
// DEMANGLED: WongWork::CClearReward::generateSpecificItem(WongWork::stGenerateRefData_t const&,WongWork::stGenerateResult_t &)
bool __cdecl WongWork::CClearReward::generateSpecificItem(
        WongWork::CClearReward *this,
        const WongWork::stGenerateRefData_t *a2,
        WongWork::stGenerateResult_t *a3)
{
  int v3; // ebx
  int v4; // eax
  int v5; // ebx
  bool result; // al
  float v7; // [esp+14h] [ebp-74h]
  _BYTE v8[2]; // [esp+27h] [ebp-61h] BYREF
  int v9; // [esp+29h] [ebp-5Fh]
  char *v10; // [esp+64h] [ebp-24h]
  float v11; // [esp+68h] [ebp-20h]
  int *GoldGenTableEh; // [esp+6Ch] [ebp-1Ch]
  int v13; // [esp+70h] [ebp-18h]
  int v14; // [esp+74h] [ebp-14h]
  int i; // [esp+78h] [ebp-10h]
  int v16; // [esp+7Ch] [ebp-Ch]

  v10 = (char *)a2 + 52;
  v7 = *((float *)this + *((unsigned __int8 *)a2 + 54) + 58) * *((float *)this + *((unsigned __int8 *)a2 + 53) + 54);
  v3 = *((_DWORD *)a2 + 14);
  v4 = G_CDataManager();
  v11 = (ServerParameterScript::GetExpBonusWeight(v4 + 104, v3) + 1.0) * v7;
  GoldGenTableEh = WongWork::CGeneratorCommonData::getGoldGenTable(
                     *((WongWork::CGeneratorCommonData **)this + 1),
                     *((_BYTE *)a2 + 52));
  v13 = 175 * *GoldGenTableEh / 1000;
  v14 = (int)((long double)(v13
                          * (*((unsigned __int16 *)a2 + 30)
                           + 2 * (2 * *((unsigned __int16 *)a2 + 33) + *((unsigned __int16 *)a2 + 31)))
                          / 2)
            * v11);
  for ( i = 0; ; ++i )
  {
    result = (unsigned __int8)v10[2] > i;
    if ( (unsigned __int8)v10[2] <= i )
      break;
    v5 = (int)((long double)v14 / 2.0 / (long double)(unsigned __int8)v10[2] * v11);
    v16 = (GetRandomRange(-GoldGenTableEh[1], GoldGenTableEh[1]) + 100) * v5 / 100;
    Inven_Item::Inven_Item((Inven_Item *)v8);
    v8[1] = 2;
    v9 = 0;
    Inven_Item::set_add_info((Inven_Item *)v8, v16);
    std::vector<Inven_Item>::push_back((int)a3, (int)v8);
  }
  return result;
}

// IDA_EA: 0x8538E64
// IDA_NAME: _ZN8WongWork12CClearReward35power_war_dungeon_gold_clear_rewardERKNS_19stGenerateRefData_tERNS_18stGenerateResult_tEi
// DEMANGLED: WongWork::CClearReward::power_war_dungeon_gold_clear_reward(WongWork::stGenerateRefData_t const&,WongWork::stGenerateResult_t &,int)
int __cdecl WongWork::CClearReward::power_war_dungeon_gold_clear_reward(
        WongWork::CClearReward *this,
        const WongWork::stGenerateRefData_t *p_StdDropRateEv,
        WongWork::stGenerateResult_t *a3,
        unsigned __int8 charac_levelEv)
{
  int v4; // ebx
  int v5; // eax
  int v6; // ebx
  float v8; // [esp+14h] [ebp-74h]
  _BYTE v9[2]; // [esp+2Bh] [ebp-5Dh] BYREF
  int v10; // [esp+2Dh] [ebp-5Bh]
  char *v11; // [esp+68h] [ebp-20h]
  float v12; // [esp+6Ch] [ebp-1Ch]
  int *GoldGenTableEh; // [esp+70h] [ebp-18h]
  int v14; // [esp+74h] [ebp-14h]
  int v15; // [esp+78h] [ebp-10h]
  int v16; // [esp+7Ch] [ebp-Ch]

  v11 = (char *)p_StdDropRateEv + 52;
  v8 = *((float *)this + *((unsigned __int8 *)p_StdDropRateEv + 54) + 58)
     * *((float *)this + *((unsigned __int8 *)p_StdDropRateEv + 53) + 54);
  v4 = *((_DWORD *)p_StdDropRateEv + 14);
  v5 = G_CDataManager();
  v12 = (ServerParameterScript::GetExpBonusWeight(v5 + 104, v4) + 1.0) * v8;
  GoldGenTableEh = WongWork::CGeneratorCommonData::getGoldGenTable(
                     *((WongWork::CGeneratorCommonData **)this + 1),
                     charac_levelEv);
  v14 = 175 * *GoldGenTableEh / 1000;
  v15 = (int)((long double)(v14
                          * (*((unsigned __int16 *)p_StdDropRateEv + 30)
                           + 2
                           * (2 * *((unsigned __int16 *)p_StdDropRateEv + 33)
                            + *((unsigned __int16 *)p_StdDropRateEv + 31)))
                          / 2)
            * v12);
  v6 = (int)((long double)v15 / 2.0 / (long double)*((unsigned __int8 *)p_StdDropRateEv + 54) * v12);
  v16 = (GetRandomRange(-GoldGenTableEh[1], GoldGenTableEh[1]) + 100) * v6 / 100;
  Inven_Item::Inven_Item((Inven_Item *)v9);
  v9[1] = 2;
  v10 = 0;
  Inven_Item::set_add_info((Inven_Item *)v9, v16);
  return std::vector<Inven_Item>::push_back((int)a3, (int)v9);
}

// IDA_EA: 0x853900C
// IDA_NAME: _ZN8WongWork12CClearReward27generatePcRoomCardBlankItemER10Inven_Item
// DEMANGLED: WongWork::CClearReward::generatePcRoomCardBlankItem(Inven_Item &)
int __cdecl WongWork::CClearReward::generatePcRoomCardBlankItem(WongWork::CClearReward *this, Inven_Item *a2)
{
  _DWORD *v3; // eax
  int v4; // ebx
  int v5; // eax
  _BYTE v6[4]; // [esp+18h] [ebp-20h] BYREF
  _BYTE v7[4]; // [esp+1Ch] [ebp-1Ch] BYREF
  _BYTE v8[4]; // [esp+20h] [ebp-18h] BYREF
  _BYTE v9[4]; // [esp+24h] [ebp-14h] BYREF
  int rand_inti_1; // [esp+28h] [ebp-10h]
  int rand_inti; // [esp+2Ch] [ebp-Ch]

  if ( (unsigned __int8)std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>::empty((char *)this + 146296) )
    return 0;
  rand_inti_1 = 0;
  rand_inti = get_rand_int(*((_DWORD *)this + 36573));
  std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>::begin(v8);
  __gnu_cxx::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t*>(
    v7,
    v8);
  std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>::end(v9);
  __gnu_cxx::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t*>(
    v6,
    v9);
  while ( 1 )
  {
    if ( !(unsigned __int8)__gnu_cxx::operator!=<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>(
                             v7,
                             v6) )
      return 0;
    v3 = (_DWORD *)__gnu_cxx::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>::operator->(v7);
    rand_inti_1 += *v3;
    if ( rand_inti < rand_inti_1 )
      break;
    __gnu_cxx::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>::operator++(v7);
  }
  if ( *(_DWORD *)(__gnu_cxx::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>::operator->(v7)
                 + 4) == -1 )
    return 0;
  *(_DWORD *)((char *)a2 + 2) = *(_DWORD *)(__gnu_cxx::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>::operator->(v7)
                                          + 4);
  v4 = *(_DWORD *)(__gnu_cxx::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>::operator->(v7)
                 + 8);
  v5 = G_CDataManager();
  CItemList::create_item(*(CItemList **)(v5 + 12), 1, a2, v4);
  return 1;
}

// IDA_EA: 0x8539166
// IDA_NAME: _ZN8WongWork12CClearReward25generateGoldCardBlankItemER10Inven_Item
// DEMANGLED: WongWork::CClearReward::generateGoldCardBlankItem(Inven_Item &)
int __cdecl WongWork::CClearReward::generateGoldCardBlankItem(WongWork::CClearReward *this, Inven_Item *a2)
{
  _DWORD *v3; // eax
  int v4; // ebx
  int v5; // eax
  _BYTE v6[4]; // [esp+18h] [ebp-20h] BYREF
  _BYTE v7[4]; // [esp+1Ch] [ebp-1Ch] BYREF
  _BYTE v8[4]; // [esp+20h] [ebp-18h] BYREF
  _BYTE v9[4]; // [esp+24h] [ebp-14h] BYREF
  int rand_inti_1; // [esp+28h] [ebp-10h]
  int rand_inti; // [esp+2Ch] [ebp-Ch]

  if ( (unsigned __int8)std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>::empty((char *)this + 146240) )
    return 0;
  rand_inti_1 = 0;
  rand_inti = get_rand_int(*((_DWORD *)this + 36559));
  std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>::begin(v8);
  __gnu_cxx::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t*>(
    v7,
    v8);
  std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>::end(v9);
  __gnu_cxx::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t*>(
    v6,
    v9);
  while ( 1 )
  {
    if ( !(unsigned __int8)__gnu_cxx::operator!=<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>(
                             v7,
                             v6) )
      return 0;
    v3 = (_DWORD *)__gnu_cxx::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>::operator->(v7);
    rand_inti_1 += *v3;
    if ( rand_inti < rand_inti_1 )
      break;
    __gnu_cxx::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>::operator++(v7);
  }
  if ( *(_DWORD *)(__gnu_cxx::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>::operator->(v7)
                 + 4) == -1 )
    return 0;
  *(_DWORD *)((char *)a2 + 2) = *(_DWORD *)(__gnu_cxx::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>::operator->(v7)
                                          + 4);
  v4 = *(_DWORD *)(__gnu_cxx::__normal_iterator<WongWork::CClearReward::stGoldCardBlankItemInfo_t const*,std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>>::operator->(v7)
                 + 8);
  v5 = G_CDataManager();
  CItemList::create_item(*(CItemList **)(v5 + 12), 1, a2, v4);
  return 1;
}

// IDA_EA: 0x85392C0
// IDA_NAME: _ZN8WongWork12CClearReward10loadScriptEPKc
// DEMANGLED: WongWork::CClearReward::loadScript(char const*)
int __usercall WongWork::CClearReward::loadScript@<eax>(
        int n2385@<ebx>,
        long double a2@<st0>,
        WongWork::CClearReward *this,
        TCHAR *filename)
{
  int n2_1; // esi
  int v5; // eax
  int v6; // eax
  int v7; // eax
  unsigned int GenItemProbIdxEiNS_22eClearRewardDropProb_tE_1; // eax
  int n4_1; // esi
  int n5_2; // esi
  int n4_3; // esi
  int n3_1; // esi
  int n4_5; // esi
  int v14; // esi
  int v15; // esi
  int v16; // esi
  _DWORD v18[3]; // [esp+24h] [ebp-74h] BYREF
  _DWORD v19[3]; // [esp+30h] [ebp-68h] BYREF
  std::string v20; // [esp+3Ch] [ebp-5Ch] BYREF
  bool v21; // [esp+43h] [ebp-55h] BYREF
  std::string v22; // [esp+44h] [ebp-54h] BYREF
  int v23; // [esp+48h] [ebp-50h]
  int v24; // [esp+4Ch] [ebp-4Ch]
  int v25; // [esp+50h] [ebp-48h]
  int v26; // [esp+54h] [ebp-44h]
  int v27; // [esp+58h] [ebp-40h]
  int n5; // [esp+5Ch] [ebp-3Ch]
  int n2; // [esp+60h] [ebp-38h]
  char *v30; // [esp+64h] [ebp-34h]
  unsigned int GenItemProbIdxEiNS_22eClearRewardDropProb_tE; // [esp+68h] [ebp-30h]
  int *v32; // [esp+6Ch] [ebp-2Ch]
  int n4; // [esp+70h] [ebp-28h]
  int n5_1; // [esp+74h] [ebp-24h]
  int n4_2; // [esp+78h] [ebp-20h]
  int n3; // [esp+7Ch] [ebp-1Ch]
  int n4_4; // [esp+80h] [ebp-18h]
  int n200; // [esp+84h] [ebp-14h]
  unsigned int n9; // [esp+88h] [ebp-10h]
  int v40; // [esp+8Ch] [ebp-Ch]

  if ( (unsigned __int8)loadRDARScriptFile((TCHAR *)dir__3, filename) == 1 )
  {
    std::string::string(&v22);
    v26 = 0;
    v21 = 0;
    while ( 1 )
    {
      while ( 1 )
      {
LABEL_4:
        if ( (unsigned __int8)ScanType(&v22, 1) != 1 )
        {
          WongWork::CItemGenRateTable::generateTable((WongWork::CClearReward *)((char *)this + 680), (int)this + 276, 0);
          n2385 = 0;
          goto LABEL_124;
        }
        if ( !std::operator==<char>(&v22, "[drop prob count]") )
          break;
        v27 = ScanInt(&v21);
        if ( !v21 )
        {
          n2385 = 2385;
LABEL_124:
          std::string::~string(&v22);
          return n2385;
        }
        for ( n5 = 0; n5 <= 5; ++n5 )
        {
          v23 = 0;
          v24 = 0;
          v25 = 0;
          std::vector<WongWork::CClearReward::stGenItemProb_t>::resize((char *)this + 12 * n5 + 24, v27, 0, 0, 0);
        }
      }
      if ( std::operator==<char>(&v22, "[drop prob]") )
        break;
      if ( std::operator==<char>(&v22, "[drop kind prob]") )
      {
        *((_DWORD *)this + 42) = ScanInt(&v21);
        if ( !v21 )
        {
          n2385 = 2426;
          goto LABEL_124;
        }
        *((_DWORD *)this + 43) = ScanInt(&v21);
        if ( !v21 )
        {
          n2385 = 2428;
          goto LABEL_124;
        }
      }
      else
      {
        if ( std::operator==<char>(&v22, "[drop item type prob]") )
        {
          for ( n4 = 1; ; ++n4 )
          {
            if ( n4 > 4 )
              goto LABEL_4;
            n4_1 = n4;
            *((_DWORD *)this + n4_1 + 44) = ScanInt(&v21);
            if ( !v21 )
              break;
          }
          n2385 = 2436;
          goto LABEL_124;
        }
        if ( std::operator==<char>(&v22, "[basis of rarity dicision]") )
        {
          for ( n5_1 = 0; ; ++n5_1 )
          {
            if ( n5_1 > 5 )
              goto LABEL_4;
            n5_2 = n5_1;
            *((_DWORD *)this + n5_2 + 63) = ScanInt(&v21);
            if ( !v21 )
              break;
          }
          n2385 = 2445;
          goto LABEL_124;
        }
        if ( std::operator==<char>(&v22, "[dungeon difficulty drop bonusrate]") )
        {
          for ( n4_2 = 0; ; ++n4_2 )
          {
            if ( n4_2 > 4 )
              goto LABEL_4;
            n4_3 = n4_2;
            *((_DWORD *)this + n4_3 + 49) = ScanInt(&v21);
            if ( !v21 )
              break;
          }
          n2385 = 2458;
          goto LABEL_124;
        }
        if ( std::operator==<char>(&v22, "[party member drop bonusrate]") )
        {
          for ( n3 = 0; ; ++n3 )
          {
            if ( n3 > 3 )
              goto LABEL_4;
            n3_1 = n3;
            ScanFloat(&v21);
            *((float *)this + n3_1 + 59) = a2;
            if ( !v21 )
              break;
          }
          n2385 = 2467;
          goto LABEL_124;
        }
        if ( std::operator==<char>(&v22, "[dungeon difficulty gold drop bonusrate]") )
        {
          for ( n4_4 = 0; ; ++n4_4 )
          {
            if ( n4_4 > 4 )
              goto LABEL_4;
            n4_5 = n4_4;
            ScanFloat(&v21);
            *((float *)this + n4_5 + 54) = a2;
            if ( !v21 )
              break;
          }
          n2385 = 2480;
          goto LABEL_124;
        }
        if ( std::operator==<char>(&v22, "[item drop ref table]") )
        {
          *((_BYTE *)this + 276) = 0;
          *((_BYTE *)this + 277) = 0;
          for ( n200 = 1; ; ++n200 )
          {
            if ( n200 > 200 )
              goto LABEL_4;
            v26 = ScanInt(&v21);
            if ( !v21 )
            {
              n2385 = 2492;
              goto LABEL_124;
            }
            v14 = v26;
            *((_BYTE *)this + 2 * v14 + 276) = ScanInt(&v21);
            if ( !v21 )
            {
              n2385 = 2496;
              goto LABEL_124;
            }
            v15 = v26;
            *((_BYTE *)this + 2 * v15 + 277) = ScanInt(&v21);
            if ( !v21 )
              break;
          }
          n2385 = 2500;
          goto LABEL_124;
        }
        if ( std::operator==<char>(&v22, "[gold card cost table]") )
        {
          do
          {
            v26 = ScanInt(&v21);
            if ( !v21 )
              goto LABEL_4;
            v16 = v26;
            *((_DWORD *)this + v16 + 36357) = ScanInt(&v21);
          }
          while ( v21 );
          n2385 = 2513;
          goto LABEL_124;
        }
        if ( !std::operator==<char>(&v22, "[gold card create rate]") )
        {
          if ( std::operator==<char>(&v22, "[pcroom card blank item]") )
          {
            for ( *((_DWORD *)this + 36573) = 0; ; *((_DWORD *)this + 36573) += v19[0] )
            {
              v19[0] = ScanInt(&v21);
              if ( !v21 )
                goto LABEL_4;
              v19[1] = ScanInt(&v21);
              if ( !v21 )
              {
                n2385 = 2534;
                goto LABEL_124;
              }
              v19[2] = ScanInt(&v21);
              if ( !v21 )
                break;
              std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>::push_back((char *)this + 146296, v19);
            }
            n2385 = 2537;
          }
          else if ( std::operator==<char>(&v22, "[reward item rate per map max count]") )
          {
            while ( 1 )
            {
              n9 = ScanInt(&v21);
              if ( !v21 )
                goto LABEL_4;
              if ( n9 > 9 )
              {
                n2385 = 2550;
                goto LABEL_124;
              }
              v40 = ScanInt(&v21);
              if ( !v21 )
                break;
              *((_DWORD *)this + n9 + 36563) = v40;
            }
            n2385 = 2553;
          }
          else if ( std::operator==<char>(&v22, "[gold card blank item]") )
          {
            for ( *((_DWORD *)this + 36559) = 0; ; *((_DWORD *)this + 36559) += v18[0] )
            {
              v18[0] = ScanInt(&v21);
              if ( !v21 )
                goto LABEL_4;
              v18[1] = ScanInt(&v21);
              if ( !v21 )
              {
                n2385 = 2568;
                goto LABEL_124;
              }
              v18[2] = ScanInt(&v21);
              if ( !v21 )
                break;
              std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>::push_back((char *)this + 146240, v18);
            }
            n2385 = 2571;
          }
          else
          {
            n2385 = 2625;
          }
          goto LABEL_124;
        }
        ScanFloat(&v21);
        *((float *)this + 36558) = a2;
        if ( !v21 )
        {
          n2385 = 2520;
          goto LABEL_124;
        }
      }
    }
    while ( 1 )
    {
      std::string::string(&v20);
      if ( (unsigned __int8)ScanStr(&v20) == 1 )
      {
        if ( std::operator==<char>(&v20, "default") )
        {
          n2 = 0;
          goto LABEL_28;
        }
        if ( std::operator==<char>(&v20, "event") )
        {
          n2 = 1;
          goto LABEL_28;
        }
        if ( std::operator==<char>(&v20, "event2") )
        {
          n2 = 2;
          goto LABEL_28;
        }
        if ( std::operator==<char>(&v20, "pcroom default") )
        {
          n2 = 3;
          goto LABEL_28;
        }
        if ( std::operator==<char>(&v20, "pcroom event") )
        {
          n2 = 4;
          goto LABEL_28;
        }
        if ( std::operator==<char>(&v20, "pcroom bonus") )
        {
          n2 = 5;
LABEL_28:
          v30 = (char *)this + 12 * n2 + 24;
          for ( GenItemProbIdxEiNS_22eClearRewardDropProb_tE = 0; ; ++GenItemProbIdxEiNS_22eClearRewardDropProb_tE )
          {
            GenItemProbIdxEiNS_22eClearRewardDropProb_tE_1 = std::vector<WongWork::CClearReward::stGenItemProb_t>::size(v30);
            if ( GenItemProbIdxEiNS_22eClearRewardDropProb_tE_1 <= GenItemProbIdxEiNS_22eClearRewardDropProb_tE )
              break;
            v32 = (int *)std::vector<WongWork::CClearReward::stGenItemProb_t>::operator[](
                           v30,
                           GenItemProbIdxEiNS_22eClearRewardDropProb_tE);
            v5 = ScanInt(&v21);
            *v32 = v5;
            if ( !v21 )
            {
              n2385 = 2415;
              n2_1 = 1;
              goto LABEL_38;
            }
            v6 = ScanInt(&v21);
            v32[1] = v6;
            if ( !v21 )
            {
              n2385 = 2417;
              n2_1 = 1;
              goto LABEL_38;
            }
            v7 = ScanInt(&v21);
            v32[2] = v7;
            if ( !v21 )
            {
              n2385 = 2419;
              n2_1 = 1;
              goto LABEL_38;
            }
          }
          n2_1 = 2;
          goto LABEL_38;
        }
        n2385 = 2409;
        n2_1 = 1;
      }
      else
      {
        n2_1 = 0;
      }
LABEL_38:
      std::string::~string(&v20);
      if ( !n2_1 )
        goto LABEL_4;
      if ( n2_1 == 1 )
        goto LABEL_124;
    }
  }
  return 2371;
}

// IDA_EA: 0x853A968
// IDA_NAME: _ZN8WongWork12CClearRewardC2Ei
// DEMANGLED: WongWork::CClearReward::CClearReward(int)
random_option::CRandomOptionItemHandle *__cdecl WongWork::CClearReward::CClearReward(
        WongWork::CClearReward *this,
        int n5)
{
  char *v2; // edi
  int n5_1; // ebx
  char *v4; // edi
  int n5_2; // ebx
  int n200; // [esp+2Ch] [ebp-1Ch]

  WongWork::CItemGenerator::CItemGenerator(this, n5);
  *(_DWORD *)this = &off_8C9A700;
  v2 = (char *)this + 24;
  for ( n5_1 = 5; n5_1 != -1; --n5_1 )
  {
    std::vector<WongWork::CClearReward::stGenItemProb_t>::vector(v2);
    v2 += 12;
  }
  v4 = (char *)this + 96;
  for ( n5_2 = 5; n5_2 != -1; --n5_2 )
  {
    std::vector<WongWork::CClearReward::stGenItemProb_t>::vector(v4);
    v4 += 12;
  }
  WongWork::CItemGenRateTable::CItemGenRateTable((WongWork::CClearReward *)((char *)this + 680));
  std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>::vector((char *)this + 146240);
  std::vector<WongWork::CClearReward::stGoldCardBlankItemInfo_t>::vector((char *)this + 146296);
  for ( n200 = 0; n200 <= 200; ++n200 )
    *((_DWORD *)this + n200 + 36357) = 0;
  *((_DWORD *)this + 36558) = 0;
  *((_DWORD *)this + 36559) = 0;
  *((_DWORD *)this + 36573) = 0;
  memset((char *)this + 146252, 0, 0x28u);
  return WongWork::CItemGenRateTable::set_disable_drop_random_option_item((WongWork::CClearReward *)((char *)this + 680));
}

// IDA_EA: 0x853F17E
// IDA_NAME: _ZN8WongWork12CClearReward25stGoldCardBlankItemInfo_tD2Ev
// DEMANGLED: WongWork::CClearReward::stGoldCardBlankItemInfo_t::~stGoldCardBlankItemInfo_t()
void WongWork::CClearReward::stGoldCardBlankItemInfo_t::~stGoldCardBlankItemInfo_t()
{
  ;
}

// IDA_EA: 0x85BF000
// IDA_NAME: _ZN8WongWork12CClearReward21getGoldCardCreateRateEv
// DEMANGLED: WongWork::CClearReward::getGoldCardCreateRate(void)
long double __cdecl WongWork::CClearReward::getGoldCardCreateRate(WongWork::CClearReward *this)
{
  return *((float *)this + 36558);
}

// IDA_EA: 0x85BF018
// IDA_NAME: _ZNK8WongWork12CClearReward31getRewardItemRatePerMapMaxCountEi
// DEMANGLED: WongWork::CClearReward::getRewardItemRatePerMapMaxCount(int)const
int __cdecl WongWork::CClearReward::getRewardItemRatePerMapMaxCount(WongWork::CClearReward *this, int n9)
{
  if ( n9 > 9 )
    return 0;
  else
    return *((_DWORD *)this + n9 + 36563);
}
