#ifndef __IDA91_WONGWORK_EVENTALTTLE_H__
#define __IDA91_WONGWORK_EVENTALTTLE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: WongWork
// Source unit: WongWork_EventAlttle
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 4805

/* 4805 */
struct WongWork::EventAlttle;

// Exported member functions:
// 0x83FB472	WongWork::EventAlttle::CheckAlreadyGetAlttleItem(unsigned int,int)
// 0x83FB530	WongWork::EventAlttle::UpdateEventAlttleInfo(unsigned int,int)
// 0x83FB595	WongWork::EventAlttle::ArrangeAlttleEventItem(unsigned int,unsigned int)

// Function declaration index:
// DECL 0x83FB472 WongWork::EventAlttle::CheckAlreadyGetAlttleItem
// DECL 0x83FB530 WongWork::EventAlttle::UpdateEventAlttleInfo
// DECL 0x83FB595 WongWork::EventAlttle::ArrangeAlttleEventItem

#endif  // __IDA91_WONGWORK_EVENTALTTLE_H__
