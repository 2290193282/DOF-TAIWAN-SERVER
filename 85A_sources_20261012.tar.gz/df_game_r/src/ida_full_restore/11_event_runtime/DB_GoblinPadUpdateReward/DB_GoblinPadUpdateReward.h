#ifndef __IDA91_DB_GOBLINPADUPDATEREWARD_H__
#define __IDA91_DB_GOBLINPADUPDATEREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_GoblinPadUpdateReward
// Source unit: DB_GoblinPadUpdateReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2558

/* 2558 */
struct DB_GoblinPadUpdateReward;

// Exported member functions:
// 0x842413C	DB_GoblinPadUpdateReward::dispatch(int,int,Stream *)
// 0x8424452	DB_GoblinPadUpdateReward::makeRequest(unsigned int,char,bool,char *)
// 0x844EBB6	DB_GoblinPadUpdateReward::DB_GoblinPadUpdateReward(void)
// 0x845EF08	DB_GoblinPadUpdateReward::~DB_GoblinPadUpdateReward()
// 0x845EF38	DB_GoblinPadUpdateReward::~DB_GoblinPadUpdateReward()

// Function declaration index:
// DECL 0x842413C DB_GoblinPadUpdateReward::dispatch
// DECL 0x8424452 DB_GoblinPadUpdateReward::makeRequest
// DECL 0x844EBB6 DB_GoblinPadUpdateReward::DB_GoblinPadUpdateReward
// DECL 0x845EF08 DB_GoblinPadUpdateReward::~DB_GoblinPadUpdateReward
// DECL 0x845EF38 DB_GoblinPadUpdateReward::~DB_GoblinPadUpdateReward

#endif  // __IDA91_DB_GOBLINPADUPDATEREWARD_H__
