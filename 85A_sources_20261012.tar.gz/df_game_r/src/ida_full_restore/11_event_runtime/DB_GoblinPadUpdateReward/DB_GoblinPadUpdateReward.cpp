#include "DB_GoblinPadUpdateReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x842413C
// IDA_NAME: _ZN24DB_GoblinPadUpdateReward8dispatchEiiP6Stream
// DEMANGLED: DB_GoblinPadUpdateReward::dispatch(int,int,Stream *)
_BOOL4 __cdecl DB_GoblinPadUpdateReward::dispatch(DB_GoblinPadUpdateReward *this, int a2, int a3, Stream *a4)
{
  const char *v4; // eax
  const char *v7; // eax
  __int64 v8; // rax
  const char *v10; // ebx
  const char *v11; // eax
  const char *v12; // ebx
  const char *v13; // eax
  __int64 v14; // rax
  bool v15; // al
  struct tm tp; // [esp+28h] [ebp-80h] BYREF
  char dest[36]; // [esp+54h] [ebp-54h] BYREF
  time_t CurSecEv; // [esp+78h] [ebp-30h] BYREF
  char s_[4]; // [esp+7Eh] [ebp-2Ah] BYREF
  int v20; // [esp+82h] [ebp-26h]
  __int16 v21; // [esp+86h] [ebp-22h]
  time_t timer; // [esp+88h] [ebp-20h] BYREF
  char s[4]; // [esp+8Eh] [ebp-1Ah] BYREF
  int v24; // [esp+92h] [ebp-16h]
  __int16 v25; // [esp+96h] [ebp-12h]
  MySQL *DBHandle; // [esp+98h] [ebp-10h]
  int Out; // [esp+9Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 6, 0);
  Out = Stream::GetOutBuffer<SIG_GOBLIN_UPDATE_REWARD>(a4);
  v4 = (const char *)NumberToString(*(_DWORD *)Out, 0);
  MySQL::set_query(DBHandle, "seLect mousepass from member_mousepass where m_id=%s", v4);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1
    || !MySQL::get_n_rows(DBHandle)
    || (unsigned __int8)MySQL::fetch(DBHandle) != 1 )
  {
    return 0;
  }
  if ( (unsigned __int8)MySQL::get_str(DBHandle, 0, dest, 36) != 1 )
    return 0;
  if ( *(_BYTE *)(Out + 4) == 2 || !*(_BYTE *)(Out + 5) )
  {
    *(_DWORD *)s_ = 0;
    v20 = 0;
    v21 = 0;
    CurSecEv = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
    localtime_r(&CurSecEv, &tp);
    strftime(s_, 0xAu, "%Y%m", &tp);
    v12 = (const char *)(Out + 6);
    v13 = (const char *)NumberToString(*(_DWORD *)Out, 0);
    MySQL::set_query(
      DBHandle,
      "inSert into member_mousepass_history_%s (occ_time, m_id, pre_mousepass, modify_type, ip_info, port_info) values (n"
      "ow(),%s,'%s',%d,'%s','')",
      s_,
      v13,
      dest,
      15,
      v12);
  }
  else
  {
    *(_DWORD *)s = 0;
    v24 = 0;
    v25 = 0;
    timer = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
    localtime_r(&timer, &tp);
    strftime(s, 0xAu, "%Y%m", &tp);
    v7 = (const char *)NumberToString(*(_DWORD *)Out, 0);
    MySQL::set_query(
      DBHandle,
      "upDate member_mousepass set reward_time = unix_timestamp(now()) where m_id=%s and enable_flag = '1'",
      v7);
    if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
      return 0;
    LODWORD(v8) = MySQL::getAffectedRowCount(DBHandle);
    if ( !v8 )
      return 0;
    v10 = (const char *)(Out + 6);
    v11 = (const char *)NumberToString(*(_DWORD *)Out, 0);
    MySQL::set_query(
      DBHandle,
      "inSert into member_mousepass_history_%s (occ_time, m_id, pre_mousepass, modify_type, ip_info, port_info) values (n"
      "ow(),%s,'%s',%d,'%s','')",
      s,
      v11,
      dest,
      16,
      v10);
  }
  v15 = 1;
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) == 1 )
  {
    LODWORD(v14) = MySQL::getAffectedRowCount(DBHandle);
    if ( v14 )
      v15 = 0;
  }
  return !v15;
}

// IDA_EA: 0x8424452
// IDA_NAME: _ZN24DB_GoblinPadUpdateReward11makeRequestEjcbPc
// DEMANGLED: DB_GoblinPadUpdateReward::makeRequest(unsigned int,char,bool,char *)
void __cdecl DB_GoblinPadUpdateReward::makeRequest(DB_GoblinPadUpdateReward *this, char a2, char a3, char *src)
{
  Stream *v4; // eax
  Stream **v5; // eax
  Stream **v6; // eax
  int v7; // eax
  _BYTE v8[8]; // [esp+24h] [ebp-14h] BYREF
  int v9; // [esp+2Ch] [ebp-Ch]

  v4 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 24515);
  CStreamGuard::CStreamGuard((CStreamGuard *)v8, v4, 1);
  v5 = (Stream **)CStreamGuard::operator*((int)v8);
  CStreamGuard::operator<<(v5, 43);
  v6 = (Stream **)CStreamGuard::operator*((int)v8);
  CStreamGuard::operator<<(v6, -1);
  v7 = CStreamGuard::operator->((int)v8);
  v9 = CStreamGuard::GetInBuffer<SIG_GOBLIN_UPDATE_REWARD>(v7);
  *(_DWORD *)v9 = this;
  *(_BYTE *)(v9 + 4) = a2;
  *(_BYTE *)(v9 + 5) = a3;
  strncpy((char *)(v9 + 6), src, 0x10u);
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v8);
  CStreamGuard::~CStreamGuard((CStreamGuard *)v8);
}

// IDA_EA: 0x844EBB6
// IDA_NAME: _ZN24DB_GoblinPadUpdateRewardC2Ev
// DEMANGLED: DB_GoblinPadUpdateReward::DB_GoblinPadUpdateReward(void)
void __cdecl DB_GoblinPadUpdateReward::DB_GoblinPadUpdateReward(DB_GoblinPadUpdateReward *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5F4F8;
}

// IDA_EA: 0x845EF08
// IDA_NAME: _ZN24DB_GoblinPadUpdateRewardD2Ev
// DEMANGLED: DB_GoblinPadUpdateReward::~DB_GoblinPadUpdateReward()
void __cdecl DB_GoblinPadUpdateReward::~DB_GoblinPadUpdateReward(DB_GoblinPadUpdateReward *this)
{
  *(_DWORD *)this = &off_8C5F4F8;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845EF38
// IDA_NAME: _ZN24DB_GoblinPadUpdateRewardD0Ev
// DEMANGLED: DB_GoblinPadUpdateReward::~DB_GoblinPadUpdateReward()
void __cdecl DB_GoblinPadUpdateReward::~DB_GoblinPadUpdateReward(DB_GoblinPadUpdateReward *this)
{
  DB_GoblinPadUpdateReward::~DB_GoblinPadUpdateReward(this);
  operator delete(this);
}
