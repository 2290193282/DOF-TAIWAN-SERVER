#ifndef __IDA91_CCLEARREWARDCARDEVENT_H__
#define __IDA91_CCLEARREWARDCARDEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CClearRewardCardEvent
// Source unit: CClearRewardCardEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 1183

/* 1183 */
struct CClearRewardCardEvent;

// Exported member functions:
// 0x810A720	CClearRewardCardEvent::CClearRewardCardEvent(void)
// 0x810A73C	CClearRewardCardEvent::~CClearRewardCardEvent()
// 0x810A76C	CClearRewardCardEvent::~CClearRewardCardEvent()
// 0x810A78A	CClearRewardCardEvent::StartEvent(void)
// 0x810A790	CClearRewardCardEvent::StartEvent(Word_Param)
// 0x810A7E2	CClearRewardCardEvent::EndEvent(void)

// Function declaration index:
// DECL 0x810A720 CClearRewardCardEvent::CClearRewardCardEvent
// DECL 0x810A73C CClearRewardCardEvent::~CClearRewardCardEvent
// DECL 0x810A76C CClearRewardCardEvent::~CClearRewardCardEvent
// DECL 0x810A78A CClearRewardCardEvent::StartEvent
// DECL 0x810A790 CClearRewardCardEvent::StartEvent
// DECL 0x810A7E2 CClearRewardCardEvent::EndEvent

#endif  // __IDA91_CCLEARREWARDCARDEVENT_H__
