#include "CClearRewardCardEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x810A720
// IDA_NAME: _ZN21CClearRewardCardEventC2Ev
// DEMANGLED: CClearRewardCardEvent::CClearRewardCardEvent(void)
void __cdecl CClearRewardCardEvent::CClearRewardCardEvent(CClearRewardCardEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B49EE8;
}

// IDA_EA: 0x810A73C
// IDA_NAME: _ZN21CClearRewardCardEventD2Ev
// DEMANGLED: CClearRewardCardEvent::~CClearRewardCardEvent()
void __cdecl CClearRewardCardEvent::~CClearRewardCardEvent(CClearRewardCardEvent *this)
{
  *(_DWORD *)this = off_8B49EE8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x810A76C
// IDA_NAME: _ZN21CClearRewardCardEventD0Ev
// DEMANGLED: CClearRewardCardEvent::~CClearRewardCardEvent()
void __cdecl CClearRewardCardEvent::~CClearRewardCardEvent(CClearRewardCardEvent *this)
{
  CClearRewardCardEvent::~CClearRewardCardEvent(this);
  operator delete(this);
}

// IDA_EA: 0x810A78A
// IDA_NAME: _ZN21CClearRewardCardEvent10StartEventEv
// DEMANGLED: CClearRewardCardEvent::StartEvent(void)
void CClearRewardCardEvent::StartEvent()
{
  ;
}

// IDA_EA: 0x810A790
// IDA_NAME: _ZN21CClearRewardCardEvent10StartEventE10Word_Param
// DEMANGLED: CClearRewardCardEvent::StartEvent(Word_Param)
int __cdecl CClearRewardCardEvent::StartEvent(CEventBase *a1)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 24, 0);
  return cMyTrace::operator()((int)v3, "Clear reward card event Start", v2);
}

// IDA_EA: 0x810A7E2
// IDA_NAME: _ZN21CClearRewardCardEvent8EndEventEv
// DEMANGLED: CClearRewardCardEvent::EndEvent(void)
int __cdecl CClearRewardCardEvent::EndEvent(CClearRewardCardEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "EndEvent", 30, 0);
  return cMyTrace::operator()((int)v3, "Clear reward card event End", v2);
}
