#include "Packet_Monitor_Event_End.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x826889A
// IDA_NAME: _ZN24Packet_Monitor_Event_EndC2Ev
// DEMANGLED: Packet_Monitor_Event_End::Packet_Monitor_Event_End(void)
void __cdecl Packet_Monitor_Event_End::Packet_Monitor_Event_End(Packet_Monitor_Event_End *this)
{
  PacketHeader::PacketHeader(this, 0x450u, 0xEu);
}
