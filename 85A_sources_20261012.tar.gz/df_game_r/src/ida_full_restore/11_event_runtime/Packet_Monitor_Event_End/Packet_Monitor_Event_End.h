#ifndef __IDA91_PACKET_MONITOR_EVENT_END_H__
#define __IDA91_PACKET_MONITOR_EVENT_END_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Packet_Monitor_Event_End
// Source unit: Packet_Monitor_Event_End
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "network/PacketGuard.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 2129

/* 2129 */
struct Packet_Monitor_Event_End;

// Exported member functions:
// 0x826889A	Packet_Monitor_Event_End::Packet_Monitor_Event_End(void)

// Function declaration index:
// DECL 0x826889A Packet_Monitor_Event_End::Packet_Monitor_Event_End

#endif  // __IDA91_PACKET_MONITOR_EVENT_END_H__
