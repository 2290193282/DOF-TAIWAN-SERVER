#include "stConditionEventInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x837C8C6
// IDA_NAME: _ZN20stConditionEventInfoC2Ev
// DEMANGLED: stConditionEventInfo::stConditionEventInfo(void)
void __cdecl stConditionEventInfo::stConditionEventInfo(stConditionEventInfo *this)
{
  std::map<int,std::pair<int,int>>::map((int)this + 8);
  std::multimap<int,stConditionEventRewardInfo>::multimap((char *)this + 32);
  std::multimap<int,stConditionEventRewardInfo>::multimap((char *)this + 56);
}

// IDA_EA: 0x837C938
// IDA_NAME: _ZN20stConditionEventInfoD2Ev
// DEMANGLED: stConditionEventInfo::~stConditionEventInfo()
void __cdecl stConditionEventInfo::~stConditionEventInfo(stConditionEventInfo *this)
{
  std::multimap<int,stConditionEventRewardInfo>::~multimap((int)this + 56);
  std::multimap<int,stConditionEventRewardInfo>::~multimap((int)this + 32);
  std::map<int,std::pair<int,int>>::~map((int)this + 8);
}
