#ifndef __IDA91_STCONDITIONEVENTINFO_H__
#define __IDA91_STCONDITIONEVENTINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stConditionEventInfo
// Source unit: stConditionEventInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4691

/* 4691 */
struct stConditionEventInfo;

// Exported member functions:
// 0x837C8C6	stConditionEventInfo::stConditionEventInfo(void)
// 0x837C938	stConditionEventInfo::~stConditionEventInfo()

// Function declaration index:
// DECL 0x837C8C6 stConditionEventInfo::stConditionEventInfo
// DECL 0x837C938 stConditionEventInfo::~stConditionEventInfo

#endif  // __IDA91_STCONDITIONEVENTINFO_H__
