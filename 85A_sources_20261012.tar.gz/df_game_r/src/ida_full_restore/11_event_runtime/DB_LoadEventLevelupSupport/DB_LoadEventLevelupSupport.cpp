#include "DB_LoadEventLevelupSupport.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x844CD38
// IDA_NAME: _ZN26DB_LoadEventLevelupSupport8dispatchEiiP6Stream
// DEMANGLED: DB_LoadEventLevelupSupport::dispatch(int,int,Stream *)
int __cdecl DB_LoadEventLevelupSupport::dispatch(DB_LoadEventLevelupSupport *this, int a2, char src, Stream *a4)
{
  _DWORD *exception; // eax
  Stream *v6; // eax
  Stream **v7; // eax
  Stream **v8; // eax
  int v9; // eax
  _DWORD *v10; // eax
  _DWORD *v11; // eax
  _DWORD *v12; // eax
  unsigned __int16 v14; // [esp+1Ch] [ebp-4Ch] BYREF
  unsigned __int16 v15; // [esp+1Eh] [ebp-4Ah] BYREF
  _BYTE v16[8]; // [esp+20h] [ebp-48h] BYREF
  int dest; // [esp+28h] [ebp-40h] BYREF
  int v18[4]; // [esp+2Ch] [ebp-3Ch] BYREF
  MySQL *DBHandle; // [esp+4Ch] [ebp-1Ch]
  int *v20; // [esp+50h] [ebp-18h]
  int n_rowsEv; // [esp+54h] [ebp-14h]
  int n_rowsEv_1; // [esp+58h] [ebp-10h]

  dest = 0;
  Stream::operator>>(a4, &dest);
  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 2, 0);
  if ( DBHandle )
  {
    MySQL::set_query(DBHandle, "seLect level, state from event_levelup_support where charac_no=%d", dest);
    if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
    {
      exception = _cxa_allocate_exception(4u);
      *exception = 49783;
      _cxa_throw(exception, (struct type_info *)&`typeinfo for'int, 0);
    }
    v6 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 49785);
    CStreamGuard::CStreamGuard((CStreamGuard *)v16, v6, 1);
    v7 = (Stream **)CStreamGuard::operator*((int)v16);
    CStreamGuard::operator<<(v7, 80);
    v8 = (Stream **)CStreamGuard::operator*((int)v16);
    CStreamGuard::operator<<(v8, src);
    v9 = CStreamGuard::operator->((int)v16);
    v20 = (int *)CStreamGuard::GetInBuffer<SIG_EVENT_LEVEUP_SUPPORT_INFO>(v9);
    n_rowsEv = MySQL::get_n_rows(DBHandle);
    *v20 = n_rowsEv;
    v15 = 0;
    v14 = 0;
    for ( n_rowsEv_1 = 0; n_rowsEv_1 < n_rowsEv; ++n_rowsEv_1 )
    {
      if ( (unsigned __int8)MySQL::fetch(DBHandle) != 1 )
      {
        v10 = _cxa_allocate_exception(4u);
        *v10 = 49804;
        _cxa_throw(v10, (struct type_info *)&`typeinfo for'int, 0);
      }
      if ( (unsigned __int8)MySQL::get_ushort(DBHandle, 0, &v15) != 1 )
      {
        v11 = _cxa_allocate_exception(4u);
        *v11 = 49805;
        _cxa_throw(v11, (struct type_info *)&`typeinfo for'int, 0);
      }
      if ( (unsigned __int8)MySQL::get_ushort(DBHandle, 1, &v14) != 1 )
      {
        v12 = _cxa_allocate_exception(4u);
        *v12 = 49806;
        _cxa_throw(v12, (struct type_info *)&`typeinfo for'int, 0);
      }
      LOWORD(v20[n_rowsEv_1 + 1]) = v15;
      HIWORD(v20[n_rowsEv_1 + 1]) = v14;
    }
    MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 1, (CStreamGuard *)v16);
    CStreamGuard::~CStreamGuard((CStreamGuard *)v16);
    return 1;
  }
  else
  {
    cMyTrace::cMyTrace(
      (cMyTrace *)v18,
      "virtual bool DB_LoadEventLevelupSupport::dispatch(int, int, Stream*)",
      49773,
      5);
    cMyTrace::operator()((int)v18, "[ERROR] Database Handle is NULL [index:%d]", 2);
    return 0;
  }
}

// IDA_EA: 0x844D0A6
// IDA_NAME: _ZN26DB_LoadEventLevelupSupport11makeRequestEii
// DEMANGLED: DB_LoadEventLevelupSupport::makeRequest(int,int)
void __cdecl DB_LoadEventLevelupSupport::makeRequest(DB_LoadEventLevelupSupport *this, char CurCharacNoEv)
{
  Stream *v2; // eax
  Stream **v3; // eax
  Stream **v4; // eax
  Stream **v5; // eax
  _BYTE v6[16]; // [esp+18h] [ebp-10h] BYREF

  v2 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 49824);
  CStreamGuard::CStreamGuard((CStreamGuard *)v6, v2, 1);
  v3 = (Stream **)CStreamGuard::operator*((int)v6);
  CStreamGuard::operator<<(v3, 80);
  v4 = (Stream **)CStreamGuard::operator*((int)v6);
  CStreamGuard::operator<<(v4, (char)this);
  v5 = (Stream **)CStreamGuard::operator*((int)v6);
  CStreamGuard::operator<<(v5, CurCharacNoEv);
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v6);
  CStreamGuard::~CStreamGuard((CStreamGuard *)v6);
}

// IDA_EA: 0x844FFD6
// IDA_NAME: _ZN26DB_LoadEventLevelupSupportC2Ev
// DEMANGLED: DB_LoadEventLevelupSupport::DB_LoadEventLevelupSupport(void)
void __cdecl DB_LoadEventLevelupSupport::DB_LoadEventLevelupSupport(DB_LoadEventLevelupSupport *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5DF08;
}

// IDA_EA: 0x845A758
// IDA_NAME: _ZN26DB_LoadEventLevelupSupportD2Ev
// DEMANGLED: DB_LoadEventLevelupSupport::~DB_LoadEventLevelupSupport()
void __cdecl DB_LoadEventLevelupSupport::~DB_LoadEventLevelupSupport(DB_LoadEventLevelupSupport *this)
{
  *(_DWORD *)this = &off_8C5DF08;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845A788
// IDA_NAME: _ZN26DB_LoadEventLevelupSupportD0Ev
// DEMANGLED: DB_LoadEventLevelupSupport::~DB_LoadEventLevelupSupport()
void __cdecl DB_LoadEventLevelupSupport::~DB_LoadEventLevelupSupport(DB_LoadEventLevelupSupport *this)
{
  DB_LoadEventLevelupSupport::~DB_LoadEventLevelupSupport(this);
  operator delete(this);
}
