#ifndef __IDA91_DB_LOADEVENTLEVELUPSUPPORT_H__
#define __IDA91_DB_LOADEVENTLEVELUPSUPPORT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_LoadEventLevelupSupport
// Source unit: DB_LoadEventLevelupSupport
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2741

/* 2741 */
struct DB_LoadEventLevelupSupport;

// Exported member functions:
// 0x844CD38	DB_LoadEventLevelupSupport::dispatch(int,int,Stream *)
// 0x844D0A6	DB_LoadEventLevelupSupport::makeRequest(int,int)
// 0x844FFD6	DB_LoadEventLevelupSupport::DB_LoadEventLevelupSupport(void)
// 0x845A758	DB_LoadEventLevelupSupport::~DB_LoadEventLevelupSupport()
// 0x845A788	DB_LoadEventLevelupSupport::~DB_LoadEventLevelupSupport()

// Function declaration index:
// DECL 0x844CD38 DB_LoadEventLevelupSupport::dispatch
// DECL 0x844D0A6 DB_LoadEventLevelupSupport::makeRequest
// DECL 0x844FFD6 DB_LoadEventLevelupSupport::DB_LoadEventLevelupSupport
// DECL 0x845A758 DB_LoadEventLevelupSupport::~DB_LoadEventLevelupSupport
// DECL 0x845A788 DB_LoadEventLevelupSupport::~DB_LoadEventLevelupSupport

#endif  // __IDA91_DB_LOADEVENTLEVELUPSUPPORT_H__
