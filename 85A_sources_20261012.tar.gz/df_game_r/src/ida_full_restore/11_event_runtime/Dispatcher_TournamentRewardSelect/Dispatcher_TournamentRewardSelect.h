#ifndef __IDA91_DISPATCHER_TOURNAMENTREWARDSELECT_H__
#define __IDA91_DISPATCHER_TOURNAMENTREWARDSELECT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Dispatcher_TournamentRewardSelect
// Source unit: Dispatcher_TournamentRewardSelect
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 4323

/* 4323 */
struct Dispatcher_TournamentRewardSelect;

// Exported member functions:
// 0x81DFFDA	Dispatcher_TournamentRewardSelect::read(PacketBuf &,MSG_BASE &)
// 0x81E00F0	Dispatcher_TournamentRewardSelect::process(CUser *,MSG_BASE &,ParamBase &)
// 0x81E02B0	Dispatcher_TournamentRewardSelect::send(CUser *,ParamBase &)
// 0x81E046C	Dispatcher_TournamentRewardSelect::check_error(CUser *,MSG_BASE &)
// 0x8244356	Dispatcher_TournamentRewardSelect::~Dispatcher_TournamentRewardSelect()
// 0x8244386	Dispatcher_TournamentRewardSelect::~Dispatcher_TournamentRewardSelect()
// 0x8597B26	Dispatcher_TournamentRewardSelect::Dispatcher_TournamentRewardSelect(void)

// Function declaration index:
// DECL 0x81DFFDA Dispatcher_TournamentRewardSelect::read
// DECL 0x81E00F0 Dispatcher_TournamentRewardSelect::process
// DECL 0x81E02B0 Dispatcher_TournamentRewardSelect::send
// DECL 0x81E046C Dispatcher_TournamentRewardSelect::check_error
// DECL 0x8244356 Dispatcher_TournamentRewardSelect::~Dispatcher_TournamentRewardSelect
// DECL 0x8244386 Dispatcher_TournamentRewardSelect::~Dispatcher_TournamentRewardSelect
// DECL 0x8597B26 Dispatcher_TournamentRewardSelect::Dispatcher_TournamentRewardSelect

#endif  // __IDA91_DISPATCHER_TOURNAMENTREWARDSELECT_H__
