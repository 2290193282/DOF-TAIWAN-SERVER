#include "Dispatcher_TournamentRewardSelect.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81DFFDA
// IDA_NAME: _ZN33Dispatcher_TournamentRewardSelect4readER9PacketBufR8MSG_BASE
// DEMANGLED: Dispatcher_TournamentRewardSelect::read(PacketBuf &,MSG_BASE &)
int __cdecl Dispatcher_TournamentRewardSelect::read(
        Dispatcher_TournamentRewardSelect *this,
        PacketBuf *a2,
        MSG_BASE *a3)
{
  if ( (unsigned __int8)PacketBuf::get_byte(a2, (char *)a3 + 13) != 1 )
    return LineFunc(21245, "virtual int Dispatcher_TournamentRewardSelect::read(PacketBuf&, MSG_BASE&)", 0, 0);
  if ( *((_BYTE *)a3 + 13) >= 2u )
    return LineFunc(21248, "virtual int Dispatcher_TournamentRewardSelect::read(PacketBuf&, MSG_BASE&)", 0, 0);
  if ( (unsigned __int8)PacketBuf::get_byte(a2, (char *)a3 + 14) != 1 )
    return LineFunc(21251, "virtual int Dispatcher_TournamentRewardSelect::read(PacketBuf&, MSG_BASE&)", 0, 0);
  if ( *((_BYTE *)a3 + 14) < 2u )
    return 0;
  return LineFunc(21254, "virtual int Dispatcher_TournamentRewardSelect::read(PacketBuf&, MSG_BASE&)", 0, 0);
}

// IDA_EA: 0x81E00F0
// IDA_NAME: _ZN33Dispatcher_TournamentRewardSelect7processEP5CUserR8MSG_BASER9ParamBase
// DEMANGLED: Dispatcher_TournamentRewardSelect::process(CUser *,MSG_BASE &,ParamBase &)
int __cdecl Dispatcher_TournamentRewardSelect::process(
        Dispatcher_TournamentRewardSelect *this,
        CUser *a2,
        MSG_BASE *a3,
        ParamBase *a4)
{
  int v4; // ebx
  char PartyIndex; // bl
  CGameManager *v6; // eax
  char v7; // si
  char v8; // bl
  int MemberSlotNo; // eax
  int v11[3]; // [esp+10h] [ebp-28h] BYREF
  ParamBase *v12; // [esp+1Ch] [ebp-1Ch]
  MSG_BASE *v13; // [esp+20h] [ebp-18h]
  CParty *Party; // [esp+24h] [ebp-14h]
  CTournamentDungeonReward *v15; // [esp+28h] [ebp-10h]
  char isCardSelectComplete; // [esp+2Eh] [ebp-Ah]

  v12 = a4;
  *((_DWORD *)a4 + 1) = Dispatcher_TournamentRewardSelect::check_error(this, a2, a3);
  if ( *((int *)v12 + 1) > 0 )
    return 0;
  if ( *((int *)v12 + 1) < 0 )
    return LineFunc(
             21269,
             "virtual int Dispatcher_TournamentRewardSelect::process(CUser*, MSG_BASE&, ParamBase&)",
             *((_DWORD *)v12 + 1),
             0);
  v13 = a3;
  PartyIndex = CUser::GetPartyIndex(a2);
  v6 = (CGameManager *)G_CGameManager();
  Party = (CParty *)CGameManager::GetParty(v6, PartyIndex);
  if ( !Party )
    return LineFunc(
             21276,
             "virtual int Dispatcher_TournamentRewardSelect::process(CUser*, MSG_BASE&, ParamBase&)",
             0,
             0);
  std::vector<int>::vector((int)v11);
  CParty::GetValidPartyMember(Party, (int)v11);
  v15 = (CParty *)((char *)Party + 6076);
  isCardSelectComplete = CTournamentDungeonReward::isCardSelectComplete((char *)Party + 6076, 2, v11);
  if ( isCardSelectComplete == 1 )
  {
    *((_DWORD *)v12 + 1) = 0x7FFFFFFF;
    v4 = 0;
  }
  else
  {
    v7 = *((_BYTE *)v13 + 14);
    v8 = *((_BYTE *)v13 + 13);
    MemberSlotNo = CParty::GetMemberSlotNo(Party, a2);
    if ( !(unsigned __int8)CTournamentDungeonReward::SelectCard(v15, MemberSlotNo, v8, v7) )
      *((_DWORD *)v12 + 1) = 0x7FFFFFFF;
    v4 = 0;
  }
  std::vector<int>::~vector(v11);
  return v4;
}

// IDA_EA: 0x81E02B0
// IDA_NAME: _ZN33Dispatcher_TournamentRewardSelect4sendEP5CUserR9ParamBase
// DEMANGLED: Dispatcher_TournamentRewardSelect::send(CUser *,ParamBase &)
void __cdecl Dispatcher_TournamentRewardSelect::send(Dispatcher_TournamentRewardSelect *this, CUser *a2, ParamBase *a3)
{
  char PartyIndex; // bl
  CGameManager *v4; // eax
  int v5[3]; // [esp+18h] [ebp-30h] BYREF
  PacketBuf *v6[3]; // [esp+24h] [ebp-24h] BYREF
  ParamBase *v7; // [esp+30h] [ebp-18h]
  CParty *Party; // [esp+34h] [ebp-14h]
  CTournamentDungeonReward *v9; // [esp+38h] [ebp-10h]
  bool isTournamentVictory; // [esp+3Fh] [ebp-9h]

  v7 = a3;
  PacketGuard::PacketGuard((PacketGuard *)v6);
  InterfacePacketBuf::clear(v6);
  InterfacePacketBuf::put_header(v6, 1, 459);
  if ( !*((_DWORD *)v7 + 1) )
  {
    InterfacePacketBuf::put_byte(v6, 1);
    PartyIndex = CUser::GetPartyIndex(a2);
    v4 = (CGameManager *)G_CGameManager();
    Party = (CParty *)CGameManager::GetParty(v4, PartyIndex);
    if ( Party )
    {
      v9 = (CParty *)((char *)Party + 6076);
      CTournamentDungeonReward::MakeSelectPacket((CParty *)((char *)Party + 6076), (PacketGuard *)v6);
      InterfacePacketBuf::finalize(v6, 1);
      CParty::send_to_party(Party, (PacketGuard *)v6);
      if ( (unsigned __int8)CParty::CheckRecvFromAllMember(Party, a2) == 1 )
      {
        std::vector<int>::vector((int)v5);
        CParty::GetValidPartyMember(Party, (int)v5);
        if ( (unsigned __int8)CTournamentDungeonReward::isCardSelectComplete((char *)v9, 2, v5) == 1 )
        {
          isTournamentVictory = CParty::isTournamentVictory(Party);
          CParty::SetTournamentDungeonClearState(Party, 3);
          CParty::TournamentDungeonClear(Party, isTournamentVictory);
        }
        std::vector<int>::~vector(v5);
      }
    }
  }
  PacketGuard::~PacketGuard(v6);
}

// IDA_EA: 0x81E046C
// IDA_NAME: _ZN33Dispatcher_TournamentRewardSelect11check_errorEP5CUserR8MSG_BASE
// DEMANGLED: Dispatcher_TournamentRewardSelect::check_error(CUser *,MSG_BASE &)
int __cdecl Dispatcher_TournamentRewardSelect::check_error(Dispatcher_TournamentRewardSelect *this, CUser *a2)
{
  char PartyIndex; // bl
  CGameManager *v4; // eax
  CParty *Party; // [esp+1Ch] [ebp-Ch]

  if ( !a2 )
    return -1;
  if ( CUser::get_state(a2) != 5 )
    return 0x7FFFFFFF;
  PartyIndex = CUser::GetPartyIndex(a2);
  v4 = (CGameManager *)G_CGameManager();
  Party = (CParty *)CGameManager::GetParty(v4, PartyIndex);
  if ( !Party )
    return -1;
  if ( (unsigned __int8)CParty::GetTournamentDungeonClearState(Party) == 2 )
    return 0;
  return 0x7FFFFFFF;
}

// IDA_EA: 0x8244356
// IDA_NAME: _ZN33Dispatcher_TournamentRewardSelectD2Ev
// DEMANGLED: Dispatcher_TournamentRewardSelect::~Dispatcher_TournamentRewardSelect()
void __cdecl Dispatcher_TournamentRewardSelect::~Dispatcher_TournamentRewardSelect(
        Dispatcher_TournamentRewardSelect *this)
{
  *(_DWORD *)this = &off_8BDA208;
  IPacketDispatcher<MsgTournamentRewardSelect,stTournamentRewardSelect,(ch_state)0>::~IPacketDispatcher(this);
}

// IDA_EA: 0x8244386
// IDA_NAME: _ZN33Dispatcher_TournamentRewardSelectD0Ev
// DEMANGLED: Dispatcher_TournamentRewardSelect::~Dispatcher_TournamentRewardSelect()
void __cdecl Dispatcher_TournamentRewardSelect::~Dispatcher_TournamentRewardSelect(
        Dispatcher_TournamentRewardSelect *this)
{
  Dispatcher_TournamentRewardSelect::~Dispatcher_TournamentRewardSelect(this);
  operator delete(this);
}

// IDA_EA: 0x8597B26
// IDA_NAME: _ZN33Dispatcher_TournamentRewardSelectC2Ev
// DEMANGLED: Dispatcher_TournamentRewardSelect::Dispatcher_TournamentRewardSelect(void)
void __cdecl Dispatcher_TournamentRewardSelect::Dispatcher_TournamentRewardSelect(
        Dispatcher_TournamentRewardSelect *this)
{
  IPacketDispatcher<MsgTournamentRewardSelect,stTournamentRewardSelect,(ch_state)0>::IPacketDispatcher(this);
  *(_DWORD *)this = &off_8BDA208;
}
