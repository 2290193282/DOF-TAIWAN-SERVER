#ifndef __IDA91_CEVENTMANAGER_H__
#define __IDA91_CEVENTMANAGER_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CEventManager
// Source unit: CEventManager
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 1204

/* 1204 */
struct CEventManager;

// Exported member functions:
// 0x8114CE4	CEventManager::CEventManager(void)
// 0x8114D4E	CEventManager::~CEventManager()
// 0x8114DCC	CEventManager::InitEventManager(void)
// 0x8115982	CEventManager::AddEvent(int,CEventBase *)
// 0x8115998	CEventManager::GetRepeatEvent(int)
// 0x81159B6	CEventManager::LoadEventFromDB(void)
// 0x8115CC6	CEventManager::TriggerEventStart(int,Word_Param)
// 0x8115D60	CEventManager::TriggerEventEnd(int)
// 0x8115DE2	CEventManager::MakeNotiEventInfo(PacketGuard &,CUser *)
// 0x8116108	CEventManager::BroadcastEventInfo(void)
// 0x8116212	CEventManager::IsExistOverlappedExpBonusEvent(void)
// 0x8116276	CEventManager::changeCharacName(CUser *,int,char *,int)
// 0x811630E	CEventManager::dailyresetData(void)
// 0x8116874	CEventManager::eventDeliveryNotify(int,DeliveryMsg &)

// Function declaration index:
// DECL 0x8114CE4 CEventManager::CEventManager
// DECL 0x8114D4E CEventManager::~CEventManager
// DECL 0x8114DCC CEventManager::InitEventManager
// DECL 0x8115982 CEventManager::AddEvent
// DECL 0x8115998 CEventManager::GetRepeatEvent
// DECL 0x81159B6 CEventManager::LoadEventFromDB
// DECL 0x8115CC6 CEventManager::TriggerEventStart
// DECL 0x8115D60 CEventManager::TriggerEventEnd
// DECL 0x8115DE2 CEventManager::MakeNotiEventInfo
// DECL 0x8116108 CEventManager::BroadcastEventInfo
// DECL 0x8116212 CEventManager::IsExistOverlappedExpBonusEvent
// DECL 0x8116276 CEventManager::changeCharacName
// DECL 0x811630E CEventManager::dailyresetData
// DECL 0x8116874 CEventManager::eventDeliveryNotify

#endif  // __IDA91_CEVENTMANAGER_H__
