#include "CEventManager.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8114CE4
// IDA_NAME: _ZN13CEventManagerC2Ev
// DEMANGLED: CEventManager::CEventManager(void)
void __cdecl CEventManager::CEventManager(CEventManager *this)
{
  CDelivery *v1; // ebx

  memset(this, 0, 0x298u);
  v1 = (CDelivery *)operator new(0x18u);
  CDelivery::CDelivery(v1);
  *((_DWORD *)this + 166) = v1;
}

// IDA_EA: 0x8114D4E
// IDA_NAME: _ZN13CEventManagerD2Ev
// DEMANGLED: CEventManager::~CEventManager()
void __cdecl CEventManager::~CEventManager(CEventManager *this)
{
  void *v1; // ebx
  int n165; // [esp+1Ch] [ebp-Ch]

  for ( n165 = 0; n165 <= 165; ++n165 )
  {
    if ( *((_DWORD *)this + n165) )
      (*(void (__cdecl **)(_DWORD))(**((_DWORD **)this + n165) + 4))(*((_DWORD *)this + n165));
  }
  v1 = (void *)*((_DWORD *)this + 166);
  if ( v1 )
  {
    CDelivery::~CDelivery(*((CDelivery **)this + 166));
    operator delete(v1);
  }
}

// IDA_EA: 0x8114DCC
// IDA_NAME: _ZN13CEventManager16InitEventManagerEv
// DEMANGLED: CEventManager::InitEventManager(void)
_BOOL4 __cdecl CEventManager::InitEventManager(CEventManager *this)
{
  CUnlimitFatigueEvent *v1; // ebx
  CMaxFatigueFactorEvent *v2; // ebx
  CExpDoubleEvent *v3; // ebx
  CCoinEventPerDay *v4; // ebx
  CCoinEventOnCharCreate *v5; // ebx
  CLeadingChannelEvent *v6; // ebx
  CItemDropRatioEvent *v7; // ebx
  CPCRoomBurningEvent *v8; // ebx
  CGuildWarEvent *v9; // ebx
  CPCRoomFatigueEvent *v10; // ebx
  CReformingDanjinEvent *v11; // ebx
  CCoinRefillEvent *v12; // ebx
  CBurningFatigueEvent *v13; // ebx
  CClearRewardCardEvent *v14; // ebx
  CCeraShopBonusItemEvent *v15; // ebx
  CTournamentPvPEvent *v16; // ebx
  CGoldCardBlankItemEvent *v17; // ebx
  CPcRoomCardBlankItemEvent *v18; // ebx
  CPowerWarEvent *v19; // ebx
  CCollectArchieveEventLog *v20; // ebx
  CPCRoomWorldDropEvent *v21; // ebx
  CPartyExpBonusEvent *v22; // ebx
  CStabToDeathEvent *v23; // ebx
  CSchoolMatchEvent *v24; // ebx
  CAutoMarketConditionsControlEvent *v25; // ebx
  CVendingMachineBonusEvent *v26; // ebx
  CBurnigGoldMonsterEvent *v27; // ebx
  CNoNeedGoldOnGuildCreateEvent *v28; // ebx
  CDeathTowerWinPointEvent *v29; // ebx
  CNotApplyBalkeunEvent *v30; // ebx
  CCharacterDayEvent *v31; // ebx
  CRestrictCharacCreationEvent *v32; // ebx
  CReduceUpgradeItemPay *v33; // ebx
  COnTimeEvent *v34; // ebx
  CBreakAwayPreventEvent *v35; // ebx
  CPowerWarVictoriousEvent *v36; // ebx
  CSecretShopEvent *v37; // ebx
  CFatigueAttendance *v38; // ebx
  CWeekendBonusEvent *v39; // ebx
  CConditionEvent *v40; // ebx
  CUXGameLogEvent *v41; // ebx
  BlueMarbleDungeonEvent *v42; // ebx
  CStopOverlabExpEvent *v43; // ebx
  CEventAdvanceAltarOpen *v44; // ebx
  CAradRyosikaEvent *v45; // ebx
  Arad_MomijiEvent *v46; // ebx
  LevelupSupportEvent *v47; // ebx
  CEventStayTime *v48; // ebx
  CEventCreateDnf *v49; // ebx
  EventGiveMeBox *v50; // ebx

  v1 = (CUnlimitFatigueEvent *)operator new(0xCu);
  CUnlimitFatigueEvent::CUnlimitFatigueEvent(v1);
  *((_DWORD *)this + 1) = v1;
  v2 = (CMaxFatigueFactorEvent *)operator new(0x10u);
  CMaxFatigueFactorEvent::CMaxFatigueFactorEvent(v2);
  *((_DWORD *)this + 2) = v2;
  v3 = (CExpDoubleEvent *)operator new(0x10u);
  CExpDoubleEvent::CExpDoubleEvent(v3);
  *((_DWORD *)this + 3) = v3;
  v4 = (CCoinEventPerDay *)operator new(0x10u);
  CCoinEventPerDay::CCoinEventPerDay(v4);
  *((_DWORD *)this + 4) = v4;
  v5 = (CCoinEventOnCharCreate *)operator new(0x10u);
  CCoinEventOnCharCreate::CCoinEventOnCharCreate(v5);
  *((_DWORD *)this + 5) = v5;
  v6 = (CLeadingChannelEvent *)operator new(0x10u);
  CLeadingChannelEvent::CLeadingChannelEvent(v6);
  *((_DWORD *)this + 6) = v6;
  v7 = (CItemDropRatioEvent *)operator new(0x10u);
  CItemDropRatioEvent::CItemDropRatioEvent(v7);
  *((_DWORD *)this + 7) = v7;
  v8 = (CPCRoomBurningEvent *)operator new(0x10u);
  CPCRoomBurningEvent::CPCRoomBurningEvent(v8);
  *((_DWORD *)this + 8) = v8;
  v9 = (CGuildWarEvent *)operator new(0x10u);
  CGuildWarEvent::CGuildWarEvent(v9);
  *((_DWORD *)this + 33) = v9;
  v10 = (CPCRoomFatigueEvent *)operator new(0xCu);
  CPCRoomFatigueEvent::CPCRoomFatigueEvent(v10);
  *((_DWORD *)this + 10) = v10;
  v11 = (CReformingDanjinEvent *)operator new(0xCu);
  CReformingDanjinEvent::CReformingDanjinEvent(v11);
  *((_DWORD *)this + 12) = v11;
  v12 = (CCoinRefillEvent *)operator new(0x20u);
  CCoinRefillEvent::CCoinRefillEvent(v12);
  *((_DWORD *)this + 13) = v12;
  v13 = (CBurningFatigueEvent *)operator new(0x10u);
  CBurningFatigueEvent::CBurningFatigueEvent(v13);
  *((_DWORD *)this + 15) = v13;
  v14 = (CClearRewardCardEvent *)operator new(0xCu);
  CClearRewardCardEvent::CClearRewardCardEvent(v14);
  *((_DWORD *)this + 16) = v14;
  v15 = (CCeraShopBonusItemEvent *)operator new(0x10u);
  CCeraShopBonusItemEvent::CCeraShopBonusItemEvent(v15);
  *((_DWORD *)this + 17) = v15;
  v16 = (CTournamentPvPEvent *)operator new(0xCu);
  CTournamentPvPEvent::CTournamentPvPEvent(v16);
  *((_DWORD *)this + 18) = v16;
  v17 = (CGoldCardBlankItemEvent *)operator new(0xCu);
  CGoldCardBlankItemEvent::CGoldCardBlankItemEvent(v17);
  *((_DWORD *)this + 19) = v17;
  v18 = (CPcRoomCardBlankItemEvent *)operator new(0xCu);
  CPcRoomCardBlankItemEvent::CPcRoomCardBlankItemEvent(v18);
  *((_DWORD *)this + 29) = v18;
  v19 = (CPowerWarEvent *)operator new(0x10u);
  CPowerWarEvent::CPowerWarEvent(v19);
  *((_DWORD *)this + 30) = v19;
  v20 = (CCollectArchieveEventLog *)operator new(0xCu);
  CCollectArchieveEventLog::CCollectArchieveEventLog(v20);
  *((_DWORD *)this + 21) = v20;
  v21 = (CPCRoomWorldDropEvent *)operator new(0xCu);
  CPCRoomWorldDropEvent::CPCRoomWorldDropEvent(v21);
  *((_DWORD *)this + 22) = v21;
  v22 = (CPartyExpBonusEvent *)operator new(0x10u);
  CPartyExpBonusEvent::CPartyExpBonusEvent(v22);
  *((_DWORD *)this + 24) = v22;
  v23 = (CStabToDeathEvent *)operator new(0xCu);
  CStabToDeathEvent::CStabToDeathEvent(v23);
  *((_DWORD *)this + 32) = v23;
  v24 = (CSchoolMatchEvent *)operator new(0x18u);
  CSchoolMatchEvent::CSchoolMatchEvent(v24);
  *((_DWORD *)this + 9) = v24;
  v25 = (CAutoMarketConditionsControlEvent *)operator new(0xCu);
  CAutoMarketConditionsControlEvent::CAutoMarketConditionsControlEvent(v25);
  *((_DWORD *)this + 34) = v25;
  v26 = (CVendingMachineBonusEvent *)operator new(0xCu);
  CVendingMachineBonusEvent::CVendingMachineBonusEvent(v26);
  *((_DWORD *)this + 35) = v26;
  v27 = (CBurnigGoldMonsterEvent *)operator new(0xCu);
  CBurnigGoldMonsterEvent::CBurnigGoldMonsterEvent(v27);
  *((_DWORD *)this + 36) = v27;
  v28 = (CNoNeedGoldOnGuildCreateEvent *)operator new(0xCu);
  CNoNeedGoldOnGuildCreateEvent::CNoNeedGoldOnGuildCreateEvent(v28);
  *((_DWORD *)this + 38) = v28;
  v29 = (CDeathTowerWinPointEvent *)operator new(0x10u);
  CDeathTowerWinPointEvent::CDeathTowerWinPointEvent(v29);
  *((_DWORD *)this + 39) = v29;
  v30 = (CNotApplyBalkeunEvent *)operator new(0xCu);
  CNotApplyBalkeunEvent::CNotApplyBalkeunEvent(v30);
  *((_DWORD *)this + 40) = v30;
  v31 = (CCharacterDayEvent *)operator new(0xCu);
  CCharacterDayEvent::CCharacterDayEvent(v31);
  *((_DWORD *)this + 41) = v31;
  v32 = (CRestrictCharacCreationEvent *)operator new(0x10u);
  CRestrictCharacCreationEvent::CRestrictCharacCreationEvent(v32);
  *((_DWORD *)this + 49) = v32;
  v33 = (CReduceUpgradeItemPay *)operator new(0xCu);
  CReduceUpgradeItemPay::CReduceUpgradeItemPay(v33);
  *((_DWORD *)this + 50) = v33;
  v34 = (COnTimeEvent *)operator new(0x60u);
  COnTimeEvent::COnTimeEvent(v34);
  *((_DWORD *)this + 51) = v34;
  v35 = (CBreakAwayPreventEvent *)operator new(0xCu);
  CBreakAwayPreventEvent::CBreakAwayPreventEvent(v35);
  *((_DWORD *)this + 52) = v35;
  v36 = (CPowerWarVictoriousEvent *)operator new(0x10u);
  CPowerWarVictoriousEvent::CPowerWarVictoriousEvent(v36);
  *((_DWORD *)this + 53) = v36;
  v37 = (CSecretShopEvent *)operator new(0xCu);
  CSecretShopEvent::CSecretShopEvent(v37);
  *((_DWORD *)this + 58) = v37;
  v38 = (CFatigueAttendance *)operator new(0xCu);
  CFatigueAttendance::CFatigueAttendance(v38);
  *((_DWORD *)this + 86) = v38;
  v39 = (CWeekendBonusEvent *)operator new(0xCu);
  CWeekendBonusEvent::CWeekendBonusEvent(v39);
  *((_DWORD *)this + 87) = v39;
  v40 = (CConditionEvent *)operator new(0xCu);
  CConditionEvent::CConditionEvent(v40);
  *((_DWORD *)this + 113) = v40;
  v41 = (CUXGameLogEvent *)operator new(0xCu);
  CUXGameLogEvent::CUXGameLogEvent(v41);
  *((_DWORD *)this + 91) = v41;
  v42 = (BlueMarbleDungeonEvent *)operator new(0xCu);
  BlueMarbleDungeonEvent::BlueMarbleDungeonEvent(v42);
  *((_DWORD *)this + 95) = v42;
  v43 = (CStopOverlabExpEvent *)operator new(0xCu);
  CStopOverlabExpEvent::CStopOverlabExpEvent(v43);
  *((_DWORD *)this + 102) = v43;
  v44 = (CEventAdvanceAltarOpen *)operator new(0xCu);
  CEventAdvanceAltarOpen::CEventAdvanceAltarOpen(v44);
  *((_DWORD *)this + 119) = v44;
  v45 = (CAradRyosikaEvent *)operator new(0x14u);
  CAradRyosikaEvent::CAradRyosikaEvent(v45);
  *((_DWORD *)this + 116) = v45;
  v46 = (Arad_MomijiEvent *)operator new(0xCu);
  Arad_MomijiEvent::Arad_MomijiEvent(v46);
  *((_DWORD *)this + 155) = v46;
  v47 = (LevelupSupportEvent *)operator new(0xCu);
  LevelupSupportEvent::LevelupSupportEvent(v47);
  *((_DWORD *)this + 158) = v47;
  v48 = (CEventStayTime *)operator new(0x14u);
  CEventStayTime::CEventStayTime(v48);
  *((_DWORD *)this + 159) = v48;
  v49 = (CEventCreateDnf *)operator new(0x18u);
  CEventCreateDnf::CEventCreateDnf(v49);
  *((_DWORD *)this + 160) = v49;
  v50 = (EventGiveMeBox *)operator new(0xCu);
  EventGiveMeBox::EventGiveMeBox(v50);
  *((_DWORD *)this + 165) = v50;
  return (unsigned __int8)CEventManager::LoadEventFromDB(this) == 1;
}

// IDA_EA: 0x8115982
// IDA_NAME: _ZN13CEventManager8AddEventEiP10CEventBase
// DEMANGLED: CEventManager::AddEvent(int,CEventBase *)
int __cdecl CEventManager::AddEvent(CEventManager *this, int a2, CEventBase *a3)
{
  *((_DWORD *)this + a2) = a3;
  return 1;
}

// IDA_EA: 0x8115998
// IDA_NAME: _ZN13CEventManager14GetRepeatEventEi
// DEMANGLED: CEventManager::GetRepeatEvent(int)
int __cdecl CEventManager::GetRepeatEvent(CEventManager *this, int n165)
{
  if ( n165 <= 165 )
    return *((_DWORD *)this + n165);
  else
    return 0;
}

// IDA_EA: 0x81159B6
// IDA_NAME: _ZN13CEventManager15LoadEventFromDBEv
// DEMANGLED: CEventManager::LoadEventFromDB(void)
int __cdecl CEventManager::LoadEventFromDB(CEventManager *this)
{
  int v1; // eax
  char v3; // bl
  char v4; // [esp+8h] [ebp-70h]
  unsigned __int16 v5[2]; // [esp+28h] [ebp-50h] BYREF
  char v6[4]; // [esp+2Ch] [ebp-4Ch] BYREF
  int v7[4]; // [esp+30h] [ebp-48h] BYREF
  int v8[4]; // [esp+40h] [ebp-38h] BYREF
  char intEiRi; // [esp+53h] [ebp-25h]
  MySQL *DBHandle; // [esp+54h] [ebp-24h]
  int n_rowsEv; // [esp+58h] [ebp-20h]
  int n_rowsEv_1; // [esp+5Ch] [ebp-1Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle(GlobalData::s_db_mgr, 1, 0);
  v1 = G_CEnvironment();
  MySQL::set_query(
    DBHandle,
    "seLect event_type, parameter1, parameter2 from dnf_event_log where end_time = 0 and server_id in (0,%d) and unix_tim"
    "estamp() >= start_time order by start_time",
    *(_DWORD *)(v1 + 888));
  cMyTrace::cMyTrace((cMyTrace *)v7, "bool CEventManager::LoadEventFromDB()", 662, 9, 1, 1);
  cMyTrace::operator()((int)v7, "[!] Load Event From DB", v4);
  intEiRi = MySQL::exec(DBHandle, 1);
  if ( intEiRi != 1 )
    return 0;
  n_rowsEv = MySQL::get_n_rows(DBHandle);
  for ( n_rowsEv_1 = 0; n_rowsEv_1 < n_rowsEv; ++n_rowsEv_1 )
  {
    intEiRi = MySQL::fetch(DBHandle);
    if ( intEiRi != 1 )
      break;
    intEiRi = MySQL::get_int(DBHandle, 0, (int *)v6);
    if ( intEiRi != 1 )
      return 0;
    intEiRi = MySQL::get_ushort(DBHandle, 1, v5);
    if ( intEiRi != 1 )
      return 0;
    intEiRi = MySQL::get_ushort(DBHandle, 2, &v5[1]);
    if ( intEiRi != 1 )
      return 0;
    if ( (unsigned __int8)CEventManager::TriggerEventStart(this, *(int *)v6, *(int *)v5) != 1 )
      return 0;
    v3 = v6[0];
    cMyTrace::cMyTrace((cMyTrace *)v8, "bool CEventManager::LoadEventFromDB()", 773, 9, 1, 1);
    cMyTrace::operator()((int)v8, "\t- Event Code(%d) , Parameter1(%d), Parameter2(%d)", v3);
  }
  return 1;
}

// IDA_EA: 0x8115CC6
// IDA_NAME: _ZN13CEventManager17TriggerEventStartEi10Word_Param
// DEMANGLED: CEventManager::TriggerEventStart(int,Word_Param)
int __cdecl CEventManager::TriggerEventStart(CEventManager *a1, int n2, int a3)
{
  int RepeatEvent; // [esp+1Ch] [ebp-Ch]

  if ( filterEvent(n2) )
    return 1;
  RepeatEvent = CEventManager::GetRepeatEvent(a1, n2);
  if ( !RepeatEvent )
    return 0;
  (*(void (__cdecl **)(int, int))(*(_DWORD *)RepeatEvent + 16))(RepeatEvent, a3);
  CEventManager::BroadcastEventInfo(a1);
  (*(void (__cdecl **)(int, _DWORD))(*(_DWORD *)RepeatEvent + 40))(RepeatEvent, *((_DWORD *)a1 + 166));
  (*(void (__cdecl **)(int))(*(_DWORD *)RepeatEvent + 20))(RepeatEvent);
  return 1;
}

// IDA_EA: 0x8115D60
// IDA_NAME: _ZN13CEventManager15TriggerEventEndEi
// DEMANGLED: CEventManager::TriggerEventEnd(int)
int __cdecl CEventManager::TriggerEventEnd(CEventManager *this, int n2)
{
  int RepeatEvent; // [esp+1Ch] [ebp-Ch]

  if ( filterEvent(n2) )
    return 1;
  RepeatEvent = CEventManager::GetRepeatEvent(this, n2);
  if ( !RepeatEvent )
    return 0;
  (*(void (__cdecl **)(int, _DWORD))(*(_DWORD *)RepeatEvent + 44))(RepeatEvent, *((_DWORD *)this + 166));
  CEventManager::BroadcastEventInfo(this);
  (*(void (__cdecl **)(int))(*(_DWORD *)RepeatEvent + 12))(RepeatEvent);
  return 1;
}

// IDA_EA: 0x8115DE2
// IDA_NAME: _ZN13CEventManager17MakeNotiEventInfoER11PacketGuardP5CUser
// DEMANGLED: CEventManager::MakeNotiEventInfo(PacketGuard &,CUser *)
int __cdecl CEventManager::MakeNotiEventInfo(CEventManager *this, PacketBuf **a2, CUser *a3)
{
  int v3; // eax
  _DWORD *v4; // eax
  int v5; // eax
  int v6; // eax
  _BYTE v8[4]; // [esp+10h] [ebp-48h] BYREF
  _BYTE v9[4]; // [esp+14h] [ebp-44h] BYREF
  int n165_1; // [esp+18h] [ebp-40h] BYREF
  __int16 v11; // [esp+1Ch] [ebp-3Ch]
  __int16 v12; // [esp+1Eh] [ebp-3Ah]
  _WORD v13[2]; // [esp+20h] [ebp-38h] BYREF
  int indexEv; // [esp+24h] [ebp-34h] BYREF
  _BYTE v15[12]; // [esp+28h] [ebp-30h] BYREF
  _BYTE v16[4]; // [esp+34h] [ebp-24h] BYREF
  _BYTE v17[4]; // [esp+38h] [ebp-20h] BYREF
  int v18; // [esp+3Ch] [ebp-1Ch]
  int n165; // [esp+40h] [ebp-18h]
  int RepeatEvent; // [esp+44h] [ebp-14h]
  int n165_2; // [esp+48h] [ebp-10h]
  int v22; // [esp+4Ch] [ebp-Ch]

  std::vector<stEVENTADDINFO>::vector(v15);
  InterfacePacketBuf::clear(a2);
  InterfacePacketBuf::put_header(a2, 0, 108);
  v18 = 0;
  indexEv = InterfacePacketBuf::get_index(a2);
  InterfacePacketBuf::put_short(a2, v18);
  if ( GlobalData::s_event_manager )
  {
    for ( n165 = 0; n165 <= 165; ++n165 )
    {
      RepeatEvent = CEventManager::GetRepeatEvent(this, n165);
      if ( RepeatEvent )
      {
        if ( (*(unsigned __int8 (__cdecl **)(int, CUser *))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, a3) )
        {
          InterfacePacketBuf::put_short(a2, n165);
          ++v18;
          (*(void (__stdcall **)(_WORD *))(*(_DWORD *)RepeatEvent + 28))(v13);
          if ( v13[0] >= 0 )
          {
            n165_1 = n165;
            v11 = v13[0];
            v12 = v13[1];
            std::vector<stEVENTADDINFO>::push_back(v15, &n165_1);
          }
        }
      }
    }
  }
  InterfacePacketBuf::put_short((InterfacePacketBuf *)a2, &indexEv, v18);
  if ( GlobalData::s_event_manager )
  {
    for ( n165_2 = 0; n165_2 <= 165; ++n165_2 )
    {
      v22 = CEventManager::GetRepeatEvent(this, n165_2);
      if ( v22 && (*(unsigned __int8 (__cdecl **)(int, CUser *))(*(_DWORD *)v22 + 52))(v22, a3) )
        (*(void (__cdecl **)(int, PacketBuf **))(*(_DWORD *)v22 + 24))(v22, a2);
    }
  }
  if ( (unsigned __int8)std::vector<stEVENTADDINFO>::empty(v15) == 1 )
  {
    InterfacePacketBuf::put_byte(a2, 0);
  }
  else
  {
    v3 = std::vector<stEVENTADDINFO>::size(v15);
    InterfacePacketBuf::put_byte(a2, v3);
    std::vector<stEVENTADDINFO>::begin(v16);
    __gnu_cxx::__normal_iterator<stEVENTADDINFO const*,std::vector<stEVENTADDINFO>>::__normal_iterator<stEVENTADDINFO*>(
      v9,
      v16);
    std::vector<stEVENTADDINFO>::end(v17);
    __gnu_cxx::__normal_iterator<stEVENTADDINFO const*,std::vector<stEVENTADDINFO>>::__normal_iterator<stEVENTADDINFO*>(
      v8,
      v17);
    while ( (unsigned __int8)__gnu_cxx::operator!=<stEVENTADDINFO const*,std::vector<stEVENTADDINFO>>(v9, v8) )
    {
      v4 = (_DWORD *)__gnu_cxx::__normal_iterator<stEVENTADDINFO const*,std::vector<stEVENTADDINFO>>::operator*(v9);
      InterfacePacketBuf::put_short(a2, *v4);
      v5 = __gnu_cxx::__normal_iterator<stEVENTADDINFO const*,std::vector<stEVENTADDINFO>>::operator*(v9);
      InterfacePacketBuf::put_short(a2, *(_WORD *)(v5 + 4));
      v6 = __gnu_cxx::__normal_iterator<stEVENTADDINFO const*,std::vector<stEVENTADDINFO>>::operator*(v9);
      InterfacePacketBuf::put_short(a2, *(_WORD *)(v6 + 6));
      __gnu_cxx::__normal_iterator<stEVENTADDINFO const*,std::vector<stEVENTADDINFO>>::operator++(v9);
    }
  }
  InterfacePacketBuf::finalize(a2, 1);
  return std::vector<stEVENTADDINFO>::~vector(v15);
}

// IDA_EA: 0x8116108
// IDA_NAME: _ZN13CEventManager18BroadcastEventInfoEv
// DEMANGLED: CEventManager::BroadcastEventInfo(void)
void __cdecl CEventManager::BroadcastEventInfo(CEventManager *this)
{
  std::_Rb_tree_node_base *src_; // [esp+14h] [ebp-24h] BYREF
  PacketBuf *v2[3]; // [esp+18h] [ebp-20h] BYREF
  int v3; // [esp+24h] [ebp-14h] BYREF
  _BYTE dest[4]; // [esp+28h] [ebp-10h] BYREF
  CUser *v5; // [esp+2Ch] [ebp-Ch]

  PacketGuard::PacketGuard((PacketGuard *)v2);
  G_GameWorld();
  std::map<unsigned short,CUser *>::begin((int)&src_);
  while ( 1 )
  {
    G_GameWorld();
    std::map<unsigned short,CUser *>::end((int)&v3);
    if ( !std::_Rb_tree_iterator<std::pair<unsigned short const,CUser *>>::operator!=(&src_, &v3) )
      break;
    v5 = *(CUser **)(std::_Rb_tree_iterator<std::pair<unsigned short const,CUser *>>::operator->(&src_) + 4);
    if ( CUser::get_state(v5) > 2 )
    {
      CEventManager::MakeNotiEventInfo(this, v2, v5);
      CUser::Send(v5, (PacketGuard *)v2);
    }
    std::_Rb_tree_iterator<std::pair<unsigned short const,CUser *>>::operator++(dest, &src_);
  }
  PacketGuard::~PacketGuard(v2);
}

// IDA_EA: 0x8116212
// IDA_NAME: _ZN13CEventManager30IsExistOverlappedExpBonusEventEv
// DEMANGLED: CEventManager::IsExistOverlappedExpBonusEvent(void)
_BOOL4 CEventManager::IsExistOverlappedExpBonusEvent()
{
  int RepeatEvent; // eax
  char v2; // [esp+1Eh] [ebp-Ah]
  char isAffectedEffect; // [esp+1Fh] [ebp-9h]

  RepeatEvent = CEventManager::GetRepeatEvent(GlobalData::s_event_manager, 102);
  v2 = (*(int (__cdecl **)(int, _DWORD))(*(_DWORD *)RepeatEvent + 52))(RepeatEvent, 0);
  isAffectedEffect = CGlobalEffectManager::isAffectedEffect(GlobalData::s_globalEffectManager_, 2u);
  return v2 || isAffectedEffect;
}

// IDA_EA: 0x8116276
// IDA_NAME: _ZN13CEventManager16changeCharacNameEP5CUseriPci
// DEMANGLED: CEventManager::changeCharacName(CUser *,int,char *,int)
bool __cdecl CEventManager::changeCharacName(CEventManager *this, CUser *a2, int a3, char *a4, int a5)
{
  bool result; // al
  int n165; // [esp+2Ch] [ebp-Ch]

  for ( n165 = 0; ; ++n165 )
  {
    result = n165 <= 165;
    if ( n165 > 165 )
      break;
    if ( *((_DWORD *)this + n165) )
    {
      if ( (*(unsigned __int8 (__cdecl **)(_DWORD, _DWORD))(**((_DWORD **)this + n165) + 52))(
             *((_DWORD *)this + n165),
             0) )
      {
        (*(void (__cdecl **)(_DWORD, CUser *, int, char *, int))(**((_DWORD **)this + n165) + 32))(
          *((_DWORD *)this + n165),
          a2,
          a3,
          a4,
          a5);
      }
    }
  }
  return result;
}

// IDA_EA: 0x811630E
// IDA_NAME: _ZN13CEventManager14dailyresetDataEv
// DEMANGLED: CEventManager::dailyresetData(void)
bool __cdecl CEventManager::dailyresetData(CEventManager *this)
{
  bool result; // al
  int n165; // [esp+1Ch] [ebp-Ch]

  for ( n165 = 0; ; ++n165 )
  {
    result = n165 <= 165;
    if ( n165 > 165 )
      break;
    if ( *((_DWORD *)this + n165) )
    {
      if ( (*(unsigned __int8 (__cdecl **)(_DWORD, _DWORD))(**((_DWORD **)this + n165) + 52))(
             *((_DWORD *)this + n165),
             0) )
      {
        (*(void (__cdecl **)(_DWORD))(**((_DWORD **)this + n165) + 36))(*((_DWORD *)this + n165));
      }
    }
  }
  return result;
}

// IDA_EA: 0x8116874
// IDA_NAME: _ZN13CEventManager19eventDeliveryNotifyEiR11DeliveryMsg
// DEMANGLED: CEventManager::eventDeliveryNotify(int,DeliveryMsg &)
int __cdecl CEventManager::eventDeliveryNotify(CEventManager *this, int n2, DeliveryMsg *a3)
{
  int result; // eax

  result = *((_DWORD *)this + 166);
  if ( result )
    return CDelivery::notify(*((CDelivery **)this + 166), n2, a3);
  return result;
}
