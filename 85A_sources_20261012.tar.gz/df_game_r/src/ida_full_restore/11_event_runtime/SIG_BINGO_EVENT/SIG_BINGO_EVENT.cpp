#include "SIG_BINGO_EVENT.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x844D600
// IDA_NAME: _ZN15SIG_BINGO_EVENT5clearEv
// DEMANGLED: SIG_BINGO_EVENT::clear(void)
SIG_BINGO_EVENT *__cdecl SIG_BINGO_EVENT::clear(SIG_BINGO_EVENT *this)
{
  SIG_BINGO_EVENT *this_1; // eax

  *(_BYTE *)this = 0;
  this_1 = this;
  *((_DWORD *)this + 1) = 0;
  return this_1;
}
