#ifndef __IDA91_SIG_BINGO_EVENT_H__
#define __IDA91_SIG_BINGO_EVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: SIG_BINGO_EVENT
// Source unit: SIG_BINGO_EVENT
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2438

/* 2438 */
struct SIG_BINGO_EVENT;

// Exported member functions:
// 0x844D600	SIG_BINGO_EVENT::clear(void)

// Function declaration index:
// DECL 0x844D600 SIG_BINGO_EVENT::clear

#endif  // __IDA91_SIG_BINGO_EVENT_H__
