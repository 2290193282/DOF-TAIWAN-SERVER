#ifndef __IDA91_STACKABLEPACKAGE_EVENTPROCESSMANAGER_H__
#define __IDA91_STACKABLEPACKAGE_EVENTPROCESSMANAGER_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: StackablePackage
// Source unit: StackablePackage_EventProcessManager
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 2154,4584

/* 2154 */
struct StackablePackage::EventProcessManager;

/* 4584 */
struct StackablePackage::EventProcessManager::EventProcessManagerImpl;

// Exported member functions:
// 0x82817C4	StackablePackage::EventProcessManager::setupEventProcessors(void)
// 0x82817CA	StackablePackage::EventProcessManager::EventProcessManager(void)
// 0x828182A	StackablePackage::EventProcessManager::~EventProcessManager()
// 0x828186C	StackablePackage::EventProcessManager::Process(StackablePackage::EVENT_TYPE,CUser &,int)
// 0x82819C6	StackablePackage::EventProcessManager::isStackablePackageItem(int)const
// 0x8281A2A	StackablePackage::EventProcessManager::registerEventProcessor(StackablePackage::EventProcessor *)
// 0x8281A9A	StackablePackage::EventProcessManager::destroy(void)
// 0x8281C26	StackablePackage::EventProcessManager::EventProcessManagerImpl::EventProcessManagerImpl(void)
// 0x8281D0A	StackablePackage::EventProcessManager::EventProcessManagerImpl::~EventProcessManagerImpl()

// Function declaration index:
// DECL 0x82817C4 StackablePackage::EventProcessManager::setupEventProcessors
// DECL 0x82817CA StackablePackage::EventProcessManager::EventProcessManager
// DECL 0x828182A StackablePackage::EventProcessManager::~EventProcessManager
// DECL 0x828186C StackablePackage::EventProcessManager::Process
// DECL 0x82819C6 StackablePackage::EventProcessManager::isStackablePackageItem
// DECL 0x8281A2A StackablePackage::EventProcessManager::registerEventProcessor
// DECL 0x8281A9A StackablePackage::EventProcessManager::destroy
// DECL 0x8281C26 StackablePackage::EventProcessManager::EventProcessManagerImpl::EventProcessManagerImpl
// DECL 0x8281D0A StackablePackage::EventProcessManager::EventProcessManagerImpl::~EventProcessManagerImpl

#endif  // __IDA91_STACKABLEPACKAGE_EVENTPROCESSMANAGER_H__
