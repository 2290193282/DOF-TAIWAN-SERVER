#include "StackablePackage_EventProcessor.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8281BFA
// IDA_NAME: _ZNK16StackablePackage14EventProcessor12GetEventTypeEv
// DEMANGLED: StackablePackage::EventProcessor::GetEventType(void)const
int __cdecl StackablePackage::EventProcessor::GetEventType(StackablePackage::EventProcessor *this)
{
  return *((_DWORD *)this + 1);
}

// IDA_EA: 0x8281C06
// IDA_NAME: _ZNK16StackablePackage14EventProcessor10GetEventIdEv
// DEMANGLED: StackablePackage::EventProcessor::GetEventId(void)const
int __cdecl StackablePackage::EventProcessor::GetEventId(StackablePackage::EventProcessor *this)
{
  return *((_DWORD *)this + 2);
}
