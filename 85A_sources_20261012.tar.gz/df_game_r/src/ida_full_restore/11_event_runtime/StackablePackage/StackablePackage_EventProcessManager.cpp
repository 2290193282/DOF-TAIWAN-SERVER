#include "StackablePackage_EventProcessManager.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x82817C4
// IDA_NAME: _ZN16StackablePackage19EventProcessManager20setupEventProcessorsEv
// DEMANGLED: StackablePackage::EventProcessManager::setupEventProcessors(void)
void StackablePackage::EventProcessManager::setupEventProcessors()
{
  ;
}

// IDA_EA: 0x82817CA
// IDA_NAME: _ZN16StackablePackage19EventProcessManagerC2Ev
// DEMANGLED: StackablePackage::EventProcessManager::EventProcessManager(void)
void __cdecl StackablePackage::EventProcessManager::EventProcessManager(StackablePackage::EventProcessManager *this)
{
  StackablePackage::EventProcessManager::EventProcessManagerImpl *v1; // ebx

  v1 = (StackablePackage::EventProcessManager::EventProcessManagerImpl *)operator new(0x18u);
  StackablePackage::EventProcessManager::EventProcessManagerImpl::EventProcessManagerImpl(v1);
  std::auto_ptr<StackablePackage::EventProcessManager::EventProcessManagerImpl>::auto_ptr(this, v1);
  StackablePackage::EventProcessManager::setupEventProcessors();
}

// IDA_EA: 0x828182A
// IDA_NAME: _ZN16StackablePackage19EventProcessManagerD2Ev
// DEMANGLED: StackablePackage::EventProcessManager::~EventProcessManager()
void __cdecl StackablePackage::EventProcessManager::~EventProcessManager(StackablePackage::EventProcessManager *a1)
{
  StackablePackage::EventProcessManager::destroy(a1);
  std::auto_ptr<StackablePackage::EventProcessManager::EventProcessManagerImpl>::~auto_ptr(a1);
}

// IDA_EA: 0x828186C
// IDA_NAME: _ZN16StackablePackage19EventProcessManager7ProcessENS_10EVENT_TYPEER5CUseri
// DEMANGLED: StackablePackage::EventProcessManager::Process(StackablePackage::EVENT_TYPE,CUser &,int)
int __cdecl StackablePackage::EventProcessManager::Process(
        StackablePackage::EventProcessManager *a1,
        char a2,
        int a3,
        int a4)
{
  int v5; // eax
  int v6; // [esp+Ch] [ebp-2Ch]
  _BYTE v7[4]; // [esp+10h] [ebp-28h] BYREF
  _BYTE v8[4]; // [esp+14h] [ebp-24h] BYREF
  _BYTE v9[4]; // [esp+18h] [ebp-20h] BYREF
  int v10; // [esp+1Ch] [ebp-1Ch] BYREF
  int v11; // [esp+20h] [ebp-18h] BYREF
  int v12; // [esp+24h] [ebp-14h] BYREF
  _BYTE v13[4]; // [esp+28h] [ebp-10h] BYREF
  int v14; // [esp+2Ch] [ebp-Ch]

  if ( (unsigned __int8)StackablePackage::EventProcessManager::isStackablePackageItem(a1, a4) != 1 )
    return 0;
  std::auto_ptr<StackablePackage::EventProcessManager::EventProcessManagerImpl>::operator->(a1);
  std::map<StackablePackage::EVENT_TYPE,std::map<int,StackablePackage::EventProcessor *>>::find(v8);
  std::auto_ptr<StackablePackage::EventProcessManager::EventProcessManagerImpl>::operator->(a1);
  std::map<StackablePackage::EVENT_TYPE,std::map<int,StackablePackage::EventProcessor *>>::end(v9);
  if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<StackablePackage::EVENT_TYPE const,std::map<int,StackablePackage::EventProcessor *>>>::operator==(
                          v9,
                          v8) )
    return 0;
  v14 = std::_Rb_tree_iterator<std::pair<StackablePackage::EVENT_TYPE const,std::map<int,StackablePackage::EventProcessor *>>>::operator*(v8)
      + 4;
  StackablePackage::FindControllableEventProcessor::FindControllableEventProcessor(
    (StackablePackage::FindControllableEventProcessor *)&v10,
    a4);
  std::map<int,StackablePackage::EventProcessor *>::end(&v11);
  std::map<int,StackablePackage::EventProcessor *>::begin(&v12);
  v6 = v10;
  std::find_if<std::_Rb_tree_iterator<std::pair<int const,StackablePackage::EventProcessor *>>,StackablePackage::FindControllableEventProcessor>(v7);
  std::map<int,StackablePackage::EventProcessor *>::end(v13);
  if ( (unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,StackablePackage::EventProcessor *>>::operator==(
                          v13,
                          v7) )
    return 0;
  v5 = std::_Rb_tree_iterator<std::pair<int const,StackablePackage::EventProcessor *>>::operator*(v7);
  return (*(int (__cdecl **)(_DWORD, int, int, int))(**(_DWORD **)(v5 + 4) + 12))(*(_DWORD *)(v5 + 4), a3, a4, v6);
}

// IDA_EA: 0x82819C6
// IDA_NAME: _ZNK16StackablePackage19EventProcessManager22isStackablePackageItemEi
// DEMANGLED: StackablePackage::EventProcessManager::isStackablePackageItem(int)const
bool __cdecl StackablePackage::EventProcessManager::isStackablePackageItem(
        StackablePackage::EventProcessManager *this,
        unsigned int n2)
{
  CItemList **v2; // eax
  CItem *item; // [esp+18h] [ebp-10h]

  v2 = (CItemList **)G_CDataManager();
  item = (CItem *)CDataManager::find_item(v2, n2);
  if ( !item )
    return 0;
  if ( (unsigned __int8)CItem::is_stackable(item) == 1 )
    return (*(int (__cdecl **)(CItem *))(*(_DWORD *)item + 12))(item) == 38;
  return 0;
}

// IDA_EA: 0x8281A2A
// IDA_NAME: _ZN16StackablePackage19EventProcessManager22registerEventProcessorEPNS_14EventProcessorE
// DEMANGLED: StackablePackage::EventProcessManager::registerEventProcessor(StackablePackage::EventProcessor *)
int __cdecl StackablePackage::EventProcessManager::registerEventProcessor(
        StackablePackage::EventProcessManager *this,
        StackablePackage::EventProcessor *a2)
{
  int v2; // eax
  _BYTE v4[8]; // [esp+18h] [ebp-20h] BYREF
  _BYTE v5[8]; // [esp+20h] [ebp-18h] BYREF
  int EventId; // [esp+28h] [ebp-10h] BYREF
  _DWORD v7[3]; // [esp+2Ch] [ebp-Ch] BYREF

  EventId = StackablePackage::EventProcessor::GetEventId(a2);
  std::pair<int const,StackablePackage::EventProcessor *>::pair<int,StackablePackage::EventProcessor *&>(
    v5,
    &EventId,
    &a2);
  v7[0] = StackablePackage::EventProcessor::GetEventType(a2);
  v2 = std::auto_ptr<StackablePackage::EventProcessManager::EventProcessManagerImpl>::operator->(this);
  std::map<StackablePackage::EVENT_TYPE,std::map<int,StackablePackage::EventProcessor *>>::operator[](v2, v7);
  return std::map<int,StackablePackage::EventProcessor *>::insert(v4);
}

// IDA_EA: 0x8281A9A
// IDA_NAME: _ZN16StackablePackage19EventProcessManager7destroyEv
// DEMANGLED: StackablePackage::EventProcessManager::destroy(void)
int __cdecl StackablePackage::EventProcessManager::destroy(StackablePackage::EventProcessManager *this)
{
  int result; // eax
  _BYTE v2[4]; // [esp+18h] [ebp-20h] BYREF
  _BYTE v3[4]; // [esp+1Ch] [ebp-1Ch] BYREF
  _BYTE v4[4]; // [esp+20h] [ebp-18h] BYREF
  _BYTE v5[4]; // [esp+24h] [ebp-14h] BYREF
  int v6; // [esp+28h] [ebp-10h]
  int v7; // [esp+2Ch] [ebp-Ch]

  std::auto_ptr<StackablePackage::EventProcessManager::EventProcessManagerImpl>::operator->(this);
  std::map<StackablePackage::EVENT_TYPE,std::map<int,StackablePackage::EventProcessor *>>::begin(v3);
  while ( 1 )
  {
    std::auto_ptr<StackablePackage::EventProcessManager::EventProcessManagerImpl>::operator->(this);
    std::map<StackablePackage::EVENT_TYPE,std::map<int,StackablePackage::EventProcessor *>>::end(v4);
    result = std::_Rb_tree_iterator<std::pair<StackablePackage::EVENT_TYPE const,std::map<int,StackablePackage::EventProcessor *>>>::operator!=(
               v3,
               v4);
    if ( !(_BYTE)result )
      break;
    v6 = std::_Rb_tree_iterator<std::pair<StackablePackage::EVENT_TYPE const,std::map<int,StackablePackage::EventProcessor *>>>::operator*(v3)
       + 4;
    std::map<int,StackablePackage::EventProcessor *>::begin(v2);
    while ( 1 )
    {
      std::map<int,StackablePackage::EventProcessor *>::end(v5);
      if ( !(unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,StackablePackage::EventProcessor *>>::operator!=(
                               v2,
                               v5) )
        break;
      v7 = *(_DWORD *)(std::_Rb_tree_iterator<std::pair<int const,StackablePackage::EventProcessor *>>::operator*(v2) + 4);
      if ( v7 )
      {
        (*(void (__cdecl **)(int))(*(_DWORD *)v7 + 4))(v7);
        v7 = 0;
      }
      std::_Rb_tree_iterator<std::pair<int const,StackablePackage::EventProcessor *>>::operator++(v2);
    }
    std::_Rb_tree_iterator<std::pair<StackablePackage::EVENT_TYPE const,std::map<int,StackablePackage::EventProcessor *>>>::operator++(v3);
  }
  return result;
}

// IDA_EA: 0x8281C26
// IDA_NAME: _ZN16StackablePackage19EventProcessManager23EventProcessManagerImplC2Ev
// DEMANGLED: StackablePackage::EventProcessManager::EventProcessManagerImpl::EventProcessManagerImpl(void)
int __cdecl StackablePackage::EventProcessManager::EventProcessManagerImpl::EventProcessManagerImpl(
        StackablePackage::EventProcessManager::EventProcessManagerImpl *this)
{
  return std::map<StackablePackage::EVENT_TYPE,std::map<int,StackablePackage::EventProcessor *>>::map(this);
}

// IDA_EA: 0x8281D0A
// IDA_NAME: _ZN16StackablePackage19EventProcessManager23EventProcessManagerImplD2Ev
// DEMANGLED: StackablePackage::EventProcessManager::EventProcessManagerImpl::~EventProcessManagerImpl()
void __cdecl StackablePackage::EventProcessManager::EventProcessManagerImpl::~EventProcessManagerImpl(
        StackablePackage::EventProcessManager::EventProcessManagerImpl *this)
{
  std::map<StackablePackage::EVENT_TYPE,std::map<int,StackablePackage::EventProcessor *>>::~map((int)this);
}
