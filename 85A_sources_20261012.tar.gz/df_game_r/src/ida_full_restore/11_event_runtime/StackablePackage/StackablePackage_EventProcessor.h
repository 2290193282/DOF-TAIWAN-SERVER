#ifndef __IDA91_STACKABLEPACKAGE_EVENTPROCESSOR_H__
#define __IDA91_STACKABLEPACKAGE_EVENTPROCESSOR_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: StackablePackage
// Source unit: StackablePackage_EventProcessor
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2155

/* 2155 */
struct StackablePackage::EventProcessor;

// Exported member functions:
// 0x8281BFA	StackablePackage::EventProcessor::GetEventType(void)const
// 0x8281C06	StackablePackage::EventProcessor::GetEventId(void)const

// Function declaration index:
// DECL 0x8281BFA StackablePackage::EventProcessor::GetEventType
// DECL 0x8281C06 StackablePackage::EventProcessor::GetEventId

#endif  // __IDA91_STACKABLEPACKAGE_EVENTPROCESSOR_H__
