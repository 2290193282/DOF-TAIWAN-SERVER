#include "StackablePackage_FindControllableEventProcessor.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8281C3A
// IDA_NAME: _ZN16StackablePackage30FindControllableEventProcessorC2Ei
// DEMANGLED: StackablePackage::FindControllableEventProcessor::FindControllableEventProcessor(int)
StackablePackage::FindControllableEventProcessor *__cdecl StackablePackage::FindControllableEventProcessor::FindControllableEventProcessor(
        StackablePackage::FindControllableEventProcessor *this,
        int a2)
{
  StackablePackage::FindControllableEventProcessor *this_1; // eax

  this_1 = this;
  *(_DWORD *)this = a2;
  return this_1;
}

// IDA_EA: 0x8281C48
// IDA_NAME: _ZNK16StackablePackage30FindControllableEventProcessorclERKSt4pairIKiPNS_14EventProcessorEE
// DEMANGLED: StackablePackage::FindControllableEventProcessor::operator()(std::pair<int const,StackablePackage::EventProcessor *> const&)const
int __cdecl StackablePackage::FindControllableEventProcessor::operator()(_DWORD *a1, int a2)
{
  if ( *(_DWORD *)(a2 + 4) )
    return (*(int (__cdecl **)(_DWORD, _DWORD))(**(_DWORD **)(a2 + 4) + 8))(*(_DWORD *)(a2 + 4), *a1);
  else
    return 0;
}
