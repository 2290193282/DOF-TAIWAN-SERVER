#ifndef __IDA91_STACKABLEPACKAGE_FINDCONTROLLABLEEVENTPROCESSOR_H__
#define __IDA91_STACKABLEPACKAGE_FINDCONTROLLABLEEVENTPROCESSOR_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: StackablePackage
// Source unit: StackablePackage_FindControllableEventProcessor
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2156

/* 2156 */
struct StackablePackage::FindControllableEventProcessor;

// Exported member functions:
// 0x8281C3A	StackablePackage::FindControllableEventProcessor::FindControllableEventProcessor(int)
// 0x8281C48	StackablePackage::FindControllableEventProcessor::operator()(std::pair<int const,StackablePackage::EventProcessor *> const&)const

// Function declaration index:
// DECL 0x8281C3A StackablePackage::FindControllableEventProcessor::FindControllableEventProcessor
// DECL 0x8281C48 StackablePackage::FindControllableEventProcessor::operator

#endif  // __IDA91_STACKABLEPACKAGE_FINDCONTROLLABLEEVENTPROCESSOR_H__
