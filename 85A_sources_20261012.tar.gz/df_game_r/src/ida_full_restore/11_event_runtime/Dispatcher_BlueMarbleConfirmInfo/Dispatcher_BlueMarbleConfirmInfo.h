#ifndef __IDA91_DISPATCHER_BLUEMARBLECONFIRMINFO_H__
#define __IDA91_DISPATCHER_BLUEMARBLECONFIRMINFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Dispatcher_BlueMarbleConfirmInfo
// Source unit: Dispatcher_BlueMarbleConfirmInfo
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 1541

/* 1541 */
struct Dispatcher_BlueMarbleConfirmInfo;

// Exported member functions:
// 0x81E6242	Dispatcher_BlueMarbleConfirmInfo::read(PacketBuf &,MSG_BASE &)
// 0x81E62DA	Dispatcher_BlueMarbleConfirmInfo::process(CUser *,MSG_BASE &,ParamBase &)
// 0x81E68C8	Dispatcher_BlueMarbleConfirmInfo::check_error(CUser *,MSG_BASE &)
// 0x81E6904	Dispatcher_BlueMarbleConfirmInfo::send(CUser *,ParamBase &)
// 0x8243C54	Dispatcher_BlueMarbleConfirmInfo::~Dispatcher_BlueMarbleConfirmInfo()
// 0x8243C84	Dispatcher_BlueMarbleConfirmInfo::~Dispatcher_BlueMarbleConfirmInfo()
// 0x8597DE2	Dispatcher_BlueMarbleConfirmInfo::Dispatcher_BlueMarbleConfirmInfo(void)

// Function declaration index:
// DECL 0x81E6242 Dispatcher_BlueMarbleConfirmInfo::read
// DECL 0x81E62DA Dispatcher_BlueMarbleConfirmInfo::process
// DECL 0x81E68C8 Dispatcher_BlueMarbleConfirmInfo::check_error
// DECL 0x81E6904 Dispatcher_BlueMarbleConfirmInfo::send
// DECL 0x8243C54 Dispatcher_BlueMarbleConfirmInfo::~Dispatcher_BlueMarbleConfirmInfo
// DECL 0x8243C84 Dispatcher_BlueMarbleConfirmInfo::~Dispatcher_BlueMarbleConfirmInfo
// DECL 0x8597DE2 Dispatcher_BlueMarbleConfirmInfo::Dispatcher_BlueMarbleConfirmInfo

#endif  // __IDA91_DISPATCHER_BLUEMARBLECONFIRMINFO_H__
