#include "Dispatcher_BlueMarbleConfirmInfo.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81E6242
// IDA_NAME: _ZN32Dispatcher_BlueMarbleConfirmInfo4readER9PacketBufR8MSG_BASE
// DEMANGLED: Dispatcher_BlueMarbleConfirmInfo::read(PacketBuf &,MSG_BASE &)
int __cdecl Dispatcher_BlueMarbleConfirmInfo::read(Dispatcher_BlueMarbleConfirmInfo *this, PacketBuf *a2, MSG_BASE *a3)
{
  if ( (unsigned __int8)PacketBuf::get_byte(a2, (char *)a3 + 13) != 1 )
    return LineFunc(24845, "virtual int Dispatcher_BlueMarbleConfirmInfo::read(PacketBuf&, MSG_BASE&)", 0, 0);
  if ( (unsigned __int8)PacketBuf::get_short(a2, (__int16 *)a3 + 7) == 1 )
    return 0;
  return LineFunc(24848, "virtual int Dispatcher_BlueMarbleConfirmInfo::read(PacketBuf&, MSG_BASE&)", 0, 0);
}

// IDA_EA: 0x81E62DA
// IDA_NAME: _ZN32Dispatcher_BlueMarbleConfirmInfo7processEP5CUserR8MSG_BASER9ParamBase
// DEMANGLED: Dispatcher_BlueMarbleConfirmInfo::process(CUser *,MSG_BASE &,ParamBase &)
int __cdecl Dispatcher_BlueMarbleConfirmInfo::process(
        Dispatcher_BlueMarbleConfirmInfo *this,
        CUser *UserEv,
        MSG_BASE *a3,
        ParamBase *a4)
{
  CEnvironment *v5; // eax
  char *file_nameEv; // eax
  int stateEv; // edi
  int charac_noEi; // esi
  unsigned int acc_idEv; // eax
  const char *v10; // ebx
  CDataManager *v11; // eax
  __int16 BlueMarbleIndexEv_5; // bx
  __int16 v13; // bx
  CGameManager *v14; // eax
  int stateEv_3; // edi
  int charac_noEi_3; // esi
  unsigned int acc_idEv_3; // eax
  const char *v18; // ebx
  int stateEv_4; // edi
  int charac_noEi_4; // esi
  unsigned int acc_idEv_4; // eax
  const char *v22; // ebx
  int stateEv_2; // edi
  int charac_noEi_2; // esi
  unsigned int acc_idEv_2; // eax
  const char *v26; // ebx
  int stateEv_1; // edi
  int charac_noEi_1; // esi
  unsigned int acc_idEv_1; // eax
  const char *v30; // ebx
  int BlueMarbleIndexEv; // [esp+34h] [ebp-494h]
  int v32; // [esp+38h] [ebp-490h]
  int MoveSpaceEv; // [esp+3Ch] [ebp-48Ch]
  int BlueMarbleIndexEv_3; // [esp+40h] [ebp-488h]
  int v35; // [esp+44h] [ebp-484h]
  int MoveSpaceEv_3; // [esp+48h] [ebp-480h]
  int BlueMarbleIndexEv_4; // [esp+4Ch] [ebp-47Ch]
  int v38; // [esp+50h] [ebp-478h]
  int MoveSpaceEv_4; // [esp+54h] [ebp-474h]
  int BlueMarbleIndexEv_2; // [esp+58h] [ebp-470h]
  int v41; // [esp+5Ch] [ebp-46Ch]
  int MoveSpaceEv_2; // [esp+60h] [ebp-468h]
  int BlueMarbleIndexEv_1; // [esp+64h] [ebp-464h]
  int v44; // [esp+68h] [ebp-460h]
  int MoveSpaceEv_1; // [esp+6Ch] [ebp-45Ch]
  char s[1024]; // [esp+70h] [ebp-458h] BYREF
  int v47[2]; // [esp+470h] [ebp-58h] BYREF
  int v48[2]; // [esp+478h] [ebp-50h] BYREF
  int v49[2]; // [esp+480h] [ebp-48h] BYREF
  int v50[2]; // [esp+488h] [ebp-40h] BYREF
  int v51[2]; // [esp+490h] [ebp-38h] BYREF
  ParamBase *v52; // [esp+498h] [ebp-30h]
  MSG_BASE *v53; // [esp+49Ch] [ebp-2Ch]
  int v54; // [esp+4A0h] [ebp-28h]
  BlueMarble *BlueMarbleEi; // [esp+4A4h] [ebp-24h]
  BlueMarble *BlueMarbleEv_1; // [esp+4A8h] [ebp-20h]
  BlueMarble *BlueMarbleEv; // [esp+4ACh] [ebp-1Ch]

  v52 = a4;
  *((_DWORD *)a4 + 1) = Dispatcher_BlueMarbleConfirmInfo::check_error(this, UserEv, a3);
  if ( *((int *)v52 + 1) > 0 )
    return 0;
  if ( *((int *)v52 + 1) < 0 )
    return LineFunc(
             24863,
             "virtual int Dispatcher_BlueMarbleConfirmInfo::process(CUser*, MSG_BASE&, ParamBase&)",
             *((_DWORD *)v52 + 1),
             0);
  v53 = a3;
  memset(s, 0, sizeof(s));
  v5 = (CEnvironment *)G_CEnvironment();
  file_nameEv = CEnvironment::get_file_name(v5);
  sprintf(s, "./log/%s/BlueMarbleConfirmInfo", file_nameEv);
  BlueMarbleIndexEv = (__int16)CUser::getBlueMarbleIndex(UserEv);
  v32 = *((__int16 *)v53 + 7);
  MoveSpaceEv = CUser::getMoveSpace(UserEv);
  stateEv = CUser::get_state(UserEv);
  charac_noEi = CUser::get_charac_no(UserEv, -1);
  acc_idEv = CUser::get_acc_id(UserEv);
  v10 = (const char *)NumberToString(acc_idEv, 0);
  CMyFileLog::CMyFileLog(
    (CMyFileLog *)v47,
    "virtual int Dispatcher_BlueMarbleConfirmInfo::process(CUser*, MSG_BASE&, ParamBase&)",
    24871);
  CMyFileLog::operator()(
    (int)v47,
    s,
    "Client m_id(%s) charac_no(%u) userState(%d) userSpace(%d)client_blueMarble_Index(%d) server_bluemarble_index(%d)",
    v10,
    charac_noEi,
    stateEv,
    MoveSpaceEv,
    v32,
    BlueMarbleIndexEv);
  v11 = (CDataManager *)G_CDataManager();
  v54 = *(_DWORD *)(CDataManager::getBlueMarbleScript(v11) + 48);
  BlueMarbleEi = 0;
  if ( *((_BYTE *)v53 + 13) )
  {
    BlueMarbleIndexEv_1 = (__int16)CUser::getBlueMarbleIndex(UserEv);
    v44 = *((__int16 *)v53 + 7);
    MoveSpaceEv_1 = CUser::getMoveSpace(UserEv);
    stateEv_1 = CUser::get_state(UserEv);
    charac_noEi_1 = CUser::get_charac_no(UserEv, -1);
    acc_idEv_1 = CUser::get_acc_id(UserEv);
    v30 = (const char *)NumberToString(acc_idEv_1, 0);
    CMyFileLog::CMyFileLog(
      (CMyFileLog *)v51,
      "virtual int Dispatcher_BlueMarbleConfirmInfo::process(CUser*, MSG_BASE&, ParamBase&)",
      24920);
    CMyFileLog::operator()(
      (int)v51,
      s,
      "Not Exist User m_id(%s) charac_no(%u) userState(%d) userSpace(%d)client_blueMarble_Index(%d) server_bluemarble_index(%d)",
      v30,
      charac_noEi_1,
      stateEv_1,
      MoveSpaceEv_1,
      v44,
      BlueMarbleIndexEv_1);
    BlueMarbleEv = (BlueMarble *)CUser::getBlueMarble(UserEv);
    if ( BlueMarbleEv )
      BlueMarble::checkBlueMarbleUserConfirm(BlueMarbleEv, UserEv);
  }
  else
  {
    BlueMarbleIndexEv_5 = *((_WORD *)v53 + 7);
    if ( BlueMarbleIndexEv_5 == (unsigned __int16)CUser::getBlueMarbleIndex(UserEv) )
    {
      BlueMarbleEv_1 = (BlueMarble *)CUser::getBlueMarble(UserEv);
      if ( BlueMarbleEv_1 )
      {
        BlueMarbleIndexEv_2 = (__int16)CUser::getBlueMarbleIndex(UserEv);
        v41 = *((__int16 *)v53 + 7);
        MoveSpaceEv_2 = CUser::getMoveSpace(UserEv);
        stateEv_2 = CUser::get_state(UserEv);
        charac_noEi_2 = CUser::get_charac_no(UserEv, -1);
        acc_idEv_2 = CUser::get_acc_id(UserEv);
        v26 = (const char *)NumberToString(acc_idEv_2, 0);
        CMyFileLog::CMyFileLog(
          (CMyFileLog *)v50,
          "virtual int Dispatcher_BlueMarbleConfirmInfo::process(CUser*, MSG_BASE&, ParamBase&)",
          24909);
        CMyFileLog::operator()(
          (int)v50,
          s,
          "OverLap User index same m_id(%s) charac_no(%u) userState(%d) userSpace(%d)client_blueMarble_Index(%d) server_b"
          "luemarble_index(%d)",
          v26,
          charac_noEi_2,
          stateEv_2,
          MoveSpaceEv_2,
          v41,
          BlueMarbleIndexEv_2);
        BlueMarble::checkBlueMarbleUserConfirm(BlueMarbleEv_1, UserEv);
      }
    }
    else
    {
      v13 = *((_WORD *)v53 + 7);
      v14 = (CGameManager *)G_CGameManager();
      BlueMarbleEi = (BlueMarble *)CGameManager::getBlueMarble(v14, v13);
      if ( BlueMarbleEi )
      {
        BlueMarbleIndexEv_3 = (__int16)CUser::getBlueMarbleIndex(UserEv);
        v35 = *((__int16 *)v53 + 7);
        MoveSpaceEv_3 = CUser::getMoveSpace(UserEv);
        stateEv_3 = CUser::get_state(UserEv);
        charac_noEi_3 = CUser::get_charac_no(UserEv, -1);
        acc_idEv_3 = CUser::get_acc_id(UserEv);
        v18 = (const char *)NumberToString(acc_idEv_3, 0);
        CMyFileLog::CMyFileLog(
          (CMyFileLog *)v48,
          "virtual int Dispatcher_BlueMarbleConfirmInfo::process(CUser*, MSG_BASE&, ParamBase&)",
          24885);
        CMyFileLog::operator()(
          (int)v48,
          s,
          "OverLap User index different m_id(%s) charac_no(%u) userState(%d) userSpace(%d)client_blueMarble_Index(%d) ser"
          "ver_bluemarble_index(%d)",
          v18,
          charac_noEi_3,
          stateEv_3,
          MoveSpaceEv_3,
          v35,
          BlueMarbleIndexEv_3);
        BlueMarble::checkBlueMarbleUserConfirm(BlueMarbleEi, UserEv);
      }
      BlueMarbleEi = (BlueMarble *)CUser::getBlueMarble(UserEv);
      if ( BlueMarbleEi )
      {
        BlueMarbleIndexEv_4 = (__int16)CUser::getBlueMarbleIndex(UserEv);
        v38 = *((__int16 *)v53 + 7);
        MoveSpaceEv_4 = CUser::getMoveSpace(UserEv);
        stateEv_4 = CUser::get_state(UserEv);
        charac_noEi_4 = CUser::get_charac_no(UserEv, -1);
        acc_idEv_4 = CUser::get_acc_id(UserEv);
        v22 = (const char *)NumberToString(acc_idEv_4, 0);
        CMyFileLog::CMyFileLog(
          (CMyFileLog *)v49,
          "virtual int Dispatcher_BlueMarbleConfirmInfo::process(CUser*, MSG_BASE&, ParamBase&)",
          24896);
        CMyFileLog::operator()(
          (int)v49,
          s,
          "OverLap User index different m_id(%s) charac_no(%u) userState(%d) userSpace(%d)client_blueMarble_Index(%d) ser"
          "ver_bluemarble_index(%d)",
          v22,
          charac_noEi_4,
          stateEv_4,
          MoveSpaceEv_4,
          v38,
          BlueMarbleIndexEv_4);
        BlueMarble::checkBlueMarbleUserConfirm(BlueMarbleEi, UserEv);
      }
    }
  }
  return 0;
}

// IDA_EA: 0x81E68C8
// IDA_NAME: _ZN32Dispatcher_BlueMarbleConfirmInfo11check_errorEP5CUserR8MSG_BASE
// DEMANGLED: Dispatcher_BlueMarbleConfirmInfo::check_error(CUser *,MSG_BASE &)
int __cdecl Dispatcher_BlueMarbleConfirmInfo::check_error(Dispatcher_BlueMarbleConfirmInfo *this, CUser *UserEv)
{
  if ( !UserEv )
    return -1;
  if ( CUser::get_state(UserEv) > 2 )
    return 0;
  return -1;
}

// IDA_EA: 0x81E6904
// IDA_NAME: _ZN32Dispatcher_BlueMarbleConfirmInfo4sendEP5CUserR9ParamBase
// DEMANGLED: Dispatcher_BlueMarbleConfirmInfo::send(CUser *,ParamBase &)
int __cdecl Dispatcher_BlueMarbleConfirmInfo::send(Dispatcher_BlueMarbleConfirmInfo *this, CUser *a2, ParamBase *a3)
{
  if ( *((_DWORD *)a3 + 1) )
    return CUser::SendCmdErrorPacket(a2, 508, (unsigned __int8)*((_DWORD *)a3 + 1));
  else
    return CUser::SendCmdOkPacket(a2, 508);
}

// IDA_EA: 0x8243C54
// IDA_NAME: _ZN32Dispatcher_BlueMarbleConfirmInfoD2Ev
// DEMANGLED: Dispatcher_BlueMarbleConfirmInfo::~Dispatcher_BlueMarbleConfirmInfo()
void __cdecl Dispatcher_BlueMarbleConfirmInfo::~Dispatcher_BlueMarbleConfirmInfo(
        Dispatcher_BlueMarbleConfirmInfo *this)
{
  *(_DWORD *)this = &off_8BD9C48;
  IPacketDispatcher<MSG_BLUE_MARBLE_CONFIRM_INFO,stBlueMarbleConfirmInfo,(ch_state)3>::~IPacketDispatcher(this);
}

// IDA_EA: 0x8243C84
// IDA_NAME: _ZN32Dispatcher_BlueMarbleConfirmInfoD0Ev
// DEMANGLED: Dispatcher_BlueMarbleConfirmInfo::~Dispatcher_BlueMarbleConfirmInfo()
void __cdecl Dispatcher_BlueMarbleConfirmInfo::~Dispatcher_BlueMarbleConfirmInfo(
        Dispatcher_BlueMarbleConfirmInfo *this)
{
  Dispatcher_BlueMarbleConfirmInfo::~Dispatcher_BlueMarbleConfirmInfo(this);
  operator delete(this);
}

// IDA_EA: 0x8597DE2
// IDA_NAME: _ZN32Dispatcher_BlueMarbleConfirmInfoC2Ev
// DEMANGLED: Dispatcher_BlueMarbleConfirmInfo::Dispatcher_BlueMarbleConfirmInfo(void)
void __cdecl Dispatcher_BlueMarbleConfirmInfo::Dispatcher_BlueMarbleConfirmInfo(Dispatcher_BlueMarbleConfirmInfo *this)
{
  IPacketDispatcher<MSG_BLUE_MARBLE_CONFIRM_INFO,stBlueMarbleConfirmInfo,(ch_state)3>::IPacketDispatcher(this);
  *(_DWORD *)this = &off_8BD9C48;
}
