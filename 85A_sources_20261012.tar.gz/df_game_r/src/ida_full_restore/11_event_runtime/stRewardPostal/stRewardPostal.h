#ifndef __IDA91_STREWARDPOSTAL_H__
#define __IDA91_STREWARDPOSTAL_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: stRewardPostal
// Source unit: stRewardPostal
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4484

/* 4484 */
struct stRewardPostal;

// Exported member functions:
// 0x8AA96F2	stRewardPostal::stRewardPostal(void)

// Function declaration index:
// DECL 0x8AA96F2 stRewardPostal::stRewardPostal

#endif  // __IDA91_STREWARDPOSTAL_H__
