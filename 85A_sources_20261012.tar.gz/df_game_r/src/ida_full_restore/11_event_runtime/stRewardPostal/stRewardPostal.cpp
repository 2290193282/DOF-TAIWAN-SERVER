#include "stRewardPostal.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8AA96F2
// IDA_NAME: _ZN14stRewardPostalC2Ev
// DEMANGLED: stRewardPostal::stRewardPostal(void)
void __cdecl stRewardPostal::stRewardPostal(stRewardPostal *this)
{
  stTitleRewardBasis::stTitleRewardBasis(this);
  std::string::string((std::string *)this + 3);
  std::string::string((std::string *)this + 4);
  std::string::string((std::string *)this + 5);
  *((_DWORD *)this + 6) = 0;
  *((_DWORD *)this + 7) = 0;
  *(_DWORD *)this = 3;
}
