#ifndef __IDA91_DB_INSERTATTENDANCEEVENT_H__
#define __IDA91_DB_INSERTATTENDANCEEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_InsertAttendanceEvent
// Source unit: DB_InsertAttendanceEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2718

/* 2718 */
struct DB_InsertAttendanceEvent;

// Exported member functions:
// 0x8448A48	DB_InsertAttendanceEvent::dispatch(int,int,Stream *)
// 0x8448AFE	DB_InsertAttendanceEvent::makeRequest(int,unsigned int,unsigned int)
// 0x844FD52	DB_InsertAttendanceEvent::DB_InsertAttendanceEvent(void)
// 0x845AF5A	DB_InsertAttendanceEvent::~DB_InsertAttendanceEvent()
// 0x845AF8A	DB_InsertAttendanceEvent::~DB_InsertAttendanceEvent()

// Function declaration index:
// DECL 0x8448A48 DB_InsertAttendanceEvent::dispatch
// DECL 0x8448AFE DB_InsertAttendanceEvent::makeRequest
// DECL 0x844FD52 DB_InsertAttendanceEvent::DB_InsertAttendanceEvent
// DECL 0x845AF5A DB_InsertAttendanceEvent::~DB_InsertAttendanceEvent
// DECL 0x845AF8A DB_InsertAttendanceEvent::~DB_InsertAttendanceEvent

#endif  // __IDA91_DB_INSERTATTENDANCEEVENT_H__
