#include "DB_InsertAttendanceEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8448A48
// IDA_NAME: _ZN24DB_InsertAttendanceEvent8dispatchEiiP6Stream
// DEMANGLED: DB_InsertAttendanceEvent::dispatch(int,int,Stream *)
_BOOL4 __cdecl DB_InsertAttendanceEvent::dispatch(DB_InsertAttendanceEvent *this, int a2, int a3, Stream *a4)
{
  int v4; // ebx
  const char *v5; // eax
  int v7; // [esp+14h] [ebp-14h] BYREF
  unsigned int v8; // [esp+18h] [ebp-10h] BYREF
  MySQL *DBHandle; // [esp+1Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 9, 0);
  v8 = 0;
  v7 = 0;
  Stream::operator>>(a4, (int)&v8);
  Stream::operator>>(a4, (int)&v7);
  v4 = v7;
  v5 = (const char *)NumberToString(v8, 0);
  MySQL::set_query(
    DBHandle,
    "inSert into event_1207_attendance(m_id, charac_no, occ_date) \t\t\t\t  values(%s, %u, now())",
    v5,
    v4);
  return (unsigned __int8)MySQL::exec(DBHandle, 1) == 1;
}

// IDA_EA: 0x8448AFE
// IDA_NAME: _ZN24DB_InsertAttendanceEvent11makeRequestEijj
// DEMANGLED: DB_InsertAttendanceEvent::makeRequest(int,unsigned int,unsigned int)
void __cdecl DB_InsertAttendanceEvent::makeRequest(DB_InsertAttendanceEvent *this, char src, char src_1)
{
  Stream *v3; // eax
  Stream **v4; // eax
  Stream **v5; // eax
  Stream **v6; // eax
  Stream **v7; // eax
  _BYTE v8[16]; // [esp+18h] [ebp-10h] BYREF

  v3 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 46673);
  CStreamGuard::CStreamGuard((CStreamGuard *)v8, v3, 1);
  v4 = (Stream **)CStreamGuard::operator*((int)v8);
  CStreamGuard::operator<<(v4, 14);
  v5 = (Stream **)CStreamGuard::operator*((int)v8);
  CStreamGuard::operator<<(v5, (char)this);
  v6 = (Stream **)CStreamGuard::operator*((int)v8);
  CStreamGuard::operator<<(v6, src);
  v7 = (Stream **)CStreamGuard::operator*((int)v8);
  CStreamGuard::operator<<(v7, src_1);
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v8);
  CStreamGuard::~CStreamGuard((CStreamGuard *)v8);
}

// IDA_EA: 0x844FD52
// IDA_NAME: _ZN24DB_InsertAttendanceEventC2Ev
// DEMANGLED: DB_InsertAttendanceEvent::DB_InsertAttendanceEvent(void)
void __cdecl DB_InsertAttendanceEvent::DB_InsertAttendanceEvent(DB_InsertAttendanceEvent *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5E160;
}

// IDA_EA: 0x845AF5A
// IDA_NAME: _ZN24DB_InsertAttendanceEventD2Ev
// DEMANGLED: DB_InsertAttendanceEvent::~DB_InsertAttendanceEvent()
void __cdecl DB_InsertAttendanceEvent::~DB_InsertAttendanceEvent(DB_InsertAttendanceEvent *this)
{
  *(_DWORD *)this = &off_8C5E160;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845AF8A
// IDA_NAME: _ZN24DB_InsertAttendanceEventD0Ev
// DEMANGLED: DB_InsertAttendanceEvent::~DB_InsertAttendanceEvent()
void __cdecl DB_InsertAttendanceEvent::~DB_InsertAttendanceEvent(DB_InsertAttendanceEvent *this)
{
  DB_InsertAttendanceEvent::~DB_InsertAttendanceEvent(this);
  operator delete(this);
}
