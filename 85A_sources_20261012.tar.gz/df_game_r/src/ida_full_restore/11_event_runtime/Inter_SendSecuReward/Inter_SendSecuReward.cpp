#include "Inter_SendSecuReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84E5E1E
// IDA_NAME: _ZN20Inter_SendSecuReward12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_SendSecuReward::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_SendSecuReward::dispatch_sig(Inter_SendSecuReward *this, CUser *a2, char *a3)
{
  if ( *(_DWORD *)a3 )
    CUser::AddSecuRewardItem(a2, 0x10u);
  else
    CUser::AddSecuRewardItem(a2, 8u);
  return 0;
}

// IDA_EA: 0x84EEC8C
// IDA_NAME: _ZN20Inter_SendSecuRewardC2Ev
// DEMANGLED: Inter_SendSecuReward::Inter_SendSecuReward(void)
void __cdecl Inter_SendSecuReward::Inter_SendSecuReward(Inter_SendSecuReward *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8E5B8;
}

// IDA_EA: 0x84F5EE0
// IDA_NAME: _ZN20Inter_SendSecuRewardD2Ev
// DEMANGLED: Inter_SendSecuReward::~Inter_SendSecuReward()
void __cdecl Inter_SendSecuReward::~Inter_SendSecuReward(Inter_SendSecuReward *this)
{
  *(_DWORD *)this = &off_8C8E5B8;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84F5F10
// IDA_NAME: _ZN20Inter_SendSecuRewardD0Ev
// DEMANGLED: Inter_SendSecuReward::~Inter_SendSecuReward()
void __cdecl Inter_SendSecuReward::~Inter_SendSecuReward(Inter_SendSecuReward *this)
{
  Inter_SendSecuReward::~Inter_SendSecuReward(this);
  operator delete(this);
}
