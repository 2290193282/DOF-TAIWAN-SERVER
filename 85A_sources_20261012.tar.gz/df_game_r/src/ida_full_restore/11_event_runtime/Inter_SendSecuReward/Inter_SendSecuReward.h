#ifndef __IDA91_INTER_SENDSECUREWARD_H__
#define __IDA91_INTER_SENDSECUREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_SendSecuReward
// Source unit: Inter_SendSecuReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 3218

/* 3218 */
struct Inter_SendSecuReward;

// Exported member functions:
// 0x84E5E1E	Inter_SendSecuReward::dispatch_sig(CUser *,char *,int)
// 0x84EEC8C	Inter_SendSecuReward::Inter_SendSecuReward(void)
// 0x84F5EE0	Inter_SendSecuReward::~Inter_SendSecuReward()
// 0x84F5F10	Inter_SendSecuReward::~Inter_SendSecuReward()

// Function declaration index:
// DECL 0x84E5E1E Inter_SendSecuReward::dispatch_sig
// DECL 0x84EEC8C Inter_SendSecuReward::Inter_SendSecuReward
// DECL 0x84F5EE0 Inter_SendSecuReward::~Inter_SendSecuReward
// DECL 0x84F5F10 Inter_SendSecuReward::~Inter_SendSecuReward

#endif  // __IDA91_INTER_SENDSECUREWARD_H__
