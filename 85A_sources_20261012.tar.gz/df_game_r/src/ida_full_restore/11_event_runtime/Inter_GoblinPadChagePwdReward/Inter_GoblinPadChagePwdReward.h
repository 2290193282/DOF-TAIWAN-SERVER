#ifndef __IDA91_INTER_GOBLINPADCHAGEPWDREWARD_H__
#define __IDA91_INTER_GOBLINPADCHAGEPWDREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_GoblinPadChagePwdReward
// Source unit: Inter_GoblinPadChagePwdReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 3204

/* 3204 */
struct Inter_GoblinPadChagePwdReward;

// Exported member functions:
// 0x84E4354	Inter_GoblinPadChagePwdReward::dispatch_sig(CUser *,char *,int)
// 0x84EEAE8	Inter_GoblinPadChagePwdReward::Inter_GoblinPadChagePwdReward(void)
// 0x84F64AA	Inter_GoblinPadChagePwdReward::~Inter_GoblinPadChagePwdReward()
// 0x84F64DA	Inter_GoblinPadChagePwdReward::~Inter_GoblinPadChagePwdReward()

// Function declaration index:
// DECL 0x84E4354 Inter_GoblinPadChagePwdReward::dispatch_sig
// DECL 0x84EEAE8 Inter_GoblinPadChagePwdReward::Inter_GoblinPadChagePwdReward
// DECL 0x84F64AA Inter_GoblinPadChagePwdReward::~Inter_GoblinPadChagePwdReward
// DECL 0x84F64DA Inter_GoblinPadChagePwdReward::~Inter_GoblinPadChagePwdReward

#endif  // __IDA91_INTER_GOBLINPADCHAGEPWDREWARD_H__
