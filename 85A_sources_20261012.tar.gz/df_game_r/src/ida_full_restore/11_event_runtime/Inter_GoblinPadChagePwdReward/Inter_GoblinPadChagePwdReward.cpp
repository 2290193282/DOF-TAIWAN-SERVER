#include "Inter_GoblinPadChagePwdReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84E4354
// IDA_NAME: _ZN29Inter_GoblinPadChagePwdReward12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_GoblinPadChagePwdReward::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_GoblinPadChagePwdReward::dispatch_sig(Inter_GoblinPadChagePwdReward *this, CUser *a2)
{
  char *PadEv; // eax

  if ( a2 )
  {
    PadEv = CUser::getPad(a2);
    Sanicova::CPad::SendChagePwdReward((Sanicova::CPad *)PadEv, a2);
  }
  return 0;
}

// IDA_EA: 0x84EEAE8
// IDA_NAME: _ZN29Inter_GoblinPadChagePwdRewardC2Ev
// DEMANGLED: Inter_GoblinPadChagePwdReward::Inter_GoblinPadChagePwdReward(void)
void __cdecl Inter_GoblinPadChagePwdReward::Inter_GoblinPadChagePwdReward(Inter_GoblinPadChagePwdReward *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8E790;
}

// IDA_EA: 0x84F64AA
// IDA_NAME: _ZN29Inter_GoblinPadChagePwdRewardD2Ev
// DEMANGLED: Inter_GoblinPadChagePwdReward::~Inter_GoblinPadChagePwdReward()
void __cdecl Inter_GoblinPadChagePwdReward::~Inter_GoblinPadChagePwdReward(Inter_GoblinPadChagePwdReward *this)
{
  *(_DWORD *)this = &off_8C8E790;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84F64DA
// IDA_NAME: _ZN29Inter_GoblinPadChagePwdRewardD0Ev
// DEMANGLED: Inter_GoblinPadChagePwdReward::~Inter_GoblinPadChagePwdReward()
void __cdecl Inter_GoblinPadChagePwdReward::~Inter_GoblinPadChagePwdReward(Inter_GoblinPadChagePwdReward *this)
{
  Inter_GoblinPadChagePwdReward::~Inter_GoblinPadChagePwdReward(this);
  operator delete(this);
}
