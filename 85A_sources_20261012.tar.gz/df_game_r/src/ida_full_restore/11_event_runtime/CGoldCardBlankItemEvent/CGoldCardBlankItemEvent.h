#ifndef __IDA91_CGOLDCARDBLANKITEMEVENT_H__
#define __IDA91_CGOLDCARDBLANKITEMEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CGoldCardBlankItemEvent
// Source unit: CGoldCardBlankItemEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "items/Inven_Item.h"
//   #include "items/CItem.h"
// Local type ordinals: 1211

/* 1211 */
struct CGoldCardBlankItemEvent;

// Exported member functions:
// 0x811CE24	CGoldCardBlankItemEvent::CGoldCardBlankItemEvent(void)
// 0x811CE40	CGoldCardBlankItemEvent::~CGoldCardBlankItemEvent()
// 0x811CE70	CGoldCardBlankItemEvent::~CGoldCardBlankItemEvent()
// 0x811CE8E	CGoldCardBlankItemEvent::StartEvent(void)
// 0x811CE94	CGoldCardBlankItemEvent::StartEvent(Word_Param)
// 0x811CEE6	CGoldCardBlankItemEvent::EndEvent(void)

// Function declaration index:
// DECL 0x811CE24 CGoldCardBlankItemEvent::CGoldCardBlankItemEvent
// DECL 0x811CE40 CGoldCardBlankItemEvent::~CGoldCardBlankItemEvent
// DECL 0x811CE70 CGoldCardBlankItemEvent::~CGoldCardBlankItemEvent
// DECL 0x811CE8E CGoldCardBlankItemEvent::StartEvent
// DECL 0x811CE94 CGoldCardBlankItemEvent::StartEvent
// DECL 0x811CEE6 CGoldCardBlankItemEvent::EndEvent

#endif  // __IDA91_CGOLDCARDBLANKITEMEVENT_H__
