#include "CGoldCardBlankItemEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x811CE24
// IDA_NAME: _ZN23CGoldCardBlankItemEventC2Ev
// DEMANGLED: CGoldCardBlankItemEvent::CGoldCardBlankItemEvent(void)
void __cdecl CGoldCardBlankItemEvent::CGoldCardBlankItemEvent(CGoldCardBlankItemEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B545A8;
}

// IDA_EA: 0x811CE40
// IDA_NAME: _ZN23CGoldCardBlankItemEventD2Ev
// DEMANGLED: CGoldCardBlankItemEvent::~CGoldCardBlankItemEvent()
void __cdecl CGoldCardBlankItemEvent::~CGoldCardBlankItemEvent(CGoldCardBlankItemEvent *this)
{
  *(_DWORD *)this = off_8B545A8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x811CE70
// IDA_NAME: _ZN23CGoldCardBlankItemEventD0Ev
// DEMANGLED: CGoldCardBlankItemEvent::~CGoldCardBlankItemEvent()
void __cdecl CGoldCardBlankItemEvent::~CGoldCardBlankItemEvent(CGoldCardBlankItemEvent *this)
{
  CGoldCardBlankItemEvent::~CGoldCardBlankItemEvent(this);
  operator delete(this);
}

// IDA_EA: 0x811CE8E
// IDA_NAME: _ZN23CGoldCardBlankItemEvent10StartEventEv
// DEMANGLED: CGoldCardBlankItemEvent::StartEvent(void)
void CGoldCardBlankItemEvent::StartEvent()
{
  ;
}

// IDA_EA: 0x811CE94
// IDA_NAME: _ZN23CGoldCardBlankItemEvent10StartEventE10Word_Param
// DEMANGLED: CGoldCardBlankItemEvent::StartEvent(Word_Param)
int __cdecl CGoldCardBlankItemEvent::StartEvent(CEventBase *a1)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(a1, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "StartEvent", 24, 0);
  return cMyTrace::operator()((int)v3, "Gold Card Blank Item Event Start", v2);
}

// IDA_EA: 0x811CEE6
// IDA_NAME: _ZN23CGoldCardBlankItemEvent8EndEventEv
// DEMANGLED: CGoldCardBlankItemEvent::EndEvent(void)
int __cdecl CGoldCardBlankItemEvent::EndEvent(CGoldCardBlankItemEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "EndEvent", 30, 0);
  return cMyTrace::operator()((int)v3, "Gold Card Blank Item Event End", v2);
}
