#include "DB_UpdateBingoEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8448EB8
// IDA_NAME: _ZN19DB_UpdateBingoEvent8dispatchEiiP6Stream
// DEMANGLED: DB_UpdateBingoEvent::dispatch(int,int,Stream *)
_BOOL4 __cdecl DB_UpdateBingoEvent::dispatch(DB_UpdateBingoEvent *this, int a2, int a3, Stream *a4)
{
  int tm_hour; // ebx
  time_t CurSecEv; // eax
  const char *v6; // eax
  _BOOL4 result; // eax
  __int64 v8; // rax
  int v9; // esi
  int v10; // ebx
  const char *v11; // eax
  _BYTE dest[5]; // [esp+2Fh] [ebp-19h] BYREF
  unsigned int v13; // [esp+34h] [ebp-14h] BYREF
  MySQL *DBHandle; // [esp+38h] [ebp-10h]
  time_t CurrentResetBaseTime; // [esp+3Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 9, 0);
  v13 = 0;
  memset(dest, 0, sizeof(dest));
  Stream::operator>>(a4, (int)&v13);
  Stream::operator>>(a4, &dest[1]);
  Stream::operator>>(a4, (int)dest);
  tm_hour = *(_DWORD *)(G_CEnvironment() + 892);
  CurSecEv = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
  CurrentResetBaseTime = GetCurrentResetBaseTime(CurSecEv, tm_hour);
  v6 = (const char *)NumberToString(v13, 0);
  MySQL::set_query(
    DBHandle,
    "upDate event_1208_bingo set board = %d,reward=%d where m_id = %s and occ_date > from_unixtime(%u)",
    *(_DWORD *)&dest[1],
    dest[0],
    v6,
    CurrentResetBaseTime);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
    return 0;
  LODWORD(v8) = MySQL::getAffectedRowCount(DBHandle);
  result = 1;
  if ( !v8 )
  {
    v9 = dest[0];
    v10 = *(_DWORD *)&dest[1];
    v11 = (const char *)NumberToString(v13, 0);
    MySQL::set_query(
      DBHandle,
      "inSert into event_1208_bingo(m_id,occ_date,board,reward) values(%s,now(),%d,%d)",
      v11,
      v10,
      v9);
    if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
      return 0;
  }
  return result;
}

// IDA_EA: 0x8449032
// IDA_NAME: _ZN19DB_UpdateBingoEvent11makeRequestEijib
// DEMANGLED: DB_UpdateBingoEvent::makeRequest(int,unsigned int,int,bool)
void __cdecl DB_UpdateBingoEvent::makeRequest(DB_UpdateBingoEvent *this, char src, char src_1, char a4)
{
  Stream *v4; // eax
  Stream **v5; // eax
  Stream **v6; // eax
  Stream **v7; // eax
  Stream **v8; // eax
  Stream **v9; // eax
  _BYTE v10[16]; // [esp+28h] [ebp-10h] BYREF

  v4 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 46942);
  CStreamGuard::CStreamGuard((CStreamGuard *)v10, v4, 1);
  v5 = (Stream **)CStreamGuard::operator*((int)v10);
  CStreamGuard::operator<<(v5, 31);
  v6 = (Stream **)CStreamGuard::operator*((int)v10);
  CStreamGuard::operator<<(v6, (char)this);
  v7 = (Stream **)CStreamGuard::operator*((int)v10);
  CStreamGuard::operator<<(v7, src);
  v8 = (Stream **)CStreamGuard::operator*((int)v10);
  CStreamGuard::operator<<(v8, src_1);
  v9 = (Stream **)CStreamGuard::operator*((int)v10);
  CStreamGuard::operator<<(v9, a4);
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v10);
  CStreamGuard::~CStreamGuard((CStreamGuard *)v10);
}

// IDA_EA: 0x844FD6E
// IDA_NAME: _ZN19DB_UpdateBingoEventC2Ev
// DEMANGLED: DB_UpdateBingoEvent::DB_UpdateBingoEvent(void)
void __cdecl DB_UpdateBingoEvent::DB_UpdateBingoEvent(DB_UpdateBingoEvent *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5E148;
}

// IDA_EA: 0x845AF0C
// IDA_NAME: _ZN19DB_UpdateBingoEventD2Ev
// DEMANGLED: DB_UpdateBingoEvent::~DB_UpdateBingoEvent()
void __cdecl DB_UpdateBingoEvent::~DB_UpdateBingoEvent(DB_UpdateBingoEvent *this)
{
  *(_DWORD *)this = &off_8C5E148;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845AF3C
// IDA_NAME: _ZN19DB_UpdateBingoEventD0Ev
// DEMANGLED: DB_UpdateBingoEvent::~DB_UpdateBingoEvent()
void __cdecl DB_UpdateBingoEvent::~DB_UpdateBingoEvent(DB_UpdateBingoEvent *this)
{
  DB_UpdateBingoEvent::~DB_UpdateBingoEvent(this);
  operator delete(this);
}
