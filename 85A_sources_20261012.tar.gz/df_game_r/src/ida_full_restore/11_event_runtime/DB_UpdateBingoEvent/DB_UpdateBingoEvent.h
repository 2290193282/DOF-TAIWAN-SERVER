#ifndef __IDA91_DB_UPDATEBINGOEVENT_H__
#define __IDA91_DB_UPDATEBINGOEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_UpdateBingoEvent
// Source unit: DB_UpdateBingoEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2719

/* 2719 */
struct DB_UpdateBingoEvent;

// Exported member functions:
// 0x8448EB8	DB_UpdateBingoEvent::dispatch(int,int,Stream *)
// 0x8449032	DB_UpdateBingoEvent::makeRequest(int,unsigned int,int,bool)
// 0x844FD6E	DB_UpdateBingoEvent::DB_UpdateBingoEvent(void)
// 0x845AF0C	DB_UpdateBingoEvent::~DB_UpdateBingoEvent()
// 0x845AF3C	DB_UpdateBingoEvent::~DB_UpdateBingoEvent()

// Function declaration index:
// DECL 0x8448EB8 DB_UpdateBingoEvent::dispatch
// DECL 0x8449032 DB_UpdateBingoEvent::makeRequest
// DECL 0x844FD6E DB_UpdateBingoEvent::DB_UpdateBingoEvent
// DECL 0x845AF0C DB_UpdateBingoEvent::~DB_UpdateBingoEvent
// DECL 0x845AF3C DB_UpdateBingoEvent::~DB_UpdateBingoEvent

#endif  // __IDA91_DB_UPDATEBINGOEVENT_H__
