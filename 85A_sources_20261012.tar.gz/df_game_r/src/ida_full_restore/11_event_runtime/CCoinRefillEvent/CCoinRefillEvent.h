#ifndef __IDA91_CCOINREFILLEVENT_H__
#define __IDA91_CCOINREFILLEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CCoinRefillEvent
// Source unit: CCoinRefillEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 2337

/* 2337 */
struct CCoinRefillEvent;

// Exported member functions:
// 0x832BDF4	CCoinRefillEvent::CCoinRefillEvent(void)
// 0x832BE2E	CCoinRefillEvent::~CCoinRefillEvent()
// 0x832BE5E	CCoinRefillEvent::~CCoinRefillEvent()
// 0x832BE7C	CCoinRefillEvent::StartEvent(void)
// 0x832BE82	CCoinRefillEvent::StartEvent(Word_Param)
// 0x832C048	CCoinRefillEvent::EndEvent(void)
// 0x832C0B8	CCoinRefillEvent::getLastEventTime(void)const
// 0x832C148	CCoinRefillEvent::getNextEventTime(tm const&)const
// 0x832C1FE	CCoinRefillEvent::registNextRefillTimer(void)const

// Function declaration index:
// DECL 0x832BDF4 CCoinRefillEvent::CCoinRefillEvent
// DECL 0x832BE2E CCoinRefillEvent::~CCoinRefillEvent
// DECL 0x832BE5E CCoinRefillEvent::~CCoinRefillEvent
// DECL 0x832BE7C CCoinRefillEvent::StartEvent
// DECL 0x832BE82 CCoinRefillEvent::StartEvent
// DECL 0x832C048 CCoinRefillEvent::EndEvent
// DECL 0x832C0B8 CCoinRefillEvent::getLastEventTime
// DECL 0x832C148 CCoinRefillEvent::getNextEventTime
// DECL 0x832C1FE CCoinRefillEvent::registNextRefillTimer

#endif  // __IDA91_CCOINREFILLEVENT_H__
