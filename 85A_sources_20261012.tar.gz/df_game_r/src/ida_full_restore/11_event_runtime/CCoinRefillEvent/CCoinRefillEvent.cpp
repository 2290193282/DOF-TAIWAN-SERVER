#include "CCoinRefillEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x832BDF4
// IDA_NAME: _ZN16CCoinRefillEventC2Ev
// DEMANGLED: CCoinRefillEvent::CCoinRefillEvent(void)
void __cdecl CCoinRefillEvent::CCoinRefillEvent(CCoinRefillEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8C2ABA8;
  memset((char *)this + 12, -1, 0x14u);
}

// IDA_EA: 0x832BE2E
// IDA_NAME: _ZN16CCoinRefillEventD2Ev
// DEMANGLED: CCoinRefillEvent::~CCoinRefillEvent()
void __cdecl CCoinRefillEvent::~CCoinRefillEvent(CCoinRefillEvent *this)
{
  *(_DWORD *)this = off_8C2ABA8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x832BE5E
// IDA_NAME: _ZN16CCoinRefillEventD0Ev
// DEMANGLED: CCoinRefillEvent::~CCoinRefillEvent()
void __cdecl CCoinRefillEvent::~CCoinRefillEvent(CCoinRefillEvent *this)
{
  CCoinRefillEvent::~CCoinRefillEvent(this);
  operator delete(this);
}

// IDA_EA: 0x832BE7C
// IDA_NAME: _ZN16CCoinRefillEvent10StartEventEv
// DEMANGLED: CCoinRefillEvent::StartEvent(void)
void CCoinRefillEvent::StartEvent()
{
  ;
}

// IDA_EA: 0x832BE82
// IDA_NAME: _ZN16CCoinRefillEvent10StartEventE10Word_Param
// DEMANGLED: CCoinRefillEvent::StartEvent(Word_Param)
int __cdecl CCoinRefillEvent::StartEvent(CEventBase *a1, int a2)
{
  int v2; // ebx
  int v4[4]; // [esp+20h] [ebp-38h] BYREF
  int n5_2; // [esp+30h] [ebp-28h]
  int n25; // [esp+34h] [ebp-24h]
  int n5; // [esp+38h] [ebp-20h]
  int n5_1; // [esp+3Ch] [ebp-1Ch]

  CEventBase::SetEventFlag(a1, 1);
  memset((char *)a1 + 12, -1, 0x14u);
  *((_DWORD *)a1 + 4) = *(_DWORD *)(G_CEnvironment() + 892);
  *((_DWORD *)a1 + 5) = (unsigned __int16)a2;
  *((_DWORD *)a1 + 6) = HIWORD(a2);
  for ( *((_DWORD *)a1 + 3) = 0; *((_DWORD *)a1 + 3) <= 3u; ++*((_DWORD *)a1 + 3) )
  {
    if ( *((int *)a1 + *((_DWORD *)a1 + 3) + 4) > 23 )
      *((_DWORD *)a1 + *((_DWORD *)a1 + 3) + 4) = -1;
    if ( *((_DWORD *)a1 + *((_DWORD *)a1 + 3) + 4) == -1 )
      break;
  }
  for ( n5_2 = 1; *((_DWORD *)a1 + 3) >= n5_2; ++n5_2 )
  {
    n25 = 25;
    n5 = 5;
    for ( n5_1 = n5_2; *((_DWORD *)a1 + 3) >= n5_1; ++n5_1 )
    {
      if ( *((_DWORD *)a1 + n5_1 + 3) < n25 )
      {
        n25 = *((_DWORD *)a1 + n5_1 + 3);
        n5 = n5_1;
      }
    }
    *((_DWORD *)a1 + n5 + 3) = *((_DWORD *)a1 + n5_2 + 3);
    *((_DWORD *)a1 + n5_2 + 3) = n25;
  }
  CCoinRefillEvent::registNextRefillTimer(a1);
  v2 = *((_DWORD *)a1 + 4);
  cMyTrace::cMyTrace((cMyTrace *)v4, "virtual void CCoinRefillEvent::StartEvent(Word_Param)", 72, 0);
  return cMyTrace::operator()((int)v4, "Coin Refill Event Start! time(%d) time(%d) time(%d)", v2);
}

// IDA_EA: 0x832C048
// IDA_NAME: _ZN16CCoinRefillEvent8EndEventEv
// DEMANGLED: CCoinRefillEvent::EndEvent(void)
int __cdecl CCoinRefillEvent::EndEvent(CCoinRefillEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  memset((char *)this + 12, -1, 0x14u);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CCoinRefillEvent::EndEvent()", 79, 0);
  return cMyTrace::operator()((int)v3, "Coin Refill Event End", v2);
}

// IDA_EA: 0x832C0B8
// IDA_NAME: _ZNK16CCoinRefillEvent16getLastEventTimeEv
// DEMANGLED: CCoinRefillEvent::getLastEventTime(void)const
int __cdecl CCoinRefillEvent::getLastEventTime(CCoinRefillEvent *this)
{
  struct tm tp; // [esp+1Ch] [ebp-3Ch] BYREF
  time_t timer; // [esp+48h] [ebp-10h] BYREF
  int n2; // [esp+4Ch] [ebp-Ch]

  timer = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
  localtime_r(&timer, &tp);
  if ( tp.tm_hour < *((_DWORD *)this + 4) )
    return *((_DWORD *)this + *((_DWORD *)this + 3) + 3);
  for ( n2 = 2; *((_DWORD *)this + 3) >= n2; ++n2 )
  {
    if ( tp.tm_hour < *((_DWORD *)this + n2 + 3) )
      return *((_DWORD *)this + n2 + 2);
  }
  return *((_DWORD *)this + *((_DWORD *)this + 3) + 3);
}

// IDA_EA: 0x832C148
// IDA_NAME: _ZNK16CCoinRefillEvent16getNextEventTimeERK2tm
// DEMANGLED: CCoinRefillEvent::getNextEventTime(tm const&)const
int __cdecl CCoinRefillEvent::getNextEventTime(CCoinRefillEvent *this, const tm *p_tp)
{
  int v2; // ebx
  int v4; // ebx
  int i; // [esp+8h] [ebp-10h]
  int j; // [esp+Ch] [ebp-Ch]

  for ( i = 1; *((_DWORD *)this + 3) >= i; ++i )
  {
    v2 = *((_DWORD *)this + i + 3);
    if ( v2 != *(_DWORD *)(G_CEnvironment() + 892) && p_tp->tm_hour < *((_DWORD *)this + i + 3) )
      return *((_DWORD *)this + i + 3);
  }
  for ( j = 1; *((_DWORD *)this + 3) >= j; ++j )
  {
    v4 = *((_DWORD *)this + j + 3);
    if ( v4 != *(_DWORD *)(G_CEnvironment() + 892) )
      return *((_DWORD *)this + j + 3);
  }
  return *((_DWORD *)this + 4);
}

// IDA_EA: 0x832C1FE
// IDA_NAME: _ZNK16CCoinRefillEvent21registNextRefillTimerEv
// DEMANGLED: CCoinRefillEvent::registNextRefillTimer(void)const
int __cdecl CCoinRefillEvent::registNextRefillTimer(CCoinRefillEvent *this)
{
  int result; // eax
  int v2; // ebx
  TimerQueue *v3; // eax
  struct tm tp_; // [esp+20h] [ebp-78h] BYREF
  struct tm tp; // [esp+4Ch] [ebp-4Ch] BYREF
  time_t timer_; // [esp+78h] [ebp-20h] BYREF
  time_t timer; // [esp+7Ch] [ebp-1Ch] BYREF
  int v8[6]; // [esp+80h] [ebp-18h] BYREF

  timer = CSystemTime::getCurSec((CSystemTime *)GlobalData::s_systemTime_);
  localtime_r(&timer, &tp);
  tp_.tm_sec = tp.tm_sec;
  tp_.tm_min = tp.tm_min;
  tp_.tm_mday = tp.tm_mday;
  tp_.tm_mon = tp.tm_mon;
  tp_.tm_year = tp.tm_year;
  tp_.tm_wday = tp.tm_wday;
  tp_.tm_yday = tp.tm_yday;
  tp_.tm_isdst = tp.tm_isdst;
  tp_.tm_gmtoff = tp.tm_gmtoff;
  tp_.tm_zone = tp.tm_zone;
  tp_.tm_hour = CCoinRefillEvent::getNextEventTime(this, &tp);
  if ( tp_.tm_hour < tp.tm_hour )
    ++tp_.tm_mday;
  tp_.tm_min = 0;
  tp_.tm_sec = 0;
  timer_ = mktime(&tp_);
  result = timer_ - timer;
  if ( timer_ - timer >= 0 )
  {
    v2 = timer_ - timer;
    v3 = (TimerQueue *)G_TimerQueue();
    TimerQueue::InsertTimer(v3, 2, 0, 101, v2, 0, 0);
    LOBYTE(v2) = (unsigned __int8)ctime(&timer_);
    cMyTrace::cMyTrace((cMyTrace *)v8, "void CCoinRefillEvent::registNextRefillTimer() const", 136, 0);
    return cMyTrace::operator()((int)v8, "Next coin refill time is %s", v2);
  }
  return result;
}
