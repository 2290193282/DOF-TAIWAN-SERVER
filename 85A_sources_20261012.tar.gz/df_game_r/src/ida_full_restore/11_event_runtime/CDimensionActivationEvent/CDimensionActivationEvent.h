#ifndef __IDA91_CDIMENSIONACTIVATIONEVENT_H__
#define __IDA91_CDIMENSIONACTIVATIONEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CDimensionActivationEvent
// Source unit: CDimensionActivationEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "world/CDungeon.h"
// Local type ordinals: 4368

/* 4368 */
struct CDimensionActivationEvent;

// Exported member functions:
// 0x80EEA84	CDimensionActivationEvent::CDimensionActivationEvent(void)
// 0x80EEAA0	CDimensionActivationEvent::~CDimensionActivationEvent()
// 0x80EEAD0	CDimensionActivationEvent::~CDimensionActivationEvent()
// 0x80EEAEE	CDimensionActivationEvent::StartEvent(void)
// 0x80EEB4A	CDimensionActivationEvent::StartEvent(Word_Param)
// 0x80EEB64	CDimensionActivationEvent::EndEvent(void)
// 0x80EEBC0	CDimensionActivationEvent::set_dungeon_play_count(void)
// 0x80EEC58	CDimensionActivationEvent::reset_dungeon_play_count(void)
// 0x80EECA4	CDimensionActivationEvent::checkFreeRevivalCondition(int)

// Function declaration index:
// DECL 0x80EEA84 CDimensionActivationEvent::CDimensionActivationEvent
// DECL 0x80EEAA0 CDimensionActivationEvent::~CDimensionActivationEvent
// DECL 0x80EEAD0 CDimensionActivationEvent::~CDimensionActivationEvent
// DECL 0x80EEAEE CDimensionActivationEvent::StartEvent
// DECL 0x80EEB4A CDimensionActivationEvent::StartEvent
// DECL 0x80EEB64 CDimensionActivationEvent::EndEvent
// DECL 0x80EEBC0 CDimensionActivationEvent::set_dungeon_play_count
// DECL 0x80EEC58 CDimensionActivationEvent::reset_dungeon_play_count
// DECL 0x80EECA4 CDimensionActivationEvent::checkFreeRevivalCondition

#endif  // __IDA91_CDIMENSIONACTIVATIONEVENT_H__
