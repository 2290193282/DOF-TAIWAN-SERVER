#include "CDimensionActivationEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x80EEA84
// IDA_NAME: _ZN25CDimensionActivationEventC2Ev
// DEMANGLED: CDimensionActivationEvent::CDimensionActivationEvent(void)
void __cdecl CDimensionActivationEvent::CDimensionActivationEvent(CDimensionActivationEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8B39BE8;
}

// IDA_EA: 0x80EEAA0
// IDA_NAME: _ZN25CDimensionActivationEventD2Ev
// DEMANGLED: CDimensionActivationEvent::~CDimensionActivationEvent()
void __cdecl CDimensionActivationEvent::~CDimensionActivationEvent(CDimensionActivationEvent *this)
{
  *(_DWORD *)this = off_8B39BE8;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x80EEAD0
// IDA_NAME: _ZN25CDimensionActivationEventD0Ev
// DEMANGLED: CDimensionActivationEvent::~CDimensionActivationEvent()
void __cdecl CDimensionActivationEvent::~CDimensionActivationEvent(CDimensionActivationEvent *this)
{
  CDimensionActivationEvent::~CDimensionActivationEvent(this);
  operator delete(this);
}

// IDA_EA: 0x80EEAEE
// IDA_NAME: _ZN25CDimensionActivationEvent10StartEventEv
// DEMANGLED: CDimensionActivationEvent::StartEvent(void)
int __cdecl CDimensionActivationEvent::StartEvent(CDimensionActivationEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 1);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CDimensionActivationEvent::StartEvent()", 18, 0);
  cMyTrace::operator()((int)v3, "CDimensionActivationEvent Event Start!", v2);
  return CDimensionActivationEvent::set_dungeon_play_count(this);
}

// IDA_EA: 0x80EEB4A
// IDA_NAME: _ZN25CDimensionActivationEvent10StartEventE10Word_Param
// DEMANGLED: CDimensionActivationEvent::StartEvent(Word_Param)
int __cdecl CDimensionActivationEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x80EEB64
// IDA_NAME: _ZN25CDimensionActivationEvent8EndEventEv
// DEMANGLED: CDimensionActivationEvent::EndEvent(void)
int __cdecl CDimensionActivationEvent::EndEvent(CDimensionActivationEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  CEventBase::SetEventFlag(this, 0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void CDimensionActivationEvent::EndEvent()", 30, 0);
  cMyTrace::operator()((int)v3, "CDimensionActivationEvent Event End!", v2);
  return CDimensionActivationEvent::reset_dungeon_play_count(this);
}

// IDA_EA: 0x80EEBC0
// IDA_NAME: _ZN25CDimensionActivationEvent22set_dungeon_play_countEv
// DEMANGLED: CDimensionActivationEvent::set_dungeon_play_count(void)
char CDimensionActivationEvent::set_dungeon_play_count()
{
  char result; // al
  char v1; // bl
  CDataManager *v2; // eax
  int v3[4]; // [esp+18h] [ebp-20h] BYREF
  char v4[4]; // [esp+28h] [ebp-10h]
  int n5; // [esp+2Ch] [ebp-Ch]

  *(_DWORD *)v4 = *(_DWORD *)(G_CDataManager() + 19224);
  cMyTrace::cMyTrace((cMyTrace *)v3, "void CDimensionActivationEvent::set_dungeon_play_count()", 39, 0);
  result = cMyTrace::operator()((int)v3, "CDimensionActivationEvent day_play_count : %d", v4[0]);
  if ( *(int *)v4 > 0 )
  {
    for ( n5 = 0; ; ++n5 )
    {
      result = n5 <= 5;
      if ( n5 > 5 )
        break;
      v1 = v4[0];
      v2 = (CDataManager *)G_CDataManager();
      CDataManager::set_dimensionInout(v2, n5, v1);
    }
  }
  return result;
}

// IDA_EA: 0x80EEC58
// IDA_NAME: _ZN25CDimensionActivationEvent24reset_dungeon_play_countEv
// DEMANGLED: CDimensionActivationEvent::reset_dungeon_play_count(void)
int CDimensionActivationEvent::reset_dungeon_play_count()
{
  CDataManager *v0; // eax
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  v0 = (CDataManager *)G_CDataManager();
  CDataManager::reset_dimensionInout(v0);
  cMyTrace::cMyTrace((cMyTrace *)v3, "void CDimensionActivationEvent::reset_dungeon_play_count()", 52, 0);
  return cMyTrace::operator()((int)v3, "CDimensionActivationEvent reset_dungeon_play_count", v2);
}

// IDA_EA: 0x80EECA4
// IDA_NAME: _ZN25CDimensionActivationEvent25checkFreeRevivalConditionEi
// DEMANGLED: CDimensionActivationEvent::checkFreeRevivalCondition(int)
_BOOL4 __cdecl CDimensionActivationEvent::checkFreeRevivalCondition()
{
  _BYTE v1[4]; // [esp+18h] [ebp-10h] BYREF
  _BYTE v2[12]; // [esp+1Ch] [ebp-Ch] BYREF

  G_CDataManager();
  std::map<int,DimensionCoinInfo>::find(v1);
  G_CDataManager();
  std::map<int,DimensionCoinInfo>::end(v2);
  return (unsigned __int8)std::_Rb_tree_iterator<std::pair<int const,DimensionCoinInfo>>::operator!=(v1, v2)
      && *(_BYTE *)(std::_Rb_tree_iterator<std::pair<int const,DimensionCoinInfo>>::operator->(v1) + 8) != 1;
}
