#ifndef __IDA91_DBINSERTGIVEBOXEVENTREWARD_H__
#define __IDA91_DBINSERTGIVEBOXEVENTREWARD_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DBInsertGiveBoxEventReward
// Source unit: DBInsertGiveBoxEventReward
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 1328

/* 1328 */
struct DBInsertGiveBoxEventReward;

// Exported member functions:
// 0x815D2C8	DBInsertGiveBoxEventReward::makeRequest(CUser *)
// 0x815D3EE	DBInsertGiveBoxEventReward::dispatch(int,int,Stream *)
// 0x815E550	DBInsertGiveBoxEventReward::DBInsertGiveBoxEventReward(void)
// 0x815E574	DBInsertGiveBoxEventReward::~DBInsertGiveBoxEventReward()
// 0x815E5A4	DBInsertGiveBoxEventReward::~DBInsertGiveBoxEventReward()

// Function declaration index:
// DECL 0x815D2C8 DBInsertGiveBoxEventReward::makeRequest
// DECL 0x815D3EE DBInsertGiveBoxEventReward::dispatch
// DECL 0x815E550 DBInsertGiveBoxEventReward::DBInsertGiveBoxEventReward
// DECL 0x815E574 DBInsertGiveBoxEventReward::~DBInsertGiveBoxEventReward
// DECL 0x815E5A4 DBInsertGiveBoxEventReward::~DBInsertGiveBoxEventReward

#endif  // __IDA91_DBINSERTGIVEBOXEVENTREWARD_H__
