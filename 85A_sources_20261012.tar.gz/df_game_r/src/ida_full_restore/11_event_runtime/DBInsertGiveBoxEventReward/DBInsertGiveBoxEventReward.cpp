#include "DBInsertGiveBoxEventReward.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x815D2C8
// IDA_NAME: _ZN26DBInsertGiveBoxEventReward11makeRequestEP5CUser
// DEMANGLED: DBInsertGiveBoxEventReward::makeRequest(CUser *)
void __cdecl DBInsertGiveBoxEventReward::makeRequest(DBInsertGiveBoxEventReward *this)
{
  Stream *v1; // eax
  char src; // al
  int v3; // eax
  int acc_idEv; // eax
  int charac_noEi; // eax
  char v6; // [esp+8h] [ebp-30h]
  int v7[2]; // [esp+14h] [ebp-24h] BYREF
  int v8[4]; // [esp+1Ch] [ebp-1Ch] BYREF
  int *v9; // [esp+2Ch] [ebp-Ch]

  v1 = (Stream *)StreamPool::Acquire(GlobalData::s_stream_pool, "localtaiwan/Dispatcher/Taiwan_DbThread.cpp", 873);
  CStreamGuard::CStreamGuard((CStreamGuard *)v7, v1, 1);
  src = CUser::GetUID(this);
  Taiwan::internal_stream((int)v7, 16, src);
  v3 = CStreamGuard::operator->((int)v7);
  v9 = (int *)CStreamGuard::GetInBuffer<DBInsertGiveBoxEventReward::MSG>(v3);
  if ( v9 )
  {
    acc_idEv = CUser::get_acc_id(this);
    *v9 = acc_idEv;
    charac_noEi = CUser::get_charac_no(this, -1);
    v9[1] = charac_noEi;
    MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v7);
  }
  else
  {
    cMyTrace::cMyTrace((cMyTrace *)v8, "static void DBInsertGiveBoxEventReward::makeRequest(CUser*)", 878, 0);
    cMyTrace::operator()((int)v8, "[Taiwan, Event] msg is null", v6);
  }
  CStreamGuard::~CStreamGuard((CStreamGuard *)v7);
}

// IDA_EA: 0x815D3EE
// IDA_NAME: _ZN26DBInsertGiveBoxEventReward8dispatchEiiP6Stream
// DEMANGLED: DBInsertGiveBoxEventReward::dispatch(int,int,Stream *)
int __cdecl DBInsertGiveBoxEventReward::dispatch(DBInsertGiveBoxEventReward *this, int a2, char src, Stream *a4)
{
  _DWORD *exception; // eax
  _DWORD *v5; // eax
  const char *v6; // eax
  _DWORD *v7; // eax
  unsigned int v8; // ebx
  const char *v9; // eax
  _DWORD *v10; // eax
  Stream *v11; // eax
  int v12; // eax
  _DWORD *v13; // eax
  struct tm tp_1; // [esp+24h] [ebp-84h] BYREF
  struct tm tp; // [esp+50h] [ebp-58h] BYREF
  int v17[2]; // [esp+7Ch] [ebp-2Ch] BYREF
  time_t timer; // [esp+84h] [ebp-24h] BYREF
  unsigned int *v19; // [esp+88h] [ebp-20h]
  MySQL *DBHandle; // [esp+8Ch] [ebp-1Ch]
  time_t v21; // [esp+90h] [ebp-18h]
  unsigned int *v23; // [esp+98h] [ebp-10h]

  v19 = (unsigned int *)Stream::GetOutBuffer<DBInsertGiveBoxEventReward::MSG>(a4);
  if ( !v19 )
  {
    exception = _cxa_allocate_exception(4u);
    *exception = "context null";
    _cxa_throw(exception, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  DBHandle = (MySQL *)DBMgr::GetDBHandle(GlobalData::s_db_mgr, 9, 0);
  if ( !DBHandle )
  {
    v5 = _cxa_allocate_exception(4u);
    *v5 = "handle null";
    _cxa_throw(v5, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  timer = time(0);
  localtime_r(&timer, &tp);
  tp_1 = tp;
  tp_1.tm_hour = *(_DWORD *)(G_CEnvironment() + 892);
  tp_1.tm_min = 0;
  tp_1.tm_sec = 0;
  v21 = mktime(&tp_1);
  if ( tp.tm_hour < tp_1.tm_hour )
    v21 -= 86400;
  v6 = (const char *)NumberToString(*v19, 0);
  MySQL::set_query(
    DBHandle,
    "seLect m_id from event_1306_account_reward_2nd where m_id=%s and occ_date > FROM_UNIXTIME(%d)",
    v6,
    v21);
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
  {
    v7 = _cxa_allocate_exception(4u);
    *v7 = "select_exec";
    _cxa_throw(v7, (struct type_info *)&`typeinfo for'char const*, 0);
  }
  if ( !MySQL::get_n_rows(DBHandle) )
  {
    v8 = v19[1];
    v9 = (const char *)NumberToString(*v19, 0);
    MySQL::set_query(
      DBHandle,
      "inSert into event_1306_account_reward_2nd (m_id , charac_no , occ_date ) values (%s , %u , now())",
      v9,
      v8);
    if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
    {
      v10 = _cxa_allocate_exception(4u);
      *v10 = "insert_exec";
      _cxa_throw(v10, (struct type_info *)&`typeinfo for'char const*, 0);
    }
    v11 = (Stream *)StreamPool::Acquire(GlobalData::s_stream_pool, "localtaiwan/Dispatcher/Taiwan_DbThread.cpp", 933);
    CStreamGuard::CStreamGuard((CStreamGuard *)v17, v11, 1);
    Taiwan::internal_stream((int)v17, 16, src);
    v12 = CStreamGuard::operator->((int)v17);
    v23 = (unsigned int *)CStreamGuard::GetInBuffer<DBInsertGiveBoxEventReward::MSG>(v12);
    if ( !v23 )
    {
      v13 = _cxa_allocate_exception(4u);
      *v13 = "stream";
      _cxa_throw(v13, (struct type_info *)&`typeinfo for'char const*, 0);
    }
    v23[1] = v19[1];
    *v23 = *v19;
    MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 1, (CStreamGuard *)v17);
    CStreamGuard::~CStreamGuard((CStreamGuard *)v17);
  }
  return 1;
}

// IDA_EA: 0x815E550
// IDA_NAME: _ZN26DBInsertGiveBoxEventRewardC2Ev
// DEMANGLED: DBInsertGiveBoxEventReward::DBInsertGiveBoxEventReward(void)
void __cdecl DBInsertGiveBoxEventReward::DBInsertGiveBoxEventReward(DBInsertGiveBoxEventReward *this)
{
  TaiwanInterfaceDBDispatcher::TaiwanInterfaceDBDispatcher(this, 16);
  *(_DWORD *)this = off_8B79340;
}

// IDA_EA: 0x815E574
// IDA_NAME: _ZN26DBInsertGiveBoxEventRewardD2Ev
// DEMANGLED: DBInsertGiveBoxEventReward::~DBInsertGiveBoxEventReward()
void __cdecl DBInsertGiveBoxEventReward::~DBInsertGiveBoxEventReward(DBInsertGiveBoxEventReward *this)
{
  *(_DWORD *)this = off_8B79340;
  TaiwanInterfaceDBDispatcher::~TaiwanInterfaceDBDispatcher(this);
}

// IDA_EA: 0x815E5A4
// IDA_NAME: _ZN26DBInsertGiveBoxEventRewardD0Ev
// DEMANGLED: DBInsertGiveBoxEventReward::~DBInsertGiveBoxEventReward()
void __cdecl DBInsertGiveBoxEventReward::~DBInsertGiveBoxEventReward(DBInsertGiveBoxEventReward *this)
{
  DBInsertGiveBoxEventReward::~DBInsertGiveBoxEventReward(this);
  operator delete(this);
}
