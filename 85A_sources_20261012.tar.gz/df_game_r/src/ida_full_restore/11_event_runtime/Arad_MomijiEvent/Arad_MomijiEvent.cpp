#include "Arad_MomijiEvent.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x819E738
// IDA_NAME: _ZN16Arad_MomijiEventC2Ev
// DEMANGLED: Arad_MomijiEvent::Arad_MomijiEvent(void)
void __cdecl Arad_MomijiEvent::Arad_MomijiEvent(Arad_MomijiEvent *this)
{
  CEventBase::CEventBase(this);
  *(_DWORD *)this = off_8BA8C08;
}

// IDA_EA: 0x819E754
// IDA_NAME: _ZN16Arad_MomijiEventD2Ev
// DEMANGLED: Arad_MomijiEvent::~Arad_MomijiEvent()
void __cdecl Arad_MomijiEvent::~Arad_MomijiEvent(Arad_MomijiEvent *this)
{
  *(_DWORD *)this = off_8BA8C08;
  CEventBase::~CEventBase(this);
}

// IDA_EA: 0x819E784
// IDA_NAME: _ZN16Arad_MomijiEventD0Ev
// DEMANGLED: Arad_MomijiEvent::~Arad_MomijiEvent()
void __cdecl Arad_MomijiEvent::~Arad_MomijiEvent(Arad_MomijiEvent *this)
{
  Arad_MomijiEvent::~Arad_MomijiEvent(this);
  operator delete(this);
}

// IDA_EA: 0x819E7A2
// IDA_NAME: _ZN16Arad_MomijiEvent10StartEventEv
// DEMANGLED: Arad_MomijiEvent::StartEvent(void)
CEventBase *__cdecl Arad_MomijiEvent::StartEvent(Arad_MomijiEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void Arad_MomijiEvent::StartEvent()", 20, 0);
  cMyTrace::operator()((int)v3, "[MOMIJI_EVENT] Event Start.", v2);
  return CEventBase::SetEventFlag(this, 1);
}

// IDA_EA: 0x819E7F4
// IDA_NAME: _ZN16Arad_MomijiEvent10StartEventE10Word_Param
// DEMANGLED: Arad_MomijiEvent::StartEvent(Word_Param)
int __cdecl Arad_MomijiEvent::StartEvent(int a1)
{
  return (*(int (__cdecl **)(int))(*(_DWORD *)a1 + 8))(a1);
}

// IDA_EA: 0x819E80E
// IDA_NAME: _ZN16Arad_MomijiEvent8EndEventEv
// DEMANGLED: Arad_MomijiEvent::EndEvent(void)
CEventBase *__cdecl Arad_MomijiEvent::EndEvent(Arad_MomijiEvent *this)
{
  char v2; // [esp+8h] [ebp-20h]
  int v3[6]; // [esp+10h] [ebp-18h] BYREF

  cMyTrace::cMyTrace((cMyTrace *)v3, "virtual void Arad_MomijiEvent::EndEvent()", 31, 0);
  cMyTrace::operator()((int)v3, "[MOMIJI_EVENT] Event End.", v2);
  return CEventBase::SetEventFlag(this, 0);
}
