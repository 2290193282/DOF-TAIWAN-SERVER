#ifndef __IDA91_ARAD_MOMIJIEVENT_H__
#define __IDA91_ARAD_MOMIJIEVENT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Arad_MomijiEvent
// Source unit: Arad_MomijiEvent
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "ARAD/ARAD_types.h"
//   #include "CUser/CUser.h"
//   #include "network/Stream.h"
// Local type ordinals: 4135

/* 4135 */
struct Arad_MomijiEvent;

// Exported member functions:
// 0x819E738	Arad_MomijiEvent::Arad_MomijiEvent(void)
// 0x819E754	Arad_MomijiEvent::~Arad_MomijiEvent()
// 0x819E784	Arad_MomijiEvent::~Arad_MomijiEvent()
// 0x819E7A2	Arad_MomijiEvent::StartEvent(void)
// 0x819E7F4	Arad_MomijiEvent::StartEvent(Word_Param)
// 0x819E80E	Arad_MomijiEvent::EndEvent(void)

// Function declaration index:
// DECL 0x819E738 Arad_MomijiEvent::Arad_MomijiEvent
// DECL 0x819E754 Arad_MomijiEvent::~Arad_MomijiEvent
// DECL 0x819E784 Arad_MomijiEvent::~Arad_MomijiEvent
// DECL 0x819E7A2 Arad_MomijiEvent::StartEvent
// DECL 0x819E7F4 Arad_MomijiEvent::StartEvent
// DECL 0x819E80E Arad_MomijiEvent::EndEvent

#endif  // __IDA91_ARAD_MOMIJIEVENT_H__
