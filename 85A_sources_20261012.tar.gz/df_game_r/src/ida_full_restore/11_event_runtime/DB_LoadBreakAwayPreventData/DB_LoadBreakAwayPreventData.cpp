#include "DB_LoadBreakAwayPreventData.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x8438920
// IDA_NAME: _ZN27DB_LoadBreakAwayPreventData11makeRequestEb
// DEMANGLED: DB_LoadBreakAwayPreventData::makeRequest(bool)
void __cdecl DB_LoadBreakAwayPreventData::makeRequest(DB_LoadBreakAwayPreventData *this)
{
  Stream *v1; // eax
  Stream **v2; // eax
  Stream **v3; // eax
  int v4; // eax
  _BYTE v5[16]; // [esp+28h] [ebp-10h] BYREF

  v1 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 34370);
  CStreamGuard::CStreamGuard((CStreamGuard *)v5, v1, 1);
  v2 = (Stream **)CStreamGuard::operator*((int)v5);
  CStreamGuard::operator<<(v2, 65);
  v3 = (Stream **)CStreamGuard::operator*((int)v5);
  CStreamGuard::operator<<(v3, -1);
  v4 = CStreamGuard::operator*((int)v5);
  CStreamGuard::operator<<(v4, (unsigned __int8)this);
  MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 2, (CStreamGuard *)v5);
  CStreamGuard::~CStreamGuard((CStreamGuard *)v5);
}

// IDA_EA: 0x84389FE
// IDA_NAME: _ZN27DB_LoadBreakAwayPreventData8dispatchEiiP6Stream
// DEMANGLED: DB_LoadBreakAwayPreventData::dispatch(int,int,Stream *)
int __cdecl DB_LoadBreakAwayPreventData::dispatch(DB_LoadBreakAwayPreventData *this, int a2, int a3, Stream *a4)
{
  int v4; // ebx
  __int64 v5; // rax
  __int64 v7; // rax
  Stream *v9; // eax
  Stream **v10; // eax
  Stream **v11; // eax
  int v12; // eax
  char v14; // [esp+8h] [ebp-340h]
  char v15; // [esp+8h] [ebp-340h]
  __int16 src; // [esp+1Ch] [ebp-32Ch] BYREF
  __int16 v17; // [esp+1Eh] [ebp-32Ah] BYREF
  __int16 v18; // [esp+20h] [ebp-328h] BYREF
  __int16 v19; // [esp+22h] [ebp-326h] BYREF
  __int16 v20; // [esp+24h] [ebp-324h] BYREF
  __int16 v21; // [esp+26h] [ebp-322h] BYREF
  __int16 v22; // [esp+28h] [ebp-320h] BYREF
  char v23[722]; // [esp+2Ah] [ebp-31Eh] BYREF
  int n_rowsEv_2; // [esp+2FCh] [ebp-4Ch]
  _BYTE v25[8]; // [esp+300h] [ebp-48h] BYREF
  int v26; // [esp+308h] [ebp-40h] BYREF
  unsigned __int8 v27; // [esp+30Fh] [ebp-39h] BYREF
  _BYTE v28[16]; // [esp+310h] [ebp-38h] BYREF
  int v29[4]; // [esp+320h] [ebp-28h] BYREF
  MySQL *DBHandle; // [esp+330h] [ebp-18h]
  int n_rowsEv; // [esp+334h] [ebp-14h]
  void *dest; // [esp+338h] [ebp-10h]
  int n_rowsEv_1; // [esp+33Ch] [ebp-Ch]

  DBHandle = (MySQL *)DBMgr::GetDBHandle((int *)GlobalData::s_db_mgr, 6, 0);
  v27 = 0;
  Stream::operator>>(a4, (int)&v27);
  SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER::SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER((SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER *)&src);
  n_rowsEv = 0;
  v26 = 0;
  MySQL::set_query(
    DBHandle,
    "seLect no, weekday_var_a, weekday_var_b, weekday_var_c, weekend_var_x, weekend_var_y, weekend_var_z, next_reward_day"
    ", state_flag from churn_system_manager order by no desc limit 1");
  if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 )
    return 0;
  n_rowsEv = MySQL::get_n_rows(DBHandle);
  if ( n_rowsEv != 1 )
    return 0;
  if ( (unsigned __int8)MySQL::fetch(DBHandle) != 1 )
    return 0;
  if ( (unsigned __int8)MySQL::get_int(DBHandle, 0, &v26) != 1 )
    return 0;
  if ( (unsigned __int8)MySQL::get_short(DBHandle, 1, &src) != 1 )
    return 0;
  if ( (unsigned __int8)MySQL::get_short(DBHandle, 2, &v17) != 1 )
    return 0;
  if ( (unsigned __int8)MySQL::get_short(DBHandle, 3, &v18) != 1 )
    return 0;
  if ( (unsigned __int8)MySQL::get_short(DBHandle, 4, &v19) != 1 )
    return 0;
  if ( (unsigned __int8)MySQL::get_short(DBHandle, 5, &v20) != 1 )
    return 0;
  if ( (unsigned __int8)MySQL::get_short(DBHandle, 6, &v21) != 1 )
    return 0;
  if ( (unsigned __int8)MySQL::get_short(DBHandle, 7, &v22) != 1 )
    return 0;
  if ( (unsigned __int8)MySQL::get_byte(DBHandle, 8, v23) != 1 )
    return 0;
  if ( v27 == 1 )
  {
    MySQL::set_query(DBHandle, "upDate churn_system_manager set state_flag=%d where no = %d", 1, v26);
    if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 || (LODWORD(v7) = MySQL::getAffectedRowCount(DBHandle), !v7) )
    {
      cMyTrace::cMyTrace(
        (cMyTrace *)v29,
        "virtual bool DB_LoadBreakAwayPreventData::dispatch(int, int, Stream*)",
        34442,
        0);
      cMyTrace::operator()((int)v29, "BREAK_AWAY : STATE_FALG ALREADY ON!!", v15);
    }
    v23[0] = v27;
    MySQL::set_query(
      DBHandle,
      "seLect min_day, max_day, min_val, max_val, item_id, add_info, luck_point, quest_id from churn_reward_manager");
    if ( (unsigned __int8)MySQL::exec(DBHandle, 1) == 1 )
    {
      n_rowsEv = MySQL::get_n_rows(DBHandle);
      for ( n_rowsEv_1 = 0; n_rowsEv_1 < n_rowsEv; ++n_rowsEv_1 )
      {
        if ( (unsigned __int8)MySQL::fetch(DBHandle) != 1 )
          return 0;
        if ( (unsigned __int8)MySQL::get_byte(DBHandle, 0, (char *)&src + 24 * n_rowsEv_1 + 17) != 1 )
          return 0;
        if ( (unsigned __int8)MySQL::get_byte(DBHandle, 1, (char *)&src + 24 * n_rowsEv_1 + 18) != 1 )
          return 0;
        if ( (unsigned __int8)MySQL::get_int(DBHandle, 2, (int *)&v18 + 6 * n_rowsEv_1 + 4) != 1 )
          return 0;
        if ( (unsigned __int8)MySQL::get_int(DBHandle, 3, (int *)&v20 + 6 * n_rowsEv_1 + 4) != 1 )
          return 0;
        if ( (unsigned __int8)MySQL::get_uint(DBHandle, 4, (unsigned int *)(v23 + 24 * n_rowsEv_1 + 14)) != 1 )
          return 0;
        if ( (unsigned __int8)MySQL::get_int(DBHandle, 5, (int *)&src + 6 * n_rowsEv_1 + 8) != 1 )
          return 0;
        if ( (unsigned __int8)MySQL::get_int(DBHandle, 6, (int *)&v18 + 6 * n_rowsEv_1 + 8) != 1 )
          return 0;
        if ( (unsigned __int8)MySQL::get_byte(DBHandle, 7, (char *)&src + 24 * n_rowsEv_1 + 16) != 1 )
          return 0;
      }
      n_rowsEv_2 = n_rowsEv;
      v9 = StreamPool::Acquire(GlobalData::s_stream_pool, "DBThread.cpp", 34501);
      CStreamGuard::CStreamGuard((CStreamGuard *)v25, v9, 1);
      v10 = (Stream **)CStreamGuard::operator*((int)v25);
      CStreamGuard::operator<<(v10, 65);
      v11 = (Stream **)CStreamGuard::operator*((int)v25);
      CStreamGuard::operator<<(v11, -1);
      v12 = CStreamGuard::operator->((int)v25);
      dest = (void *)CStreamGuard::GetInBuffer<SIG_BREAK_AWAY_PREVENT_SYSTEM_MANAGER>(v12);
      memcpy(dest, &src, 0x2E4u);
      MsgQueueMgr::put((int)GlobalData::s_msgq_mgr, 1, (CStreamGuard *)v25);
      v4 = 1;
      CStreamGuard::~CStreamGuard((CStreamGuard *)v25);
    }
    else
    {
      return 0;
    }
  }
  else
  {
    MySQL::set_query(DBHandle, "upDate churn_system_manager set state_flag=%d where no = %d", v27, v26);
    if ( (unsigned __int8)MySQL::exec(DBHandle, 1) != 1 || (LODWORD(v5) = MySQL::getAffectedRowCount(DBHandle), !v5) )
    {
      cMyTrace::cMyTrace(
        (cMyTrace *)v28,
        "virtual bool DB_LoadBreakAwayPreventData::dispatch(int, int, Stream*)",
        34436,
        0);
      cMyTrace::operator()((int)v28, "BREAK_AWAY : STATE_FALG ALREADY OFF!!", v14);
    }
    return 0;
  }
  return v4;
}

// IDA_EA: 0x844ED22
// IDA_NAME: _ZN27DB_LoadBreakAwayPreventDataC2Ev
// DEMANGLED: DB_LoadBreakAwayPreventData::DB_LoadBreakAwayPreventData(void)
void __cdecl DB_LoadBreakAwayPreventData::DB_LoadBreakAwayPreventData(DB_LoadBreakAwayPreventData *this)
{
  DBDispatcher::DBDispatcher(this);
  *(_DWORD *)this = &off_8C5EAC0;
}

// IDA_EA: 0x845CDD2
// IDA_NAME: _ZN27DB_LoadBreakAwayPreventDataD2Ev
// DEMANGLED: DB_LoadBreakAwayPreventData::~DB_LoadBreakAwayPreventData()
void __cdecl DB_LoadBreakAwayPreventData::~DB_LoadBreakAwayPreventData(DB_LoadBreakAwayPreventData *this)
{
  *(_DWORD *)this = &off_8C5EAC0;
  DBDispatcher::~DBDispatcher(this);
}

// IDA_EA: 0x845CE02
// IDA_NAME: _ZN27DB_LoadBreakAwayPreventDataD0Ev
// DEMANGLED: DB_LoadBreakAwayPreventData::~DB_LoadBreakAwayPreventData()
void __cdecl DB_LoadBreakAwayPreventData::~DB_LoadBreakAwayPreventData(DB_LoadBreakAwayPreventData *this)
{
  DB_LoadBreakAwayPreventData::~DB_LoadBreakAwayPreventData(this);
  operator delete(this);
}
