#ifndef __IDA91_DB_LOADBREAKAWAYPREVENTDATA_H__
#define __IDA91_DB_LOADBREAKAWAYPREVENTDATA_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: DB_LoadBreakAwayPreventData
// Source unit: DB_LoadBreakAwayPreventData
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "db/MySQL.h"
//   #include "network/Stream.h"
//   #include "quest/QuestTypes.h"
// Local type ordinals: 2571

/* 2571 */
struct DB_LoadBreakAwayPreventData;

// Exported member functions:
// 0x8438920	DB_LoadBreakAwayPreventData::makeRequest(bool)
// 0x84389FE	DB_LoadBreakAwayPreventData::dispatch(int,int,Stream *)
// 0x844ED22	DB_LoadBreakAwayPreventData::DB_LoadBreakAwayPreventData(void)
// 0x845CDD2	DB_LoadBreakAwayPreventData::~DB_LoadBreakAwayPreventData()
// 0x845CE02	DB_LoadBreakAwayPreventData::~DB_LoadBreakAwayPreventData()

// Function declaration index:
// DECL 0x8438920 DB_LoadBreakAwayPreventData::makeRequest
// DECL 0x84389FE DB_LoadBreakAwayPreventData::dispatch
// DECL 0x844ED22 DB_LoadBreakAwayPreventData::DB_LoadBreakAwayPreventData
// DECL 0x845CDD2 DB_LoadBreakAwayPreventData::~DB_LoadBreakAwayPreventData
// DECL 0x845CE02 DB_LoadBreakAwayPreventData::~DB_LoadBreakAwayPreventData

#endif  // __IDA91_DB_LOADBREAKAWAYPREVENTDATA_H__
