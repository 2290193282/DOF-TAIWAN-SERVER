#include "Packet_Guild_Attendance_Info.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x822C384
// IDA_NAME: _ZN28Packet_Guild_Attendance_InfoC2Ev
// DEMANGLED: Packet_Guild_Attendance_Info::Packet_Guild_Attendance_Info(void)
void __cdecl Packet_Guild_Attendance_Info::Packet_Guild_Attendance_Info(Packet_Guild_Attendance_Info *this)
{
  PacketHeader::PacketHeader(this, 0x1BC6u, 0x13u);
  *(_DWORD *)((char *)this + 10) = 0;
  *(_DWORD *)((char *)this + 14) = 0;
  *((_BYTE *)this + 18) = 0;
}
