#ifndef __IDA91_PACKET_GUILD_ATTENDANCE_INFO_H__
#define __IDA91_PACKET_GUILD_ATTENDANCE_INFO_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Packet_Guild_Attendance_Info
// Source unit: Packet_Guild_Attendance_Info
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "network/PacketGuard.h"
//   #include "network/PacketBuf.h"
// Local type ordinals: 1610

/* 1610 */
struct Packet_Guild_Attendance_Info;

// Exported member functions:
// 0x822C384	Packet_Guild_Attendance_Info::Packet_Guild_Attendance_Info(void)

// Function declaration index:
// DECL 0x822C384 Packet_Guild_Attendance_Info::Packet_Guild_Attendance_Info

#endif  // __IDA91_PACKET_GUILD_ATTENDANCE_INFO_H__
