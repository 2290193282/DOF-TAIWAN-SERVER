#ifndef __IDA91_BLUEMARBLEINFOSCRIPT_H__
#define __IDA91_BLUEMARBLEINFOSCRIPT_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: BlueMarbleInfoScript
// Source unit: BlueMarbleInfoScript
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "world/CDungeon.h"
// Local type ordinals: 4356

/* 4356 */
struct BlueMarbleInfoScript;

// Exported member functions:
// 0x837E218	BlueMarbleInfoScript::~BlueMarbleInfoScript()
// 0x88D5690	BlueMarbleInfoScript::BlueMarbleInfoScript(void)
// 0x88D57C0	BlueMarbleInfoScript::clear(void)
// 0x88D589C	BlueMarbleInfoScript::importScript(char const*,char const*)
// 0x88D5E92	BlueMarbleInfoScript::getRandomDungeonIndex(int)
// 0x88D5F38	BlueMarbleInfoScript::getBossDungeonIndex(int)
// 0x88D5FDE	BlueMarbleInfoScript::getUniqueDungeonIndex(int)
// 0x88D6084	BlueMarbleInfoScript::getDungeonDifficulty(int)

// Function declaration index:
// DECL 0x837E218 BlueMarbleInfoScript::~BlueMarbleInfoScript
// DECL 0x88D5690 BlueMarbleInfoScript::BlueMarbleInfoScript
// DECL 0x88D57C0 BlueMarbleInfoScript::clear
// DECL 0x88D589C BlueMarbleInfoScript::importScript
// DECL 0x88D5E92 BlueMarbleInfoScript::getRandomDungeonIndex
// DECL 0x88D5F38 BlueMarbleInfoScript::getBossDungeonIndex
// DECL 0x88D5FDE BlueMarbleInfoScript::getUniqueDungeonIndex
// DECL 0x88D6084 BlueMarbleInfoScript::getDungeonDifficulty

#endif  // __IDA91_BLUEMARBLEINFOSCRIPT_H__
