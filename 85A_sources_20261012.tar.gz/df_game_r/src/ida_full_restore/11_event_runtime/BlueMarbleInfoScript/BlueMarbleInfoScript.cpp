#include "BlueMarbleInfoScript.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x837E218
// IDA_NAME: _ZN20BlueMarbleInfoScriptD2Ev
// DEMANGLED: BlueMarbleInfoScript::~BlueMarbleInfoScript()
void __cdecl BlueMarbleInfoScript::~BlueMarbleInfoScript(BlueMarbleInfoScript *this)
{
  std::vector<BlueMarbleTilePos>::~vector((char *)this + 128);
  std::vector<BlueMarbleRewardInfo>::~vector((char *)this + 116);
  std::vector<BlueMarbleRandomItemInfo>::~vector((char *)this + 104);
  std::vector<BlueMarbleRandomDungeonInfo>::~vector((char *)this + 92);
  std::vector<BlueMarbleRandomDungeonInfo>::~vector((char *)this + 80);
  std::vector<BlueMarbleRandomDungeonInfo>::~vector((char *)this + 68);
  std::vector<BlueMarbleDungeonDifficulty>::~vector((char *)this + 36);
}

// IDA_EA: 0x88D5690
// IDA_NAME: _ZN20BlueMarbleInfoScriptC2Ev
// DEMANGLED: BlueMarbleInfoScript::BlueMarbleInfoScript(void)
void __cdecl BlueMarbleInfoScript::BlueMarbleInfoScript(BlueMarbleInfoScript *this)
{
  std::vector<BlueMarbleDungeonDifficulty>::vector((char *)this + 36);
  std::vector<BlueMarbleRandomDungeonInfo>::vector((char *)this + 68);
  std::vector<BlueMarbleRandomDungeonInfo>::vector((char *)this + 80);
  std::vector<BlueMarbleRandomDungeonInfo>::vector((char *)this + 92);
  std::vector<BlueMarbleRandomItemInfo>::vector((char *)this + 104);
  std::vector<BlueMarbleRewardInfo>::vector((char *)this + 116);
  std::vector<BlueMarbleTilePos>::vector((char *)this + 128);
  BlueMarbleInfoScript::clear(this);
}

// IDA_EA: 0x88D57C0
// IDA_NAME: _ZN20BlueMarbleInfoScript5clearEv
// DEMANGLED: BlueMarbleInfoScript::clear(void)
BlueMarbleInfoScript *__cdecl BlueMarbleInfoScript::clear(BlueMarbleInfoScript *this)
{
  BlueMarbleInfoScript *this_1; // eax

  *(_DWORD *)this = 0;
  *((_DWORD *)this + 1) = 0;
  *((_DWORD *)this + 2) = 0;
  *((_DWORD *)this + 3) = 0;
  *((_DWORD *)this + 4) = 0;
  *((_DWORD *)this + 5) = 0;
  *((_DWORD *)this + 6) = 0;
  *((_DWORD *)this + 7) = 0;
  *((_DWORD *)this + 8) = 0;
  std::vector<BlueMarbleDungeonDifficulty>::clear((char *)this + 36);
  *((_DWORD *)this + 12) = 0;
  *((_DWORD *)this + 13) = 0;
  *((_DWORD *)this + 14) = 0;
  *((_DWORD *)this + 15) = 0;
  std::vector<BlueMarbleRandomDungeonInfo>::clear((char *)this + 68);
  std::vector<BlueMarbleRandomDungeonInfo>::clear((char *)this + 80);
  std::vector<BlueMarbleRandomItemInfo>::clear((char *)this + 104);
  std::vector<BlueMarbleTilePos>::clear((char *)this + 128);
  this_1 = this;
  *((_DWORD *)this + 16) = 1000;
  return this_1;
}

// IDA_EA: 0x88D589C
// IDA_NAME: _ZN20BlueMarbleInfoScript12importScriptEPKcS1_
// DEMANGLED: BlueMarbleInfoScript::importScript(char const*,char const*)
int __cdecl BlueMarbleInfoScript::importScript(BlueMarbleInfoScript *this, TCHAR *dir, TCHAR *filename)
{
  int v3; // ebx
  int v5; // [esp+14h] [ebp-54h] BYREF
  int v6; // [esp+18h] [ebp-50h] BYREF
  int v7; // [esp+1Ch] [ebp-4Ch] BYREF
  int v8; // [esp+20h] [ebp-48h] BYREF
  int v9; // [esp+24h] [ebp-44h] BYREF
  int v10; // [esp+28h] [ebp-40h] BYREF
  int v11; // [esp+2Ch] [ebp-3Ch] BYREF
  int v12; // [esp+30h] [ebp-38h] BYREF
  int v13; // [esp+34h] [ebp-34h] BYREF
  int v14; // [esp+38h] [ebp-30h] BYREF
  int v15; // [esp+3Ch] [ebp-2Ch] BYREF
  int v16; // [esp+40h] [ebp-28h] BYREF
  int v17; // [esp+44h] [ebp-24h] BYREF
  int v18; // [esp+48h] [ebp-20h] BYREF
  int v19; // [esp+4Ch] [ebp-1Ch] BYREF
  int v20; // [esp+50h] [ebp-18h] BYREF
  int v21; // [esp+54h] [ebp-14h] BYREF
  std::string v22; // [esp+58h] [ebp-10h] BYREF
  int v23; // [esp+5Ch] [ebp-Ch]

  if ( !loadRDARScriptFile(dir, filename) )
    return 0;
  std::string::string(&v22);
  v23 = 0;
  while ( (unsigned __int8)ScanType(&v22, 1) == 1 )
  {
    if ( std::operator==<char>(&v22, "[dungeon list]") )
    {
      std::vector<BlueMarbleRandomDungeonInfo>::clear((char *)this + 68);
      while ( ScanInt(&v19) && ScanInt(&v20) && ScanInt(&v21) )
        std::vector<BlueMarbleRandomDungeonInfo>::push_back((char *)this + 68, &v19);
    }
    else if ( std::operator==<char>(&v22, "[boss dungeon list]") )
    {
      std::vector<BlueMarbleRandomDungeonInfo>::clear((char *)this + 80);
      while ( ScanInt(&v16) && ScanInt(&v17) && ScanInt(&v18) )
        std::vector<BlueMarbleRandomDungeonInfo>::push_back((char *)this + 80, &v16);
    }
    else if ( std::operator==<char>(&v22, "[item list]") )
    {
      std::vector<BlueMarbleRandomItemInfo>::clear((char *)this + 104);
      while ( ScanInt(&v14) && ScanInt(&v15) )
      {
        *((_DWORD *)this + 7) += v15;
        std::vector<BlueMarbleRandomItemInfo>::push_back((char *)this + 104, &v14);
      }
    }
    else if ( std::operator==<char>(&v22, "[player max]") )
    {
      ScanInt((int *)this);
    }
    else if ( std::operator==<char>(&v22, "[enter level]") )
    {
      ScanInt((int *)this + 1);
    }
    else if ( std::operator==<char>(&v22, "[enter max level]") )
    {
      ScanInt((int *)this + 2);
    }
    else if ( std::operator==<char>(&v22, "[enter count]") )
    {
      ScanInt((int *)this + 3);
    }
    else if ( std::operator==<char>(&v22, "[die count]") )
    {
      ScanInt((int *)this + 4);
    }
    else if ( std::operator==<char>(&v22, "[dice value]") )
    {
      ScanInt((int *)this + 5);
      ScanInt((int *)this + 6);
    }
    else if ( std::operator==<char>(&v22, "[reward item]") )
    {
      std::vector<BlueMarbleRewardInfo>::clear((char *)this + 116);
      while ( ScanInt(&v12) && ScanInt(&v13) )
        std::vector<BlueMarbleRewardInfo>::push_back((char *)this + 116, &v12);
    }
    else if ( std::operator==<char>(&v22, "[tile pos]") )
    {
      std::vector<BlueMarbleTilePos>::clear((char *)this + 128);
      while ( ScanInt(&v10) && ScanInt(&v11) )
        std::vector<BlueMarbleTilePos>::push_back((char *)this + 128, &v10);
    }
    else if ( std::operator==<char>(&v22, "[dungeon difficulty]") )
    {
      *((_DWORD *)this + 8) = ScanInt(0);
    }
    else if ( std::operator==<char>(&v22, "[dungeon difficulty list]") )
    {
      std::vector<BlueMarbleDungeonDifficulty>::clear((char *)this + 36);
      while ( ScanInt(&v8) && ScanInt(&v9) )
        std::vector<BlueMarbleDungeonDifficulty>::push_back((char *)this + 36, &v8);
    }
    else if ( std::operator==<char>(&v22, "[super armor time]") )
    {
      *((_DWORD *)this + 12) = ScanInt(0);
    }
    else if ( std::operator==<char>(&v22, "[unique dungeon list]") )
    {
      std::vector<BlueMarbleRandomDungeonInfo>::clear((char *)this + 92);
      while ( ScanInt(&v5) && ScanInt(&v6) && ScanInt(&v7) )
        std::vector<BlueMarbleRandomDungeonInfo>::push_back((char *)this + 92, &v5);
    }
    else if ( std::operator==<char>(&v22, "[buff max value]") )
    {
      ScanInt((int *)this + 13);
    }
    else if ( std::operator==<char>(&v22, "[gold base]") )
    {
      ScanFloat((float *)this + 14);
    }
    else if ( std::operator==<char>(&v22, "[gold multi]") )
    {
      ScanFloat((float *)this + 15);
    }
    else if ( std::operator==<char>(&v22, "[equipment upgrade max]") )
    {
      *((_DWORD *)this + 16) = ScanInt(0);
    }
  }
  v3 = 1;
  std::string::~string(&v22);
  return v3;
}

// IDA_EA: 0x88D5E92
// IDA_NAME: _ZN20BlueMarbleInfoScript21getRandomDungeonIndexEi
// DEMANGLED: BlueMarbleInfoScript::getRandomDungeonIndex(int)
BlueMarbleInfoScript *__stdcall BlueMarbleInfoScript::getRandomDungeonIndex(
        BlueMarbleInfoScript *this,
        int a2,
        int charac_levelEv)
{
  unsigned int i; // [esp+18h] [ebp-20h]
  _DWORD *v5; // [esp+1Ch] [ebp-1Ch]

  std::vector<int>::vector((int)this);
  for ( i = 0; std::vector<BlueMarbleRandomDungeonInfo>::size((_DWORD *)(a2 + 68)) > i; ++i )
  {
    v5 = (_DWORD *)std::vector<BlueMarbleRandomDungeonInfo>::operator[]((_DWORD *)(a2 + 68), i);
    if ( *v5 <= charac_levelEv && v5[1] >= charac_levelEv )
      std::vector<int>::push_back((int)this, (int)(v5 + 2));
  }
  return this;
}

// IDA_EA: 0x88D5F38
// IDA_NAME: _ZN20BlueMarbleInfoScript19getBossDungeonIndexEi
// DEMANGLED: BlueMarbleInfoScript::getBossDungeonIndex(int)
BlueMarbleInfoScript *__stdcall BlueMarbleInfoScript::getBossDungeonIndex(
        BlueMarbleInfoScript *this,
        int a2,
        int charac_levelEv)
{
  unsigned int i; // [esp+18h] [ebp-20h]
  _DWORD *v5; // [esp+1Ch] [ebp-1Ch]

  std::vector<int>::vector((int)this);
  for ( i = 0; std::vector<BlueMarbleRandomDungeonInfo>::size((_DWORD *)(a2 + 80)) > i; ++i )
  {
    v5 = (_DWORD *)std::vector<BlueMarbleRandomDungeonInfo>::operator[]((_DWORD *)(a2 + 80), i);
    if ( *v5 <= charac_levelEv && v5[1] >= charac_levelEv )
      std::vector<int>::push_back((int)this, (int)(v5 + 2));
  }
  return this;
}

// IDA_EA: 0x88D5FDE
// IDA_NAME: _ZN20BlueMarbleInfoScript21getUniqueDungeonIndexEi
// DEMANGLED: BlueMarbleInfoScript::getUniqueDungeonIndex(int)
BlueMarbleInfoScript *__stdcall BlueMarbleInfoScript::getUniqueDungeonIndex(
        BlueMarbleInfoScript *this,
        int a2,
        int charac_levelEv)
{
  unsigned int i; // [esp+18h] [ebp-20h]
  _DWORD *v5; // [esp+1Ch] [ebp-1Ch]

  std::vector<int>::vector((int)this);
  for ( i = 0; std::vector<BlueMarbleRandomDungeonInfo>::size((_DWORD *)(a2 + 92)) > i; ++i )
  {
    v5 = (_DWORD *)std::vector<BlueMarbleRandomDungeonInfo>::operator[]((_DWORD *)(a2 + 92), i);
    if ( *v5 <= charac_levelEv && v5[1] >= charac_levelEv )
      std::vector<int>::push_back((int)this, (int)(v5 + 2));
  }
  return this;
}

// IDA_EA: 0x88D6084
// IDA_NAME: _ZN20BlueMarbleInfoScript20getDungeonDifficultyEi
// DEMANGLED: BlueMarbleInfoScript::getDungeonDifficulty(int)
int __cdecl BlueMarbleInfoScript::getDungeonDifficulty(BlueMarbleInfoScript *this, int a2)
{
  unsigned int i; // [esp+1Ch] [ebp-Ch]

  for ( i = 0; std::vector<BlueMarbleDungeonDifficulty>::size((char *)this + 36) > i; ++i )
  {
    if ( *(_DWORD *)std::vector<BlueMarbleDungeonDifficulty>::operator[]((char *)this + 36, i) == a2 )
      return *(_DWORD *)(std::vector<BlueMarbleDungeonDifficulty>::operator[]((char *)this + 36, i) + 4);
  }
  return *((_DWORD *)this + 8);
}
