#ifndef __IDA91_INTER_ACHIEVEGUILDATTENDANCE_H__
#define __IDA91_INTER_ACHIEVEGUILDATTENDANCE_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: Inter_AchieveGuildAttendance
// Source unit: Inter_AchieveGuildAttendance
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
//   #include "CUser/CUser_types.h"
//   #include "network/PacketGuard.h"
//   #include "items/Inven_Item.h"
// Local type ordinals: 3201

/* 3201 */
struct Inter_AchieveGuildAttendance;

// Exported member functions:
// 0x84E41E4	Inter_AchieveGuildAttendance::dispatch_sig(CUser *,char *,int)
// 0x84EEA94	Inter_AchieveGuildAttendance::Inter_AchieveGuildAttendance(void)
// 0x84F6594	Inter_AchieveGuildAttendance::~Inter_AchieveGuildAttendance()
// 0x84F65C4	Inter_AchieveGuildAttendance::~Inter_AchieveGuildAttendance()

// Function declaration index:
// DECL 0x84E41E4 Inter_AchieveGuildAttendance::dispatch_sig
// DECL 0x84EEA94 Inter_AchieveGuildAttendance::Inter_AchieveGuildAttendance
// DECL 0x84F6594 Inter_AchieveGuildAttendance::~Inter_AchieveGuildAttendance
// DECL 0x84F65C4 Inter_AchieveGuildAttendance::~Inter_AchieveGuildAttendance

#endif  // __IDA91_INTER_ACHIEVEGUILDATTENDANCE_H__
