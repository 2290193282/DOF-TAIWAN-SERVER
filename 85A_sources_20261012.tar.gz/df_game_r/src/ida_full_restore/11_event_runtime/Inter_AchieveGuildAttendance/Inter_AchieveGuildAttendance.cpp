#include "Inter_AchieveGuildAttendance.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x84E41E4
// IDA_NAME: _ZN28Inter_AchieveGuildAttendance12dispatch_sigEP5CUserPci
// DEMANGLED: Inter_AchieveGuildAttendance::dispatch_sig(CUser *,char *,int)
int __cdecl Inter_AchieveGuildAttendance::dispatch_sig(Inter_AchieveGuildAttendance *this, CUser *a2, char *a3)
{
  int CurCharacNoEv; // ebx
  PacketBuf *v5[3]; // [esp+10h] [ebp-18h] BYREF
  char *v6; // [esp+1Ch] [ebp-Ch]

  v6 = a3;
  if ( CUser::get_state(a2) > 2 )
  {
    CurCharacNoEv = *(_DWORD *)(v6 + 10);
    if ( CurCharacNoEv == CUserCharacInfo::getCurCharacNo(a2) )
    {
      PacketGuard::PacketGuard((PacketGuard *)v5);
      InterfacePacketBuf::put_header(v5, 0, 308);
      InterfacePacketBuf::put_int(v5, *(_DWORD *)(v6 + 18));
      InterfacePacketBuf::put_int(v5, *(_DWORD *)(v6 + 22));
      InterfacePacketBuf::finalize(v5, 1);
      CUser::Send(a2, (PacketGuard *)v5);
      PacketGuard::~PacketGuard(v5);
    }
  }
  return 0;
}

// IDA_EA: 0x84EEA94
// IDA_NAME: _ZN28Inter_AchieveGuildAttendanceC2Ev
// DEMANGLED: Inter_AchieveGuildAttendance::Inter_AchieveGuildAttendance(void)
void __cdecl Inter_AchieveGuildAttendance::Inter_AchieveGuildAttendance(Inter_AchieveGuildAttendance *this)
{
  ISigDispatcher::ISigDispatcher(this);
  *(_DWORD *)this = &off_8C8E7D8;
}

// IDA_EA: 0x84F6594
// IDA_NAME: _ZN28Inter_AchieveGuildAttendanceD2Ev
// DEMANGLED: Inter_AchieveGuildAttendance::~Inter_AchieveGuildAttendance()
void __cdecl Inter_AchieveGuildAttendance::~Inter_AchieveGuildAttendance(Inter_AchieveGuildAttendance *this)
{
  *(_DWORD *)this = &off_8C8E7D8;
  ISigDispatcher::~ISigDispatcher(this);
}

// IDA_EA: 0x84F65C4
// IDA_NAME: _ZN28Inter_AchieveGuildAttendanceD0Ev
// DEMANGLED: Inter_AchieveGuildAttendance::~Inter_AchieveGuildAttendance()
void __cdecl Inter_AchieveGuildAttendance::~Inter_AchieveGuildAttendance(Inter_AchieveGuildAttendance *this)
{
  Inter_AchieveGuildAttendance::~Inter_AchieveGuildAttendance(this);
  operator delete(this);
}
