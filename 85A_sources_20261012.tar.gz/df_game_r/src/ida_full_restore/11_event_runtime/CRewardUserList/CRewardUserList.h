#ifndef __IDA91_CREWARDUSERLIST_H__
#define __IDA91_CREWARDUSERLIST_H__

// Generated from IDA 9.1 Hex-Rays export.
// Folder: CRewardUserList
// Source unit: CRewardUserList
// Game flow module: 11_event_runtime
// Suggested dependencies:
//   #include "common/ida_types.h"
//   #include "common/server_types.h"
//   #include "common/packet_types.h"
// Local type ordinals: 4405

/* 4405 */
struct CRewardUserList;

// Exported member functions:
// 0x81BB690	CRewardUserList::insert(unsigned int,int,int)
// 0x81BB73C	CRewardUserList::is_exist(unsigned int)
// 0x81BB7BC	CRewardUserList::delete_mark(unsigned int)
// 0x81BBFB6	CRewardUserList::CRewardUserList(void)
// 0x81BBFFC	CRewardUserList::~CRewardUserList()
// 0x81BC042	CRewardUserList::clear(void)
// 0x81BC064	CRewardUserList::get_index_size(void)

// Function declaration index:
// DECL 0x81BB690 CRewardUserList::insert
// DECL 0x81BB73C CRewardUserList::is_exist
// DECL 0x81BB7BC CRewardUserList::delete_mark
// DECL 0x81BBFB6 CRewardUserList::CRewardUserList
// DECL 0x81BBFFC CRewardUserList::~CRewardUserList
// DECL 0x81BC042 CRewardUserList::clear
// DECL 0x81BC064 CRewardUserList::get_index_size

#endif  // __IDA91_CREWARDUSERLIST_H__
