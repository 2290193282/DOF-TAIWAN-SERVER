#include "CRewardUserList.h"

// Generated from IDA 9.1 Hex-Rays export.
// Keep one IDA function as one source function during cleanup.

// IDA_EA: 0x81BB690
// IDA_NAME: _ZN15CRewardUserList6insertEjii
// DEMANGLED: CRewardUserList::insert(unsigned int,int,int)
int __cdecl CRewardUserList::insert(CRewardUserList *this, int acc_idEv, int charac_noEi, int ontime_idEv)
{
  _DWORD v5[2]; // [esp+1Ch] [ebp-3Ch] BYREF
  char v6; // [esp+24h] [ebp-34h]
  _BYTE v7[8]; // [esp+28h] [ebp-30h] BYREF
  int v8[4]; // [esp+30h] [ebp-28h] BYREF
  unsigned int __t[6]; // [esp+40h] [ebp-18h] BYREF

  if ( CRewardUserList::is_exist() )
    return 0;
  RewardUserData::RewardUserData((RewardUserData *)v5);
  v5[0] = charac_noEi;
  v5[1] = ontime_idEv;
  v6 = 0;
  std::make_pair<unsigned int &,RewardUserData &>(__t, (int)&acc_idEv, (int)v5);
  std::pair<unsigned int const,RewardUserData>::pair<unsigned int,RewardUserData>((int)v8, __t);
  std::map<unsigned int,RewardUserData>::insert((int)v7);
  std::deque<unsigned int>::push_back((int)this + 24, &acc_idEv);
  return 1;
}

// IDA_EA: 0x81BB73C
// IDA_NAME: _ZN15CRewardUserList8is_existEj
// DEMANGLED: CRewardUserList::is_exist(unsigned int)
_BOOL4 __cdecl CRewardUserList::is_exist()
{
  _BYTE v1[4]; // [esp+10h] [ebp-18h] BYREF
  _BYTE v2[4]; // [esp+14h] [ebp-14h] BYREF
  _BYTE v3[4]; // [esp+18h] [ebp-10h] BYREF
  _BYTE v4[12]; // [esp+1Ch] [ebp-Ch] BYREF

  std::map<unsigned int,RewardUserData>::find(v2);
  std::_Rb_tree_const_iterator<std::pair<unsigned int const,RewardUserData>>::_Rb_tree_const_iterator(v1, v2);
  std::map<unsigned int,RewardUserData>::end(v4);
  std::_Rb_tree_const_iterator<std::pair<unsigned int const,RewardUserData>>::_Rb_tree_const_iterator(v3, v4);
  return (unsigned __int8)std::_Rb_tree_const_iterator<std::pair<unsigned int const,RewardUserData>>::operator==(v1, v3) == 0;
}

// IDA_EA: 0x81BB7BC
// IDA_NAME: _ZN15CRewardUserList11delete_markEj
// DEMANGLED: CRewardUserList::delete_mark(unsigned int)
int __cdecl CRewardUserList::delete_mark()
{
  _BYTE v1[4]; // [esp+18h] [ebp-10h] BYREF
  _BYTE v2[12]; // [esp+1Ch] [ebp-Ch] BYREF

  std::map<unsigned int,RewardUserData>::find(v1);
  std::map<unsigned int,RewardUserData>::end(v2);
  if ( !(unsigned __int8)std::_Rb_tree_iterator<std::pair<unsigned int const,RewardUserData>>::operator!=(v1, v2) )
    return 0;
  *(_BYTE *)(std::_Rb_tree_iterator<std::pair<unsigned int const,RewardUserData>>::operator->(v1) + 12) = 1;
  return 1;
}

// IDA_EA: 0x81BBFB6
// IDA_NAME: _ZN15CRewardUserListC2Ev
// DEMANGLED: CRewardUserList::CRewardUserList(void)
void __cdecl CRewardUserList::CRewardUserList(CRewardUserList *this)
{
  std::map<unsigned int,RewardUserData>::map(this);
  std::deque<unsigned int>::deque((char *)this + 24);
}

// IDA_EA: 0x81BBFFC
// IDA_NAME: _ZN15CRewardUserListD2Ev
// DEMANGLED: CRewardUserList::~CRewardUserList()
void __cdecl CRewardUserList::~CRewardUserList(CRewardUserList *this)
{
  std::deque<unsigned int>::~deque((char *)this + 24);
  std::map<unsigned int,RewardUserData>::~map((int)this);
}

// IDA_EA: 0x81BC042
// IDA_NAME: _ZN15CRewardUserList5clearEv
// DEMANGLED: CRewardUserList::clear(void)
int __cdecl CRewardUserList::clear(CRewardUserList *this)
{
  std::map<unsigned int,RewardUserData>::clear(this);
  return std::deque<unsigned int>::clear((char *)this + 24);
}

// IDA_EA: 0x81BC064
// IDA_NAME: _ZN15CRewardUserList14get_index_sizeEv
// DEMANGLED: CRewardUserList::get_index_size(void)
int __cdecl CRewardUserList::get_index_size(CRewardUserList *this)
{
  return std::deque<unsigned int>::size((char *)this + 24);
}
